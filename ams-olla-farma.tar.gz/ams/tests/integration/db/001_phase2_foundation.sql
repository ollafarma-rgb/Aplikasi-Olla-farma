-- Uji migrasi 001 + seed. Dijalankan oleh scripts/test-db.sh dengan
-- variabel psql :perm_count (jumlah izin di katalog TypeScript).
\set ON_ERROR_STOP on
SET client_min_messages = notice;

-- ---------- Seed ----------
SELECT amstest.ok((SELECT count(*) FROM permissions) = :perm_count, 'seed: semua izin katalog masuk');
SELECT amstest.ok((SELECT count(*) FROM roles WHERE is_system) = 5, 'seed: 5 peran sistem');
SELECT amstest.ok(EXISTS (
  SELECT 1 FROM role_permissions rp JOIN roles r ON r.id = rp.role_id JOIN permissions p ON p.id = rp.permission_id
  WHERE r.code = 'APOTEKER' AND p.code = 'rx.verify'), 'seed: apoteker boleh verifikasi resep');
SELECT amstest.ok(NOT EXISTS (
  SELECT 1 FROM role_permissions rp JOIN roles r ON r.id = rp.role_id JOIN permissions p ON p.id = rp.permission_id
  WHERE r.code = 'OWNER' AND p.code = 'rx.verify'), 'seed: owner TIDAK boleh verifikasi resep (kewenangan apoteker)');
SELECT amstest.ok(NOT EXISTS (
  SELECT 1 FROM role_permissions rp JOIN roles r ON r.id = rp.role_id JOIN permissions p ON p.id = rp.permission_id
  WHERE r.code = 'KASIR' AND p.code IN ('finance.view', 'reports.finance.view', 'dashboard.finance.view')),
  'seed: kasir tidak punya izin laporan keuangan (skenario 8)');
SELECT amstest.ok((SELECT value_json->>'mode' FROM pharmacy_settings WHERE key = 'tax') = 'NON_PKP', 'seed: mode pajak Non-PKP');
SELECT amstest.ok((SELECT count(*) FROM regulatory_rules) = 5, 'seed: 5 aturan regulasi awal');
SELECT amstest.ok((SELECT rule_json->'handover_roles' FROM regulatory_rules WHERE code = 'OWA_HANDOVER') = '["APOTEKER", "TTK"]'::jsonb,
  'seed: OWA boleh diserahkan apoteker dan TTK (keputusan #6)');
SELECT amstest.ok(EXISTS (
  SELECT 1 FROM role_permissions rp JOIN roles r ON r.id = rp.role_id JOIN permissions p ON p.id = rp.permission_id
  WHERE r.code = 'TTK' AND p.code = 'sales.owa.dispense'), 'seed: izin OWA untuk TTK');
SELECT amstest.ok((SELECT value_json->>'mode' FROM pharmacy_settings WHERE key = 'pricing.discounts') = 'PERIOD_RULES'
  AND (SELECT value_json->>'manual_discount_allowed' FROM pharmacy_settings WHERE key = 'pricing.discounts') = 'false',
  'seed: diskon hanya lewat aturan periode (keputusan #5)');
SELECT amstest.ok((SELECT (value_json->>'paper_width_mm')::int FROM pharmacy_settings WHERE key = 'receipt') = 80, 'seed: struk thermal 80 mm');
SELECT amstest.ok((SELECT value_json->>'default_credit_limit' FROM pharmacy_settings WHERE key = 'receivables') = '0',
  'seed: piutang aktif dengan plafon default 0');
SELECT amstest.ok((SELECT bool_and(legal_basis LIKE '%PERLU VERIFIKASI APJ%') FROM regulatory_rules), 'seed: aturan regulasi ditandai perlu verifikasi');
SELECT amstest.ok((SELECT must_change_password FROM users WHERE username = 'owner.test'), 'seed: owner wajib ganti sandi saat login pertama');

-- ---------- Users ----------
SELECT amstest.throws($$INSERT INTO users (id, username, password_hash, full_name, updated_at)
  VALUES (gen_random_uuid(), 'Kasir1', 'x', 'X', now())$$, 'users_username_lower_chk', 'username huruf besar ditolak');
SELECT amstest.throws($$INSERT INTO users (id, username, password_hash, full_name, updated_at)
  VALUES (gen_random_uuid(), 'ka sir', 'x', 'X', now())$$, 'users_username_lower_chk', 'username berspasi ditolak');
SELECT amstest.throws($$INSERT INTO users (id, username, password_hash, full_name, updated_at)
  VALUES (gen_random_uuid(), 'owner.test', 'x', 'X', now())$$, 'users_username_key', 'username duplikat ditolak');

INSERT INTO users (id, username, password_hash, full_name, updated_at) VALUES
  ('00000000-0000-7000-8000-000000000001', 'kasir.a', 'x', 'Kasir A', now()),
  ('00000000-0000-7000-8000-000000000002', 'apt.b', 'x', 'Apoteker B', now());

-- ---------- Sessions ----------
SELECT amstest.throws($$INSERT INTO user_sessions (id, user_id, session_version, expires_at)
  VALUES ('BUKAN-HEX', '00000000-0000-7000-8000-000000000001', 1, now() + interval '1 hour')$$,
  'user_sessions_id_hex_chk', 'id sesi wajib hash hex 64 karakter');
INSERT INTO user_sessions (id, user_id, session_version, expires_at)
  VALUES (repeat('a', 64), '00000000-0000-7000-8000-000000000001', 1, now() + interval '12 hours');
SELECT amstest.throws($$DELETE FROM users WHERE id = '00000000-0000-7000-8000-000000000001'$$,
  'foreign key', 'user dengan riwayat sesi tidak bisa dihapus (RESTRICT)');

-- ---------- Approvals ----------
SELECT amstest.throws($$INSERT INTO approvals (id, action_code, requested_by, approved_by, ref_type, ref_id, reason)
  VALUES (gen_random_uuid(), 'sales.cancel', '00000000-0000-7000-8000-000000000001', '00000000-0000-7000-8000-000000000001',
  'sale', gen_random_uuid(), 'salah input')$$, 'approvals_not_self_chk', 'menyetujui permintaan sendiri ditolak');
SELECT amstest.throws($$INSERT INTO approvals (id, action_code, requested_by, approved_by, ref_type, ref_id, reason)
  VALUES (gen_random_uuid(), 'sales.cancel', '00000000-0000-7000-8000-000000000001', '00000000-0000-7000-8000-000000000002',
  'sale', gen_random_uuid(), '   ')$$, 'approvals_reason_chk', 'persetujuan tanpa alasan ditolak');
INSERT INTO approvals (id, action_code, requested_by, approved_by, ref_type, ref_id, reason)
  VALUES (gen_random_uuid(), 'sales.cancel', '00000000-0000-7000-8000-000000000001', '00000000-0000-7000-8000-000000000002',
  'sale', gen_random_uuid(), 'salah input jumlah');
SELECT amstest.ok(true, 'persetujuan oleh pengguna lain diterima');

-- ---------- Audit log ----------
INSERT INTO audit_logs (user_id, action, entity, entity_id, after_json, hash)
  VALUES ('00000000-0000-7000-8000-000000000001', 'auth.login.success', 'user', 'a', '{"x":1}', 'PALSU');
INSERT INTO audit_logs (user_id, action, entity, entity_id) VALUES (NULL, 'auth.login.failed', 'user', NULL);
INSERT INTO audit_logs (user_id, action, entity, entity_id, before_json, after_json)
  VALUES ('00000000-0000-7000-8000-000000000002', 'settings.changed', 'pharmacy_settings', 'tax', '{"a":1}', '{"a":2}');

SELECT amstest.ok((SELECT bool_and(hash ~ '^[0-9a-f]{64}$') FROM audit_logs), 'audit: hash SHA-256 diisi trigger');
SELECT amstest.ok((SELECT hash FROM audit_logs ORDER BY id LIMIT 1) <> 'PALSU', 'audit: hash kiriman aplikasi diabaikan');
SELECT amstest.ok((SELECT prev_hash IS NULL FROM audit_logs ORDER BY id LIMIT 1), 'audit: baris pertama adalah genesis');
SELECT amstest.ok(NOT EXISTS (
  SELECT 1 FROM (SELECT prev_hash, lag(hash) OVER (ORDER BY id) AS expected FROM audit_logs) t
  WHERE t.expected IS NOT NULL AND t.prev_hash IS DISTINCT FROM t.expected), 'audit: setiap baris menunjuk hash baris sebelumnya');
SELECT amstest.ok(ams_audit_verify_chain() IS NULL, 'audit: verifikasi rantai utuh');
SELECT amstest.throws($$UPDATE audit_logs SET action = 'diubah'$$, 'AMS_APPEND_ONLY', 'audit: UPDATE ditolak');
SELECT amstest.throws($$DELETE FROM audit_logs$$, 'AMS_APPEND_ONLY', 'audit: DELETE ditolak');
SELECT amstest.throws($$TRUNCATE audit_logs$$, 'AMS_APPEND_ONLY', 'audit: TRUNCATE ditolak');

-- Simulasi pemalsuan oleh superuser yang mematikan trigger: harus terdeteksi.
DO $$
DECLARE v_broken bigint; v_target bigint;
BEGIN
  -- id bisa bercelah (lihat trigger ams_audit_chain), jadi ambil baris kedua.
  SELECT id INTO v_target FROM audit_logs ORDER BY id OFFSET 1 LIMIT 1;
  ALTER TABLE audit_logs DISABLE TRIGGER audit_logs_append_only_trg;
  UPDATE audit_logs SET after_json = '{"a":999}' WHERE id = v_target;
  ALTER TABLE audit_logs ENABLE TRIGGER audit_logs_append_only_trg;
  v_broken := ams_audit_verify_chain();
  PERFORM amstest.ok(v_broken = v_target, 'audit: pemalsuan isi terdeteksi oleh verifikasi rantai');
  RAISE EXCEPTION 'rollback-simulasi';
EXCEPTION WHEN OTHERS THEN
  IF SQLERRM <> 'rollback-simulasi' THEN RAISE; END IF;
END;
$$;
SELECT amstest.ok(ams_audit_verify_chain() IS NULL, 'audit: rantai kembali utuh setelah simulasi di-rollback');

-- ---------- Penomoran ----------
SELECT amstest.ok(ams_next_number('PJ', '2611') = 1, 'nomor: urutan pertama = 1');
SELECT amstest.ok(ams_next_number('PJ', '2611') = 2, 'nomor: urutan kedua = 2');
SELECT amstest.ok(ams_next_number('PJ', '2612') = 1, 'nomor: periode baru mulai dari 1');
SELECT amstest.ok(ams_next_number('RX', '2611') = 1, 'nomor: jenis dokumen lain terpisah');

-- ---------- Rate limit ----------
SELECT amstest.ok((SELECT bool_and(ams_rate_limit_hit('login:1.2.3.4:kasir.a', 60, 5)) FROM generate_series(1, 5)),
  'rate limit: 5 percobaan pertama diizinkan');
SELECT amstest.ok(NOT ams_rate_limit_hit('login:1.2.3.4:kasir.a', 60, 5), 'rate limit: percobaan ke-6 ditolak');
UPDATE rate_limits SET window_start = now() - interval '61 seconds' WHERE key = 'login:1.2.3.4:kasir.a';
SELECT amstest.ok(ams_rate_limit_hit('login:1.2.3.4:kasir.a', 60, 5), 'rate limit: jendela baru diizinkan lagi');

-- ---------- Peran sistem ----------
SELECT amstest.throws($$DELETE FROM roles WHERE code = 'KASIR'$$, 'AMS_SYSTEM_ROLE|foreign key', 'peran sistem tidak bisa dihapus');

-- ---------- Aturan regulasi ----------
SELECT amstest.throws($$INSERT INTO regulatory_rules (id, code, description, rule_json, legal_basis, effective_from, effective_to)
  VALUES (gen_random_uuid(), 'X', 'x', '{}', 'x', '2026-12-01', '2026-11-01')$$, 'regulatory_rules_period_chk',
  'aturan regulasi dengan periode terbalik ditolak');
