-- Helper uji database (HANYA untuk database tes, tidak masuk migrasi).
CREATE SCHEMA IF NOT EXISTS amstest;

CREATE OR REPLACE FUNCTION amstest.ok(p_cond boolean, p_name text) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  IF p_cond IS NOT TRUE THEN
    RAISE EXCEPTION 'GAGAL: %', p_name;
  END IF;
  RAISE NOTICE 'LULUS: %', p_name;
END;
$$;

-- Pastikan SQL gagal dan pesan error memuat pola tertentu.
CREATE OR REPLACE FUNCTION amstest.throws(p_sql text, p_pattern text, p_name text) RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  BEGIN
    EXECUTE p_sql;
  EXCEPTION WHEN OTHERS THEN
    IF SQLERRM ~* p_pattern THEN
      RAISE NOTICE 'LULUS: % (ditolak: %)', p_name, SQLERRM;
      RETURN;
    END IF;
    RAISE EXCEPTION 'GAGAL: % (error tak terduga: %)', p_name, SQLERRM;
  END;
  RAISE EXCEPTION 'GAGAL: % (SQL seharusnya ditolak tetapi berhasil)', p_name;
END;
$$;
