-- Uji Fase 5 (pengadaan). Dijalankan setelah 004 oleh scripts/test-db.sh (superuser).
\set ON_ERROR_STOP on

-- Data uji tersendiri -----------------------------------------------------------
INSERT INTO users (id, username, password_hash, full_name, updated_at)
  VALUES ('00000000-0000-7000-8000-00000000a501', 'gudang.p5', 'x', 'Staf Gudang Uji P5', now());
INSERT INTO users (id, username, password_hash, full_name, updated_at)
  VALUES ('00000000-0000-7000-8000-00000000a502', 'apt.p5', 'x', 'Apoteker Uji P5', now());
SELECT set_config('ams.user_id', '00000000-0000-7000-8000-00000000a501', false);

INSERT INTO suppliers (id, code, name, updated_at)
  VALUES ('00000000-0000-7000-8000-00000000e501', 'SUP-P5A', 'PBF Uji Fase 5', now());

INSERT INTO medicines (id, sku, name, generic_name, product_type, drug_class, registration_no,
  base_unit_id, purchase_unit_id, sales_unit_id, selling_price, min_stock, requires_prescription, updated_at)
SELECT '00000000-0000-7000-8000-00000000d501', 'OBT-00P5A', 'Paracetamol 500 mg', 'Parasetamol',
  'PRESCRIPTION_DRUG', 'KERAS', 'DKL9999000222', t.id, b.id, t.id, 1000, 50, true, now()
FROM units t, units b WHERE t.code = 'TAB' AND b.code = 'BOX';

-- Surat Pesanan: validasi CHECK ---------------------------------------------------
INSERT INTO purchase_orders (id, po_no, supplier_id, created_by, updated_at)
  VALUES ('00000000-0000-7000-8000-00000000f501', 'SP-2611-0001', '00000000-0000-7000-8000-00000000e501',
    '00000000-0000-7000-8000-00000000a501', now());

SELECT amstest.throws(
  $$INSERT INTO purchase_order_items (id, po_id, medicine_id, unit_id, qty_ordered, price)
    SELECT gen_random_uuid(), '00000000-0000-7000-8000-00000000f501', '00000000-0000-7000-8000-00000000d501', id, 0, 50000
    FROM units WHERE code = 'BOX'$$,
  'po_items_qty_ordered_chk', 'SP: qty_ordered harus > 0 ditolak');

SELECT amstest.throws(
  $$INSERT INTO purchase_order_items (id, po_id, medicine_id, unit_id, qty_ordered, price, discount_pct)
    SELECT gen_random_uuid(), '00000000-0000-7000-8000-00000000f501', '00000000-0000-7000-8000-00000000d501', id, 5, 50000, 150
    FROM units WHERE code = 'BOX'$$,
  'po_items_discount_chk', 'SP: diskon di atas 100% ditolak');

INSERT INTO purchase_order_items (id, po_id, medicine_id, unit_id, qty_ordered, price)
  SELECT '00000000-0000-7000-8000-0000000011f1', '00000000-0000-7000-8000-00000000f501', '00000000-0000-7000-8000-00000000d501', id, 5, 50000
  FROM units WHERE code = 'BOX';

SELECT amstest.throws(
  $$INSERT INTO purchase_orders (id, po_no, supplier_id, created_by, updated_at)
    VALUES (gen_random_uuid(), 'SP-2611-0001', '00000000-0000-7000-8000-00000000e501',
      '00000000-0000-7000-8000-00000000a501', now())$$,
  'purchase_orders_po_no_key', 'SP: nomor SP duplikat ditolak');

SELECT amstest.ok(
  (SELECT status FROM purchase_orders WHERE id = '00000000-0000-7000-8000-00000000f501') = 'DRAFT',
  'SP: status awal DRAFT');

-- Penerimaan barang membuat batch lewat ams_apply_stock_movement (RECEIPT) -------
INSERT INTO goods_receipts (id, gr_no, po_id, supplier_id, received_at, checked_by)
  VALUES ('00000000-0000-7000-8000-00000000f601', 'GR-2611-0001', '00000000-0000-7000-8000-00000000f501',
    '00000000-0000-7000-8000-00000000e501', now(), '00000000-0000-7000-8000-00000000a501');

SELECT amstest.throws(
  $$INSERT INTO goods_receipt_items (id, gr_id, medicine_id, unit_id, qty, qty_base, batch_no, expiry_date, unit_cost)
    SELECT gen_random_uuid(), '00000000-0000-7000-8000-00000000f601', '00000000-0000-7000-8000-00000000d501', id, 0, 1, 'B-P5-X', DATE '2027-06-30', 450
    FROM units WHERE code = 'TAB'$$,
  'gr_items_qty_chk', 'Penerimaan: qty harus > 0 ditolak');

INSERT INTO goods_receipt_items (id, gr_id, po_item_id, medicine_id, unit_id, qty, qty_base, batch_no, expiry_date, unit_cost)
  VALUES ('00000000-0000-7000-8000-0000000012f1', '00000000-0000-7000-8000-00000000f601', '00000000-0000-7000-8000-0000000011f1',
    '00000000-0000-7000-8000-00000000d501', (SELECT id FROM units WHERE code='BOX'), 5, 500, 'B-P5-1', DATE '2027-06-30', 450);

-- Posting: buat batch, tautkan goods_receipt_item_id, catat kartu stok RECEIPT ---
INSERT INTO medicine_batches (id, medicine_id, batch_no, expiry_date, source, goods_receipt_item_id, unit_cost, qty_received, updated_at)
  VALUES ('00000000-0000-7000-8000-00000000b501', '00000000-0000-7000-8000-00000000d501', 'B-P5-1', DATE '2027-06-30',
    'RECEIPT', '00000000-0000-7000-8000-0000000012f1', 450, 500, now());

SELECT amstest.ok(
  (SELECT 1 FROM pg_enum e JOIN pg_type t ON e.enumtypid = t.oid WHERE t.typname = 'MovementType' AND e.enumlabel = 'RECEIPT') IS NOT NULL,
  'MovementType: RECEIPT tersedia');

SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b501','RECEIPT',NULL,'SALEABLE',
  500,450,'goods_receipt','00000000-0000-7000-8000-00000000f601','GR-2611-0001','Penerimaan barang',NULL,NULL);
SELECT amstest.ok(
  (SELECT qty_saleable FROM medicine_batches WHERE id='00000000-0000-7000-8000-00000000b501') = 500,
  'penerimaan: RECEIPT menambah stok saleable batch baru');
SELECT amstest.ok(
  (SELECT count(*) FROM stock_movements WHERE batch_id='00000000-0000-7000-8000-00000000b501' AND movement_type='RECEIPT') = 1,
  'penerimaan: satu baris kartu stok RECEIPT tercatat');

UPDATE purchase_order_items SET qty_received_base = 500 WHERE id = '00000000-0000-7000-8000-0000000011f1';
UPDATE goods_receipts SET status = 'POSTED', posted_by = '00000000-0000-7000-8000-00000000a502', posted_at = now()
  WHERE id = '00000000-0000-7000-8000-00000000f601';
UPDATE purchase_orders SET status = 'RECEIVED' WHERE id = '00000000-0000-7000-8000-00000000f501';

-- Satu item penerimaan hanya boleh menautkan satu batch (unique) -----------------
SELECT amstest.throws(
  $$INSERT INTO medicine_batches (id, medicine_id, batch_no, expiry_date, goods_receipt_item_id, unit_cost, qty_received, updated_at)
    VALUES (gen_random_uuid(), '00000000-0000-7000-8000-00000000d501', 'B-P5-DUP', DATE '2027-06-30',
      '00000000-0000-7000-8000-0000000012f1', 450, 1, now())$$,
  'medicine_batches_goods_receipt_item_id_key', 'penerimaan: satu item hanya tertaut satu batch');

-- Retur pembelian: keluar dari bucket, tidak boleh melebihi stok -----------------
INSERT INTO purchase_returns (id, return_no, supplier_id, created_by)
  VALUES ('00000000-0000-7000-8000-00000000f701', 'RB-2611-0001', '00000000-0000-7000-8000-00000000e501',
    '00000000-0000-7000-8000-00000000a501');

SELECT amstest.throws(
  $$INSERT INTO purchase_return_items (id, return_id, batch_id, bucket, qty, unit_cost, reason)
    VALUES (gen_random_uuid(), '00000000-0000-7000-8000-00000000f701', '00000000-0000-7000-8000-00000000b501', 'SALEABLE', 0, 450, 'Rusak kemasan')$$,
  'return_items_qty_chk', 'retur: qty harus > 0 ditolak');

SELECT amstest.throws(
  $$INSERT INTO purchase_return_items (id, return_id, batch_id, bucket, qty, unit_cost, reason)
    VALUES (gen_random_uuid(), '00000000-0000-7000-8000-00000000f701', '00000000-0000-7000-8000-00000000b501', 'SALEABLE', 10, 450, '')$$,
  'return_items_reason_chk', 'retur: alasan wajib diisi ditolak');

INSERT INTO purchase_return_items (id, return_id, batch_id, bucket, qty, unit_cost, reason)
  VALUES ('00000000-0000-7000-8000-0000000013f1', '00000000-0000-7000-8000-00000000f701', '00000000-0000-7000-8000-00000000b501',
    'SALEABLE', 20, 450, 'Kemasan rusak saat penerimaan');

-- Posting retur lewat approval (maker-checker dicek di service layer) -----------
INSERT INTO approvals (id, action_code, requested_by, approved_by, ref_type, ref_id, reason)
  VALUES ('00000000-0000-7000-8000-0000000014f1', 'procurement.return.approve', '00000000-0000-7000-8000-00000000a501',
    '00000000-0000-7000-8000-00000000a502', 'purchase_return', '00000000-0000-7000-8000-00000000f701', 'Kemasan rusak saat penerimaan');

SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b501','PURCHASE_RETURN','SALEABLE',NULL,
  20,450,'purchase_return','00000000-0000-7000-8000-00000000f701','RB-2611-0001','Kemasan rusak saat penerimaan',NULL,
  '00000000-0000-7000-8000-0000000014f1');
UPDATE purchase_returns SET status = 'POSTED', approval_id = '00000000-0000-7000-8000-0000000014f1', posted_at = now()
  WHERE id = '00000000-0000-7000-8000-00000000f701';

SELECT amstest.ok(
  (SELECT qty_saleable FROM medicine_batches WHERE id='00000000-0000-7000-8000-00000000b501') = 480,
  'retur: PURCHASE_RETURN mengurangi stok saleable batch');
SELECT amstest.ok(
  (SELECT approval_id FROM stock_movements WHERE ref_no='RB-2611-0001') = '00000000-0000-7000-8000-0000000014f1',
  'retur: pergerakan tertaut ke approval');

SELECT amstest.throws(
  $$SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b501','PURCHASE_RETURN','SALEABLE',NULL,
    1000,450,'purchase_return',gen_random_uuid(),'RB-X','Retur berlebih',NULL,NULL)$$,
  'AMS_STOCK_NEGATIVE', 'retur: melebihi stok saleable ditolak');

-- Persetujuan retur oleh pembuat sendiri tetap ditolak di tingkat aplikasi; ------
-- di DB hanya dicegah constraint approvals_not_self_chk bila requested_by = approved_by.
SELECT amstest.throws(
  $$INSERT INTO approvals (id, action_code, requested_by, approved_by, ref_type, ref_id, reason)
    VALUES (gen_random_uuid(), 'procurement.return.approve', '00000000-0000-7000-8000-00000000a501',
      '00000000-0000-7000-8000-00000000a501', 'purchase_return', '00000000-0000-7000-8000-00000000f701', 'Coba setujui sendiri')$$,
  'approvals_not_self_chk', 'retur: menyetujui retur sendiri ditolak (approvals_not_self_chk)');

-- Pemasok tidak bisa dihapus (append-only, lihat Fase 3) -----------------------
SELECT amstest.throws(
  $$DELETE FROM suppliers WHERE id = '00000000-0000-7000-8000-00000000e501'$$,
  'AMS_APPEND_ONLY', 'pemasok yang dipakai SP/GR/retur tetap tidak bisa dihapus');

-- SP tidak bisa dihapus setelah ada item (RESTRICT) ------------------------------
SELECT amstest.throws(
  $$DELETE FROM purchase_orders WHERE id = '00000000-0000-7000-8000-00000000f501'$$,
  'violates foreign key constraint', 'SP yang sudah punya item/penerimaan tidak bisa dihapus');
