-- Uji Fase 4 (persediaan). Dijalankan setelah 003 oleh scripts/test-db.sh (superuser).
\set ON_ERROR_STOP on

-- Data uji tersendiri -----------------------------------------------------------
INSERT INTO users (id, username, password_hash, full_name, updated_at)
  VALUES ('00000000-0000-7000-8000-00000000a401', 'gudang.uji', 'x', 'Staf Gudang Uji', now());
SELECT set_config('ams.user_id', '00000000-0000-7000-8000-00000000a401', false);

INSERT INTO medicines (id, sku, name, generic_name, product_type, drug_class, registration_no,
  base_unit_id, purchase_unit_id, sales_unit_id, selling_price, min_stock, requires_prescription, updated_at)
SELECT '00000000-0000-7000-8000-00000000d401', 'OBT-00P4A', 'Amoxicillin 500 mg', 'Amoksisilin',
  'PRESCRIPTION_DRUG', 'KERAS', 'DKL9999000111', id, id, id, 2500, 50, true, now()
FROM units WHERE code = 'TAB';

INSERT INTO medicine_batches (id, medicine_id, batch_no, expiry_date, unit_cost, qty_received, updated_at)
VALUES
  ('00000000-0000-7000-8000-00000000b401', '00000000-0000-7000-8000-00000000d401', 'B-AWAL-1', DATE '2027-06-30', 1800, 0, now()),
  ('00000000-0000-7000-8000-00000000b402', '00000000-0000-7000-8000-00000000d401', 'B-AWAL-2', DATE '2026-12-31', 1750, 0, now());

-- Saldo awal: OPENING menambah bucket SALEABLE dan mencatat kartu stok ----------
SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b401','OPENING',NULL,'SALEABLE',
  100,1800,'OPENING','00000000-0000-7000-8000-00000000b401','SALDO-0001','Saldo awal',NULL,NULL);
SELECT amstest.ok(
  (SELECT qty_saleable FROM medicine_batches WHERE id='00000000-0000-7000-8000-00000000b401') = 100,
  'saldo awal: OPENING menambah stok saleable batch');
SELECT amstest.ok(
  (SELECT count(*) FROM stock_movements WHERE batch_id='00000000-0000-7000-8000-00000000b401' AND movement_type='OPENING') = 1,
  'saldo awal: satu baris kartu stok tercatat');
SELECT amstest.ok(
  (SELECT user_id FROM stock_movements WHERE ref_no='SALDO-0001') = '00000000-0000-7000-8000-00000000a401',
  'kartu stok: user diisi dari ams.user_id');

-- Karantina: pindah SALEABLE -> QUARANTINE, total kekal -------------------------
SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b401','QUARANTINE_MOVE','SALEABLE','QUARANTINE',
  30,1800,'QUARANTINE','00000000-0000-7000-8000-00000000b401','KRT-0001',NULL,NULL,NULL);
SELECT amstest.ok(
  (SELECT qty_saleable=70 AND qty_quarantine=30 FROM medicine_batches WHERE id='00000000-0000-7000-8000-00000000b401'),
  'karantina: saleable berkurang, quarantine bertambah, total kekal');

-- Stok tidak boleh negatif ------------------------------------------------------
SELECT amstest.throws(
  $$SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b401','ADJUSTMENT','SALEABLE',NULL,
    1000,1800,'ADJUSTMENT',gen_random_uuid(),'ADJ-X',NULL,NULL,NULL)$$,
  'AMS_STOCK_NEGATIVE', 'pergerakan melebihi stok bucket ditolak');

-- Butuh identitas pengguna ------------------------------------------------------
SELECT set_config('ams.user_id', '', false);
SELECT amstest.throws(
  $$SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b402','OPENING',NULL,'SALEABLE',
    10,1750,'OPENING',gen_random_uuid(),'SALDO-X',NULL,NULL,NULL)$$,
  'AMS_NO_ACTOR', 'pergerakan tanpa ams.user_id ditolak');
SELECT set_config('ams.user_id', '00000000-0000-7000-8000-00000000a401', false);

-- Validasi jumlah dan bucket ----------------------------------------------------
SELECT amstest.throws(
  $$SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b402','OPENING',NULL,'SALEABLE',
    0,1750,'OPENING',gen_random_uuid(),'SALDO-0',NULL,NULL,NULL)$$,
  'AMS_STOCK_QTY', 'jumlah nol ditolak');
SELECT amstest.throws(
  $$SELECT ams_apply_stock_movement('00000000-0000-7000-8000-00000000b402','OPENING',NULL,NULL,
    5,1750,'OPENING',gen_random_uuid(),'SALDO-NB',NULL,NULL,NULL)$$,
  'AMS_STOCK_BUCKET', 'pergerakan tanpa asal dan tujuan ditolak');
SELECT amstest.throws(
  $$SELECT ams_apply_stock_movement('00000000-0000-7000-8000-ffffffffffff','OPENING',NULL,'SALEABLE',
    5,1750,'OPENING',gen_random_uuid(),'SALDO-NF',NULL,NULL,NULL)$$,
  'AMS_BATCH_NOT_FOUND', 'batch tidak ada ditolak');

-- Kartu stok append-only --------------------------------------------------------
SELECT amstest.throws(
  $$UPDATE stock_movements SET qty = qty + 1 WHERE ref_no = 'SALDO-0001'$$,
  'AMS_APPEND_ONLY', 'kartu stok tidak bisa di-UPDATE');
SELECT amstest.throws(
  $$DELETE FROM stock_movements WHERE ref_no = 'SALDO-0001'$$,
  'AMS_APPEND_ONLY', 'kartu stok tidak bisa di-DELETE');

-- Batch tidak bisa dihapus ------------------------------------------------------
SELECT amstest.throws(
  $$DELETE FROM medicine_batches WHERE id = '00000000-0000-7000-8000-00000000b402'$$,
  'AMS_APPEND_ONLY', 'batch tidak bisa dihapus');

-- Batch unik (medicine, batch_no, expiry) --------------------------------------
SELECT amstest.throws(
  $$INSERT INTO medicine_batches (id, medicine_id, batch_no, expiry_date, unit_cost, qty_received, updated_at)
    VALUES (gen_random_uuid(), '00000000-0000-7000-8000-00000000d401', 'B-AWAL-1', DATE '2027-06-30', 1800, 0, now())$$,
  'medicine_batches_medicine_id_batch_no_expiry_date_key', 'batch duplikat (obat+no+ED) ditolak');

-- Penyesuaian: delta tidak boleh nol -------------------------------------------
INSERT INTO stock_adjustments (id, adj_no, reason_code, created_by)
  VALUES ('00000000-0000-7000-8000-00000000c401', 'ADJ-0001', 'KOREKSI', '00000000-0000-7000-8000-00000000a401');
SELECT amstest.throws(
  $$INSERT INTO stock_adjustment_items (id, adjustment_id, batch_id, bucket, qty_delta)
    VALUES (gen_random_uuid(), '00000000-0000-7000-8000-00000000c401', '00000000-0000-7000-8000-00000000b401', 'SALEABLE', 0)$$,
  'sai_delta_chk', 'item penyesuaian dengan delta nol ditolak');

-- FEFO: batch ED paling dekat lebih dulu ---------------------------------------
SELECT amstest.ok(
  (SELECT batch_no FROM medicine_batches
    WHERE medicine_id='00000000-0000-7000-8000-00000000d401' AND qty_saleable + qty_quarantine + qty_damaged >= 0
    ORDER BY expiry_date, received_at LIMIT 1) = 'B-AWAL-2',
  'FEFO: batch kedaluwarsa terdekat diurutkan pertama');
