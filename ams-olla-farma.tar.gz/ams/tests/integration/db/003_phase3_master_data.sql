-- Uji migrasi 002 (master data). Dijalankan setelah 001 oleh scripts/test-db.sh.
\set ON_ERROR_STOP on

SELECT amstest.ok((SELECT count(*) FROM units) = 16, 'seed: 16 satuan standar');

INSERT INTO users (id, username, password_hash, full_name, updated_at)
  VALUES ('00000000-0000-7000-8000-0000000000a1', 'apt.harga', 'x', 'Apoteker Harga', now());
INSERT INTO categories (id, name) VALUES ('00000000-0000-7000-8000-0000000000c1', 'Analgesik');

-- Helper: sisipkan obat valid dengan pengguna aktif di sesi.
SELECT set_config('ams.user_id', '00000000-0000-7000-8000-0000000000a1', false);

INSERT INTO medicines (id, sku, barcode, name, generic_name, product_type, drug_class, registration_no,
  base_unit_id, purchase_unit_id, sales_unit_id, selling_price, default_purchase_price, category_id, updated_at)
SELECT '00000000-0000-7000-8000-0000000000d1', 'OBT-000001', '8991234567890', 'Paracetamol 500 mg', 'Parasetamol',
  'OTC', 'BEBAS', 'DBL1234567890A1', b.id, x.id, b.id, 500, 40000, '00000000-0000-7000-8000-0000000000c1', now()
FROM units b, units x WHERE b.code = 'TAB' AND x.code = 'BOX';

SELECT amstest.ok((SELECT count(*) FROM medicine_price_history WHERE medicine_id = '00000000-0000-7000-8000-0000000000d1') = 2,
  'harga: harga awal jual dan beli tercatat saat obat dibuat');

-- ---------- Golongan regulasi ----------
SELECT amstest.throws($$INSERT INTO medicines (id, sku, name, product_type, drug_class, registration_no, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'X1', 'Kodein', 'PRESCRIPTION_DRUG', 'NARKOTIKA', 'DKL1', id, id, id, 1000, now() FROM units WHERE code='TAB'$$,
  'medicines_narc_psy_rx_chk', 'narkotika tanpa tanda wajib resep ditolak');
SELECT amstest.throws($$INSERT INTO medicines (id, sku, name, product_type, drug_class, registration_no, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'X2', 'Amoksisilin', 'PRESCRIPTION_DRUG', 'KERAS', 'DKL2', id, id, id, 1000, now() FROM units WHERE code='TAB'$$,
  'medicines_keras_rx_chk', 'obat keras non-OWA tanpa wajib resep ditolak');
SELECT amstest.throws($$INSERT INTO medicines (id, sku, name, product_type, drug_class, registration_no, is_owa, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'X3', 'Vitamin C', 'OTC', 'BEBAS', 'DBL3', true, id, id, id, 1000, now() FROM units WHERE code='TAB'$$,
  'medicines_owa_chk|medicines_type_class_chk', 'OWA pada obat bebas ditolak');
SELECT amstest.throws($$INSERT INTO medicines (id, sku, name, product_type, drug_class, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'X4', 'Antasida', 'OTC', 'BEBAS', id, id, id, 1000, now() FROM units WHERE code='TAB'$$,
  'medicines_nie_chk', 'obat tanpa nomor izin edar ditolak');
SELECT amstest.throws($$INSERT INTO medicines (id, sku, name, product_type, drug_class, registration_no, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'X5', 'Ibuprofen', 'OTC', 'KERAS', 'DKL5', id, id, id, 1000, now() FROM units WHERE code='TAB'$$,
  'medicines_type_class_chk|medicines_keras_rx_chk', 'jenis OTC dengan golongan keras ditolak');
INSERT INTO medicines (id, sku, name, product_type, drug_class, registration_no, is_owa, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'OWA-1', 'Ranitidin 150 mg', 'PRESCRIPTION_DRUG', 'KERAS', 'DKL6', true, id, id, id, 1500, now() FROM units WHERE code='TAB';
SELECT amstest.ok(true, 'obat keras bertanda OWA diterima tanpa wajib resep');
INSERT INTO medicines (id, sku, name, product_type, drug_class, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'ALK-1', 'Kasa steril', 'MEDICAL_SUPPLY', 'NON_OBAT', id, id, id, 2000, now() FROM units WHERE code='PCS';
SELECT amstest.ok(true, 'BMHP non-obat diterima tanpa NIE');

-- ---------- SKU dan barcode ----------
SELECT amstest.throws($$INSERT INTO medicines (id, sku, name, product_type, drug_class, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'OBT-000001', 'Lain', 'OTHER', 'NON_OBAT', id, id, id, 1, now() FROM units WHERE code='PCS'$$,
  'medicines_sku_key', 'SKU duplikat ditolak');
SELECT amstest.throws($$INSERT INTO medicines (id, sku, barcode, name, product_type, drug_class, base_unit_id, purchase_unit_id, sales_unit_id, selling_price, updated_at)
  SELECT gen_random_uuid(), 'B1', '8991234567890', 'Lain', 'OTHER', 'NON_OBAT', id, id, id, 1, now() FROM units WHERE code='PCS'$$,
  'medicines_barcode_key', 'barcode duplikat antar obat ditolak');
INSERT INTO medicine_unit_conversions (id, medicine_id, unit_id, factor_to_base, barcode, selling_price)
  SELECT gen_random_uuid(), '00000000-0000-7000-8000-0000000000d1', id, 10, '8991234567891', 4500 FROM units WHERE code = 'STRIP';
INSERT INTO medicine_unit_conversions (id, medicine_id, unit_id, factor_to_base, barcode)
  SELECT gen_random_uuid(), '00000000-0000-7000-8000-0000000000d1', id, 100, '8991234567892' FROM units WHERE code = 'BOX';
SELECT amstest.ok(true, 'konversi strip (10 tab) dan box (100 tab) diterima');
SELECT amstest.throws($$INSERT INTO medicine_unit_conversions (id, medicine_id, unit_id, factor_to_base, barcode)
  SELECT gen_random_uuid(), m.id, u.id, 12, '8991234567890' FROM medicines m, units u WHERE m.sku = 'OWA-1' AND u.code = 'STRIP'$$,
  'AMS_BARCODE_DUPLICATE', 'barcode konversi yang sama dengan barcode obat lain ditolak');
SELECT amstest.throws($$UPDATE medicines SET barcode = '8991234567891' WHERE sku = 'OWA-1'$$,
  'AMS_BARCODE_DUPLICATE', 'barcode obat yang sama dengan barcode konversi ditolak');
SELECT amstest.throws($$INSERT INTO medicine_unit_conversions (id, medicine_id, unit_id, factor_to_base)
  SELECT gen_random_uuid(), '00000000-0000-7000-8000-0000000000d1', id, 1 FROM units WHERE code = 'BLISTER'$$,
  'muc_factor_chk', 'faktor konversi 1 ditolak (itu satuan dasar)');
SELECT amstest.throws($$INSERT INTO medicine_unit_conversions (id, medicine_id, unit_id, factor_to_base)
  SELECT gen_random_uuid(), '00000000-0000-7000-8000-0000000000d1', id, 5 FROM units WHERE code = 'TAB'$$,
  'AMS_CONVERSION_BASE_UNIT', 'satuan dasar tidak boleh dijadikan konversi');

-- ---------- Riwayat harga ----------
SELECT set_config('ams.price_reason', 'Penyesuaian harga PBF', false);
UPDATE medicines SET selling_price = 600 WHERE id = '00000000-0000-7000-8000-0000000000d1';
SELECT amstest.ok(EXISTS (SELECT 1 FROM medicine_price_history WHERE medicine_id = '00000000-0000-7000-8000-0000000000d1'
  AND price_type = 'SELLING' AND old_price = 500 AND new_price = 600 AND reason = 'Penyesuaian harga PBF'
  AND changed_by = '00000000-0000-7000-8000-0000000000a1'), 'harga: perubahan harga jual tercatat lengkap dengan pengguna dan alasan');
UPDATE medicines SET name = 'Paracetamol 500 mg Tablet' WHERE id = '00000000-0000-7000-8000-0000000000d1';
SELECT amstest.ok((SELECT count(*) FROM medicine_price_history WHERE medicine_id = '00000000-0000-7000-8000-0000000000d1' AND price_type = 'SELLING') = 2,
  'harga: perubahan non-harga tidak menambah riwayat');
UPDATE medicine_unit_conversions SET selling_price = 4800 WHERE barcode = '8991234567891';
SELECT amstest.ok(EXISTS (SELECT 1 FROM medicine_price_history WHERE price_type = 'SELLING_UNIT' AND old_price = 4500 AND new_price = 4800),
  'harga: perubahan harga per strip tercatat');
SELECT set_config('ams.user_id', '', false);
SELECT amstest.throws($$UPDATE medicines SET selling_price = 700 WHERE id = '00000000-0000-7000-8000-0000000000d1'$$,
  'AMS_NO_ACTOR', 'harga: perubahan harga tanpa identitas pengguna ditolak');
SELECT amstest.throws($$UPDATE medicine_price_history SET new_price = 1$$, 'AMS_APPEND_ONLY', 'harga: riwayat tidak bisa diubah');
SELECT amstest.throws($$DELETE FROM medicine_price_history$$, 'AMS_APPEND_ONLY', 'harga: riwayat tidak bisa dihapus');

-- ---------- Larangan hapus ----------
SELECT amstest.throws($$DELETE FROM medicines WHERE sku = 'ALK-1'$$, 'AMS_APPEND_ONLY', 'obat tidak bisa dihapus (nonaktifkan saja)');
INSERT INTO suppliers (id, code, name, updated_at) VALUES (gen_random_uuid(), 'PBF-0001', 'PBF Uji', now());
SELECT amstest.throws($$DELETE FROM suppliers WHERE code = 'PBF-0001'$$, 'AMS_APPEND_ONLY', 'pemasok tidak bisa dihapus');
SELECT amstest.throws($$INSERT INTO suppliers (id, code, name, payment_term_days, updated_at) VALUES (gen_random_uuid(), 'PBF-0002', 'X', 400, now())$$,
  'suppliers_term_chk', 'termin pembayaran di atas 365 hari ditolak');
SELECT amstest.throws($$DELETE FROM categories WHERE name = 'Analgesik'$$, 'foreign key', 'kategori yang dipakai obat tidak bisa dihapus');

-- ---------- Pencarian trigram ----------
SELECT amstest.ok((SELECT count(*) FROM medicines WHERE name ILIKE '%paraset%' OR generic_name ILIKE '%paraset%') = 1,
  'cari: nama generik ditemukan');
SELECT amstest.ok((SELECT similarity(name, 'paracetamol') > 0.3 FROM medicines WHERE sku = 'OBT-000001'),
  'cari: pg_trgm aktif untuk pencarian toleran salah ketik');
