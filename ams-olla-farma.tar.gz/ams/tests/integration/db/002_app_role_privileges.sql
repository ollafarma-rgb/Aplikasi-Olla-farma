-- Uji hak akses pengguna database aplikasi (bukan pemilik tabel).
-- Dijalankan sebagai role ams_app. Aplikasi tidak boleh bisa mematikan
-- trigger, mengubah skema, atau memalsukan audit log.
\set ON_ERROR_STOP on

SELECT amstest.ok(current_user = 'ams_app', 'hak akses: berjalan sebagai ams_app');
SELECT amstest.throws($$ALTER TABLE audit_logs DISABLE TRIGGER audit_logs_append_only_trg$$,
  'must be owner|permission denied', 'hak akses: aplikasi tidak bisa mematikan trigger audit');
SELECT amstest.throws($$DROP TABLE audit_logs$$, 'must be owner|permission denied', 'hak akses: aplikasi tidak bisa DROP tabel');
SELECT amstest.throws($$CREATE TABLE coba (id int)$$, 'permission denied', 'hak akses: aplikasi tidak bisa membuat tabel');
SELECT amstest.throws($$UPDATE audit_logs SET action = 'x'$$, 'AMS_APPEND_ONLY|permission denied', 'hak akses: aplikasi tidak bisa mengubah audit');

INSERT INTO audit_logs (user_id, action, entity) VALUES (NULL, 'auth.login.failed', 'user');
SELECT amstest.ok(ams_audit_verify_chain() IS NULL, 'hak akses: aplikasi bisa menulis audit dan rantai tetap utuh');
SELECT amstest.ok(ams_next_number('PJ', '2699') = 1, 'hak akses: aplikasi bisa mengambil nomor dokumen');
SELECT amstest.throws($$UPDATE medicine_price_history SET new_price = 1$$, 'AMS_APPEND_ONLY|permission denied', 'hak akses: aplikasi tidak bisa mengubah riwayat harga');
SELECT amstest.throws($$DELETE FROM medicines$$, 'AMS_APPEND_ONLY', 'hak akses: aplikasi tidak bisa menghapus obat');
SELECT amstest.throws($$UPDATE stock_movements SET qty = 1$$, 'AMS_APPEND_ONLY|permission denied', 'hak akses: aplikasi tidak bisa mengubah kartu stok');
SELECT amstest.throws($$DELETE FROM stock_movements$$, 'AMS_APPEND_ONLY|permission denied', 'hak akses: aplikasi tidak bisa menghapus kartu stok');
SELECT amstest.throws($$DELETE FROM medicine_batches$$, 'AMS_APPEND_ONLY', 'hak akses: aplikasi tidak bisa menghapus batch');

-- Fase 5: dokumen pengadaan BUKAN append-only (statusnya berubah lewat workflow
-- draft -> kirim/posting), jadi aplikasi harus tetap bisa UPDATE baris dokumen itu.
UPDATE purchase_orders SET notes = 'dicoba ams_app' WHERE id = '00000000-0000-7000-8000-00000000f501';
SELECT amstest.ok(
  (SELECT notes FROM purchase_orders WHERE id = '00000000-0000-7000-8000-00000000f501') = 'dicoba ams_app',
  'hak akses: aplikasi bisa mengubah dokumen pengadaan (bukan append-only)');
