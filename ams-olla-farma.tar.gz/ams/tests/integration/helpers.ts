import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import { permissionsForRoles } from '@/lib/permissions/check';
import type { RoleCode } from '@/lib/permissions/catalog';

/** Pelaku uji: pengguna nyata di DB dengan izin dari peran yang diberikan. */
export async function actorFor(username: string, roles: RoleCode[]): Promise<Actor> {
  let user = await prisma.user.findUnique({ where: { username } });
  user ??= await prisma.user.create({ data: { username, full_name: username, password_hash: 'x', must_change_password: false } });
  return { id: user.id, permissions: permissionsForRoles(roles), ip: '127.0.0.1', userAgent: 'vitest' };
}

export async function unitId(code: string): Promise<string> {
  return (await prisma.unit.findUniqueOrThrow({ where: { code } })).id;
}

/** Tangkap error dari promise untuk diperiksa kode dan field-nya. */
export async function caught(p: Promise<unknown>): Promise<{ code?: string; message?: string; fields?: Record<string, string> }> {
  try {
    await p;
  } catch (e) {
    return e as { code?: string; message?: string; fields?: Record<string, string> };
  }
  throw new Error('Diharapkan gagal, tetapi berhasil');
}
