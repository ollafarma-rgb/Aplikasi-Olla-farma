import { beforeAll, describe, expect, it } from 'vitest';
import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import { createMedicine, saveConversion } from '@/modules/medicines/service';
import { saveSupplier } from '@/modules/suppliers/service';
import { createOpeningBalance } from '@/modules/inventory/service';
import {
  approvePurchaseReturn, cancelPurchaseOrder, createGoodsReceipt, createPurchaseOrder, createPurchaseReturn,
  getGoodsReceipt, getPurchaseOrder, getPurchaseReturn, postGoodsReceipt, sendPurchaseOrder,
} from '@/modules/procurement/service';
import { actorFor, caught, unitId } from '../helpers';

let owner: Actor, apoteker: Actor, apoteker2: Actor, gudang: Actor, kasir: Actor;
let TAB: string, BOX: string;
let supplierId: string;

async function newMedicine(name: string, nie: string, purchaseUnit: string) {
  // purchase_unit_id di master obat harus satuan dasar atau sudah ada di konversi;
  // di sini selalu TAB (satuan dasar) saat dibuat, lalu konversi BOX ditambahkan
  // setelahnya bila dibutuhkan — baris SP/GR tetap bebas memilih satuan apa pun
  // yang sudah terkonversi.
  const { id } = await createMedicine({
    name, generic_name: name, product_type: 'OTC', drug_class: 'BEBAS', registration_no: nie,
    base_unit_id: TAB, purchase_unit_id: TAB, sales_unit_id: TAB, selling_price: '2500',
    default_purchase_price: '1800', min_stock: '50', max_stock: '',
  }, owner);
  if (purchaseUnit === BOX) {
    await saveConversion(id, { unit_id: BOX, factor_to_base: '100', barcode: '', selling_price: '', price_reason: '' }, owner);
  }
  return id;
}

beforeAll(async () => {
  owner = await actorFor('owner.test', ['OWNER']);
  apoteker = await actorFor('apt.proc', ['APOTEKER']);
  apoteker2 = await actorFor('apt.proc2', ['APOTEKER']);
  gudang = await actorFor('gudang.proc', ['GUDANG']);
  kasir = await actorFor('kasir.proc', ['KASIR']);
  TAB = await unitId('TAB');
  BOX = await unitId('BOX');
  supplierId = await saveSupplier(null, {
    name: 'PBF Uji Pengadaan', company_name: 'PT PBF Uji', address: '', phone: '', email: '',
    sales_rep: '', npwp: '', pbf_license_no: '', payment_term_days: '30', status: 'ACTIVE', notes: '',
  }, owner);
});

describe('Surat Pesanan', () => {
  it('gudang membuat draf -> dikirim apoteker -> status SENT', async () => {
    const medId = await newMedicine('Proc Paracetamol', 'DBLPROC000001', BOX);
    const po = await createPurchaseOrder(gudang, { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: 'pesanan rutin' },
      [{ medicine_id: medId, unit_id: BOX, qty_ordered: 5, price: '50000', discount_pct: '0' }]);
    expect(po.poNo).toMatch(/^SP-\d{4}-\d{4}$/);
    const draft = await getPurchaseOrder(apoteker, po.id);
    expect(draft.status).toBe('DRAFT');

    await sendPurchaseOrder(apoteker, po.id);
    const sent = await getPurchaseOrder(apoteker, po.id);
    expect(sent.status).toBe('SENT');
    expect(sent.signed_by).toBe(apoteker.id);
  });

  it('SP khusus narkotika wajib apoteker (po_special.sign), gudang ditolak', async () => {
    const medId = await newMedicine('Proc Kodein', 'DBLPROC000002', TAB);
    const e = await caught(createPurchaseOrder(gudang, { supplier_id: supplierId, order_type: 'NARKOTIKA', expected_date: '', notes: '' },
      [{ medicine_id: medId, unit_id: TAB, qty_ordered: 10, price: '1000', discount_pct: '0' }]));
    expect(e.code).toBe('FORBIDDEN');

    const po = await createPurchaseOrder(apoteker, { supplier_id: supplierId, order_type: 'NARKOTIKA', expected_date: '', notes: '' },
      [{ medicine_id: medId, unit_id: TAB, qty_ordered: 10, price: '1000', discount_pct: '0' }]);
    const eSend = await caught(sendPurchaseOrder(gudang, po.id));
    expect(eSend.code).toBe('FORBIDDEN');
    await sendPurchaseOrder(apoteker, po.id);
    expect((await getPurchaseOrder(apoteker, po.id)).status).toBe('SENT');
  });

  it('kasir tidak boleh membuat SP', async () => {
    const medId = await newMedicine('Proc Kasir', 'DBLPROC000003', TAB);
    const e = await caught(createPurchaseOrder(kasir, { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: '' },
      [{ medicine_id: medId, unit_id: TAB, qty_ordered: 10, price: '1000', discount_pct: '0' }]));
    expect(e.code).toBe('FORBIDDEN');
  });

  it('SP tanpa baris ditolak', async () => {
    const e = await caught(createPurchaseOrder(gudang, { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: '' }, []));
    expect(e.code).toBe('VALIDATION_ERROR');
  });

  it('SP draf bisa dibatalkan pembuat; SP terkirim tanpa penerimaan tetap bisa dibatalkan apoteker', async () => {
    const medId = await newMedicine('Proc Batal', 'DBLPROC000004', TAB);
    const po = await createPurchaseOrder(gudang, { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: '' },
      [{ medicine_id: medId, unit_id: TAB, qty_ordered: 10, price: '1000', discount_pct: '0' }]);
    await cancelPurchaseOrder(gudang, po.id);
    expect((await getPurchaseOrder(apoteker, po.id)).status).toBe('CANCELLED');
  });
});

describe('Penerimaan barang -> membuat batch', () => {
  it('penerimaan penuh (BOX->TAB) membuat batch baru, kartu stok RECEIPT, dan SP berstatus RECEIVED', async () => {
    const medId = await newMedicine('Proc Terima Penuh', 'DBLPROC000010', BOX);
    const po = await createPurchaseOrder(gudang, { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: '' },
      [{ medicine_id: medId, unit_id: BOX, qty_ordered: 3, price: '45000', discount_pct: '0' }]);
    await sendPurchaseOrder(apoteker, po.id);
    const poDetail = await getPurchaseOrder(apoteker, po.id);
    const poItemId = poDetail.items[0].id;

    const gr = await createGoodsReceipt(gudang, { po_id: po.id, supplier_do_no: 'DO-001', received_at: '2026-11-13' },
      [{ po_item_id: poItemId, qty: 3, batch_no: 'B-PENUH-1', expiry_date: '2027-10-31', unit_cost: '450', condition: 'OK', notes: null }]);
    const draftGr = await getGoodsReceipt(gudang, gr.id);
    expect(draftGr.status).toBe('DRAFT');

    const selfPost = await caught(postGoodsReceipt(gudang, gr.id));
    expect(selfPost.code).toBe('FORBIDDEN');

    await postGoodsReceipt(apoteker, gr.id);
    const posted = await getGoodsReceipt(apoteker, gr.id);
    expect(posted.status).toBe('POSTED');
    expect(posted.items[0].batch).toBeTruthy();

    const batch = await prisma.medicineBatch.findFirstOrThrow({ where: { batch_no: 'B-PENUH-1', medicine_id: medId } });
    expect(batch.qty_saleable).toBe(300); // 3 BOX x 100 TAB/BOX
    expect(batch.source).toBe('RECEIPT');
    const mv = await prisma.stockMovement.findMany({ where: { batch_id: batch.id, movement_type: 'RECEIPT' } });
    expect(mv.length).toBe(1);

    const poAfter = await getPurchaseOrder(apoteker, po.id);
    expect(poAfter.status).toBe('RECEIVED');
    expect(poAfter.items[0].qty_received_base).toBe(300);
  });

  it('penerimaan sebagian -> SP berstatus PARTIAL; item REJECTED tidak membuat batch', async () => {
    const medId = await newMedicine('Proc Terima Sebagian', 'DBLPROC000011', TAB);
    const po = await createPurchaseOrder(gudang, { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: '' },
      [{ medicine_id: medId, unit_id: TAB, qty_ordered: 100, price: '900', discount_pct: '0' }]);
    await sendPurchaseOrder(apoteker, po.id);
    const poItemId = (await getPurchaseOrder(apoteker, po.id)).items[0].id;

    const gr = await createGoodsReceipt(gudang, { po_id: po.id, supplier_do_no: '', received_at: '2026-11-13' }, [
      { po_item_id: poItemId, qty: 40, batch_no: 'B-SEBAGIAN-OK', expiry_date: '2027-10-31', unit_cost: '900', condition: 'OK', notes: null },
      { po_item_id: poItemId, qty: 10, batch_no: 'B-SEBAGIAN-REJ', expiry_date: '2027-10-31', unit_cost: '900', condition: 'REJECTED', notes: 'rusak berat' },
    ]);
    await postGoodsReceipt(apoteker, gr.id);

    const poAfter = await getPurchaseOrder(apoteker, po.id);
    expect(poAfter.status).toBe('PARTIAL');
    expect(poAfter.items[0].qty_received_base).toBe(40);
    const rejectedBatch = await prisma.medicineBatch.findFirst({ where: { batch_no: 'B-SEBAGIAN-REJ' } });
    expect(rejectedBatch).toBeNull();
  });

  it('penerimaan hanya untuk SP yang sudah terkirim (bukan DRAFT)', async () => {
    const medId = await newMedicine('Proc Belum Kirim', 'DBLPROC000012', TAB);
    const po = await createPurchaseOrder(gudang, { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: '' },
      [{ medicine_id: medId, unit_id: TAB, qty_ordered: 10, price: '1000', discount_pct: '0' }]);
    const poItemId = (await getPurchaseOrder(apoteker, po.id)).items[0].id;
    const e = await caught(createGoodsReceipt(gudang, { po_id: po.id, supplier_do_no: '', received_at: '2026-11-13' },
      [{ po_item_id: poItemId, qty: 10, batch_no: 'B-X', expiry_date: '2027-10-31', unit_cost: '1000', condition: 'OK', notes: null }]));
    expect(e.code).toBe('INVALID_STATE_TRANSITION');
  });
});

describe('Retur pembelian', () => {
  it('draf -> tidak boleh disetujui pembuat sendiri -> apoteker lain posting mengurangi stok saleable', async () => {
    const medId = await newMedicine('Proc Retur', 'DBLPROC000020', TAB);
    const batch = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'RET-1', expiry_date: '2027-12-31', qty: '100', unit_cost: '800', note: '' });

    const ret = await createPurchaseReturn(gudang, { supplier_id: supplierId, notes: 'kemasan rusak' },
      [{ batch_id: batch.id, bucket: 'SALEABLE', qty: 20, reason: 'Kemasan rusak saat penerimaan' }]);
    expect(ret.returnNo).toMatch(/^RB-\d{4}-\d{4}$/);

    const selfApprove = await caught(approvePurchaseReturn(gudang, ret.id));
    expect(selfApprove.code).toBe('FORBIDDEN');

    await approvePurchaseReturn(apoteker, ret.id);
    const batchAfter = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batch.id } });
    expect(batchAfter.qty_saleable).toBe(80);
    const posted = await getPurchaseReturn(apoteker, ret.id);
    expect(posted.status).toBe('POSTED');
    expect(await prisma.stockMovement.count({ where: { ref_type: 'purchase_return', ref_id: ret.id, movement_type: 'PURCHASE_RETURN' } })).toBe(1);
  });

  it('melebihi stok batch ditolak dengan pesan ramah', async () => {
    const medId = await newMedicine('Proc ReturLebih', 'DBLPROC000021', TAB);
    const batch = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'RET-2', expiry_date: '2027-12-31', qty: '5', unit_cost: '800', note: '' });
    const ret = await createPurchaseReturn(gudang, { supplier_id: supplierId, notes: '' },
      [{ batch_id: batch.id, bucket: 'SALEABLE', qty: 50, reason: 'Melebihi stok' }]);
    const e = await caught(approvePurchaseReturn(apoteker2, ret.id));
    expect(e.code).toBe('VALIDATION_ERROR');
    const batchAfter = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batch.id } });
    expect(batchAfter.qty_saleable).toBe(5);
  });

  it('retur tanpa alasan ditolak di tingkat input', async () => {
    const medId = await newMedicine('Proc ReturNoReason', 'DBLPROC000022', TAB);
    const batch = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'RET-3', expiry_date: '2027-12-31', qty: '5', unit_cost: '800', note: '' });
    const e = await caught(createPurchaseReturn(gudang, { supplier_id: supplierId, notes: '' },
      [{ batch_id: batch.id, bucket: 'SALEABLE', qty: 2, reason: '' }]));
    expect(e.code).toBe('VALIDATION_ERROR');
  });
});
