import { beforeAll, describe, expect, it } from 'vitest';
import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import { authService } from '@/modules/authentication';
import {
  addLicense, createUser, generateTemporaryPassword, getUser, removeLicense, resetUserPassword, setUserActive, unlockUser, updateUser,
} from '@/modules/users/service';
import { listSuppliers, saveSupplier } from '@/modules/suppliers/service';
import { deleteReference, listReferences, saveReference } from '@/modules/references/service';
import { validatePasswordPolicy } from '@/lib/auth/password';
import { createMedicine } from '@/modules/medicines/service';
import { actorFor, caught } from '../helpers';

let owner: Actor, apoteker: Actor, kasir: Actor;
const ctx = () => ({ ip: '10.1.1.1', userAgent: 'vitest', now: new Date() });

beforeAll(async () => {
  owner = await actorFor('owner.test', ['OWNER']);
  apoteker = await actorFor('apt.uji2', ['APOTEKER']);
  kasir = await actorFor('kasir.uji2', ['KASIR']);
});

describe('pengguna dan karyawan', () => {
  it('sandi sementara mudah dibacakan dan lolos kebijakan sandi', () => {
    for (let i = 0; i < 50; i++) {
      const p = generateTemporaryPassword();
      expect(p).toMatch(/^[a-z2-9]{4}-[a-z2-9]{4}-[a-z2-9]{4}$/);
      expect(validatePasswordPolicy(p)).toBeNull();
    }
  });

  it('owner membuat akun kasir; karyawan login dengan sandi sementara dan wajib ganti sandi', async () => {
    const { id, temporaryPassword } = await createUser({ username: 'Kasir.Rina', full_name: 'Rina', role_KASIR: 'on' }, owner);
    const u = await getUser(id, owner);
    expect(u.username).toBe('kasir.rina');
    expect(u.roleCodes).toEqual(['KASIR']);
    const login = await authService.login({ username: 'kasir.rina', password: temporaryPassword }, ctx());
    expect(login.mustChangePassword).toBe(true);
  });

  it('validasi: tanpa peran dan username duplikat ditolak', async () => {
    expect((await caught(createUser({ username: 'x.tanpa.peran', full_name: 'X' }, owner))).fields?.roles).toContain('minimal satu');
    expect((await caught(createUser({ username: 'kasir.rina', full_name: 'Y', role_KASIR: 'on' }, owner))).fields?.username).toContain('sudah dipakai');
  });

  it('hanya pemegang users.manage yang bisa membuat akun', async () => {
    expect((await caught(createUser({ username: 'coba', full_name: 'C', role_KASIR: 'on' }, apoteker))).code).toBe('FORBIDDEN');
  });

  it('ubah peran memaksa login ulang agar izin baru berlaku', async () => {
    const { id, temporaryPassword } = await createUser({ username: 'ttk.budi', full_name: 'Budi', role_KASIR: 'on' }, owner);
    const { token } = await authService.login({ username: 'ttk.budi', password: temporaryPassword }, ctx());
    expect(await authService.validateSession(token, new Date())).toBeDefined();
    await updateUser(id, { full_name: 'Budi Santoso', role_TTK: 'on' }, owner);
    expect(await authService.validateSession(token, new Date())).toBeNull();
    expect((await getUser(id, owner)).roleCodes).toEqual(['TTK']);
    expect(await prisma.auditLog.count({ where: { action: 'user.roles.changed', entity_id: id } })).toBe(1);
  });

  it('tidak bisa menonaktifkan diri sendiri atau mencabut peran Pemilik sendiri', async () => {
    expect((await caught(setUserActive(owner.id, false, owner))).message).toContain('akun sendiri');
    expect((await caught(updateUser(owner.id, { full_name: 'Owner', role_KASIR: 'on' }, owner))).fields?.roles).toContain('akun sendiri');
  });

  it('Pemilik aktif terakhir tidak bisa dinonaktifkan', async () => {
    const admin: Actor = { ...kasir }; // izin disesuaikan: kasir dengan izin Pemilik
    admin.permissions = owner.permissions;
    expect((await caught(setUserActive(owner.id, false, admin))).message).toContain('minimal satu Pemilik');
  });

  it('nonaktifkan memutus sesi; reset sandi membuka kunci dan memutus sesi', async () => {
    const { id, temporaryPassword } = await createUser({ username: 'gudang.dedi', full_name: 'Dedi', role_GUDANG: 'on' }, owner);
    const { token } = await authService.login({ username: 'gudang.dedi', password: temporaryPassword }, ctx());
    await setUserActive(id, false, owner);
    expect(await authService.validateSession(token, new Date())).toBeNull();
    await setUserActive(id, true, owner);
    await prisma.user.update({ where: { id }, data: { failed_login_count: 5, locked_until: new Date(Date.now() + 600_000) } });
    const fresh = await resetUserPassword(id, owner);
    expect(fresh === temporaryPassword).toBe(false);
    const u = await getUser(id, owner);
    expect(u.locked).toBe(false);
    expect(u.must_change_password).toBe(true);
    expect((await authService.login({ username: 'gudang.dedi', password: fresh }, ctx())).mustChangePassword).toBe(true);
  });

  it('buka kunci akun oleh Pemilik', async () => {
    const id = (await prisma.user.findUniqueOrThrow({ where: { username: 'kasir.rina' } })).id;
    await prisma.user.update({ where: { id }, data: { failed_login_count: 5, locked_until: new Date(Date.now() + 600_000) } });
    await unlockUser(id, owner);
    expect((await getUser(id, owner)).locked).toBe(false);
    expect(await prisma.auditLog.count({ where: { action: 'user.unlocked', entity_id: id } })).toBe(1);
  });

  it('izin praktik: tambah dan hapus tercatat di audit', async () => {
    const id = (await prisma.user.findUniqueOrThrow({ where: { username: 'ttk.budi' } })).id;
    await addLicense(id, { license_type: 'SIPTTK', number: '503/123/SIPTTK/2026', valid_until: '2031-11-12' }, owner);
    const lic = (await getUser(id, owner)).licenses[0];
    expect(lic.number).toBe('503/123/SIPTTK/2026');
    await removeLicense(id, lic.id, owner);
    expect((await getUser(id, owner)).licenses.length).toBe(0);
    expect(await prisma.auditLog.count({ where: { entity_id: id, action: { in: ['user.license.added', 'user.license.removed'] } } })).toBe(2);
  });
});

describe('pemasok', () => {
  it('kode otomatis, validasi email/termin, perubahan tercatat', async () => {
    const id = await saveSupplier(null, { name: 'PT Antar Mitra Sembada', payment_term_days: '30', status: 'ACTIVE', email: 'ams@contoh.co.id' }, owner);
    const s = await prisma.supplier.findUniqueOrThrow({ where: { id } });
    expect(s.code).toMatch(/^PBF-\d{4}$/);
    expect((await caught(saveSupplier(null, { name: 'X', payment_term_days: '400', status: 'ACTIVE' }, owner))).fields?.payment_term_days).toBeDefined();
    expect((await caught(saveSupplier(null, { name: 'X', payment_term_days: '30', status: 'ACTIVE', email: 'bukan-email' }, owner))).fields?.email).toContain('tidak valid');
    await saveSupplier(id, { name: 'PT Antar Mitra Sembada', payment_term_days: '45', status: 'ACTIVE', email: 'ams@contoh.co.id' }, owner);
    const audit = await prisma.auditLog.findFirstOrThrow({ where: { action: 'supplier.updated', entity_id: id } });
    expect(audit.after_json).toEqual({ payment_term_days: 45 });
  });

  it('kasir tidak bisa melihat pemasok; pencarian berdasarkan nama', async () => {
    expect((await caught(listSuppliers({}, kasir))).code).toBe('FORBIDDEN');
    expect((await listSuppliers({ q: 'mitra' }, apoteker)).total).toBe(1);
  });
});

describe('referensi obat', () => {
  it('kategori: tambah, nama duplikat ditolak, hapus jika belum dipakai', async () => {
    await saveReference('kategori', null, { name: 'Antibiotik', is_active: 'on' }, apoteker);
    expect((await caught(saveReference('kategori', null, { name: 'Antibiotik', is_active: 'on' }, apoteker))).fields?.name).toContain('sudah ada');
    const row = (await listReferences('kategori', apoteker)).find((r) => r.label === 'Antibiotik')!;
    await deleteReference('kategori', row.id, apoteker);
    expect((await listReferences('kategori', apoteker)).some((r) => r.label === 'Antibiotik')).toBe(false);
  });

  it('satuan yang dipakai obat tidak bisa dihapus; satuan dikelola Pemilik saja', async () => {
    expect((await caught(saveReference('satuan', null, { code: 'SUPP', name: 'Suppositoria', is_active: 'on' }, apoteker))).code).toBe('FORBIDDEN');
    await saveReference('satuan', null, { code: 'supp', name: 'Suppositoria', is_active: 'on' }, owner);
    const supp = (await listReferences('satuan', owner)).find((r) => r.label === 'SUPP — Suppositoria')!;
    await createMedicine({
      name: 'Kasa uji satuan', product_type: 'MEDICAL_SUPPLY', drug_class: 'NON_OBAT',
      base_unit_id: supp.id, purchase_unit_id: supp.id, sales_unit_id: supp.id, selling_price: '1000', min_stock: '0',
    }, owner);
    expect((await caught(deleteReference('satuan', supp.id, owner))).message).toContain('masih dipakai');
  });

  it('lokasi rak dengan kondisi penyimpanan', async () => {
    await saveReference('lokasi', null, { code: 'lk-01', name: 'Lemari Narkotika', condition: 'SPECIAL_CABINET' }, apoteker);
    expect((await listReferences('lokasi', apoteker)).find((r) => r.label.startsWith('LK-01'))?.detail).toContain('narkotika');
  });
});
