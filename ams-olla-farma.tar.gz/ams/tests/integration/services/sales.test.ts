import { beforeAll, describe, expect, it } from 'vitest';
import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import { createMedicine, saveConversion } from '@/modules/medicines/service';
import { saveSupplier } from '@/modules/suppliers/service';
import { createOpeningBalance } from '@/modules/inventory/service';
import { createPurchaseOrder, sendPurchaseOrder, createGoodsReceipt, postGoodsReceipt } from '@/modules/procurement/service';
import {
  createCustomer,
  createSale,
  cancelSale,
  openSession,
  closeSession,
  getOpenSession,
  createPrescription,
  verifyPrescription,
  createSaleReturnDraft,
  postSaleReturn,
  createPurchaseInvoice,
  recordSupplierPayment,
  getSaleDetail,
  getPurchaseInvoiceDetail,
} from '@/modules/sales/service';
import { actorFor, caught, unitId } from '../helpers';

let owner: Actor, apoteker: Actor, apoteker2: Actor, kasir: Actor, kasir2: Actor;
let TAB: string;
let supplierId: string;
let medId: string;
let batchId: string;
let batchQtyBefore: number;

beforeAll(async () => {
  owner      = await actorFor('owner.sales',    ['OWNER']);
  apoteker   = await actorFor('apt.sales',      ['APOTEKER']);
  apoteker2  = await actorFor('apt.sales2',     ['APOTEKER']);
  kasir      = await actorFor('kasir.sales',    ['KASIR']);
  kasir2     = await actorFor('kasir.sales2',   ['KASIR']);
  TAB = await unitId('TAB');

  supplierId = await saveSupplier(null, {
    name: 'PBF Uji Penjualan', company_name: 'PT PBF Test', address: '', phone: '', email: '',
    sales_rep: '', npwp: '', pbf_license_no: '', payment_term_days: '30', status: 'ACTIVE', notes: '',
  }, owner);

  // Buat obat + stok awal
  const med = await createMedicine({
    name: 'Paracetamol Uji Jual', generic_name: 'Paracetamol', product_type: 'OTC', drug_class: 'BEBAS',
    registration_no: 'DBLJUAL01', base_unit_id: TAB, purchase_unit_id: TAB, sales_unit_id: TAB,
    selling_price: '1500', default_purchase_price: '900', min_stock: '10', max_stock: '',
  }, owner);
  medId = med.id;

  // Stok awal 100 TAB
  const batch = await createOpeningBalance(apoteker, {
    medicine_id: medId, batch_no: 'BJ-001', expiry_date: '2027-06-30', qty: '100', unit_cost: '900', note: '',
  });
  batchId = batch.id;

  const batchRow = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } });
  batchQtyBefore = batchRow.qty_saleable;
});

// ─────────────────────────── Customer ───────────────────────────

describe('Pelanggan', () => {
  it('kasir bisa membuat pelanggan baru', async () => {
    const r = await createCustomer(kasir, {
      code: 'CST-TEST-01', name: 'Rina Jual Test', phone: '', address: '', date_of_birth: '', credit_limit: '500000', notes: '',
    });
    expect(r.id).toBeTruthy();
    const c = await prisma.customer.findUniqueOrThrow({ where: { id: r.id } });
    expect(c.name).toBe('Rina Jual Test');
    expect(Number(c.credit_limit)).toBe(500000);
  });

  it('kode duplikat ditolak', async () => {
    const e = await caught(createCustomer(kasir, {
      code: 'CST-TEST-01', name: 'Duplikat', phone: '', address: '', date_of_birth: '', credit_limit: '', notes: '',
    }));
    expect(e.code).toBe('DUPLICATE');
  });
});

// ─────────────────────────── Sesi Kasir ───────────────────────────

describe('Sesi Kasir', () => {
  it('kasir buka sesi → status OPEN', async () => {
    const sess = await openSession(kasir, { opening_cash: '500000', notes: 'shift pagi' });
    expect(sess.id).toBeTruthy();
    const row = await prisma.saleSession.findUniqueOrThrow({ where: { id: sess.id } });
    expect(row.status).toBe('OPEN');
    expect(Number(row.opening_cash)).toBe(500000);
  });

  it('kasir tidak bisa buka dua sesi sekaligus', async () => {
    const e = await caught(openSession(kasir, { opening_cash: '0', notes: '' }));
    expect(e.message ?? e.code).toMatch(/sesi|sudah/i);
  });

  it('kasir bisa tutup sesi yang sedang buka', async () => {
    const open = await getOpenSession(kasir);
    expect(open).not.toBeNull();
    const result = await closeSession(kasir, open!.id, { closing_cash: '550000', notes: 'tutup normal' });
    expect(result.status).toBe('CLOSED');
  });

  it('setelah tutup tidak ada sesi aktif', async () => {
    const open = await getOpenSession(kasir);
    expect(open).toBeNull();
  });
});

// ─────────────────────────── Penjualan Tunai ───────────────────────────

describe('Penjualan Tunai', () => {
  let saleId: string;
  let saleNo: string;
  let sessionId: string;

  it('buka sesi → buat penjualan tunai → stok berkurang', async () => {
    const sess = await openSession(kasir2, { opening_cash: '1000000', notes: '' });
    sessionId = sess.id;

    const result = await createSale(
      kasir2,
      { customer_id: '', prescription_id: '', payment_method: 'CASH', amount_paid: '15000', notes: '' },
      [{ medicine_id: medId, batch_id: batchId, unit_id: TAB, qty: 10, unit_price: '1500', discount_pct: '0' }],
    );
    saleId = result.id;
    saleNo  = result.saleNo;

    expect(saleNo).toMatch(/^TRJ-\d{4}-\d{4}$/);

    const batch = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } });
    expect(batch.qty_saleable).toBe(batchQtyBefore - 10);
    batchQtyBefore = batch.qty_saleable; // update baseline
  });

  it('detail penjualan ada items dan total benar', async () => {
    const detail = await getSaleDetail(apoteker, saleId);
    expect(detail.items).toHaveLength(1);
    expect(Number(detail.total_amount)).toBe(15000);
    expect(detail.payment_method).toBe('CASH');
  });

  it('kartu stok tercatat SALE', async () => {
    const mv = await prisma.stockMovement.findMany({ where: { ref_id: saleId, movement_type: 'SALE' } });
    expect(mv.length).toBeGreaterThan(0);
  });

  it('saleNo unik pada penjualan berikutnya', async () => {
    const r = await createSale(
      kasir2,
      { customer_id: '', prescription_id: '', payment_method: 'CASH', amount_paid: '3000', notes: '' },
      [{ medicine_id: medId, batch_id: batchId, unit_id: TAB, qty: 2, unit_price: '1500', discount_pct: '0' }],
    );
    expect(r.saleNo).not.toBe(saleNo);
    batchQtyBefore -= 2;
  });

  it('kasir tidak boleh jual lebih dari stok tersedia', async () => {
    const e = await caught(createSale(
      kasir2,
      { customer_id: '', prescription_id: '', payment_method: 'CASH', amount_paid: '999999', notes: '' },
      [{ medicine_id: medId, batch_id: batchId, unit_id: TAB, qty: 9999, unit_price: '1500', discount_pct: '0' }],
    ));
    expect(e.code ?? e.message).toBeTruthy();
  });

  it('penjualan tanpa item ditolak', async () => {
    const e = await caught(createSale(
      kasir2,
      { customer_id: '', prescription_id: '', payment_method: 'CASH', amount_paid: '0', notes: '' },
      [],
    ));
    expect(e.code ?? e.message).toBeTruthy();
  });

  it('kasir bisa batalkan penjualan → stok kembali', async () => {
    const qtyBefore = (await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } })).qty_saleable;

    const r = await createSale(
      kasir2,
      { customer_id: '', prescription_id: '', payment_method: 'CASH', amount_paid: '1500', notes: '' },
      [{ medicine_id: medId, batch_id: batchId, unit_id: TAB, qty: 1, unit_price: '1500', discount_pct: '0' }],
    );
    batchQtyBefore--;

    await cancelSale(apoteker, r.id, 'uji pembatalan');

    const qtyAfter = (await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } })).qty_saleable;
    expect(qtyAfter).toBe(qtyBefore);
    batchQtyBefore++;
  });
});

// ─────────────────────────── Resep Dokter ───────────────────────────

describe('Resep Dokter', () => {
  let rxId: string;

  it('kasir membuat resep → status PENDING', async () => {
    const r = await createPrescription(
      kasir2,
      {
        customer_id: '', doctor_name: 'Dr. Handoko', doctor_sip: 'SIP.001', clinic_name: 'Klinik Sehat',
        prescribed_at: '2024-11-13', notes: '',
      },
      [{ medicine_id: medId, qty_prescribed: 20, instructions: '3x sehari 1 tablet', notes: '' }],
    );
    rxId = r.id;
    expect(rxId).toBeTruthy();

    const rx = await prisma.prescription.findUniqueOrThrow({ where: { id: rxId } });
    expect(rx.status).toBe('PENDING');
  });

  it('pembuat tidak bisa verifikasi resep sendiri', async () => {
    // kasir2 adalah pembuat, kasir2 juga tidak punya izin verifikasi (hanya APOTEKER)
    const e = await caught(verifyPrescription(kasir2, rxId));
    expect(e.code ?? e.message).toBeTruthy();
  });

  it('apoteker lain bisa verifikasi → status VERIFIED', async () => {
    await verifyPrescription(apoteker, rxId);
    const rx = await prisma.prescription.findUniqueOrThrow({ where: { id: rxId } });
    expect(rx.status).toBe('VERIFIED');
    expect(rx.verified_by).toBe(apoteker.id);
  });

  it('resep yang sudah diverifikasi tidak bisa diverifikasi ulang', async () => {
    const e = await caught(verifyPrescription(apoteker2, rxId));
    expect(e.code ?? e.message).toBeTruthy();
  });
});

// ─────────────────────────── Retur Penjualan ───────────────────────────

describe('Retur Penjualan', () => {
  let saleIdForReturn: string;
  let saleItemId: string;
  let returnId: string;

  it('siapkan penjualan untuk diretur', async () => {
    // pastikan ada sesi kasir aktif
    const existingSession = await getOpenSession(kasir2);
    if (!existingSession) {
      await openSession(kasir2, { opening_cash: '0', notes: 'sesi retur' });
    }

    const r = await createSale(
      kasir2,
      { customer_id: '', prescription_id: '', payment_method: 'CASH', amount_paid: '15000', notes: '' },
      [{ medicine_id: medId, batch_id: batchId, unit_id: TAB, qty: 10, unit_price: '1500', discount_pct: '0' }],
    );
    saleIdForReturn = r.id;
    batchQtyBefore -= 10;

    const detail = await getSaleDetail(apoteker, saleIdForReturn);
    saleItemId = detail.items[0].id;
  });

  it('kasir membuat draf retur', async () => {
    const r = await createSaleReturnDraft(
      kasir2,
      { sale_id: saleIdForReturn, notes: 'obat rusak' },
      [{ sale_item_id: saleItemId, batch_id: batchId, qty: 3, disposition: 'RESTOCK', reason: 'Kemasan rusak' }],
    );
    returnId = r.id;
    expect(returnId).toBeTruthy();

    const ret = await prisma.saleReturn.findUniqueOrThrow({ where: { id: returnId } });
    expect(ret.status).toBe('DRAFT');
  });

  it('pembuat tidak bisa posting retur sendiri (four-eyes)', async () => {
    const e = await caught(postSaleReturn(kasir2, returnId));
    expect(e.code ?? e.message).toBeTruthy();
  });

  it('apoteker posting retur → stok bertambah (RESTOCK)', async () => {
    const qtyBefore = (await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } })).qty_saleable;

    await postSaleReturn(apoteker, returnId);

    const ret = await prisma.saleReturn.findUniqueOrThrow({ where: { id: returnId } });
    expect(ret.status).toBe('POSTED');

    const qtyAfter = (await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } })).qty_saleable;
    expect(qtyAfter).toBe(qtyBefore + 3);
    batchQtyBefore += 3;
  });

  it('retur DISPOSE tidak menambah stok saleable', async () => {
    // Buat penjualan baru untuk diretur
    const sale2 = await createSale(
      kasir2,
      { customer_id: '', prescription_id: '', payment_method: 'CASH', amount_paid: '3000', notes: '' },
      [{ medicine_id: medId, batch_id: batchId, unit_id: TAB, qty: 2, unit_price: '1500', discount_pct: '0' }],
    );
    batchQtyBefore -= 2;
    const detail2 = await getSaleDetail(apoteker, sale2.id);
    const itemId2 = detail2.items[0].id;

    const qtyBefore = (await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } })).qty_saleable;

    const ret2 = await createSaleReturnDraft(
      kasir2,
      { sale_id: sale2.id, notes: 'obat kadaluarsa' },
      [{ sale_item_id: itemId2, batch_id: batchId, qty: 1, disposition: 'DISPOSE', reason: 'Kadaluarsa' }],
    );
    await postSaleReturn(apoteker, ret2.id);

    const qtyAfter = (await prisma.medicineBatch.findUniqueOrThrow({ where: { id: batchId } })).qty_saleable;
    expect(qtyAfter).toBe(qtyBefore); // DISPOSE tidak menambah saleable
  });
});

// ─────────────────────────── Faktur & AP ───────────────────────────

describe('Faktur Pembelian & Utang Dagang', () => {
  let grId: string;
  let invoiceId: string;

  it('siapkan penerimaan barang untuk membuat faktur', async () => {
    const po = await createPurchaseOrder(
      apoteker,
      { supplier_id: supplierId, order_type: 'REGULER', expected_date: '', notes: 'pesanan uji AP' },
      [{ medicine_id: medId, unit_id: TAB, qty_ordered: 50, price: '900', discount_pct: '0' }],
    );
    await sendPurchaseOrder(apoteker, po.id);

    // Ambil po item id
    const poDetail = await prisma.purchaseOrder.findUniqueOrThrow({
      where: { id: po.id }, include: { items: true },
    });
    const poItemId = poDetail.items[0].id;

    const gr = await createGoodsReceipt(apoteker, po.id, [
      { po_item_id: poItemId, qty: 50, batch_no: 'BJ-AP-001', expiry_date: '2027-12-31', unit_cost: '900', condition: 'OK', notes: null },
    ]);
    await postGoodsReceipt(apoteker, gr.id);
    grId = gr.id;
    batchQtyBefore += 50; // batch baru atau batch berbeda (bukan batchId kita)
  });

  it('apoteker membuat faktur → status UNPAID', async () => {
    const r = await createPurchaseInvoice(apoteker, {
      gr_id: grId,
      supplier_inv_no: 'INV/PBF/TEST/001',
      invoice_date: '2024-11-01',
      due_date: '2024-12-01',
      notes: '',
    });
    invoiceId = r.id;
    expect(r.invNo).toMatch(/^FKT-\d{4}-\d{4}$/);

    const inv = await prisma.purchaseInvoice.findUniqueOrThrow({ where: { id: invoiceId } });
    expect(inv.status).toBe('UNPAID');
  });

  it('GR yang sudah ada faktur tidak bisa difakturkan ulang', async () => {
    const e = await caught(createPurchaseInvoice(apoteker, {
      gr_id: grId, supplier_inv_no: 'INV/DUPLIKAT', invoice_date: '2024-11-02', due_date: '2024-12-02', notes: '',
    }));
    expect(e.code ?? e.message).toBeTruthy();
  });

  it('kasir tidak boleh membuat faktur', async () => {
    const e = await caught(createPurchaseInvoice(kasir, {
      gr_id: grId, supplier_inv_no: 'INV/KASIR', invoice_date: '2024-11-02', due_date: '2024-12-02', notes: '',
    }));
    expect(e.code ?? e.message).toBeTruthy();
  });

  it('catat pembayaran sebagian → status PARTIAL', async () => {
    const inv = await prisma.purchaseInvoice.findUniqueOrThrow({ where: { id: invoiceId } });
    const totalAmount = Number(inv.subtotal);

    await recordSupplierPayment(owner, {
      invoice_id: invoiceId,
      payment_date: '2024-11-15',
      amount: String(Math.floor(totalAmount / 2)),
      reference_no: 'TRF/BCA/001',
      notes: 'pembayaran tahap 1',
    });

    const invAfter = await prisma.purchaseInvoice.findUniqueOrThrow({ where: { id: invoiceId } });
    expect(invAfter.status).toBe('PARTIAL');
  });

  it('lunas pembayaran → status PAID', async () => {
    const inv = await prisma.purchaseInvoice.findUniqueOrThrow({ where: { id: invoiceId } });
    const remaining = Number(inv.subtotal) - Number(inv.amount_paid);

    await recordSupplierPayment(owner, {
      invoice_id: invoiceId,
      payment_date: '2024-11-20',
      amount: String(remaining),
      reference_no: 'TRF/BCA/002',
      notes: 'pelunasan',
    });

    const invAfter = await prisma.purchaseInvoice.findUniqueOrThrow({ where: { id: invoiceId } });
    expect(invAfter.status).toBe('PAID');
  });

  it('tidak bisa bayar lebih dari sisa utang', async () => {
    const e = await caught(recordSupplierPayment(owner, {
      invoice_id: invoiceId,
      payment_date: '2024-11-21',
      amount: '99999999',
      reference_no: '',
      notes: '',
    }));
    expect(e.code ?? e.message).toBeTruthy();
  });

  it('detail faktur menampilkan riwayat pembayaran', async () => {
    const detail = await getPurchaseInvoiceDetail(owner, invoiceId);
    expect(detail.payments.length).toBeGreaterThanOrEqual(2);
  });
});
