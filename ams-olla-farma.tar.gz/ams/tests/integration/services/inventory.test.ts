import { beforeAll, describe, expect, it } from 'vitest';
import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import { createMedicine } from '@/modules/medicines/service';
import {
  approveAdjustment, createAdjustment, createOpeningBalance, createOpname, getMedicineStock,
  getOpname, inventoryValue, listStock, moveBucket, postOpname, saveOpnameCounts,
} from '@/modules/inventory/service';
import { actorFor, caught, unitId } from '../helpers';

let owner: Actor, apoteker: Actor, gudang: Actor, kasir: Actor;
let TAB: string;

async function newMedicine(name: string, nie: string, min = '50') {
  const { id } = await createMedicine({
    name, generic_name: name, product_type: 'OTC', drug_class: 'BEBAS', registration_no: nie,
    base_unit_id: TAB, purchase_unit_id: TAB, sales_unit_id: TAB, selling_price: '2500',
    default_purchase_price: '1800', min_stock: min, max_stock: '',
  }, owner);
  return id;
}

beforeAll(async () => {
  owner = await actorFor('owner.test', ['OWNER']);
  apoteker = await actorFor('apt.inv', ['APOTEKER']);
  gudang = await actorFor('gudang.inv', ['GUDANG']);
  kasir = await actorFor('kasir.inv', ['KASIR']);
  TAB = await unitId('TAB');
});

describe('saldo awal', () => {
  it('apoteker: membuat batch, menambah stok saleable, mencatat kartu stok dan audit', async () => {
    const medId = await newMedicine('Inv Amoxicillin', 'DBLINV0000001');
    const r = await createOpeningBalance(apoteker, {
      medicine_id: medId, batch_no: 'B1', expiry_date: '2027-12-31', qty: '120', unit_cost: '1800', note: 'awal',
    });
    expect(r.refNo).toMatch(/^SALDO-\d{4}-\d{4}$/);
    const batch = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: r.id } });
    expect(batch.qty_saleable).toBe(120);
    expect(batch.qty_received).toBe(120);
    expect(batch.unit_cost.toString()).toBe('1800');
    const mv = await prisma.stockMovement.findMany({ where: { batch_id: r.id } });
    expect(mv.length).toBe(1);
    expect(mv[0].movement_type).toBe('OPENING');
    expect(mv[0].user_id).toBe(apoteker.id);
    expect(await prisma.auditLog.count({ where: { action: 'inventory.opening_balance', entity_id: r.id } })).toBe(1);
  });

  it('kasir: ditolak (bukan apoteker/pemilik)', async () => {
    const medId = await newMedicine('Inv Vit C', 'DBLINV0000002');
    const e = await caught(createOpeningBalance(kasir, { medicine_id: medId, batch_no: 'B1', expiry_date: '2027-01-31', qty: '10', unit_cost: '500', note: '' }));
    expect(e.code).toBe('FORBIDDEN');
  });

  it('batch duplikat (obat+no+ED) ditolak dengan pesan ramah', async () => {
    const medId = await newMedicine('Inv Dup', 'DBLINV0000003');
    await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'X', expiry_date: '2027-05-31', qty: '5', unit_cost: '100', note: '' });
    const e = await caught(createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'X', expiry_date: '2027-05-31', qty: '5', unit_cost: '100', note: '' }));
    expect(e.code).toBe('VALIDATION_ERROR');
    expect(e.fields?.batch_no).toBeTruthy();
  });
});

describe('ringkasan stok', () => {
  it('menjumlahkan stok dan nilai, serta memfilter stok menipis', async () => {
    const medId = await newMedicine('Inv Ringkas', 'DBLINV0000010', '1000');
    await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'R1', expiry_date: '2027-12-31', qty: '30', unit_cost: '2000', note: '' });
    const low = await listStock(gudang, { q: 'Inv Ringkas', view: 'menipis' });
    const row = low.items.find((r) => r.id === medId);
    expect(row).toBeTruthy();
    expect(row!.saleable).toBe(30);
    expect(row!.low).toBe(true);
    expect(row!.value).toBe('60000');
    expect(Number(await inventoryValue(gudang))).toBeGreaterThan(0);
  });
});

describe('pindah bucket', () => {
  it('gudang: saleable -> karantina, total kekal, tidak boleh bucket sama', async () => {
    const medId = await newMedicine('Inv Karantina', 'DBLINV0000020');
    const b = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'K1', expiry_date: '2027-12-31', qty: '40', unit_cost: '1000', note: '' });
    await moveBucket(gudang, { batch_id: b.id, from_bucket: 'SALEABLE', to_bucket: 'QUARANTINE', qty: '15', reason: 'rusak kemasan' });
    const batch = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: b.id } });
    expect(batch.qty_saleable).toBe(25);
    expect(batch.qty_quarantine).toBe(15);
    const e = await caught(moveBucket(gudang, { batch_id: b.id, from_bucket: 'SALEABLE', to_bucket: 'SALEABLE', qty: '1', reason: '' }));
    expect(e.code).toBe('VALIDATION_ERROR');
  });
});

describe('penyesuaian stok', () => {
  it('draf -> tidak boleh disetujui pembuat sendiri -> apoteker posting mengurangi stok', async () => {
    const medId = await newMedicine('Inv Adj', 'DBLINV0000030');
    const b = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'A1', expiry_date: '2027-12-31', qty: '100', unit_cost: '1500', note: '' });
    const adj = await createAdjustment(gudang, { reason_code: 'HILANG', notes: 'selisih gudang' },
      [{ batch_id: b.id, bucket: 'SALEABLE', qty_delta: -10, reason: 'hilang' }]);
    expect(adj.adjNo).toMatch(/^ADJ-\d{4}-\d{4}$/);

    const self = await caught(approveAdjustment(gudang, adj.id));
    expect(self.code).toBe('FORBIDDEN');

    await approveAdjustment(apoteker, adj.id);
    const batch = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: b.id } });
    expect(batch.qty_saleable).toBe(90);
    const posted = await prisma.stockAdjustment.findUniqueOrThrow({ where: { id: adj.id } });
    expect(posted.status).toBe('POSTED');
    expect(posted.approval_id).toBeTruthy();
    expect(await prisma.stockMovement.count({ where: { ref_type: 'stock_adjustment', ref_id: adj.id } })).toBe(1);
  });

  it('posting yang melebihi stok ditolak dengan pesan ramah dan tidak mengubah stok', async () => {
    const medId = await newMedicine('Inv AdjNeg', 'DBLINV0000031');
    const b = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'N1', expiry_date: '2027-12-31', qty: '5', unit_cost: '1500', note: '' });
    const adj = await createAdjustment(gudang, { reason_code: 'HILANG', notes: '' },
      [{ batch_id: b.id, bucket: 'SALEABLE', qty_delta: -50, reason: '' }]);
    const e = await caught(approveAdjustment(apoteker, adj.id));
    expect(e.code).toBe('VALIDATION_ERROR');
    const batch = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: b.id } });
    expect(batch.qty_saleable).toBe(5);
    expect((await prisma.stockAdjustment.findUniqueOrThrow({ where: { id: adj.id } })).status).toBe('DRAFT');
  });

  it('item dengan delta nol ditolak', async () => {
    const medId = await newMedicine('Inv AdjZero', 'DBLINV0000032');
    const b = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'Z1', expiry_date: '2027-12-31', qty: '5', unit_cost: '1', note: '' });
    const e = await caught(createAdjustment(gudang, { reason_code: 'KOREKSI', notes: '' }, [{ batch_id: b.id, bucket: 'SALEABLE', qty_delta: 0, reason: '' }]));
    expect(e.code).toBe('VALIDATION_ERROR');
  });
});

describe('stok opname', () => {
  it('mulai -> isi hitungan -> tidak boleh diposting pembuat -> apoteker posting mengoreksi ke hasil hitung', async () => {
    const medId = await newMedicine('Inv Opname', 'DBLINV0000040');
    const b = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'O1', expiry_date: '2027-12-31', qty: '80', unit_cost: '1200', note: '' });
    const op = await createOpname(gudang, { medicine_id: medId, scope_note: 'rak A' });
    const detail = await getOpname(gudang, op.id);
    const item = detail.items.find((i) => i.batch_id === b.id)!;
    expect(item.system_qty).toBe(80);

    await saveOpnameCounts(gudang, op.id, { [item.id]: 75 });
    const self = await caught(postOpname(gudang, op.id));
    expect(self.code).toBe('FORBIDDEN');

    const r = await postOpname(apoteker, op.id);
    expect(r.diffs).toBe(1);
    const batch = await prisma.medicineBatch.findUniqueOrThrow({ where: { id: b.id } });
    expect(batch.qty_saleable).toBe(75);
    const posted = await prisma.stockOpname.findUniqueOrThrow({ where: { id: op.id } });
    expect(posted.status).toBe('POSTED');
    expect(posted.adjustment_id).toBeTruthy();
    expect(posted.approved_by).toBe(apoteker.id);
    expect(await prisma.stockMovement.count({ where: { ref_type: 'stock_opname', ref_id: op.id } })).toBe(1);
  });

  it('kartu stok per obat memuat batch dan riwayat movement', async () => {
    const medId = await newMedicine('Inv Kartu', 'DBLINV0000050');
    const b = await createOpeningBalance(apoteker, { medicine_id: medId, batch_no: 'C1', expiry_date: '2027-12-31', qty: '20', unit_cost: '900', note: '' });
    const { batches, movements } = await getMedicineStock(gudang, medId);
    expect(batches.some((x) => x.id === b.id)).toBe(true);
    expect(movements.length).toBeGreaterThanOrEqual(1);
  });
});
