/**
 * Integration tests: Fase 7 — Diskon Periode
 *
 * Menguji: createDiscountRule, approveDiscountRule, cancelDiscountRule,
 *           listDiscountRules, resolveApplicableDiscount.
 * Maker-checker: pembuat tidak boleh menyetujui aturannya sendiri.
 */

import { beforeAll, describe, expect, it } from 'vitest';
import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import {
  createDiscountRule,
  approveDiscountRule,
  cancelDiscountRule,
  listDiscountRules,
  getDiscountRuleById,
  resolveApplicableDiscount,
} from '@/modules/discounts/service';
import { createMedicine } from '@/modules/medicines/service';
import { actorFor, caught, unitId } from '../helpers';

let owner: Actor, apoteker: Actor, apoteker2: Actor, kasir: Actor;
let TAB: string;
let medicineId: string;
let categoryId: string;

// helpers

function futureRange(daysFromNow = 30) {
  const starts = new Date(Date.now() + 1000 * 60); // +1 menit dari sekarang
  const ends   = new Date(Date.now() + 86_400_000 * daysFromNow);
  return {
    starts_at: starts.toISOString(),
    ends_at:   ends.toISOString(),
  };
}

function activeRange() {
  const starts = new Date(Date.now() - 86_400_000); // kemarin
  const ends   = new Date(Date.now() + 86_400_000); // besok
  return {
    starts_at: starts.toISOString(),
    ends_at:   ends.toISOString(),
  };
}

async function createAndApprove(actor: Actor, approver: Actor, overrides: Record<string, unknown> = {}) {
  const rule = await createDiscountRule(actor, {
    code: `DISC_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    name: 'Aturan Uji',
    scope: 'ALL',
    type: 'PERCENT',
    value: '10',
    min_qty_base: 1,
    ...activeRange(),
    ...overrides,
  });
  await approveDiscountRule(approver, { id: rule.id, action: 'APPROVE', notes: '' });
  return rule;
}

// ────────────────────────────────────────────────────────────────

beforeAll(async () => {
  owner    = await actorFor('owner.disc', ['OWNER']);
  apoteker = await actorFor('apt.disc1',  ['APOTEKER']);
  apoteker2= await actorFor('apt.disc2',  ['APOTEKER']);
  kasir    = await actorFor('kasir.disc', ['KASIR']);
  TAB      = await unitId('TAB');

  // Pastikan kategori ada
  let cat = await prisma.category.findFirst({ where: { name: 'Analgesik Uji' } });
  cat ??= await prisma.category.create({ data: { name: 'Analgesik Uji' } });
  categoryId = cat.id;

  // Obat untuk scope MEDICINE
  const med = await createMedicine({
    name: 'Disc Paracetamol',
    generic_name: 'Paracetamol',
    product_type: 'OTC',
    drug_class: 'BEBAS',
    registration_no: `DBLD${Date.now()}`,
    base_unit_id: TAB,
    purchase_unit_id: TAB,
    sales_unit_id: TAB,
    selling_price: '3000',
    default_purchase_price: '1500',
    min_stock: '10',
    max_stock: '',
  }, owner);
  medicineId = med.id;
});

// ─────────────────────────── CREATE ───────────────────────────

describe('createDiscountRule', () => {
  it('apoteker dapat membuat aturan diskon DRAFT', async () => {
    const rule = await createDiscountRule(apoteker, {
      code: `APT_DISC_${Date.now()}`,
      name: 'Diskon Akhir Bulan',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
      notes: 'diskon rutin akhir bulan',
    });
    expect(rule.status).toBe('DRAFT');
    expect(rule.created_by).toBe(apoteker.id);
  });

  it('kasir tidak boleh membuat aturan diskon', async () => {
    const e = await caught(createDiscountRule(kasir, {
      code: 'KASIR_DISC',
      name: 'Diskon Kasir',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
    }));
    expect(e.code).toBe('FORBIDDEN');
  });

  it('kode duplikat ditolak', async () => {
    const code = `DUP_${Date.now()}`;
    await createDiscountRule(apoteker, {
      code,
      name: 'Diskon 1',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
    });
    const e = await caught(createDiscountRule(apoteker2, {
      code,
      name: 'Diskon 2',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
    }));
    expect(e.code).toBe('VALIDATION_ERROR');
    expect(e.fields?.code).toMatch(/sudah digunakan/i);
  });

  it('scope CATEGORY dengan UUID tidak ada menghasilkan NOT_FOUND', async () => {
    // UUID valid tapi tidak ada di DB
    const fakeUUID = '00000000-0000-7000-8000-000000000001';
    const e = await caught(createDiscountRule(apoteker, {
      code: `CAT_DISC_ERR_${Date.now()}`,
      name: 'Diskon Kategori Error',
      scope: 'CATEGORY',
      category_id: fakeUUID,
      type: 'PERCENT',
      value: '10',
      min_qty_base: 1,
      ...futureRange(),
    }));
    expect(e.code).toBe('NOT_FOUND');
  });

  it('scope MEDICINE dengan UUID tidak ada menghasilkan NOT_FOUND', async () => {
    // UUID valid tapi tidak ada di DB
    const fakeUUID = '00000000-0000-7000-8000-000000000002';
    const e = await caught(createDiscountRule(apoteker, {
      code: `MED_DISC_ERR_${Date.now()}`,
      name: 'Diskon Obat Error',
      scope: 'MEDICINE',
      medicine_id: fakeUUID,
      type: 'PERCENT',
      value: '10',
      min_qty_base: 1,
      ...futureRange(),
    }));
    expect(e.code).toBe('NOT_FOUND');
  });
});

// ─────────────────────────── APPROVE / REJECT ─────────────────

describe('approveDiscountRule (maker-checker)', () => {
  it('pembuat tidak boleh menyetujui aturannya sendiri', async () => {
    const rule = await createDiscountRule(apoteker, {
      code: `SELF_APR_${Date.now()}`,
      name: 'Diskon Self-Approve',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
    });
    const e = await caught(approveDiscountRule(apoteker, { id: rule.id, action: 'APPROVE', notes: '' }));
    expect(e.code).toBe('FORBIDDEN');
  });

  it('apoteker lain dapat menyetujui aturan', async () => {
    const rule = await createDiscountRule(apoteker, {
      code: `APPROVE_OK_${Date.now()}`,
      name: 'Diskon Disetujui',
      scope: 'ALL',
      type: 'PERCENT',
      value: '15',
      min_qty_base: 1,
      ...futureRange(),
    });
    await approveDiscountRule(apoteker2, { id: rule.id, action: 'APPROVE', notes: '' });
    const updated = await getDiscountRuleById(owner, rule.id);
    expect(updated.status).toBe('APPROVED');
    expect(updated.approved_by).toBe(apoteker2.id);
  });

  it('apoteker dapat menolak aturan dengan catatan', async () => {
    const rule = await createDiscountRule(apoteker, {
      code: `REJECT_OK_${Date.now()}`,
      name: 'Diskon Ditolak',
      scope: 'ALL',
      type: 'PERCENT',
      value: '20',
      min_qty_base: 1,
      ...futureRange(),
    });
    await approveDiscountRule(apoteker2, { id: rule.id, action: 'REJECT', notes: 'Terlalu besar' });
    const updated = await getDiscountRuleById(owner, rule.id);
    expect(updated.status).toBe('REJECTED');
  });

  it('tidak bisa approve aturan yang bukan DRAFT', async () => {
    const rule = await createDiscountRule(apoteker, {
      code: `APR_TWICE_${Date.now()}`,
      name: 'Diskon Approve 2x',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
    });
    await approveDiscountRule(apoteker2, { id: rule.id, action: 'APPROVE', notes: '' });
    const e = await caught(approveDiscountRule(owner, { id: rule.id, action: 'APPROVE', notes: '' }));
    expect(e.code).toBe('INVALID_STATE_TRANSITION');
  });
});

// ─────────────────────────── CANCEL ───────────────────────────

describe('cancelDiscountRule', () => {
  it('pembuat dapat membatalkan aturan DRAFT miliknya', async () => {
    const rule = await createDiscountRule(apoteker, {
      code: `CANCEL_${Date.now()}`,
      name: 'Diskon Dibatalkan',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
    });
    await cancelDiscountRule(apoteker, rule.id);
    const updated = await getDiscountRuleById(owner, rule.id);
    expect(updated.status).toBe('CANCELLED');
  });

  it('apoteker lain tidak boleh membatalkan aturan orang lain', async () => {
    const rule = await createDiscountRule(apoteker, {
      code: `CANCEL_OTHER_${Date.now()}`,
      name: 'Diskon Bukan Milikku',
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
      ...futureRange(),
    });
    const e = await caught(cancelDiscountRule(apoteker2, rule.id));
    expect(e.code).toBe('FORBIDDEN');
  });
});

// ─────────────────────────── LIST ─────────────────────────────

describe('listDiscountRules', () => {
  it('dapat memfilter berdasarkan status', async () => {
    // Buat 1 aturan dan setujui
    await createAndApprove(apoteker, apoteker2, { code: `LIST_APR_${Date.now()}` });

    const result = await listDiscountRules(owner, { status: 'APPROVED' });
    expect(result.items.length).toBeGreaterThan(0);
    expect(result.items.every((r: { status: string }) => r.status === 'APPROVED')).toBe(true);
  });

  it('dapat memfilter berdasarkan scope', async () => {
    await createAndApprove(apoteker, apoteker2, {
      code: `LIST_MED_${Date.now()}`,
      scope: 'MEDICINE',
      medicine_id: medicineId,
    });
    const result = await listDiscountRules(owner, { scope: 'MEDICINE' });
    expect(result.items.every((r: { scope: string }) => r.scope === 'MEDICINE')).toBe(true);
  });
});

// ─────────────────────────── RESOLVE DISCOUNT ─────────────────

describe('resolveApplicableDiscount', () => {
  it('mengembalikan diskon MEDICINE jika lebih spesifik dari ALL', async () => {
    // Buat dan approve aturan ALL 5%
    await createAndApprove(apoteker, apoteker2, {
      code: `RESOLVE_ALL_${Date.now()}`,
      scope: 'ALL',
      type: 'PERCENT',
      value: '5',
      min_qty_base: 1,
    });

    // Buat dan approve aturan MEDICINE 20%
    const medRule = await createDiscountRule(apoteker, {
      code: `RESOLVE_MED_${Date.now()}`,
      name: 'Diskon Obat Spesifik',
      scope: 'MEDICINE',
      medicine_id: medicineId,
      type: 'PERCENT',
      value: '20',
      min_qty_base: 1,
      ...activeRange(),
    });
    await approveDiscountRule(apoteker2, { id: medRule.id, action: 'APPROVE', notes: '' });

    const result = await prisma.$transaction(async (tx) => {
      return resolveApplicableDiscount(tx, {
        medicine_id:  medicineId,
        category_id:  categoryId,
        qty_base:     5,
        at:           new Date(),
      });
    });

    expect(result).not.toBeNull();
    expect(result?.rule_id).toBe(medRule.id);
    expect(result?.type).toBe('PERCENT');
    expect(parseFloat(result?.value ?? '0')).toBe(20);
  });

  it('mengembalikan null jika tidak ada aturan aktif yang cocok', async () => {
    const result = await prisma.$transaction(async (tx) => {
      return resolveApplicableDiscount(tx, {
        medicine_id: '00000000-0000-7000-8000-000000000001',
        category_id: '00000000-0000-7000-8000-000000000002',
        qty_base:    999,
        at:          new Date('2000-01-01'), // jauh di masa lalu
      });
    });
    expect(result).toBeNull();
  });

  it('min_qty_base dihormati — tidak cocok jika qty kurang', async () => {
    // Buat aturan min_qty_base = 100
    const rule = await createDiscountRule(apoteker, {
      code: `MINQTY_${Date.now()}`,
      name: 'Diskon Min 100 Unit',
      scope: 'ALL',
      type: 'PERCENT',
      value: '30',
      min_qty_base: 100,
      ...activeRange(),
    });
    await approveDiscountRule(apoteker2, { id: rule.id, action: 'APPROVE', notes: '' });

    const result = await prisma.$transaction(async (tx) => {
      return resolveApplicableDiscount(tx, {
        medicine_id: medicineId,
        category_id: categoryId,
        qty_base:    5, // kurang dari 100
        at:          new Date(),
      });
    });

    // Aturan 30%/min100 tidak boleh muncul; mungkin ada aturan lain lebih rendah
    if (result !== null) {
      expect(result.rule_id).not.toBe(rule.id);
    }
  });
});
