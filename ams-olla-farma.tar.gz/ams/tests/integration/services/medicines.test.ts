import { beforeAll, describe, expect, it } from 'vitest';
import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import {
  createMedicine, getMedicine, listMedicines, removeConversion, saveConversion, setMedicineActive, updateMedicine,
} from '@/modules/medicines/service';
import { actorFor, caught, unitId } from '../helpers';

let owner: Actor, apoteker: Actor, ttk: Actor, kasir: Actor;
let TAB: string, BOX: string, STRIP: string;

const base = () => ({
  name: 'Paracetamol 500 mg', generic_name: 'Parasetamol', product_type: 'OTC', drug_class: 'BEBAS',
  registration_no: 'DBL1234567890A1', base_unit_id: TAB, purchase_unit_id: TAB, sales_unit_id: TAB,
  selling_price: '500', default_purchase_price: '40.000', min_stock: '100', max_stock: '',
});

beforeAll(async () => {
  owner = await actorFor('owner.test', ['OWNER']);
  apoteker = await actorFor('apt.uji', ['APOTEKER']);
  ttk = await actorFor('ttk.uji', ['TTK']);
  kasir = await actorFor('kasir.uji', ['KASIR']);
  [TAB, BOX, STRIP] = await Promise.all([unitId('TAB'), unitId('BOX'), unitId('STRIP')]);
});

describe('membuat obat', () => {
  it('Pemilik: SKU otomatis, aktif, harga awal masuk riwayat, audit tercatat', async () => {
    const { id, activeNote } = await createMedicine({ ...base(), barcode: '8991234567890' }, owner);
    const m = await prisma.medicine.findUniqueOrThrow({ where: { id }, include: { price_history: true } });
    expect(m.sku).toMatch(/^OBT-\d{6}$/);
    expect(m.is_active).toBe(true);
    expect(activeNote).toBeNull();
    expect(m.default_purchase_price?.toString()).toBe('40000');
    expect(m.price_history.length).toBe(2);
    expect(m.price_history.every((h) => h.changed_by === owner.id)).toBe(true);
    expect(await prisma.auditLog.count({ where: { action: 'medicine.created', entity_id: id } })).toBe(1);
  });

  it('TTK: harga diabaikan, obat disimpan nonaktif sampai apoteker mengisi harga', async () => {
    const { id, activeNote } = await createMedicine({ ...base(), name: 'Antasida Doen', registration_no: 'DBL0000000001' }, ttk);
    const m = await prisma.medicine.findUniqueOrThrow({ where: { id } });
    expect(m.is_active).toBe(false);
    expect(m.selling_price.toString()).toBe('0');
    expect(m.default_purchase_price).toBeNull();
    expect(activeNote).toContain('NONAKTIF');
    expect((await caught(setMedicineActive(id, true, ttk))).message).toContain('harga jual');
  });

  it('narkotika hanya bisa didaftarkan apoteker', async () => {
    const narc = { ...base(), name: 'Kodein 10 mg', product_type: 'PRESCRIPTION_DRUG', drug_class: 'NARKOTIKA', requires_prescription: 'on', registration_no: 'DKL1111111111' };
    expect((await caught(createMedicine(narc, ttk))).code).toBe('FORBIDDEN');
    const { id } = await createMedicine(narc, apoteker);
    expect((await prisma.medicine.findUniqueOrThrow({ where: { id } })).drug_class).toBe('NARKOTIKA');
  });

  it('aturan regulasi memberi pesan per field', async () => {
    const e1 = await caught(createMedicine({ ...base(), product_type: 'PRESCRIPTION_DRUG', drug_class: 'KERAS' }, owner));
    expect(e1.fields?.requires_prescription).toContain('wajib resep');
    const e2 = await caught(createMedicine({ ...base(), registration_no: '' }, owner));
    expect(e2.fields?.registration_no).toContain('izin edar');
    const e3 = await caught(createMedicine({ ...base(), sales_unit_id: BOX }, owner));
    expect(e3.fields?.sales_unit_id).toContain('konversi');
  });

  it('barcode duplikat ditolak dengan pesan yang jelas (dari constraint database)', async () => {
    const e = await caught(createMedicine({ ...base(), name: 'Lain', barcode: '8991234567890' }, owner));
    expect(e.code).toBe('VALIDATION_ERROR');
    expect(e.fields?.barcode).toContain('sudah dipakai');
  });

  it('kasir tidak bisa membuat obat', async () => {
    expect((await caught(createMedicine(base(), kasir))).code).toBe('FORBIDDEN');
  });
});

describe('mengubah obat', () => {
  let id: string;
  beforeAll(async () => {
    id = (await createMedicine({ ...base(), name: 'Amoksisilin 500 mg', product_type: 'PRESCRIPTION_DRUG', drug_class: 'KERAS', requires_prescription: 'on', registration_no: 'DKL2222222222', selling_price: '1500', default_purchase_price: '' }, apoteker)).id;
  });

  it('ubah harga wajib alasan; alasan tersimpan di riwayat', async () => {
    const form = { ...base(), name: 'Amoksisilin 500 mg', product_type: 'PRESCRIPTION_DRUG', drug_class: 'KERAS', requires_prescription: 'on', registration_no: 'DKL2222222222', default_purchase_price: '' };
    expect((await caught(updateMedicine(id, { ...form, selling_price: '1700' }, apoteker))).fields?.price_reason).toBeDefined();
    await updateMedicine(id, { ...form, selling_price: '1700', price_reason: 'Harga PBF naik' }, apoteker);
    const h = await prisma.medicinePriceHistory.findFirstOrThrow({ where: { medicine_id: id, new_price: 1700 } });
    expect(h.reason).toBe('Harga PBF naik');
    expect(h.old_price?.toString()).toBe('1500');
  });

  it('nilai harga yang sama dengan format berbeda bukan perubahan', async () => {
    const form = { ...base(), name: 'Amoksisilin 500 mg', product_type: 'PRESCRIPTION_DRUG', drug_class: 'KERAS', requires_prescription: 'on', registration_no: 'DKL2222222222', default_purchase_price: '', selling_price: '1.700,00' };
    const before = await prisma.medicinePriceHistory.count({ where: { medicine_id: id } });
    await updateMedicine(id, form, apoteker);
    expect(await prisma.medicinePriceHistory.count({ where: { medicine_id: id } })).toBe(before);
  });

  it('TTK tidak bisa mengubah golongan, dan perubahan harga dari TTK diabaikan', async () => {
    const form = { ...base(), name: 'Amoksisilin 500 mg', product_type: 'PRESCRIPTION_DRUG', drug_class: 'KERAS', requires_prescription: 'on', registration_no: 'DKL2222222222', default_purchase_price: '' };
    expect((await caught(updateMedicine(id, { ...form, is_owa: 'on', requires_prescription: '' }, ttk))).code).toBe('FORBIDDEN');
    await updateMedicine(id, { ...form, selling_price: '1', min_stock: '50' }, ttk);
    const m = await prisma.medicine.findUniqueOrThrow({ where: { id } });
    expect(m.selling_price.toString()).toBe('1700');
    expect(m.min_stock).toBe(50);
  });
});

describe('konversi satuan', () => {
  it('strip dan box: satuan jual hanya bisa dipakai setelah ada konversinya, dan tidak bisa dihapus selama dipakai', async () => {
    const { id } = await createMedicine({ ...base(), name: 'Vitamin C 500 mg', product_type: 'VITAMIN', drug_class: 'BEBAS', registration_no: 'DBL3333333333', barcode: '8990000000001' }, owner);
    await saveConversion(id, { unit_id: STRIP, factor_to_base: '10', barcode: '8990000000002', selling_price: '4500' }, owner);
    await saveConversion(id, { unit_id: BOX, factor_to_base: '100', barcode: '8990000000003' }, owner);
    await updateMedicine(id, { ...base(), name: 'Vitamin C 500 mg', product_type: 'VITAMIN', drug_class: 'BEBAS', registration_no: 'DBL3333333333', barcode: '8990000000001', sales_unit_id: STRIP, purchase_unit_id: BOX }, owner);
    const m = await getMedicine(id, owner);
    expect(m.conversions.map((c) => [c.unit.code, c.factor_to_base])).toEqual([['STRIP', 10], ['BOX', 100]]);
    const stripId = m.conversions[0].id;
    expect((await caught(removeConversion(id, stripId, owner))).message).toContain('satuan beli atau jual');
    expect((await caught(saveConversion(id, { unit_id: TAB, factor_to_base: '5' }, owner))).fields?.unit_id).toContain('Satuan dasar');
    expect((await caught(saveConversion(id, { unit_id: (await unitId('BTL')), factor_to_base: '5', barcode: '8991234567890' }, owner))).fields?.barcode).toContain('sudah dipakai');
  });
});

describe('daftar dan pencarian', () => {
  it('cari berdasarkan nama generik, barcode satuan, dan SKU; kasir tidak melihat harga pokok', async () => {
    expect((await listMedicines({ q: 'parasetamol' }, kasir)).items.map((i) => i.name)).toContain('Paracetamol 500 mg');
    expect((await listMedicines({ q: '8990000000002' }, kasir)).items.map((i) => i.name)).toEqual(['Vitamin C 500 mg']);
    const anySku = (await prisma.medicine.findFirstOrThrow({ where: { name: 'Vitamin C 500 mg' } })).sku;
    expect((await listMedicines({ q: anySku.toLowerCase() }, kasir)).total).toBe(1);
    expect((await listMedicines({}, kasir)).showCost).toBe(false);
    const detail = await getMedicine((await prisma.medicine.findFirstOrThrow({ where: { name: 'Paracetamol 500 mg' } })).id, kasir);
    expect(detail.default_purchase_price).toBeNull();
    expect(detail.price_history.some((h) => h.price_type === 'PURCHASE_DEFAULT')).toBe(false);
  });

  it('status nonaktif tersaring; gudang tanpa izin lihat obat ditolak', async () => {
    expect((await listMedicines({ status: 'nonaktif' }, owner)).items.map((i) => i.name)).toContain('Antasida Doen');
    expect((await listMedicines({ status: 'aktif' }, owner)).items.map((i) => i.name)).not.toContain('Antasida Doen');
    const nobody: Actor = { ...kasir, permissions: new Set() };
    expect((await caught(listMedicines({}, nobody))).code).toBe('FORBIDDEN');
  });
});
