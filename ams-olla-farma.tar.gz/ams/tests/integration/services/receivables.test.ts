/**
 * Integration tests: Fase 7 — Piutang Pelanggan
 *
 * Menguji: createReceivableInTx, recordReceivablePayment, writeOffReceivable,
 *           listReceivables, getReceivable, getAgingReport.
 */

import { beforeAll, describe, expect, it } from 'vitest';
import { Prisma } from '@/generated/prisma/client';
import { prisma } from '@/lib/database/client';
import type { Actor } from '@/lib/auth/actor';
import {
  createReceivableInTx,
  recordReceivablePayment,
  writeOffReceivable,
  listReceivables,
  getReceivable,
  getAgingReport,
} from '@/modules/receivables/service';
import { actorFor, caught } from '../helpers';

let owner: Actor, apoteker: Actor, kasir: Actor;
let customerId: string;
let sessionId: string;

// ─────────────────────────── Setup ────────────────────────────

beforeAll(async () => {
  owner    = await actorFor('owner.rcv',   ['OWNER']);
  apoteker = await actorFor('apt.rcv',     ['APOTEKER']);
  kasir    = await actorFor('kasir.rcv',   ['KASIR']);

  // Buat pelanggan uji
  let cust = await prisma.customer.findFirst({ where: { name: 'Pelanggan Piutang Uji' } });
  cust ??= await prisma.customer.create({
    data: {
      code:         `CR${Date.now().toString().slice(-8)}`,
      name: 'Pelanggan Piutang Uji',
      phone: '081200000001',
      address: 'Jl. Uji No. 1',
      credit_limit: new Prisma.Decimal(5_000_000),
      credit_used:  new Prisma.Decimal(5_000_000),
      is_active:    true,
    },
  });
  customerId = cust.id;

  // Buat SaleSession untuk kasir (reuse jika sudah ada)
  let sess = await prisma.saleSession.findFirst({
    where: { cashier_id: kasir.id, status: 'OPEN' },
  });
  sess ??= await prisma.saleSession.create({
    data: {
      session_no:   `SES-RCV-${Date.now()}`,
      cashier_id:   kasir.id,
      status:       'OPEN',
      opening_cash: new Prisma.Decimal(0),
    },
  });
  sessionId = sess.id;
});

// ─────────────────────────── Helpers ──────────────────────────

/** Buat piutang minimal melalui createReceivableInTx di dalam transaksi. */
async function makeReceivable(amount: number, overdueDays = 0) {
  const suffix = Math.random().toString(36).slice(2, 6);

  // Buat sale dummy (pakai sessionId dari beforeAll)
  const sale = await prisma.sale.create({
    data: {
      id: crypto.randomUUID(),
      invoice_no: `INV-RCV-${Date.now()}-${suffix}`,
      session_id:  sessionId,
      customer_id: customerId,
      cashier_id:  kasir.id,
      payment_method: 'RECEIVABLE',
      subtotal:       new Prisma.Decimal(amount),
      discount_amount: new Prisma.Decimal(0),
      total_amount:   new Prisma.Decimal(amount),
      amount_paid:    new Prisma.Decimal(0),
      change_given:   new Prisma.Decimal(0),
      notes: null,
    },
  });

  const saleDate = overdueDays > 0
    ? new Date(Date.now() - 86_400_000 * (overdueDays + 30)) // pastikan jatuh tempo sudah lewat
    : new Date();

  const receivableId = await prisma.$transaction(async (tx) => {
    return createReceivableInTx(tx, {
      sale_id:     sale.id,
      customer_id: customerId,
      amount:      new Prisma.Decimal(amount),
      sale_date:   saleDate,
    });
  });

  // Jika overdue, paksa update due_date ke masa lalu
  if (overdueDays > 0) {
    await prisma.customerReceivable.update({
      where: { id: receivableId },
      data: { due_date: new Date(Date.now() - 86_400_000 * overdueDays) },
    });
  }

  return receivableId;
}

// ─────────────────────────── CREATE ───────────────────────────

describe('createReceivableInTx', () => {
  it('membuat piutang OPEN dengan due_date +30 hari', async () => {
    const id = await makeReceivable(100_000);
    const r = await prisma.customerReceivable.findUniqueOrThrow({ where: { id } });
    expect(r.status).toBe('OPEN');
    expect(Number(r.paid_amount)).toBe(0);

    const expectedDue = new Date(Date.now() + 86_400_000 * 30);
    // Toleransi 2 hari untuk offset jam
    const diffDays = Math.abs(r.due_date.getTime() - expectedDue.getTime()) / 86_400_000;
    expect(diffDays).toBeLessThan(2);
  });
});

// ─────────────────────────── RECORD PAYMENT ───────────────────

describe('recordReceivablePayment', () => {
  it('pembayaran parsial mengubah status ke PARTIAL', async () => {
    const id = await makeReceivable(200_000);
    const result = await recordReceivablePayment(apoteker, {
      receivable_id: id,
      amount: '50000',
    });
    expect(result.status).toBe('PARTIAL');
    expect(result.payment_no).toMatch(/^BPR\//);

    const r = await prisma.customerReceivable.findUniqueOrThrow({ where: { id } });
    expect(Number(r.paid_amount)).toBe(50_000);
  });

  it('pembayaran lunas mengubah status ke PAID', async () => {
    const id = await makeReceivable(150_000);
    const result = await recordReceivablePayment(apoteker, {
      receivable_id: id,
      amount: '150000',
    });
    expect(result.status).toBe('PAID');

    const r = await prisma.customerReceivable.findUniqueOrThrow({ where: { id } });
    expect(r.status).toBe('PAID');
  });

  it('pembayaran melebihi sisa ditolak', async () => {
    const id = await makeReceivable(100_000);
    const e = await caught(recordReceivablePayment(apoteker, {
      receivable_id: id,
      amount: '999999',
    }));
    expect(e.code).toBe('VALIDATION_ERROR');
  });

  it('tidak bisa bayar piutang PAID', async () => {
    const id = await makeReceivable(50_000);
    // Lunas dulu
    await recordReceivablePayment(apoteker, { receivable_id: id, amount: '50000' });
    // Bayar lagi
    const e = await caught(recordReceivablePayment(apoteker, {
      receivable_id: id,
      amount: '1000',
    }));
    expect(e.code).toBe('INVALID_STATE_TRANSITION');
  });

  it('kasir tidak boleh mencatat pembayaran', async () => {
    const id = await makeReceivable(75_000);
    const e = await caught(recordReceivablePayment(kasir, {
      receivable_id: id,
      amount: '75000',
    }));
    expect(e.code).toBe('FORBIDDEN');
  });

  it('payment_no format BPR/YYYYMM/NNNNN', async () => {
    const id = await makeReceivable(60_000);
    const result = await recordReceivablePayment(owner, {
      receivable_id: id,
      amount: '60000',
    });
    expect(result.payment_no).toMatch(/^BPR\/\d{6}\/\d{5}$/);
  });
});

// ─────────────────────────── WRITE OFF ────────────────────────

describe('writeOffReceivable', () => {
  it('apoteker dapat menghapus piutang OPEN', async () => {
    const id = await makeReceivable(80_000);
    await writeOffReceivable(apoteker, { id, notes: 'Pelanggan tidak bisa dihubungi' });
    const r = await prisma.customerReceivable.findUniqueOrThrow({ where: { id } });
    expect(r.status).toBe('WRITTEN_OFF');
  });

  it('tidak bisa hapus piutang PAID', async () => {
    const id = await makeReceivable(40_000);
    await recordReceivablePayment(apoteker, { receivable_id: id, amount: '40000' });
    const e = await caught(writeOffReceivable(apoteker, { id }));
    expect(e.code).toBe('INVALID_STATE_TRANSITION');
  });

  it('kasir tidak boleh write-off', async () => {
    const id = await makeReceivable(55_000);
    const e = await caught(writeOffReceivable(kasir, { id }));
    expect(e.code).toBe('FORBIDDEN');
  });
});

// ─────────────────────────── LIST ─────────────────────────────

describe('listReceivables', () => {
  it('dapat memfilter berdasarkan status OPEN', async () => {
    await makeReceivable(10_000);
    const result = await listReceivables(owner, { status: 'OPEN', page: 1, pageSize: 50 });
    expect(result.items.length).toBeGreaterThan(0);
    expect(result.items.every((r: { status: string }) => r.status === 'OPEN')).toBe(true);
  });

  it('kasir tidak boleh list', async () => {
    const e = await caught(listReceivables(kasir, {}));
    expect(e.code).toBe('FORBIDDEN');
  });
});

// ─────────────────────────── GET ──────────────────────────────

describe('getReceivable', () => {
  it('mengembalikan detail piutang dengan riwayat pembayaran', async () => {
    const id = await makeReceivable(300_000);
    await recordReceivablePayment(apoteker, { receivable_id: id, amount: '100000', reference: 'TRF001' });

    const detail = await getReceivable(owner, id);
    expect(detail.id).toBe(id);
    expect(detail.payments.length).toBe(1);
    expect(detail.payments[0].reference).toBe('TRF001');
  });

  it('NOT_FOUND untuk ID yang tidak ada', async () => {
    const e = await caught(getReceivable(owner, '00000000-0000-7000-8000-000000000099'));
    expect(e.code).toBe('NOT_FOUND');
  });
});

// ─────────────────────────── AGING ────────────────────────────

describe('getAgingReport', () => {
  it('mengembalikan 4 bucket aging', async () => {
    // Buat piutang overdue di berbagai bucket
    await makeReceivable(10_000, 15);  // 1-30 hari
    await makeReceivable(20_000, 45);  // 31-60 hari
    await makeReceivable(30_000, 75);  // 61-90 hari
    await makeReceivable(40_000, 100); // >90 hari

    const report = await getAgingReport(owner);
    expect(report.buckets.length).toBe(4);
    // Setiap bucket punya label & total
    for (const b of report.buckets) {
      expect(b).toHaveProperty('label');
      expect(b).toHaveProperty('count');
      expect(b).toHaveProperty('total_amount');
      expect(b).toHaveProperty('total_remaining');
    }

    // Bucket >90 harus ada isinya
    const over90 = report.buckets.find((b: { label: string }) => b.label.includes('90'));
    expect(over90).toBeDefined();
    expect(over90!.count).toBeGreaterThan(0);
  });

  it('kasir tidak boleh lihat aging', async () => {
    const e = await caught(getAgingReport(kasir));
    expect(e.code).toBe('FORBIDDEN');
  });
});
