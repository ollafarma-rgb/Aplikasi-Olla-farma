import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';

/** Buat ulang database ams_it sekali sebelum seluruh uji integrasi. */
export default function setup() {
  execFileSync('bash', [resolve(__dirname, '../../scripts/prepare-db.sh'), 'ams_it'], { stdio: 'inherit' });
}
