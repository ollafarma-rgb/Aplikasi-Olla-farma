import { expect, Browser, BrowserContext, Page, test } from '@playwright/test';

/**
 * E2E Fase 4 — persediaan: saldo awal, kartu stok, penyesuaian (maker-checker),
 * stok opname, dan laporan stok menipis. Owner membuat, apoteker menyetujui.
 */
const OWNER = { username: 'owner.test', password: 'Uji-Sandi-Owner-2026' };
const NEW_PASSWORD = 'Hijau-Daun-Kopi-7';
const APT = { username: 'apt.e2e.inv', password: 'Apoteker-Inv-2026x' };
const NIE = 'DBLE2EINV0001';
const MED = 'E2E Stok Amoxicillin';

async function selectByText(page: Page, selectName: string, text: string) {
  const value = await page.locator(`select[name="${selectName}"] option`, { hasText: text }).first().getAttribute('value');
  if (!value) throw new Error(`opsi "${text}" tak ditemukan di ${selectName}`);
  await page.selectOption(`select[name="${selectName}"]`, value);
}

async function loginOwner(page: Page) {
  await page.goto('/login');
  await page.getByLabel('Nama pengguna').fill(OWNER.username);
  await page.getByLabel('Kata sandi', { exact: true }).fill(NEW_PASSWORD);
  await page.getByRole('button', { name: 'Masuk' }).click();
  await page.waitForLoadState('networkidle');
  if (/\/login/.test(page.url())) {
    await page.getByLabel('Nama pengguna').fill(OWNER.username);
    await page.getByLabel('Kata sandi', { exact: true }).fill(OWNER.password);
    await page.getByRole('button', { name: 'Masuk' }).click();
    await expect(page).toHaveURL(/ganti-sandi/);
    await page.getByLabel('Kata sandi lama').fill(OWNER.password);
    await page.getByLabel('Kata sandi baru', { exact: true }).fill(NEW_PASSWORD);
    await page.getByLabel('Ulangi kata sandi baru').fill(NEW_PASSWORD);
    await page.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
  }
  await expect(page).toHaveURL(/dashboard/);
}

test.describe.serial('persediaan fase 4', () => {
  let ownerCtx: BrowserContext, aptCtx: BrowserContext;
  let owner: Page, apt: Page;

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    ownerCtx = await browser.newContext();
    owner = await ownerCtx.newPage();
    owner.on('dialog', (d) => d.accept());
    await loginOwner(owner);

    // Buat obat uji (BEBAS/OTC, min stok tinggi agar tampil "menipis").
    await owner.goto('/obat/baru');
    await owner.getByLabel('Nama obat / produk').fill(MED);
    await owner.getByLabel('Nama generik').fill('Amoksisilin');
    await owner.getByLabel('Nomor izin edar (NIE)').fill(NIE);
    await owner.getByLabel('Jenis produk').selectOption({ label: 'Obat bebas (OTC)' });
    await owner.getByLabel('Golongan').selectOption({ label: 'Obat bebas' });
    await owner.getByLabel(/Satuan dasar/).selectOption({ label: 'TAB — Tablet' });
    await owner.getByLabel('Satuan beli', { exact: true }).selectOption({ label: 'TAB — Tablet' });
    await owner.getByLabel('Satuan jual', { exact: true }).selectOption({ label: 'TAB — Tablet' });
    await owner.getByLabel(/Harga jual per satuan dasar/).fill('2500');
    await owner.getByLabel(/Harga beli acuan/).fill('1800');
    await owner.getByLabel('Alasan perubahan harga').fill('Harga awal');
    await owner.getByLabel('Stok minimum').fill('500');
    await owner.getByRole('button', { name: /Simpan/ }).click();
    await expect(owner).toHaveURL(/\/obat\/[0-9a-f-]+/);

    // Buat akun apoteker untuk peran penyetuju.
    await owner.goto('/karyawan/baru');
    await owner.getByLabel(/Nama pengguna/).fill(APT.username);
    await owner.getByLabel('Nama lengkap').fill('Apoteker E2E Inv');
    await owner.getByLabel('Apoteker', { exact: true }).check();
    await owner.getByRole('button', { name: 'Buat akun' }).click();
    const temp = (await owner.getByTestId('temporary-password').innerText()).trim();

    aptCtx = await browser.newContext();
    apt = await aptCtx.newPage();
    apt.on('dialog', (d) => d.accept());
    await apt.goto('/login');
    await apt.getByLabel('Nama pengguna').fill(APT.username);
    await apt.getByLabel('Kata sandi', { exact: true }).fill(temp);
    await apt.getByRole('button', { name: 'Masuk' }).click();
    await expect(apt).toHaveURL(/ganti-sandi/);
    await apt.getByLabel('Kata sandi lama').fill(temp);
    await apt.getByLabel('Kata sandi baru', { exact: true }).fill(APT.password);
    await apt.getByLabel('Ulangi kata sandi baru').fill(APT.password);
    await apt.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
    await expect(apt).toHaveURL(/dashboard/);
  });

  test.afterAll(async () => { await ownerCtx.close(); await aptCtx.close(); });

  test('saldo awal menambah stok dan tercatat di kartu stok', async () => {
    await owner.goto('/persediaan/saldo-awal');
    await selectByText(owner, 'medicine_id', MED);
    await owner.getByLabel('Nomor batch').fill('B-E2E-1');
    await owner.getByLabel('Tanggal kedaluwarsa').fill('2027-12-31');
    await owner.getByLabel(/Jumlah/).fill('100');
    await owner.getByLabel(/HPP per satuan/).fill('1800');
    await owner.getByRole('button', { name: 'Catat saldo awal' }).click();
    await expect(owner.getByText(/Saldo awal SALDO-/)).toBeVisible();
    await owner.getByRole('link', { name: /Lihat kartu stok obat/ }).click();
    await expect(owner.getByRole('cell', { name: 'B-E2E-1' }).first()).toBeVisible();
    await expect(owner.getByText('Saldo awal').first()).toBeVisible();
  });

  test('stok menipis muncul di filter persediaan', async () => {
    await owner.goto('/persediaan');
    await owner.getByLabel('Cari obat').fill('E2E Stok Amoxicillin');
    await owner.getByLabel('Tampilan').selectOption('menipis');
    await owner.getByRole('button', { name: 'Cari' }).click();
    await expect(owner.getByRole('link', { name: new RegExp(MED) })).toBeVisible();
    await expect(owner.getByText(/Menipis/).first()).toBeVisible();
  });

  test('penyesuaian: pembuat tak bisa setujui sendiri, apoteker menyetujui & stok berkurang', async () => {
    test.setTimeout(60_000);
    // Owner membuat draf penyesuaian -10 untuk obat uji.
    await owner.goto('/penyesuaian/baru');
    await selectByText(owner, 'medicine', MED);
    await owner.getByRole('button', { name: 'Lanjut' }).click();
    await expect(owner.getByText(/B-E2E-1/)).toBeVisible();
    // Baris batch: isi selisih -10 (input number pertama di tabel)
    await owner.locator('input[name^="delta_"]').first().fill('-10');
    await owner.getByRole('button', { name: /Buat draf penyesuaian/ }).click();
    await owner.getByRole('link', { name: 'Lihat draf' }).click();
    await owner.waitForURL(/\/penyesuaian\/[0-9a-f]{8}-[0-9a-f]{4}-/);
    // Owner adalah pembuat → tidak boleh menyetujui sendiri.
    await expect(owner.getByText(/tidak bisa menyetujuinya sendiri/)).toBeVisible();
    const url = owner.url();

    // Apoteker menyetujui.
    await apt.goto(url);
    await apt.getByRole('button', { name: /Setujui/ }).click();
    await expect(apt.getByText(/Disetujui/).first()).toBeVisible();

    // Stok berkurang 100 → 90.
    await owner.goto('/persediaan');
    await owner.getByLabel('Cari obat').fill('E2E Stok Amoxicillin');
    await owner.getByRole('button', { name: 'Cari' }).click();
    await owner.getByRole('link', { name: new RegExp(MED) }).click();
    await expect(owner.getByRole('cell', { name: '90', exact: true })).toBeVisible();
  });

  test('opname: hitung selisih, apoteker posting mengoreksi stok', async () => {
    test.setTimeout(60_000);
    await owner.goto('/opname/baru');
    await selectByText(owner, 'medicine_id', MED);
    await owner.getByRole('button', { name: 'Mulai opname' }).click();
    await owner.getByRole('link', { name: 'Mulai menghitung' }).click();
    await owner.waitForURL(/\/opname\/[0-9a-f]{8}-[0-9a-f]{4}-/);
    const url = owner.url();
    // Hitung fisik 80 (sistem 90) → selisih -10.
    await owner.locator('input[name^="count_"]').first().fill('80');
    await owner.getByRole('button', { name: 'Simpan hasil hitung' }).click();
    await expect(owner.getByText('Hasil hitung tersimpan.')).toBeVisible();
    // Owner pembuat → tak bisa posting sendiri.
    await expect(owner.getByText(/tidak bisa memposting sendiri/)).toBeVisible();

    await apt.goto(url);
    await apt.getByRole('button', { name: /Posting/ }).click();
    await expect(apt.getByText(/Selesai/).first()).toBeVisible();

    await owner.goto('/persediaan');
    await owner.getByLabel('Cari obat').fill('E2E Stok Amoxicillin');
    await owner.getByRole('button', { name: 'Cari' }).click();
    await owner.getByRole('link', { name: new RegExp(MED) }).click();
    await expect(owner.getByRole('cell', { name: '80', exact: true })).toBeVisible();
  });
});
