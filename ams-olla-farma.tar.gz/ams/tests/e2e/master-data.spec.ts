import { expect, Browser, BrowserContext, Page, test } from '@playwright/test';

/**
 * E2E Fase 3 — data master obat, konversi satuan, pencarian, riwayat harga,
 * dan manajemen karyawan + RBAC. Database tes di-seed dengan owner.test.
 * Owner login SEKALI lalu sesi dipakai bersama agar tidak kena rate limit login.
 */
const OWNER = { username: 'owner.test', password: 'Uji-Sandi-Owner-2026' };
const NEW_PASSWORD = 'Hijau-Daun-Kopi-7';
const BARCODE = '8991234000017';

async function loginOwner(page: Page) {
  await page.goto('/login');
  await page.getByLabel('Nama pengguna').fill(OWNER.username);
  await page.getByLabel('Kata sandi', { exact: true }).fill(NEW_PASSWORD);
  await page.getByRole('button', { name: 'Masuk' }).click();
  await page.waitForLoadState('networkidle');
  if (/\/login/.test(page.url())) {
    await page.getByLabel('Nama pengguna').fill(OWNER.username);
    await page.getByLabel('Kata sandi', { exact: true }).fill(OWNER.password);
    await page.getByRole('button', { name: 'Masuk' }).click();
    await expect(page).toHaveURL(/ganti-sandi/);
    await page.getByLabel('Kata sandi lama').fill(OWNER.password);
    await page.getByLabel('Kata sandi baru', { exact: true }).fill(NEW_PASSWORD);
    await page.getByLabel('Ulangi kata sandi baru').fill(NEW_PASSWORD);
    await page.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
  }
  await expect(page).toHaveURL(/dashboard/);
}

async function fillMedicine(page: Page, o: { name: string; generic: string; barcode: string; price: string }) {
  await page.getByLabel('Nama obat / produk').fill(o.name);
  await page.getByLabel('Nama generik').fill(o.generic);
  await page.getByLabel('Barcode satuan dasar').fill(o.barcode);
  await page.getByLabel('Nomor izin edar (NIE)').fill('DBL1234567890A1');
  await page.getByLabel('Jenis produk').selectOption({ label: 'Obat bebas (OTC)' });
  await page.getByLabel('Golongan').selectOption({ label: 'Obat bebas' });
  await page.getByLabel(/Satuan dasar/).selectOption({ label: 'TAB — Tablet' });
  await page.getByLabel('Satuan beli', { exact: true }).selectOption({ label: 'TAB — Tablet' });
  await page.getByLabel('Satuan jual', { exact: true }).selectOption({ label: 'TAB — Tablet' });
  await page.getByLabel(/Harga jual per satuan dasar/).fill(o.price);
  await page.getByLabel(/Harga beli acuan/).fill('800');
  await page.getByLabel('Alasan perubahan harga').fill('Harga awal');
}

test.describe.serial('data master fase 3', () => {
  let ctx: BrowserContext;
  let page: Page;

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    ctx = await browser.newContext();
    page = await ctx.newPage();
    await loginOwner(page);
  });
  test.afterAll(async () => { await ctx.close(); });

  test('owner membuat obat dengan harga awal', async () => {
    await page.goto('/obat/baru');
    await fillMedicine(page, { name: 'Parasetamol 500 mg', generic: 'Paracetamol', barcode: BARCODE, price: '1500' });
    await page.getByRole('button', { name: /Simpan/ }).click();
    await expect(page).toHaveURL(/\/obat\/[0-9a-f-]+/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Parasetamol 500 mg');
  });

  test('barcode ganda ditolak', async () => {
    await page.goto('/obat/baru');
    await fillMedicine(page, { name: 'Parasetamol Duplikat', generic: 'Paracetamol', barcode: BARCODE, price: '1600' });
    await page.getByRole('button', { name: /Simpan/ }).click();
    await expect(page.getByText(/sudah dipakai|sudah digunakan/i)).toBeVisible();
    await expect(page).toHaveURL(/\/obat\/baru/);
  });

  test('cari berdasarkan nama generik', async () => {
    await page.goto('/obat');
    await page.getByLabel('Cari obat').fill('paracetamol');
    await page.getByRole('button', { name: 'Cari' }).click();
    await expect(page.getByRole('link', { name: /Parasetamol 500 mg/ })).toBeVisible();
  });

  test('tambah konversi satuan dan ubah harga tercatat', async () => {
    await page.goto('/obat');
    await page.getByRole('link', { name: /Parasetamol 500 mg/ }).click();
    await expect(page).toHaveURL(/\/obat\/[0-9a-f-]+/);
    await page.getByLabel('Satuan', { exact: true }).selectOption({ label: 'BOX — Box' });
    await page.getByLabel(/Isi \(dalam TAB\)/).fill('100');
    await page.getByRole('button', { name: 'Simpan satuan' }).click();
    await expect(page.getByRole('cell', { name: 'BOX', exact: true })).toBeVisible();
    await page.getByLabel(/Harga jual per satuan dasar/).fill('1750');
    await page.getByLabel('Alasan perubahan harga').fill('Penyesuaian HPP November');
    await page.getByRole('button', { name: /Simpan perubahan/ }).click();
    await expect(page.getByText('Riwayat harga')).toBeVisible();
    await expect(page.getByText('Penyesuaian HPP November')).toBeVisible();
  });

  test('owner membuat kasir; kasir login, menu terbatas, tak bisa buka karyawan', async ({ browser }) => {
    await page.goto('/karyawan/baru');
    await page.getByLabel(/Nama pengguna/).fill('kasir.uji');
    await page.getByLabel('Nama lengkap').fill('Kasir Uji');
    await page.getByLabel('Kasir / Administrasi').check();
    await page.getByRole('button', { name: 'Buat akun' }).click();
    const temp = (await page.getByTestId('temporary-password').innerText()).trim();
    expect(temp).toMatch(/\w{4}-\w{4}-\w{4}/);

    const kctx = await browser.newContext();
    const kp = await kctx.newPage();
    await kp.goto('/login');
    await kp.getByLabel('Nama pengguna').fill('kasir.uji');
    await kp.getByLabel('Kata sandi', { exact: true }).fill(temp);
    await kp.getByRole('button', { name: 'Masuk' }).click();
    await expect(kp).toHaveURL(/ganti-sandi/);
    await kp.getByLabel('Kata sandi lama').fill(temp);
    await kp.getByLabel('Kata sandi baru', { exact: true }).fill('Kasir-Baru-2026x');
    await kp.getByLabel('Ulangi kata sandi baru').fill('Kasir-Baru-2026x');
    await kp.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
    await expect(kp).toHaveURL(/dashboard/);

    await expect(kp.getByRole('link', { name: 'Karyawan & Pengguna' })).toHaveCount(0);
    await kp.goto('/karyawan');
    await expect(kp).toHaveURL(/tidak-diizinkan|login/);
    await kctx.close();
  });
});
