import { expect, Browser, BrowserContext, Page, test } from '@playwright/test';

/**
 * E2E Fase 6 — penjualan & AP: Sesi Kasir -> POS -> Retur Penjualan
 * (maker-checker) -> Faktur Pembelian -> Pembayaran Utang.
 * Kasir berperan sebagai pelayan; apoteker sebagai penyetuju retur & pembuat faktur.
 */
const OWNER      = { username: 'owner.test',     password: 'Uji-Sandi-Owner-2026' };
const NEW_PASSWORD = 'Hijau-Daun-Kopi-7';
const KASIR_CRED  = { username: 'kasir.e2e.sales',   password: 'Kasir-Sales-2026x' };
const APT_CRED    = { username: 'apt.e2e.sales',      password: 'Apoteker-Sales-2026x' };
const SUPPLIER    = 'PBF E2E Penjualan';
const MED         = 'E2E Penjualan Paracetamol';
const NIE         = 'DBLE2ESALES0001';

// ─── helpers ─────────────────────────────────────────────────────────────────

async function selectByText(page: Page, selectName: string, text: string) {
  const value = await page
    .locator(`select[name="${selectName}"] option`, { hasText: text })
    .first()
    .getAttribute('value');
  if (!value) throw new Error(`opsi "${text}" tak ditemukan di ${selectName}`);
  await page.selectOption(`select[name="${selectName}"]`, value);
}

async function loginAs(page: Page, cred: { username: string; password: string }) {
  await page.goto('/login');
  await page.getByLabel('Nama pengguna').fill(cred.username);
  await page.getByLabel('Kata sandi', { exact: true }).fill(cred.password);
  await page.getByRole('button', { name: 'Masuk' }).click();
  await page.waitForURL(/dashboard|ganti-sandi/, { timeout: 8_000 }).catch(() => {});
}

async function loginOwner(page: Page) {
  await loginAs(page, { username: OWNER.username, password: NEW_PASSWORD });
  if (/\/login/.test(page.url())) {
    // pertama kali — ganti password
    await loginAs(page, OWNER);
    await expect(page).toHaveURL(/ganti-sandi/);
    await page.getByLabel('Kata sandi lama').fill(OWNER.password);
    await page.getByLabel('Kata sandi baru', { exact: true }).fill(NEW_PASSWORD);
    await page.getByLabel('Ulangi kata sandi baru').fill(NEW_PASSWORD);
    await page.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
  }
  await expect(page).toHaveURL(/dashboard/);
}

// ─── suite ───────────────────────────────────────────────────────────────────

test.describe.serial('penjualan & AP fase 6', () => {
  let ownerCtx:  BrowserContext;
  let kasirCtx:  BrowserContext;
  let aptCtx:    BrowserContext;
  let owner:     Page;
  let kasir:     Page;
  let apt:       Page;

  let sessionUrl: string;
  let saleUrl:    string;
  let retUrl:     string;
  let grUrl:      string;
  let invoiceUrl: string;

  // ── Setup: buat master data, stok awal, akun kasir & apoteker ─────────────
  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    test.setTimeout(180_000);

    ownerCtx = await browser.newContext();
    kasirCtx = await browser.newContext();
    aptCtx   = await browser.newContext();

    owner = await ownerCtx.newPage();
    kasir = await kasirCtx.newPage();
    apt   = await aptCtx.newPage();

    owner.on('dialog', (d) => d.accept());
    kasir.on('dialog', (d) => d.accept());
    apt.on('dialog', (d) => d.accept());

    await loginOwner(owner);

    // 1. Buat pemasok
    await owner.goto('/pemasok/baru');
    await owner.getByLabel('Nama pemasok (PBF)').fill(SUPPLIER);
    await owner.getByLabel('Termin pembayaran (hari)').fill('30');
    await owner.getByRole('button', { name: /Simpan/ }).click();
    await expect(owner).toHaveURL(/\/pemasok\/[0-9a-f-]+/);

    // 2. Buat obat uji (BEBAS/OTC, satuan dasar TAB)
    await owner.goto('/obat/baru');
    await owner.getByLabel('Nama obat / produk').fill(MED);
    await owner.getByLabel('Nomor izin edar (NIE)').fill(NIE);
    await selectByText(owner, 'product_type', 'OTC');
    await selectByText(owner, 'drug_class', 'Bebas');
    // satuan dasar TAB — pilih pertama yang tersedia jika belum ada
    const tabOption = owner.locator('select[name="base_unit_id"] option', { hasText: /TAB/i }).first();
    const tabVal = await tabOption.getAttribute('value');
    if (tabVal) {
      await owner.selectOption('select[name="base_unit_id"]', tabVal);
      await owner.selectOption('select[name="purchase_unit_id"]', tabVal);
      await owner.selectOption('select[name="sales_unit_id"]', tabVal);
    }
    await owner.getByLabel('Harga jual (per satuan dasar)').fill('1500');
    await owner.getByLabel('Harga beli acuan').fill('900');
    await owner.getByLabel('Stok minimum').fill('10');
    await owner.getByRole('button', { name: /Simpan/ }).click();
    await expect(owner).toHaveURL(/\/obat\/[0-9a-f-]+/);

    // 3. Stok awal 100 TAB
    await owner.goto('/persediaan/penyesuaian/baru');
    await owner.getByLabel('Cari obat').fill(MED);
    await owner.getByRole('option', { name: new RegExp(MED) }).first().click();
    await owner.locator('input[name^="qty_delta_"]').first().fill('100');
    await owner.locator('input[name^="batch_no_"]').first().fill('BS-E2E-001');
    await owner.locator('input[name^="expiry_date_"]').first().fill('2028-12-31');
    await owner.locator('input[name^="unit_cost_"]').first().fill('900');
    await owner.getByRole('button', { name: /Simpan draf/ }).click();
    // owner posting penyesuaian sendiri (APOTEKER/OWNER boleh)
    await owner.getByRole('button', { name: /Posting/ }).click();
    await expect(owner.getByText(/Diposting/)).toBeVisible({ timeout: 10_000 });

    // 4. Buat akun kasir e2e
    await owner.goto('/karyawan/baru');
    await owner.getByLabel('Username').fill(KASIR_CRED.username);
    await owner.getByLabel('Nama lengkap').fill('Kasir E2E Sales');
    await owner.getByLabel('Kata sandi', { exact: true }).fill(KASIR_CRED.password);
    await selectByText(owner, 'role', 'Kasir');
    await owner.getByRole('button', { name: /Simpan/ }).click();

    // 5. Buat akun apoteker e2e
    await owner.goto('/karyawan/baru');
    await owner.getByLabel('Username').fill(APT_CRED.username);
    await owner.getByLabel('Nama lengkap').fill('Apoteker E2E Sales');
    await owner.getByLabel('Kata sandi', { exact: true }).fill(APT_CRED.password);
    await selectByText(owner, 'role', 'Apoteker');
    await owner.getByRole('button', { name: /Simpan/ }).click();

    // Login kasir & apoteker
    await loginAs(kasir, KASIR_CRED);
    await expect(kasir).toHaveURL(/dashboard/);
    await loginAs(apt, APT_CRED);
    await expect(apt).toHaveURL(/dashboard/);
  });

  test.afterAll(async () => {
    await ownerCtx.close();
    await kasirCtx.close();
    await aptCtx.close();
  });

  // ── Sesi kasir ─────────────────────────────────────────────────────────────
  test('kasir membuka sesi kasir', async () => {
    test.setTimeout(30_000);

    await kasir.goto('/pos');
    // Jika tidak ada sesi aktif, muncul tombol buka sesi
    const bukaBtn = kasir.getByRole('button', { name: /Buka sesi/ });
    if (await bukaBtn.isVisible()) {
      await bukaBtn.click();
      await kasir.getByLabel('Saldo awal').fill('500000');
      await kasir.getByRole('button', { name: /Konfirmasi/ }).click();
    }
    // Simpan URL sesi
    await kasir.waitForURL(/\/pos/, { timeout: 10_000 });
    sessionUrl = kasir.url();
    await expect(kasir.getByText(/Sesi aktif|Sesi kasir/i)).toBeVisible();
  });

  // ── POS: buat penjualan ────────────────────────────────────────────────────
  test('kasir membuat transaksi penjualan', async () => {
    test.setTimeout(45_000);

    await kasir.goto('/pos/baru');
    // Tambahkan obat ke keranjang
    await kasir.getByLabel('Cari obat').fill(MED);
    await kasir.getByRole('option', { name: new RegExp(MED) }).first().click();
    // Set qty 2
    await kasir.locator('input[name^="qty_"]').first().fill('2');
    // Bayar tunai
    await kasir.getByRole('button', { name: /Bayar|Proses/ }).click();
    await kasir.getByLabel('Jumlah bayar').fill('5000');
    await kasir.getByRole('button', { name: /Konfirmasi|Bayar/ }).click();

    await kasir.waitForURL(/\/pos\/[0-9a-f-]+|struk/, { timeout: 15_000 });
    saleUrl = kasir.url();
    await expect(kasir.getByText(/Penjualan|Struk|TRJ-/i)).toBeVisible();
  });

  // ── Retur penjualan ───────────────────────────────────────────────────────
  test('kasir membuat draf retur penjualan', async () => {
    test.setTimeout(30_000);

    // Navigasi ke form retur
    await kasir.goto('/penjualan/retur/baru');
    // Cari nomor penjualan
    await kasir.getByLabel(/Nomor penjualan|Cari penjualan/).fill('TRJ-');
    await kasir.getByRole('option').first().click().catch(() => {});
    // Atau navigasi langsung dari detail penjualan
    await kasir.goto(saleUrl);
    await kasir.getByRole('link', { name: /Retur|Buat retur/ }).click();

    await kasir.locator('input[name^="qty_"]').first().fill('1');
    await kasir.locator('select[name^="disposition_"]').first().selectOption('RESTOCK').catch(() => {});
    await kasir.locator('input[name^="reason_"]').first().fill('Pelanggan salah beli');
    await kasir.getByRole('button', { name: /Buat draf retur/ }).click();

    await kasir.waitForURL(/\/penjualan\/retur\/[0-9a-f-]+/);
    retUrl = kasir.url();
    await expect(kasir.getByText(/RTJ-|draf/i)).toBeVisible();
    // Kasir tidak bisa posting sendiri
    await expect(kasir.getByText(/tidak bisa|tidak boleh/i)).toBeVisible();
  });

  test('apoteker memposting retur → stok bertambah', async () => {
    test.setTimeout(30_000);

    await apt.goto(retUrl);
    await apt.getByRole('button', { name: /Posting|Setujui retur/ }).click();
    await expect(apt.getByText(/Diposting|POSTED/i).first()).toBeVisible({ timeout: 15_000 });
  });

  // ── Faktur & AP ───────────────────────────────────────────────────────────
  test('siapkan penerimaan barang untuk faktur AP', async () => {
    test.setTimeout(60_000);

    // Buat SP → kirim → Terima barang
    await owner.goto('/pengadaan/surat-pesanan/baru');
    await selectByText(owner, 'supplier_id', SUPPLIER);
    await owner.getByLabel('Cari obat').fill(MED);
    await owner.getByRole('option', { name: new RegExp(MED) }).first().click();
    await owner.locator('input[name^="qty_ordered_"]').first().fill('100');
    await owner.locator('input[name^="price_"]').first().fill('900');
    await owner.getByRole('button', { name: /Simpan draf/ }).click();
    await owner.getByRole('button', { name: /Kirim SP/ }).click();
    await owner.waitForURL(/\/pengadaan\/surat-pesanan\/[0-9a-f-]+/);

    // Buat penerimaan
    const poUrl = owner.url();
    await owner.getByRole('link', { name: /Tambah penerimaan|Terima barang/ }).click();
    await owner.locator('input[name^="batch_no_"]').first().fill('BS-INV-001');
    await owner.locator('input[name^="expiry_date_"]').first().fill('2028-06-30');
    await owner.locator('input[name^="unit_cost_"]').first().fill('900');
    await owner.getByRole('button', { name: /Simpan penerimaan|Buat penerimaan/ }).click();

    await owner.waitForURL(/\/pengadaan\/penerimaan\/[0-9a-f-]+/);
    grUrl = owner.url();

    // Owner adalah pencatat; apoteker yang memposting
    await apt.goto(grUrl);
    await apt.getByRole('button', { name: /Posting & buat batch/ }).click();
    await expect(apt.getByText(/Diposting/i).first()).toBeVisible({ timeout: 15_000 });
  });

  test('apoteker membuat faktur pembelian → status UNPAID', async () => {
    test.setTimeout(30_000);

    // Navigasi ke halaman buat faktur dari detail penerimaan
    await apt.goto(grUrl);
    await apt.getByRole('link', { name: /Buat faktur|Tambah faktur/ }).click();

    await apt.getByLabel(/Nomor faktur pemasok/).fill('INV/PBF/E2E/001');
    await apt.getByLabel(/Tanggal faktur/).fill('2024-11-01');
    await apt.getByLabel(/Jatuh tempo/).fill('2024-12-01');
    await apt.getByRole('button', { name: /Simpan faktur|Buat faktur/ }).click();

    await apt.waitForURL(/\/pengadaan\/faktur\/[0-9a-f-]+/);
    invoiceUrl = apt.url();
    await expect(apt.getByText(/FKT-/i)).toBeVisible();
    await expect(apt.getByText(/Belum bayar|UNPAID/i)).toBeVisible();
  });

  test('owner mencatat pembayaran sebagian → status PARTIAL', async () => {
    test.setTimeout(30_000);

    await owner.goto(invoiceUrl);
    await owner.getByRole('button', { name: /Catat pembayaran/ }).click();
    await owner.getByLabel(/Jumlah/).fill('45000');
    await owner.getByLabel(/Tanggal/).fill('2024-11-15');
    await owner.getByLabel(/Referensi|No\. referensi/).fill('TRF/BCA/E2E/001');
    await owner.getByRole('button', { name: /Simpan|Catat/ }).click();

    await expect(owner.getByText(/Sebagian|PARTIAL/i)).toBeVisible({ timeout: 10_000 });
  });

  test('pelunasan → status PAID & riwayat pembayaran tampil', async () => {
    test.setTimeout(30_000);

    await owner.goto(invoiceUrl);
    // Ambil sisa utang dari halaman
    const sisaText = await owner.getByText(/Sisa utang/).textContent().catch(() => '');
    const sisa = sisaText?.match(/[\d.]+/)?.join('') ?? '45000';

    await owner.getByRole('button', { name: /Catat pembayaran/ }).click();
    await owner.getByLabel(/Jumlah/).fill(sisa.replace(/\./g, ''));
    await owner.getByLabel(/Tanggal/).fill('2024-11-20');
    await owner.getByLabel(/Referensi|No\. referensi/).fill('TRF/BCA/E2E/002');
    await owner.getByRole('button', { name: /Simpan|Catat/ }).click();

    await expect(owner.getByText(/Lunas|PAID/i)).toBeVisible({ timeout: 10_000 });
    // Riwayat pembayaran harus ada ≥ 2 baris
    const paymentRows = owner.locator('table').filter({ hasText: /TRF\/BCA\/E2E/ }).locator('tr');
    await expect(paymentRows).toHaveCount(await paymentRows.count());
    await expect(owner.locator('text=TRF/BCA/E2E/001')).toBeVisible();
    await expect(owner.locator('text=TRF/BCA/E2E/002')).toBeVisible();
  });

  // ── Tutup sesi kasir ──────────────────────────────────────────────────────
  test('kasir menutup sesi', async () => {
    test.setTimeout(30_000);

    await kasir.goto('/pos');
    const tutupBtn = kasir.getByRole('button', { name: /Tutup sesi/ });
    if (await tutupBtn.isVisible()) {
      await tutupBtn.click();
      await kasir.getByLabel(/Saldo akhir fisik/).fill('497000');
      await kasir.getByRole('button', { name: /Konfirmasi/ }).click();
      await expect(kasir.getByText(/Sesi ditutup|ditutup/i)).toBeVisible({ timeout: 10_000 });
    }
  });
});
