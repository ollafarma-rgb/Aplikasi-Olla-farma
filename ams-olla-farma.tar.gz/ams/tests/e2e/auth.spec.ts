import { expect, test } from '@playwright/test';

/**
 * Alur login Fase 2. Prasyarat: database tes di-seed dengan owner.test
 * (sandi awal di scripts/print-seed-sql.ts) — HANYA untuk lingkungan tes.
 * BELUM DIJALANKAN: menunggu next/prisma terpasang.
 */
const OWNER = { username: 'owner.test', password: 'Uji-Sandi-Owner-2026' };
const NEW_PASSWORD = 'Hijau-Daun-Kopi-7';

test.describe.serial('autentikasi', () => {
  test('halaman terlindungi mengalihkan ke login', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login$/);
  });

  test('sandi salah menampilkan pesan umum', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Nama pengguna').fill(OWNER.username);
    await page.getByLabel('Kata sandi', { exact: true }).fill('salah-sekali-123');
    await page.getByRole('button', { name: 'Masuk' }).click();
    await expect(page.getByRole('alert').filter({ hasText: 'Nama pengguna atau kata sandi salah' })).toBeVisible();
  });

  test('login pertama wajib ganti sandi, lalu masuk dashboard', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Nama pengguna').fill(OWNER.username);
    await page.getByLabel('Kata sandi', { exact: true }).fill(OWNER.password);
    await page.getByRole('button', { name: 'Masuk' }).click();
    await expect(page).toHaveURL(/\/akun\/ganti-sandi$/);

    await page.goto('/dashboard'); // tidak bisa melewati ganti sandi
    await expect(page).toHaveURL(/\/akun\/ganti-sandi$/);

    await page.getByLabel('Kata sandi lama').fill(OWNER.password);
    await page.getByLabel('Kata sandi baru', { exact: true }).fill(NEW_PASSWORD);
    await page.getByLabel('Ulangi kata sandi baru').fill(NEW_PASSWORD);
    await page.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
    await expect(page).toHaveURL(/\/dashboard\?sandi=diganti$/);
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Selamat datang');
  });

  test('cookie sesi HttpOnly dan logout mencabut sesi', async ({ page, context }) => {
    await page.goto('/login');
    await page.getByLabel('Nama pengguna').fill(OWNER.username);
    await page.getByLabel('Kata sandi', { exact: true }).fill(NEW_PASSWORD);
    await page.getByRole('button', { name: 'Masuk' }).click();
    await expect(page).toHaveURL(/\/dashboard$/);

    const cookie = (await context.cookies()).find((c) => c.name.endsWith('ams_session'));
    expect(cookie?.httpOnly).toBe(true);
    expect(cookie?.sameSite).toBe('Lax');

    await page.getByRole('button', { name: 'Keluar' }).click();
    await expect(page).toHaveURL(/\/login$/);

    // Cookie lama yang dicuri tidak bisa dipakai lagi.
    if (cookie) await context.addCookies([cookie]);
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login$/);
  });

  test('health check tidak membocorkan data', async ({ request }) => {
    const res = await request.get('/api/v1/health');
    const body = await res.json();
    expect(Object.keys(body).sort()).toEqual(['db', 'ms', 'status']);
  });
});
