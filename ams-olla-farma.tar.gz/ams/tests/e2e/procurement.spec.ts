import { expect, Browser, BrowserContext, Page, test } from '@playwright/test';

/**
 * E2E Fase 5 — pengadaan: Surat Pesanan -> kirim -> Penerimaan Barang (maker-checker,
 * membuat batch) -> Retur Pembelian (maker-checker, mengurangi stok).
 * Owner berperan sebagai pembuat; apoteker sebagai penyetuju/pemosting kedua.
 */
const OWNER = { username: 'owner.test', password: 'Uji-Sandi-Owner-2026' };
const NEW_PASSWORD = 'Hijau-Daun-Kopi-7';
const APT = { username: 'apt.e2e.proc', password: 'Apoteker-Proc-2026x' };
const NIE = 'DBLE2EPROC0001';
const MED = 'E2E Pengadaan Paracetamol';
const SUPPLIER = 'PBF E2E Pengadaan';

async function selectByText(page: Page, selectName: string, text: string) {
  const value = await page.locator(`select[name="${selectName}"] option`, { hasText: text }).first().getAttribute('value');
  if (!value) throw new Error(`opsi "${text}" tak ditemukan di ${selectName}`);
  await page.selectOption(`select[name="${selectName}"]`, value);
}

async function loginOwner(page: Page) {
  await page.goto('/login');
  await page.getByLabel('Nama pengguna').fill(OWNER.username);
  await page.getByLabel('Kata sandi', { exact: true }).fill(NEW_PASSWORD);
  await page.getByRole('button', { name: 'Masuk' }).click();
  await page.waitForURL(/dashboard|ganti-sandi/, { timeout: 8000 }).catch(() => {});
  if (/\/login/.test(page.url())) {
    await page.getByLabel('Nama pengguna').fill(OWNER.username);
    await page.getByLabel('Kata sandi', { exact: true }).fill(OWNER.password);
    await page.getByRole('button', { name: 'Masuk' }).click();
    await expect(page).toHaveURL(/ganti-sandi/);
    await page.getByLabel('Kata sandi lama').fill(OWNER.password);
    await page.getByLabel('Kata sandi baru', { exact: true }).fill(NEW_PASSWORD);
    await page.getByLabel('Ulangi kata sandi baru').fill(NEW_PASSWORD);
    await page.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
  }
  await expect(page).toHaveURL(/dashboard/);
}

test.describe.serial('pengadaan fase 5', () => {
  let ownerCtx: BrowserContext, aptCtx: BrowserContext;
  let owner: Page, apt: Page;

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    test.setTimeout(120_000);
    ownerCtx = await browser.newContext();
    owner = await ownerCtx.newPage();
    owner.on('dialog', (d) => d.accept());
    await loginOwner(owner);

    // Buat pemasok uji.
    await owner.goto('/pemasok/baru');
    await owner.getByLabel('Nama pemasok (PBF)').fill(SUPPLIER);
    await owner.getByLabel('Termin pembayaran (hari)').fill('30');
    await owner.getByRole('button', { name: /Simpan/ }).click();
    await expect(owner).toHaveURL(/\/pemasok\/[0-9a-f-]+/);

    // Buat obat uji (BEBAS/OTC, satuan dasar TAB).
    await owner.goto('/obat/baru');
    await owner.getByLabel('Nama obat / produk').fill(MED);
    await owner.getByLabel('Nama generik').fill('Paracetamol');
    await owner.getByLabel('Nomor izin edar (NIE)').fill(NIE);
    await owner.getByLabel('Jenis produk').selectOption({ label: 'Obat bebas (OTC)' });
    await owner.getByLabel('Golongan').selectOption({ label: 'Obat bebas' });
    await owner.getByLabel(/Satuan dasar/).selectOption({ label: 'TAB — Tablet' });
    await owner.getByLabel('Satuan beli', { exact: true }).selectOption({ label: 'TAB — Tablet' });
    await owner.getByLabel('Satuan jual', { exact: true }).selectOption({ label: 'TAB — Tablet' });
    await owner.getByLabel(/Harga jual per satuan dasar/).fill('1500');
    await owner.getByLabel(/Harga beli acuan/).fill('900');
    await owner.getByLabel('Alasan perubahan harga').fill('Harga awal');
    await owner.getByLabel('Stok minimum').fill('100');
    await owner.getByRole('button', { name: /Simpan/ }).click();
    await expect(owner).toHaveURL(/\/obat\/[0-9a-f-]+/);

    // Buat akun apoteker untuk peran penyetuju/pemosting kedua.
    await owner.goto('/karyawan/baru');
    await owner.getByLabel(/Nama pengguna/).fill(APT.username);
    await owner.getByLabel('Nama lengkap').fill('Apoteker E2E Pengadaan');
    await owner.getByLabel('Apoteker', { exact: true }).check();
    await owner.getByRole('button', { name: 'Buat akun' }).click();
    const temp = (await owner.getByTestId('temporary-password').innerText()).trim();

    aptCtx = await browser.newContext();
    apt = await aptCtx.newPage();
    apt.on('dialog', (d) => d.accept());
    await apt.goto('/login');
    await apt.getByLabel('Nama pengguna').fill(APT.username);
    await apt.getByLabel('Kata sandi', { exact: true }).fill(temp);
    await apt.getByRole('button', { name: 'Masuk' }).click();
    await expect(apt).toHaveURL(/ganti-sandi/);
    await apt.getByLabel('Kata sandi lama').fill(temp);
    await apt.getByLabel('Kata sandi baru', { exact: true }).fill(APT.password);
    await apt.getByLabel('Ulangi kata sandi baru').fill(APT.password);
    await apt.getByRole('button', { name: 'Simpan kata sandi baru' }).click();
    await expect(apt).toHaveURL(/dashboard/);
  });

  test.afterAll(async () => { await ownerCtx?.close(); await aptCtx?.close(); });

  let poUrl: string;
  let grUrl: string;

  test('SP: buat draf reguler dan kirim ke pemasok', async () => {
    test.setTimeout(60_000);
    await owner.goto('/pengadaan/sp/baru');
    await selectByText(owner, 'supplier_id', SUPPLIER);
    // Baris obat: select tanpa atribut name (dikelola via state React) -> cocokkan teks opsi secara parsial.
    const medSelect = owner.locator('table select').first();
    const medValue = await medSelect.locator('option', { hasText: MED }).first().getAttribute('value');
    if (!medValue) throw new Error(`opsi obat "${MED}" tak ditemukan`);
    await medSelect.selectOption(medValue);
    await owner.locator('input[name^="qty_"]').first().fill('200');
    await owner.locator('input[name^="price_"]').first().fill('900');
    await owner.getByRole('button', { name: 'Buat draf SP' }).click();
    await expect(owner.getByText(/SP SP-\d{4}-\d{4} dibuat sebagai draf/)).toBeVisible();
    await owner.getByRole('link', { name: 'Lihat draf' }).click();
    await owner.waitForURL(/\/pengadaan\/sp\/[0-9a-f]{8}-[0-9a-f]{4}-/);
    poUrl = owner.url();
    await expect(owner.getByText('Draf')).toBeVisible();

    // Owner (OWNER punya procurement.po.approve) kirim SP ke pemasok.
    await owner.getByRole('button', { name: 'Kirim ke pemasok' }).click();
    await expect(owner.getByText('Terkirim')).toBeVisible();
  });

  test('Penerimaan: owner catat draf, apoteker lain posting -> batch & stok terbentuk', async () => {
    test.setTimeout(60_000);
    await owner.goto('/pengadaan/penerimaan/baru');
    await selectByText(owner, 'po', SUPPLIER);
    await owner.getByRole('button', { name: 'Lanjut' }).click();
    await owner.waitForURL(/\/pengadaan\/penerimaan\/baru\?po=/);

    await owner.locator('input[name^="qty_"]').first().fill('200');
    await owner.locator('input[name^="batch_no_"]').first().fill('BP-E2E-1');
    await owner.locator('input[name^="expiry_"]').first().fill('2027-12-31');
    await owner.locator('input[name^="cost_"]').first().fill('900');
    await owner.getByRole('button', { name: 'Simpan sebagai draf' }).click();
    await expect(owner.getByText(/Penerimaan GR-\d{4}-\d{4} dicatat sebagai draf/)).toBeVisible();
    await owner.getByRole('link', { name: 'Lihat draf' }).click();
    await owner.waitForURL(/\/pengadaan\/penerimaan\/[0-9a-f]{8}-[0-9a-f]{4}-/);
    grUrl = owner.url();
    // Owner adalah pencatat -> tak bisa posting sendiri.
    await expect(owner.getByText(/tidak bisa memposting sendiri/)).toBeVisible();

    await apt.goto(grUrl);
    await apt.getByRole('button', { name: /Posting & buat batch/ }).click();
    await expect(apt.getByText('Diposting').first()).toBeVisible();

    // SP otomatis berstatus RECEIVED karena seluruh jumlah sudah diterima.
    await owner.goto(poUrl);
    await owner.reload();
    await expect(owner.getByText('Diterima').first()).toBeVisible();

    // Batch baru tampak di kartu stok obat.
    await owner.goto('/persediaan');
    await owner.getByLabel('Cari obat').fill(MED);
    await owner.getByRole('button', { name: 'Cari' }).click();
    await owner.getByRole('link', { name: new RegExp(MED) }).click();
    await expect(owner.getByRole('cell', { name: 'BP-E2E-1' }).first()).toBeVisible();
  });

  test('Retur pembelian: owner buat draf, pembuat tak bisa setujui sendiri, apoteker setujui -> stok berkurang', async () => {
    test.setTimeout(60_000);
    await owner.goto('/pengadaan/retur/baru');
    await selectByText(owner, 'supplier', SUPPLIER);
    await owner.getByRole('button', { name: 'Lanjut' }).click();
    await owner.waitForURL(/\/pengadaan\/retur\/baru\?supplier=/);

    await owner.locator('input[name^="qty_"]').first().fill('20');
    await owner.locator('input[name^="reason_"]').first().fill('Kemasan rusak saat pemeriksaan');
    await owner.getByRole('button', { name: 'Buat draf retur' }).click();
    await expect(owner.getByText(/Retur RB-\d{4}-\d{4} dibuat sebagai draf/)).toBeVisible();
    await owner.getByRole('link', { name: 'Lihat draf' }).click();
    await owner.waitForURL(/\/pengadaan\/retur\/[0-9a-f]{8}-[0-9a-f]{4}-/);
    const retUrl = owner.url();
    await expect(owner.getByText(/tidak bisa menyetujuinya sendiri/)).toBeVisible();

    await apt.goto(retUrl);
    await apt.getByRole('button', { name: /Setujui & kurangi stok/ }).click();
    await expect(apt.getByText('Diposting').first()).toBeVisible();

    // Stok berkurang 200 -> 180.
    await owner.goto('/persediaan');
    await owner.getByLabel('Cari obat').fill(MED);
    await owner.getByRole('button', { name: 'Cari' }).click();
    await owner.getByRole('link', { name: new RegExp(MED) }).click();
    await expect(owner.getByRole('cell', { name: '180', exact: true })).toBeVisible();
  });
});
