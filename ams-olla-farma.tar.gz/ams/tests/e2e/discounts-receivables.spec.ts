import { expect, BrowserContext, Page, test } from '@playwright/test';

/**
 * E2E Fase 7 — Aturan Diskon & Piutang Pelanggan
 *
 * Skenario:
 * 1. Apoteker membuat aturan diskon PERCENT 10% untuk ALL scope.
 * 2. Owner menyetujui aturan (maker-checker).
 * 3. Verifikasi aturan aktif muncul di daftar.
 * 4. Kasir membuat penjualan dengan metode RECEIVABLE untuk pelanggan.
 * 5. Apoteker mencatat pembayaran parsial piutang.
 * 6. Apoteker mencatat pelunasan penuh piutang.
 * 7. Verifikasi status piutang menjadi PAID.
 */

const OWNER_CRED = { username: 'owner.test',         password: 'Hijau-Daun-Kopi-7' };
const APT_CRED   = { username: 'apt.e2e.discount',   password: 'Apoteker-Disc-2026x' };
const KASIR_CRED = { username: 'kasir.e2e.discount',  password: 'Kasir-Disc-2026x' };

const RULE_CODE  = `DSC-E2E-${Date.now()}`;
const RULE_NAME  = 'Diskon E2E Semua Produk';
const CUST_NAME  = 'Pelanggan E2E Piutang';

// ─── helpers ──────────────────────────────────────────────────────────────────

async function loginAs(page: Page, cred: { username: string; password: string }) {
  await page.goto('/login');
  await page.getByLabel('Nama pengguna').fill(cred.username);
  await page.getByLabel('Kata sandi', { exact: true }).fill(cred.password);
  await page.getByRole('button', { name: 'Masuk' }).click();
  await page.waitForURL(/dashboard|ganti-sandi/, { timeout: 8_000 }).catch(() => {});
}

async function ensureLoggedIn(page: Page, cred: { username: string; password: string }) {
  if (!page.url().includes('/dashboard')) {
    await loginAs(page, cred);
  }
  await expect(page).toHaveURL(/dashboard/);
}

// ─── suite ────────────────────────────────────────────────────────────────────

test.describe.serial('diskon & piutang fase 7', () => {
  let ownerCtx: BrowserContext;
  let aptCtx:   BrowserContext;
  let kasirCtx: BrowserContext;
  let owner:    Page;
  let apt:      Page;
  let kasir:    Page;

  let discountRuleUrl: string;
  let receivableUrl:   string;

  test.beforeAll(async ({ browser }) => {
    ownerCtx = await browser.newContext();
    aptCtx   = await browser.newContext();
    kasirCtx = await browser.newContext();
    owner    = await ownerCtx.newPage();
    apt      = await aptCtx.newPage();
    kasir    = await kasirCtx.newPage();
  });

  test.afterAll(async () => {
    await ownerCtx.close();
    await aptCtx.close();
    await kasirCtx.close();
  });

  // ─── 1. Setup akun ──────────────────────────────────────────────────────────

  test('owner login', async () => {
    await loginAs(owner, OWNER_CRED);
    await expect(owner).toHaveURL(/dashboard/);
  });

  test('buat akun apoteker & kasir via owner', async () => {
    // Buat apoteker
    await owner.goto('/admin/pengguna/baru');
    await owner.getByLabel('Nama lengkap').fill('Apoteker Diskon E2E');
    await owner.getByLabel('Nama pengguna').fill(APT_CRED.username);
    await owner.getByLabel('Kata sandi').fill(APT_CRED.password);
    await owner.getByLabel('APOTEKER').check();
    await owner.getByRole('button', { name: 'Simpan' }).click();
    await expect(owner.getByRole('alert')).toContainText(/berhasil/i);

    // Buat kasir
    await owner.goto('/admin/pengguna/baru');
    await owner.getByLabel('Nama lengkap').fill('Kasir Diskon E2E');
    await owner.getByLabel('Nama pengguna').fill(KASIR_CRED.username);
    await owner.getByLabel('Kata sandi').fill(KASIR_CRED.password);
    await owner.getByLabel('KASIR').check();
    await owner.getByRole('button', { name: 'Simpan' }).click();
    await expect(owner.getByRole('alert')).toContainText(/berhasil/i);
  });

  test('apoteker login', async () => {
    await loginAs(apt, APT_CRED);
    await expect(apt).toHaveURL(/dashboard/);
  });

  test('kasir login', async () => {
    await loginAs(kasir, KASIR_CRED);
    await expect(kasir).toHaveURL(/dashboard/);
  });

  // ─── 2. Aturan Diskon ───────────────────────────────────────────────────────

  test('apoteker membuat aturan diskon baru', async () => {
    await apt.goto('/harga/aturan-diskon/baru');
    await apt.getByLabel('Kode').fill(RULE_CODE);
    await apt.getByLabel('Nama').fill(RULE_NAME);
    // Scope: ALL (default)
    await apt.getByLabel('Tipe diskon').selectOption('PERCENT');
    await apt.getByLabel('Nilai diskon').fill('10');
    await apt.getByLabel('Minimal qty').fill('1');
    // Tanggal berlaku: hari ini sampai 1 tahun ke depan
    const today = new Date();
    const nextYear = new Date(today);
    nextYear.setFullYear(today.getFullYear() + 1);
    await apt.getByLabel('Berlaku dari').fill(today.toISOString().slice(0, 16));
    await apt.getByLabel('Berlaku hingga').fill(nextYear.toISOString().slice(0, 16));
    await apt.getByRole('button', { name: 'Simpan aturan' }).click();
    await apt.waitForURL(/\/harga\/aturan-diskon\/[^/]+$/, { timeout: 8_000 });
    discountRuleUrl = apt.url();
    await expect(apt.getByText('DRAFT')).toBeVisible();
  });

  test('pembuat tidak bisa menyetujui sendiri', async () => {
    await apt.goto(discountRuleUrl);
    // Tombol approve tidak ada atau disabled untuk pembuat
    const approveBtn = apt.getByRole('button', { name: /setujui/i });
    const isVisible = await approveBtn.isVisible();
    if (isVisible) {
      await approveBtn.click();
      await expect(apt.getByRole('alert')).toContainText(/tidak dapat menyetujui/i);
    }
    // Status masih DRAFT
    await expect(apt.getByText('DRAFT')).toBeVisible();
  });

  test('owner menyetujui aturan diskon', async () => {
    await owner.goto(discountRuleUrl);
    await expect(owner.getByText('DRAFT')).toBeVisible();
    await owner.getByRole('button', { name: /setujui/i }).click();
    await owner.getByRole('button', { name: /ya, setujui/i }).click();
    await expect(owner.getByRole('alert')).toContainText(/disetujui/i);
    await expect(owner.getByText('APPROVED')).toBeVisible();
  });

  test('aturan aktif muncul di daftar', async () => {
    await apt.goto('/harga/aturan-diskon');
    await apt.getByRole('combobox', { name: /status/i }).selectOption('APPROVED');
    await expect(apt.getByText(RULE_NAME)).toBeVisible();
  });

  // ─── 3. Piutang ─────────────────────────────────────────────────────────────

  test('owner membuat pelanggan dengan kredit', async () => {
    await owner.goto('/pelanggan/baru');
    await owner.getByLabel('Kode').fill(`CUSTE2E${Date.now().toString().slice(-6)}`);
    await owner.getByLabel('Nama').fill(CUST_NAME);
    await owner.getByLabel('Limit kredit').fill('1000000');
    await owner.getByRole('button', { name: 'Simpan' }).click();
    await expect(owner.getByRole('alert')).toContainText(/berhasil/i);
  });

  test('kasir membuka sesi kasir', async () => {
    await kasir.goto('/kasir/sesi/buka');
    await kasir.getByLabel('Kas awal').fill('500000');
    await kasir.getByRole('button', { name: 'Buka sesi' }).click();
    await kasir.waitForURL(/\/kasir\/sesi\//, { timeout: 8_000 });
    await expect(kasir.getByText(/sesi.*aktif/i)).toBeVisible();
  });

  test('kasir membuat penjualan piutang', async () => {
    await kasir.goto('/kasir');
    // Pilih pelanggan
    await kasir.getByLabel('Cari pelanggan').fill(CUST_NAME);
    await kasir.getByText(CUST_NAME).first().click();
    // Tambah obat — asumsi ada obat dengan nama/SKU dari E2E sebelumnya
    await kasir.getByLabel('Cari obat atau scan barcode').fill('E2E');
    await kasir.getByRole('option').first().click();
    // Metode bayar: Piutang
    await kasir.getByLabel('Metode pembayaran').selectOption('RECEIVABLE');
    await kasir.getByRole('button', { name: /proses\|bayar/i }).click();
    await kasir.waitForURL(/\/kasir\/struk\//, { timeout: 10_000 });
    await expect(kasir.getByText(/piutang/i)).toBeVisible();
  });

  test('apoteker melihat daftar piutang', async () => {
    await apt.goto('/keuangan/piutang');
    await expect(apt.getByText(CUST_NAME)).toBeVisible({ timeout: 5_000 });
    // Ambil link ke detail piutang
    const row = apt.getByText(CUST_NAME).locator('..').locator('..');
    await row.getByRole('link').click();
    await apt.waitForURL(/\/keuangan\/piutang\/[^/]+$/, { timeout: 8_000 });
    receivableUrl = apt.url();
    await expect(apt.getByText('OPEN')).toBeVisible();
  });

  test('apoteker mencatat pembayaran parsial', async () => {
    await apt.goto(receivableUrl);
    await apt.getByLabel('Jumlah bayar').fill('50000');
    await apt.getByLabel('Referensi').fill('TRANSFER-001');
    await apt.getByRole('button', { name: /catat pembayaran/i }).click();
    await expect(apt.getByRole('alert')).toContainText(/berhasil/i);
    await expect(apt.getByText('PARTIAL')).toBeVisible();
  });

  test('apoteker melunasi piutang', async () => {
    await apt.goto(receivableUrl);
    // Ambil sisa yang perlu dibayar
    const remaining = await apt.getByTestId('remaining-amount').textContent();
    const amount = remaining?.replace(/[^0-9]/g, '') ?? '0';
    await apt.getByLabel('Jumlah bayar').fill(amount);
    await apt.getByLabel('Referensi').fill('TRANSFER-002');
    await apt.getByRole('button', { name: /catat pembayaran/i }).click();
    await expect(apt.getByRole('alert')).toContainText(/berhasil/i);
    await expect(apt.getByText('PAID')).toBeVisible();
  });

  // ─── 4. Laporan Aging ───────────────────────────────────────────────────────

  test('owner melihat laporan aging piutang', async () => {
    await owner.goto('/keuangan/piutang/aging');
    // 4 bucket harus tampil
    await expect(owner.getByText('0–30 hari')).toBeVisible();
    await expect(owner.getByText('31–60 hari')).toBeVisible();
    await expect(owner.getByText('61–90 hari')).toBeVisible();
    await expect(owner.getByText('> 90 hari')).toBeVisible();
  });

  // ─── 5. Pembatalan aturan diskon ────────────────────────────────────────────

  test('apoteker membuat aturan lain lalu batalkan sendiri', async () => {
    await apt.goto('/harga/aturan-diskon/baru');
    await apt.getByLabel('Kode').fill(`DSC-CANCEL-${Date.now()}`);
    await apt.getByLabel('Nama').fill('Diskon E2E untuk dibatalkan');
    await apt.getByLabel('Tipe diskon').selectOption('AMOUNT');
    await apt.getByLabel('Nilai diskon').fill('5000');
    await apt.getByLabel('Minimal qty').fill('1');
    const today = new Date();
    const nextYear = new Date(today);
    nextYear.setFullYear(today.getFullYear() + 1);
    await apt.getByLabel('Berlaku dari').fill(today.toISOString().slice(0, 16));
    await apt.getByLabel('Berlaku hingga').fill(nextYear.toISOString().slice(0, 16));
    await apt.getByRole('button', { name: 'Simpan aturan' }).click();
    await apt.waitForURL(/\/harga\/aturan-diskon\/[^/]+$/, { timeout: 8_000 });

    // Batalkan — pembuat boleh batalkan miliknya sendiri
    await apt.getByRole('button', { name: /batalkan/i }).click();
    await apt.getByRole('button', { name: /ya, batalkan/i }).click();
    await expect(apt.getByRole('alert')).toContainText(/dibatalkan/i);
    await expect(apt.getByText('CANCELLED')).toBeVisible();
  });
});
