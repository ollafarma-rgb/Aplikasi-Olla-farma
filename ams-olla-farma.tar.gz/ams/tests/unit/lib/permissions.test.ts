import { describe, expect, it } from 'vitest';
import { PERMISSIONS, PERMISSION_CODES, ROLES } from '../../../src/lib/permissions/catalog';
import { approvalViolation, assertPermission, permissionsForRoles } from '../../../src/lib/permissions/check';

describe('katalog izin', () => {
  it('kode izin unik', () => {
    expect(PERMISSION_CODES.size).toBe(PERMISSIONS.length);
  });
  it('setiap izin peran ada di katalog dan tidak dobel', () => {
    for (const role of ROLES) {
      for (const p of role.permissions) expect(PERMISSION_CODES.has(p)).toBe(true);
      expect(new Set(role.permissions).size).toBe(role.permissions.length);
    }
  });
  it('ada tepat 5 peran bawaan', () => {
    expect(ROLES.map((r) => r.code)).toEqual(['OWNER', 'APOTEKER', 'TTK', 'KASIR', 'GUDANG']);
  });
});

describe('matriks peran (dokumen Fase 1)', () => {
  const owner = permissionsForRoles(['OWNER']);
  const apoteker = permissionsForRoles(['APOTEKER']);
  const ttk = permissionsForRoles(['TTK']);
  const kasir = permissionsForRoles(['KASIR']);
  const gudang = permissionsForRoles(['GUDANG']);

  it('kasir tidak bisa melihat laporan atau dashboard keuangan (skenario 8)', () => {
    for (const p of ['finance.view', 'reports.finance.view', 'dashboard.finance.view'] as const) {
      expect(kasir.has(p)).toBe(false);
    }
  });
  it('kasir hanya melihat riwayat transaksinya sendiri', () => {
    expect(kasir.has('sales.view_own')).toBe(true);
    expect(kasir.has('sales.view_all')).toBe(false);
  });
  it('kasir tidak melihat harga pokok', () => {
    expect(kasir.has('medicines.view_cost')).toBe(false);
  });
  it('verifikasi resep, SP khusus, dan register narkotika hanya apoteker', () => {
    for (const p of ['rx.verify', 'rx.dispense', 'procurement.po_special.sign', 'rx.narcotic.manage'] as const) {
      expect(apoteker.has(p)).toBe(true);
      expect(owner.has(p)).toBe(false);
      expect(ttk.has(p)).toBe(false);
      expect(kasir.has(p)).toBe(false);
    }
  });
  it('posting penerimaan barang butuh apoteker atau owner, bukan TTK/gudang', () => {
    expect(apoteker.has('procurement.receive.post')).toBe(true);
    expect(owner.has('procurement.receive.post')).toBe(true);
    expect(ttk.has('procurement.receive.post')).toBe(false);
    expect(gudang.has('procurement.receive.post')).toBe(false);
  });
  it('hanya owner yang mengelola pengguna dan melihat seluruh audit', () => {
    for (const set of [apoteker, ttk, kasir, gudang]) {
      expect(set.has('users.manage')).toBe(false);
      expect(set.has('audit.view')).toBe(false);
    }
    expect(owner.has('users.manage')).toBe(true);
  });
  it('OWA boleh diserahkan apoteker dan TTK, tidak oleh kasir, gudang, atau pemilik non-farmasi (keputusan #6)', () => {
    expect(apoteker.has('sales.owa.dispense')).toBe(true);
    expect(ttk.has('sales.owa.dispense')).toBe(true);
    expect(kasir.has('sales.owa.dispense')).toBe(false);
    expect(gudang.has('sales.owa.dispense')).toBe(false);
    expect(owner.has('sales.owa.dispense')).toBe(false);
  });
  it('diskon periode hanya diatur manajemen: pemilik dan apoteker (keputusan #5)', () => {
    expect(owner.has('pricing.discount_rules.manage')).toBe(true);
    expect(apoteker.has('pricing.discount_rules.manage')).toBe(true);
    for (const set of [ttk, kasir, gudang]) expect(set.has('pricing.discount_rules.manage')).toBe(false);
  });
  it('gudang tidak punya akses POS', () => {
    expect(gudang.has('pos.access')).toBe(false);
  });
  it('gabungan beberapa peran menggabungkan izin', () => {
    const both = permissionsForRoles(['KASIR', 'GUDANG']);
    expect(both.has('pos.access')).toBe(true);
    expect(both.has('inventory.opname.count')).toBe(true);
  });
});

describe('pemeriksaan izin dan persetujuan', () => {
  it('assertPermission melempar FORBIDDEN', () => {
    const kasir = permissionsForRoles(['KASIR']);
    let code: string | undefined;
    try { assertPermission(kasir, 'finance.view'); } catch (e) { code = (e as { code?: string }).code; }
    expect(code).toBe('FORBIDDEN');
  });
  it('menyetujui permintaan sendiri ditolak', () => {
    const msg = approvalViolation({
      requesterId: 'u1', approverId: 'u1',
      approverPerms: permissionsForRoles(['APOTEKER']), requiredPermission: 'sales.cancel.approve',
    });
    expect(msg).toContain('pengguna lain');
  });
  it('penyetuju tanpa izin approver ditolak', () => {
    const msg = approvalViolation({
      requesterId: 'u1', approverId: 'u2',
      approverPerms: permissionsForRoles(['KASIR']), requiredPermission: 'sales.cancel.approve',
    });
    expect(msg).toContain('tidak memiliki izin');
  });
  it('apoteker lain sah menyetujui pembatalan', () => {
    expect(approvalViolation({
      requesterId: 'u1', approverId: 'u2',
      approverPerms: permissionsForRoles(['APOTEKER']), requiredPermission: 'sales.cancel.approve',
    })).toBeNull();
  });
});
