import { describe, expect, it } from 'vitest';
import { clientIpFromForwarded } from '../../../src/lib/auth/client-ip';

describe('IP klien dari X-Forwarded-For', () => {
  it('mengambil entri yang ditambahkan proxy tepercaya, bukan entri pertama', () => {
    // penyerang mengirim "1.1.1.1"; load balancer menambahkan IP asli 36.68.10.5
    expect(clientIpFromForwarded('1.1.1.1, 36.68.10.5', 1)).toBe('36.68.10.5');
  });
  it('mengganti IP palsu tiap request tidak mengubah IP yang dipakai rate limit', () => {
    expect(clientIpFromForwarded('9.9.9.9, 36.68.10.5', 1)).toBe(clientIpFromForwarded('8.8.8.8, 36.68.10.5', 1));
  });
  it('dua proxy tepercaya', () => {
    expect(clientIpFromForwarded('1.1.1.1, 36.68.10.5, 10.0.0.2', 2)).toBe('36.68.10.5');
  });
  it('header kosong, kurang entri, atau bukan IP menghasilkan null', () => {
    expect(clientIpFromForwarded(null, 1)).toBeNull();
    expect(clientIpFromForwarded('36.68.10.5', 2)).toBeNull();
    expect(clientIpFromForwarded("x' OR 1=1", 1)).toBeNull();
  });
  it('mendukung IPv6', () => {
    expect(clientIpFromForwarded('2001:db8::1', 1)).toBe('2001:db8::1');
  });
});
