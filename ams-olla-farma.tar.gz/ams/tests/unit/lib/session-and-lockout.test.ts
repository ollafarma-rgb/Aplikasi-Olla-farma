import { describe, expect, it } from 'vitest';
import {
  checkSession,
  generateSessionToken,
  hashSessionToken,
  isWellFormedToken,
  SESSION_IDLE_MS,
  type SessionRecord,
} from '../../../src/lib/auth/session-token';
import { afterFailedAttempt, afterSuccessfulLogin, isLocked, LOCK_DURATION_MS } from '../../../src/lib/auth/lockout';

const T0 = new Date('2026-11-12T01:00:00Z');
const minutes = (n: number) => new Date(T0.getTime() + n * 60_000);

function session(over: Partial<SessionRecord> = {}): SessionRecord {
  return {
    id: 'x'.repeat(64), user_id: 'u1', session_version: 1,
    created_at: T0, last_seen_at: T0, expires_at: minutes(12 * 60), revoked_at: null,
    ...over,
  };
}
const user = { is_active: true, session_version: 1, locked_until: null };

describe('token sesi', () => {
  it('token 256-bit berbentuk base64url 43 karakter', () => {
    const t = generateSessionToken();
    expect(isWellFormedToken(t)).toBe(true);
    expect(t).toHaveLength(43);
  });
  it('yang disimpan DB adalah SHA-256 hex, deterministik', () => {
    const t = generateSessionToken();
    expect(hashSessionToken(t)).toMatch(/^[0-9a-f]{64}$/);
    expect(hashSessionToken(t)).toBe(hashSessionToken(t));
  });
  it('token cacat ditolak sebelum menyentuh database', () => {
    expect(isWellFormedToken('pendek')).toBe(false);
    expect(isWellFormedToken(undefined)).toBe(false);
    expect(isWellFormedToken("' OR 1=1 --".padEnd(43, 'a'))).toBe(false);
  });
});

describe('validitas sesi', () => {
  it('sesi aktif sah', () => {
    expect(checkSession(session(), user, minutes(5))).toEqual({ valid: true, shouldTouch: true });
  });
  it('aktivitas < 60 detik tidak menulis ulang last_seen_at', () => {
    expect(checkSession(session(), user, new Date(T0.getTime() + 30_000))).toEqual({ valid: true, shouldTouch: false });
  });
  it('sesi dicabut tidak sah', () => {
    expect(checkSession(session({ revoked_at: T0 }), user, minutes(1))).toEqual({ valid: false, reason: 'revoked' });
  });
  it('logout paksa: versi sesi lama tidak sah setelah session_version naik', () => {
    expect(checkSession(session(), { ...user, session_version: 2 }, minutes(1))).toEqual({ valid: false, reason: 'version' });
  });
  it('lewat 12 jam tidak sah walau aktif terus', () => {
    const s = session({ last_seen_at: minutes(12 * 60 - 1) });
    expect(checkSession(s, user, minutes(12 * 60))).toEqual({ valid: false, reason: 'expired' });
  });
  it('diam 30 menit keluar otomatis', () => {
    expect(checkSession(session(), user, new Date(T0.getTime() + SESSION_IDLE_MS))).toEqual({ valid: false, reason: 'idle' });
  });
  it('akun dinonaktifkan langsung memutus sesi', () => {
    expect(checkSession(session(), { ...user, is_active: false }, minutes(1))).toEqual({ valid: false, reason: 'inactive' });
  });
});

describe('kunci akun', () => {
  it('4 kali gagal belum terkunci', () => {
    let s = afterSuccessfulLogin();
    for (let i = 0; i < 4; i++) s = afterFailedAttempt(s, T0);
    expect(s.failed_login_count).toBe(4);
    expect(isLocked(s, T0)).toBe(false);
  });
  it('gagal ke-5 mengunci 15 menit', () => {
    let s = afterSuccessfulLogin();
    for (let i = 0; i < 5; i++) s = afterFailedAttempt(s, T0);
    expect(isLocked(s, minutes(14))).toBe(true);
    expect(s.locked_until?.getTime()).toBe(T0.getTime() + LOCK_DURATION_MS);
    expect(isLocked(s, minutes(15))).toBe(false);
  });
  it('setelah kunci berakhir, hitungan mulai dari awal', () => {
    let s = afterSuccessfulLogin();
    for (let i = 0; i < 5; i++) s = afterFailedAttempt(s, T0);
    s = afterFailedAttempt(s, minutes(16));
    expect(s.failed_login_count).toBe(1);
    expect(s.locked_until).toBeNull();
  });
});
