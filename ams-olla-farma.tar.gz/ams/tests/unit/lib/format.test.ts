import { describe, expect, it } from 'vitest';
import { formatDocNumber, periodKey } from '../../../src/lib/numbering/format';
import { formatRupiah } from '../../../src/lib/money/format';
import { sqlLiteral, buildSeedSql } from '../../../prisma/seed/build-seed-sql';
import { PERMISSIONS } from '../../../src/lib/permissions/catalog';
import { AppError, toFailure } from '../../../src/lib/errors';

describe('nomor dokumen', () => {
  it('periode memakai zona Asia/Jakarta, bukan UTC', () => {
    // 30 Nov 2026 18:00 UTC = 1 Des 2026 01:00 WIB
    const d = new Date('2026-11-30T18:00:00Z');
    expect(periodKey(d, 'month')).toBe('2612');
    expect(periodKey(d, 'day')).toBe('261201');
    expect(periodKey(d, 'month', 'UTC')).toBe('2611');
  });
  it('format dengan nol di depan', () => {
    expect(formatDocNumber('PJ', '2611', 123)).toBe('PJ/2611/000123');
  });
  it('menolak urutan tidak sah atau melebihi lebar', () => {
    expect(() => formatDocNumber('PJ', '2611', 0)).toThrow('bilangan bulat positif');
    expect(() => formatDocNumber('PJ', '2611', 1.5)).toThrow('bilangan bulat positif');
    expect(() => formatDocNumber('PJ', '2611', 1_000_000)).toThrow('melebihi lebar');
  });
});

describe('format Rupiah (tanpa floating-point)', () => {
  it('pemisah ribuan titik', () => {
    expect(formatRupiah('1234567')).toBe('Rp 1.234.567');
  });
  it('dua desimal dengan koma', () => {
    expect(formatRupiah('1234567.5', 2)).toBe('Rp 1.234.567,50');
  });
  it('pembulatan setengah ke atas tanpa galat 0.1+0.2', () => {
    expect(formatRupiah('0.3', 0)).toBe('Rp 0');
    expect(formatRupiah('12499.5', 0)).toBe('Rp 12.500');
    expect(formatRupiah('999999.995', 2)).toBe('Rp 1.000.000,00');
    expect(formatRupiah('1.005', 2)).toBe('Rp 1,01');
  });
  it('angka negatif dan nol', () => {
    expect(formatRupiah('-2500')).toBe('-Rp 2.500');
    expect(formatRupiah('-0.4')).toBe('Rp 0');
  });
  it('menolak input bukan desimal', () => {
    expect(() => formatRupiah('1e5')).toThrow('Bukan angka desimal');
    expect(() => formatRupiah('12,5')).toThrow('Bukan angka desimal');
  });
});

describe('seed SQL', () => {
  it('literal SQL meng-escape tanda petik', () => {
    expect(sqlLiteral("Jl. Tgk. Daud Beureueh's")).toBe("'Jl. Tgk. Daud Beureueh''s'");
    expect(sqlLiteral(null)).toBe('NULL');
  });
  it('memuat semua izin dan tidak membuat owner tanpa diminta', () => {
    const sql = buildSeedSql();
    for (const p of PERMISSIONS) expect(sql).toContain(`'${p.code}'`);
    expect(sql.includes('INSERT INTO "users"')).toBe(false);
  });
});

describe('error aman untuk browser', () => {
  it('AppError diteruskan dengan kode dan pesan Indonesia', () => {
    expect(toFailure(new AppError('FORBIDDEN'))).toMatchObject({ ok: false, code: 'FORBIDDEN' });
  });
  it('error database mentah disembunyikan', () => {
    const f = toFailure(new Error('duplicate key value violates unique constraint "users_pkey"'));
    expect(f.code).toBe('INTERNAL_ERROR');
    expect(f.message.includes('users_pkey')).toBe(false);
  });
});
