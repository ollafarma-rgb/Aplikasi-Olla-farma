import { describe, expect, it } from 'vitest';
import {
  CURRENT_PARAMS,
  hashPassword,
  needsRehash,
  validatePasswordPolicy,
  verifyPassword,
} from '../../../src/lib/auth/password';

describe('hash kata sandi (scrypt)', () => {
  it('hash bisa diverifikasi dengan sandi yang benar', async () => {
    const hash = await hashPassword('Sandi-Rahasia-2026');
    expect(await verifyPassword('Sandi-Rahasia-2026', hash)).toBe(true);
  });

  it('sandi salah ditolak', async () => {
    const hash = await hashPassword('Sandi-Rahasia-2026');
    expect(await verifyPassword('sandi-rahasia-2026', hash)).toBe(false);
  });

  it('format menyimpan parameter dan tidak memuat sandi asli', async () => {
    const hash = await hashPassword('Sandi-Rahasia-2026');
    expect(hash).toMatch(/^scrypt\$15\$8\$3\$[A-Za-z0-9_-]+\$[A-Za-z0-9_-]+$/);
    expect(hash.includes('Sandi-Rahasia-2026')).toBe(false);
  });

  it('dua hash dari sandi yang sama berbeda (salt acak)', async () => {
    const a = await hashPassword('Sandi-Rahasia-2026');
    const b = await hashPassword('Sandi-Rahasia-2026');
    expect(a === b).toBe(false);
  });

  it('hash rusak atau format asing ditolak tanpa error', async () => {
    expect(await verifyPassword('apa saja', 'bukan-hash')).toBe(false);
    expect(await verifyPassword('apa saja', 'scrypt$99$8$1$AAAA$BBBB')).toBe(false);
  });

  it('hash dengan parameter lebih lemah ditandai perlu di-hash ulang', async () => {
    const weak = await hashPassword('Sandi-Rahasia-2026', { logN: 14, r: 8, p: 1 });
    expect(needsRehash(weak)).toBe(true);
    expect(await verifyPassword('Sandi-Rahasia-2026', weak)).toBe(true);
    const current = await hashPassword('Sandi-Rahasia-2026', CURRENT_PARAMS);
    expect(needsRehash(current)).toBe(false);
  });
});

describe('kebijakan kata sandi', () => {
  it('menolak sandi kurang dari 10 karakter', () => {
    expect(validatePasswordPolicy('Pendek123')).toContain('minimal 10');
  });
  it('menolak sandi umum', () => {
    expect(validatePasswordPolicy('apotek12345')).toContain('terlalu umum');
  });
  it('menolak sandi yang memuat nama pengguna', () => {
    expect(validatePasswordPolicy('kasir.andi-2026', { username: 'kasir.andi' })).toContain('nama pengguna');
  });
  it('menolak satu karakter berulang', () => {
    expect(validatePasswordPolicy('aaaaaaaaaaaa')).toContain('berulang');
  });
  it('menerima sandi yang memenuhi syarat', () => {
    expect(validatePasswordPolicy('Hijau-Daun-Kopi-7')).toBeNull();
  });
});
