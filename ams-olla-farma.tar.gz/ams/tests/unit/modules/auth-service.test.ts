import { beforeEach, describe, expect, it } from 'vitest';
import { hashPassword } from '../../../src/lib/auth/password';
import { hashSessionToken, SESSION_IDLE_MS } from '../../../src/lib/auth/session-token';
import { createAuthService, INVALID_CREDENTIALS } from '../../../src/modules/authentication/service';
import { InMemoryAuthRepo } from '../../support/in-memory-auth-repo';

const NOW = new Date('2026-11-12T01:00:00Z');
const ctx = (now = NOW, ip = '10.0.0.5') => ({ ip, userAgent: 'Vitest', now });
const PASSWORD = 'Hijau-Daun-Kopi-7';

let repo: InMemoryAuthRepo;
let auth: ReturnType<typeof createAuthService>;

beforeEach(async () => {
  repo = new InMemoryAuthRepo();
  auth = createAuthService(repo);
  repo.addUser({
    id: 'u-kasir', username: 'kasir.andi', full_name: 'Andi', password_hash: await hashPassword(PASSWORD),
    is_active: true, must_change_password: false, failed_login_count: 0, locked_until: null,
    session_version: 1, roles: ['KASIR'],
  });
});

describe('login', () => {
  it('berhasil: membuat sesi, menyimpan hash token (bukan token), dan mencatat audit', async () => {
    const res = await auth.login({ username: 'Kasir.Andi ', password: PASSWORD }, ctx());
    expect(repo.state.sessions.has(res.token)).toBe(false);
    expect(repo.state.sessions.has(hashSessionToken(res.token))).toBe(true);
    expect(repo.state.audit.at(-1)?.action).toBe('auth.login.success');
    expect(res.expiresAt.getTime() - NOW.getTime()).toBe(12 * 3600 * 1000);
  });

  it('sandi salah: pesan umum, hitungan gagal naik, audit tercatat', async () => {
    await expect(auth.login({ username: 'kasir.andi', password: 'salah-sekali-1' }, ctx()))
      .rejects.toMatchObject({ code: 'UNAUTHENTICATED', message: INVALID_CREDENTIALS });
    expect(repo.state.users.get('u-kasir')?.failed_login_count).toBe(1);
    expect(repo.state.audit.at(-1)?.action).toBe('auth.login.failed');
  });

  it('username tidak dikenal memberi pesan yang sama (tidak membocorkan username)', async () => {
    await expect(auth.login({ username: 'tidak.ada', password: PASSWORD }, ctx()))
      .rejects.toMatchObject({ code: 'UNAUTHENTICATED', message: INVALID_CREDENTIALS });
  });

  it('5 kali salah mengunci akun; sandi benar pun ditolak selama terkunci', async () => {
    for (let i = 0; i < 5; i++) {
      await auth.login({ username: 'kasir.andi', password: `salah-${i}-xxxxx` }, ctx(NOW, `10.0.0.${i}`)).catch(() => undefined);
    }
    await expect(auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx(NOW, '10.9.9.9')))
      .rejects.toMatchObject({ code: 'ACCOUNT_LOCKED' });
  });

  it('rate limit: percobaan ke-6 dalam satu menit dari IP yang sama ditolak', async () => {
    for (let i = 0; i < 5; i++) await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx());
    await expect(auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx()))
      .rejects.toMatchObject({ code: 'RATE_LIMITED' });
  });

  it('akun nonaktif ditolak setelah sandi terbukti benar', async () => {
    repo.state.users.get('u-kasir')!.is_active = false;
    await expect(auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx()))
      .rejects.toMatchObject({ code: 'ACCOUNT_INACTIVE' });
  });

  it('input kosong ditolak dengan pesan per field', async () => {
    await expect(auth.login({ username: '', password: '' }, ctx()))
      .rejects.toMatchObject({ code: 'VALIDATION_ERROR' });
  });

  it('database gagal di tengah login: tidak ada perubahan setengah jadi (skenario 9)', async () => {
    repo.failOn = 'createSession';
    repo.state.users.get('u-kasir')!.failed_login_count = 3;
    await expect(auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx())).rejects.toThrow('terputus');
    expect(repo.state.users.get('u-kasir')?.failed_login_count).toBe(3);
    expect(repo.state.sessions.size).toBe(0);
    expect(repo.state.audit.some((a) => a.action === 'auth.login.success')).toBe(false);
  });
});

describe('sesi', () => {
  it('token valid menghasilkan identitas dan peran pengguna', async () => {
    const { token } = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx());
    const s = await auth.validateSession(token, new Date(NOW.getTime() + 60_000));
    expect(s?.user).toMatchObject({ id: 'u-kasir', roles: ['KASIR'] });
  });

  it('logout mencabut sesi', async () => {
    const { token } = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx());
    const s = (await auth.validateSession(token, NOW))!;
    await auth.logout(s, ctx());
    expect(await auth.validateSession(token, NOW)).toBeNull();
  });

  it('sesi diam 30 menit tidak sah', async () => {
    const { token } = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx());
    expect(await auth.validateSession(token, new Date(NOW.getTime() + SESSION_IDLE_MS))).toBeNull();
  });

  it('logout paksa oleh owner memutus semua sesi pengguna', async () => {
    const a = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx(NOW, '10.0.0.1'));
    const b = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx(NOW, '10.0.0.2'));
    await auth.revokeAllSessions('u-owner', 'u-kasir', ctx());
    expect(await auth.validateSession(a.token, NOW)).toBeNull();
    expect(await auth.validateSession(b.token, NOW)).toBeNull();
  });
});

describe('ganti kata sandi', () => {
  it('berhasil: sesi lama di perangkat lain keluar, sesi baru dibuat', async () => {
    const other = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx(NOW, '10.0.0.1'));
    const mine = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx(NOW, '10.0.0.2'));
    const session = (await auth.validateSession(mine.token, NOW))!;
    const res = await auth.changePassword(session, {
      currentPassword: PASSWORD, newPassword: 'Biru-Laut-Teh-9', confirmPassword: 'Biru-Laut-Teh-9',
    }, ctx());
    expect(await auth.validateSession(other.token, NOW)).toBeNull();
    expect(await auth.validateSession(mine.token, NOW)).toBeNull();
    expect((await auth.validateSession(res.token, NOW))?.user.id).toBe('u-kasir');
    await expect(auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx(NOW, '10.0.0.3')))
      .rejects.toMatchObject({ code: 'UNAUTHENTICATED' });
  });

  it('sandi lama salah ditolak', async () => {
    const { token } = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx());
    const s = (await auth.validateSession(token, NOW))!;
    await expect(auth.changePassword(s, {
      currentPassword: 'bukan-sandi-lama', newPassword: 'Biru-Laut-Teh-9', confirmPassword: 'Biru-Laut-Teh-9',
    }, ctx())).rejects.toMatchObject({ code: 'VALIDATION_ERROR', fields: { currentPassword: 'Kata sandi lama salah.' } });
  });

  it('sandi baru yang lemah ditolak', async () => {
    const { token } = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx());
    const s = (await auth.validateSession(token, NOW))!;
    await expect(auth.changePassword(s, {
      currentPassword: PASSWORD, newPassword: 'apotek12345', confirmPassword: 'apotek12345',
    }, ctx())).rejects.toMatchObject({ code: 'VALIDATION_ERROR' });
  });

  it('konfirmasi berbeda ditolak', async () => {
    const { token } = await auth.login({ username: 'kasir.andi', password: PASSWORD }, ctx());
    const s = (await auth.validateSession(token, NOW))!;
    await expect(auth.changePassword(s, {
      currentPassword: PASSWORD, newPassword: 'Biru-Laut-Teh-9', confirmPassword: 'Biru-Laut-Teh-8',
    }, ctx())).rejects.toMatchObject({ code: 'VALIDATION_ERROR' });
  });
});
