import { describe, expect, it } from 'vitest';
import { formatSku, isHighControl, medicineRuleErrors } from '../../../src/modules/medicines/rules';
import { normalizeMoney } from '../../../src/lib/validation';

const base = {
  product_type: 'OTC' as const, drug_class: 'BEBAS' as const, requires_prescription: false, is_owa: false,
  registration_no: 'DBL1', min_stock: 0, max_stock: null, base_unit_id: 'u-tab', purchase_unit_id: 'u-tab', sales_unit_id: 'u-tab',
};

describe('aturan regulasi obat', () => {
  it('obat bebas yang lengkap lolos', () => {
    expect(medicineRuleErrors(base)).toEqual({});
  });
  it('psikotropika wajib resep', () => {
    expect(medicineRuleErrors({ ...base, product_type: 'PRESCRIPTION_DRUG', drug_class: 'PSIKOTROPIKA' }).requires_prescription).toContain('wajib resep');
  });
  it('obat keras: wajib resep ATAU OWA', () => {
    const keras = { ...base, product_type: 'PRESCRIPTION_DRUG' as const, drug_class: 'KERAS' as const };
    expect(medicineRuleErrors(keras).requires_prescription).toBeDefined();
    expect(medicineRuleErrors({ ...keras, is_owa: true })).toEqual({});
    expect(medicineRuleErrors({ ...keras, requires_prescription: true })).toEqual({});
    expect(medicineRuleErrors({ ...keras, is_owa: true, requires_prescription: true }).is_owa).toBeDefined();
  });
  it('OWA hanya untuk obat keras', () => {
    expect(medicineRuleErrors({ ...base, is_owa: true }).is_owa).toContain('obat keras');
  });
  it('NIE wajib untuk obat, tidak untuk alkes/BMHP', () => {
    expect(medicineRuleErrors({ ...base, registration_no: null }).registration_no).toBeDefined();
    expect(medicineRuleErrors({ ...base, product_type: 'MEDICAL_SUPPLY', drug_class: 'NON_OBAT', registration_no: null })).toEqual({});
  });
  it('jenis produk harus cocok dengan golongan', () => {
    expect(medicineRuleErrors({ ...base, drug_class: 'BEBAS_TERBATAS' }).drug_class).toBeDefined();
    expect(medicineRuleErrors({ ...base, product_type: 'MEDICAL_DEVICE' }).drug_class).toBeDefined();
  });
  it('satuan jual/beli harus satuan dasar atau ada di konversi', () => {
    expect(medicineRuleErrors({ ...base, sales_unit_id: 'u-strip' }).sales_unit_id).toBeDefined();
    expect(medicineRuleErrors({ ...base, sales_unit_id: 'u-strip' }, ['u-strip'])).toEqual({});
  });
  it('stok maksimum tidak boleh di bawah minimum', () => {
    expect(medicineRuleErrors({ ...base, min_stock: 10, max_stock: 5 }).max_stock).toBeDefined();
  });
  it('golongan kontrol ketat: narkotika, psikotropika, prekursor, OOT', () => {
    expect(isHighControl({ drug_class: 'NARKOTIKA', is_precursor: false, is_oot: false })).toBe(true);
    expect(isHighControl({ drug_class: 'KERAS', is_precursor: true, is_oot: false })).toBe(true);
    expect(isHighControl({ drug_class: 'KERAS', is_precursor: false, is_oot: false })).toBe(false);
  });
  it('format SKU', () => {
    expect(formatSku(42)).toBe('OBT-000042');
  });
});

describe('normalisasi harga untuk perbandingan', () => {
  it('format berbeda dengan nilai sama dianggap sama', () => {
    expect(normalizeMoney('1700')).toBe(normalizeMoney('1700.00'));
    expect(normalizeMoney('0040000.5')).toBe('40000.50');
    expect(normalizeMoney(null)).toBeNull();
    expect(normalizeMoney('')).toBeNull();
  });
  it('nilai berbeda tetap berbeda', () => {
    expect(normalizeMoney('1700.01') === normalizeMoney('1700')).toBe(false);
  });
});

import { medicineFilterSchema } from '@/modules/medicines/schemas';

describe('medicineFilterSchema', () => {
  it('memperlakukan golongan kosong dari form sebagai tidak difilter', () => {
    const f = medicineFilterSchema.parse({ q: 'paracetamol', golongan: '', status: 'aktif' });
    expect(f.golongan).toBeUndefined();
    expect(f.q).toBe('paracetamol');
    expect(f.status).toBe('aktif');
    expect(f.page).toBe(1);
  });
  it('tetap menerima golongan yang valid', () => {
    expect(medicineFilterSchema.parse({ golongan: 'KERAS' }).golongan).toBe('KERAS');
  });
  it('page kosong jatuh ke default 1', () => {
    expect(medicineFilterSchema.parse({ page: '' }).page).toBe(1);
  });
});
