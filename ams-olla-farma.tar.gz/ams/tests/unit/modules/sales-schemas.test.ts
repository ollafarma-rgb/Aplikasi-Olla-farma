import { describe, expect, it } from 'vitest';
import {
  customerSchema,
  openSessionSchema,
  closeSessionSchema,
  saleHeaderSchema,
  prescriptionHeaderSchema,
  saleReturnHeaderSchema,
  purchaseInvoiceSchema,
  supplierPaymentSchema,
  PAYMENT_METHOD_LABELS,
  INVOICE_STATUS_LABELS,
  RETURN_DISPOSITION_LABELS,
} from '../../../src/modules/sales/schemas';

// ─────────────────────────── Customer ───────────────────────────

describe('customerSchema', () => {
  const valid = {
    code: 'CUST001',
    name: 'Budi Santoso',
    phone: '',
    address: '',
    date_of_birth: '',
    credit_limit: '',
    notes: '',
  };

  it('pelanggan valid lolos', () => {
    const r = customerSchema.safeParse(valid);
    expect(r.success).toBe(true);
  });

  it('kode wajib diisi', () => {
    const r = customerSchema.safeParse({ ...valid, code: '' });
    expect(r.success).toBe(false);
    if (!r.success) expect(r.error.flatten().fieldErrors.code).toBeDefined();
  });

  it('nama wajib diisi', () => {
    const r = customerSchema.safeParse({ ...valid, name: '' });
    expect(r.success).toBe(false);
  });

  it('credit_limit kosong → "0"', () => {
    const r = customerSchema.safeParse({ ...valid, credit_limit: '' });
    expect(r.success).toBe(true);
    if (r.success) expect(r.data.credit_limit).toBe('0');
  });

  it('credit_limit dengan titik ribuan dinormalisasi', () => {
    const r = customerSchema.safeParse({ ...valid, credit_limit: '1.500.000' });
    expect(r.success).toBe(true);
    if (r.success) expect(r.data.credit_limit).toBe('1500000');
  });

  it('date_of_birth format invalid ditolak', () => {
    const r = customerSchema.safeParse({ ...valid, date_of_birth: '01/01/2000' });
    expect(r.success).toBe(false);
  });

  it('date_of_birth format YYYY-MM-DD valid', () => {
    const r = customerSchema.safeParse({ ...valid, date_of_birth: '1990-05-15' });
    expect(r.success).toBe(true);
  });

  it('date_of_birth kosong → undefined', () => {
    const r = customerSchema.safeParse({ ...valid, date_of_birth: '' });
    expect(r.success).toBe(true);
    if (r.success) expect(r.data.date_of_birth).toBeUndefined();
  });
});

// ─────────────────────────── Sesi Kasir ───────────────────────────

describe('openSessionSchema', () => {
  it('kas awal valid lolos', () => {
    const r = openSessionSchema.safeParse({ opening_cash: '500000', notes: '' });
    expect(r.success).toBe(true);
  });

  it('kas awal nol valid', () => {
    const r = openSessionSchema.safeParse({ opening_cash: '0', notes: '' });
    expect(r.success).toBe(true);
  });

  it('kas awal negatif ditolak', () => {
    const r = openSessionSchema.safeParse({ opening_cash: '-1000', notes: '' });
    expect(r.success).toBe(false);
  });

  it('kas awal kosong ditolak', () => {
    const r = openSessionSchema.safeParse({ opening_cash: '', notes: '' });
    expect(r.success).toBe(false);
  });
});

describe('closeSessionSchema', () => {
  it('kas akhir valid lolos', () => {
    const r = closeSessionSchema.safeParse({ closing_cash: '750000', notes: 'tutup normal' });
    expect(r.success).toBe(true);
  });

  it('kas akhir kosong ditolak', () => {
    const r = closeSessionSchema.safeParse({ closing_cash: '', notes: '' });
    expect(r.success).toBe(false);
  });
});

// ─────────────────────────── Penjualan ───────────────────────────

describe('saleHeaderSchema', () => {
  const valid = {
    customer_id: '',
    prescription_id: '',
    payment_method: 'CASH' as const,
    amount_paid: '50000',
    notes: '',
  };

  it('penjualan tunai valid lolos', () => {
    const r = saleHeaderSchema.safeParse(valid);
    expect(r.success).toBe(true);
  });

  it('penjualan piutang valid lolos', () => {
    const r = saleHeaderSchema.safeParse({ ...valid, payment_method: 'RECEIVABLE' });
    expect(r.success).toBe(true);
  });

  it('metode bayar tidak dikenal ditolak', () => {
    const r = saleHeaderSchema.safeParse({ ...valid, payment_method: 'DEBIT' });
    expect(r.success).toBe(false);
  });

  it('jumlah bayar negatif ditolak', () => {
    const r = saleHeaderSchema.safeParse({ ...valid, amount_paid: '-1000' });
    expect(r.success).toBe(false);
  });

  it('customer_id UUID valid diterima', () => {
    const r = saleHeaderSchema.safeParse({ ...valid, customer_id: '550e8400-e29b-41d4-a716-446655440000' });
    expect(r.success).toBe(true);
    if (r.success) expect(r.data.customer_id).toBe('550e8400-e29b-41d4-a716-446655440000');
  });

  it('customer_id kosong → null', () => {
    // optionalId transform '' ke null (bukan undefined)
    const r = saleHeaderSchema.safeParse({ ...valid, customer_id: '' });
    expect(r.success).toBe(true);
    if (r.success) expect(r.data.customer_id).toBeNull();
  });
});

// ─────────────────────────── Resep ───────────────────────────

describe('prescriptionHeaderSchema', () => {
  const valid = {
    customer_id: '',
    doctor_name: 'Dr. Suharto',
    doctor_sip: 'SIP.123/2024',
    clinic_name: 'Klinik Sehat',
    prescribed_at: '2024-11-13',
    notes: '',
  };

  it('resep valid lolos', () => {
    const r = prescriptionHeaderSchema.safeParse(valid);
    expect(r.success).toBe(true);
  });

  it('nama dokter wajib diisi', () => {
    const r = prescriptionHeaderSchema.safeParse({ ...valid, doctor_name: '' });
    expect(r.success).toBe(false);
  });

  it('tanggal resep wajib format YYYY-MM-DD', () => {
    const r = prescriptionHeaderSchema.safeParse({ ...valid, prescribed_at: '13/11/2024' });
    expect(r.success).toBe(false);
  });

  it('tanggal resep valid lolos', () => {
    const r = prescriptionHeaderSchema.safeParse({ ...valid, prescribed_at: '2024-11-01' });
    expect(r.success).toBe(true);
  });
});

// ─────────────────────────── Retur Penjualan ───────────────────────────

describe('saleReturnHeaderSchema', () => {
  it('dengan sale_id UUID valid lolos', () => {
    const r = saleReturnHeaderSchema.safeParse({ sale_id: '550e8400-e29b-41d4-a716-446655440000', notes: '' });
    expect(r.success).toBe(true);
  });

  it('sale_id kosong ditolak', () => {
    const r = saleReturnHeaderSchema.safeParse({ sale_id: '', notes: '' });
    expect(r.success).toBe(false);
  });

  it('sale_id bukan UUID ditolak', () => {
    const r = saleReturnHeaderSchema.safeParse({ sale_id: 'bukan-uuid', notes: '' });
    expect(r.success).toBe(false);
  });
});

// ─────────────────────────── Faktur Pembelian ───────────────────────────

describe('purchaseInvoiceSchema', () => {
  const valid = {
    gr_id: '550e8400-e29b-41d4-a716-446655440001',
    supplier_inv_no: 'INV/PBF/2024/001',
    invoice_date: '2024-11-01',
    due_date: '2024-12-01',
    notes: '',
  };

  it('faktur valid lolos', () => {
    const r = purchaseInvoiceSchema.safeParse(valid);
    expect(r.success).toBe(true);
  });

  it('gr_id wajib UUID', () => {
    const r = purchaseInvoiceSchema.safeParse({ ...valid, gr_id: '' });
    expect(r.success).toBe(false);
  });

  it('tanggal faktur wajib format YYYY-MM-DD', () => {
    const r = purchaseInvoiceSchema.safeParse({ ...valid, invoice_date: '01-11-2024' });
    expect(r.success).toBe(false);
  });

  it('tanggal jatuh tempo wajib diisi', () => {
    const r = purchaseInvoiceSchema.safeParse({ ...valid, due_date: '' });
    expect(r.success).toBe(false);
  });

  it('supplier_inv_no opsional', () => {
    const r = purchaseInvoiceSchema.safeParse({ ...valid, supplier_inv_no: '' });
    expect(r.success).toBe(true);
  });
});

// ─────────────────────────── Pembayaran Pemasok ───────────────────────────

describe('supplierPaymentSchema', () => {
  const valid = {
    invoice_id: '550e8400-e29b-41d4-a716-446655440002',
    payment_date: '2024-11-13',
    amount: '1500000',
    reference_no: 'TRF/BCA/001',
    notes: '',
  };

  it('pembayaran valid lolos', () => {
    const r = supplierPaymentSchema.safeParse(valid);
    expect(r.success).toBe(true);
  });

  it('jumlah bayar nol diterima schema (validasi bisnis ada di service)', () => {
    // money() schema hanya memvalidasi format angka, bukan nilai minimal
    const r = supplierPaymentSchema.safeParse({ ...valid, amount: '0' });
    expect(r.success).toBe(true);
  });

  it('jumlah bayar negatif ditolak (regex tidak cocok)', () => {
    const r = supplierPaymentSchema.safeParse({ ...valid, amount: '-500000' });
    expect(r.success).toBe(false);
  });

  it('invoice_id wajib UUID', () => {
    const r = supplierPaymentSchema.safeParse({ ...valid, invoice_id: '' });
    expect(r.success).toBe(false);
  });

  it('tanggal bayar wajib format YYYY-MM-DD', () => {
    const r = supplierPaymentSchema.safeParse({ ...valid, payment_date: '13/11/2024' });
    expect(r.success).toBe(false);
  });

  it('referensi opsional', () => {
    const r = supplierPaymentSchema.safeParse({ ...valid, reference_no: '' });
    expect(r.success).toBe(true);
  });
});

// ─────────────────────────── Label Konstan ───────────────────────────

describe('label konstan', () => {
  it('semua metode bayar punya label Indonesia', () => {
    expect(PAYMENT_METHOD_LABELS.CASH).toBe('Tunai');
    expect(PAYMENT_METHOD_LABELS.RECEIVABLE).toBe('Piutang');
  });

  it('semua status faktur punya label Indonesia', () => {
    expect(INVOICE_STATUS_LABELS.UNPAID).toBe('Belum dibayar');
    expect(INVOICE_STATUS_LABELS.PARTIAL).toBe('Dibayar sebagian');
    expect(INVOICE_STATUS_LABELS.PAID).toBe('Lunas');
  });

  it('semua disposisi retur punya label Indonesia', () => {
    expect(RETURN_DISPOSITION_LABELS.RESTOCK).toBe('Kembalikan ke stok');
    expect(RETURN_DISPOSITION_LABELS.QUARANTINE).toBe('Masuk karantina');
    expect(RETURN_DISPOSITION_LABELS.DISPOSE).toBe('Langsung dibuang');
  });
});
