// Pengganti modul 'server-only' saat menjalankan tes di Node (bukan React Server).
export {};
