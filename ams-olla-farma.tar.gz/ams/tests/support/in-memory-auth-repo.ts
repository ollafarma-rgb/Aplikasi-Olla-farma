/**
 * AuthRepository in-memory untuk tes unit service autentikasi.
 * transaction() memotret state dan mengembalikannya bila callback gagal,
 * meniru ROLLBACK database.
 */
import type { AuditEntry } from '../../src/lib/audit/types';
import type { SessionRecord } from '../../src/lib/auth/session-token';
import type { AuthRepository, AuthUser } from '../../src/modules/authentication/types';

interface State {
  users: Map<string, AuthUser & { last_login_at?: Date }>;
  sessions: Map<string, SessionRecord & { ip: string | null; user_agent: string | null }>;
  audit: AuditEntry[];
  rate: Map<string, number>;
}

function clone(state: State): State {
  return {
    users: new Map([...state.users].map(([k, v]) => [k, { ...v, roles: [...v.roles] }])),
    sessions: new Map([...state.sessions].map(([k, v]) => [k, { ...v }])),
    audit: [...state.audit],
    rate: new Map(state.rate),
  };
}

export class InMemoryAuthRepo implements AuthRepository {
  state: State = { users: new Map(), sessions: new Map(), audit: [], rate: new Map() };
  /** Set untuk mensimulasikan kegagalan database pada operasi tertentu. */
  failOn: 'createSession' | null = null;

  addUser(user: AuthUser) {
    this.state.users.set(user.id, user);
  }

  async findUserByUsername(username: string) {
    for (const u of this.state.users.values()) if (u.username === username) return { ...u };
    return null;
  }
  async findUserById(id: string) {
    const u = this.state.users.get(id);
    return u ? { ...u } : null;
  }
  async updateLoginState(userId: string, s: { failed_login_count: number; locked_until: Date | null; last_login_at?: Date }) {
    const u = this.state.users.get(userId)!;
    Object.assign(u, s);
  }
  async updatePassword(userId: string, hash: string, mustChange: boolean) {
    const u = this.state.users.get(userId)!;
    u.password_hash = hash;
    u.must_change_password = mustChange;
  }
  async bumpSessionVersion(userId: string) {
    const u = this.state.users.get(userId)!;
    u.session_version += 1;
    return u.session_version;
  }
  async createSession(s: SessionRecord & { ip: string | null; user_agent: string | null }) {
    if (this.failOn === 'createSession') throw new Error('simulasi: koneksi database terputus');
    this.state.sessions.set(s.id, { ...s });
  }
  async findSession(id: string) {
    const s = this.state.sessions.get(id);
    return s ? { ...s } : null;
  }
  async touchSession(id: string, at: Date) {
    const s = this.state.sessions.get(id);
    if (s) s.last_seen_at = at;
  }
  async revokeSession(id: string, at: Date) {
    const s = this.state.sessions.get(id);
    if (s && !s.revoked_at) s.revoked_at = at;
  }
  async rateLimitHit(key: string, _window: number, max: number) {
    const n = (this.state.rate.get(key) ?? 0) + 1;
    this.state.rate.set(key, n);
    return n <= max;
  }
  async writeAudit(entry: AuditEntry) {
    this.state.audit.push(entry);
  }
  async transaction<T>(fn: (repo: AuthRepository) => Promise<T>): Promise<T> {
    const snapshot = clone(this.state);
    try {
      return await fn(this);
    } catch (e) {
      this.state = snapshot;
      throw e;
    }
  }
}
