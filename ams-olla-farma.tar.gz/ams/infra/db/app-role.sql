-- Hak akses pengguna database aplikasi (jalankan oleh pemilik skema setelah migrasi).
-- Pengguna migrasi (pemilik tabel) dan pengguna aplikasi WAJIB berbeda.
-- Contoh: psql "$MIGRATION_DATABASE_URL" -v app_role=ams_app -f infra/db/app-role.sql

GRANT USAGE ON SCHEMA public TO :"app_role";
REVOKE CREATE ON SCHEMA public FROM :"app_role";
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO :"app_role";
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO :"app_role";
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO :"app_role";

-- Pertahanan berlapis untuk tabel append-only (trigger juga menolak).
REVOKE UPDATE, DELETE, TRUNCATE ON "audit_logs" FROM :"app_role";

-- Tabel yang dibuat migrasi berikutnya ikut mendapat hak yang sama.
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO :"app_role";
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO :"app_role";
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT EXECUTE ON FUNCTIONS TO :"app_role";

-- Fase 3: riwayat harga hanya ditulis trigger, tidak pernah diubah.
REVOKE UPDATE, DELETE, TRUNCATE ON "medicine_price_history" FROM :"app_role";

-- Fase 4: buku besar stok hanya ditulis (append-only), tidak pernah diubah/dihapus.
REVOKE UPDATE, DELETE, TRUNCATE ON "stock_movements" FROM :"app_role";
