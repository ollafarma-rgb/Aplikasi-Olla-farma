import type { NextConfig } from 'next';

/**
 * Header keamanan dasar. Content-Security-Policy dengan nonce dipasang di
 * src/proxy.ts agar setiap respons mendapat nonce baru.
 */
const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains' },
];

const nextConfig: NextConfig = {
  poweredByHeader: false,
  reactStrictMode: true,
  // Output standalone: satu folder mandiri untuk deployment (Railway, Docker, VPS).
  output: 'standalone',
  // pg dan node:crypto dipakai di server; jangan dibundel ke klien.
  serverExternalPackages: ['pg'],
  async headers() {
    return [{ source: '/:path*', headers: securityHeaders }];
  },
};

export default nextConfig;
