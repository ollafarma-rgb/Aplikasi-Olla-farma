// Konfigurasi Prisma 7. Variabel lingkungan dimuat eksplisit (Prisma 7 tidak lagi
// memuat .env otomatis). MIGRATION_DATABASE_URL = pengguna pemilik skema;
// aplikasi memakai DATABASE_URL dengan pengguna terbatas (lihat infra/db/app-role.sql).
import 'dotenv/config';
import { defineConfig, env } from 'prisma/config';

export default defineConfig({
  schema: 'prisma/schema.prisma',
  migrations: {
    path: 'prisma/migrations',
    seed: 'tsx prisma/seed.ts',
  },
  datasource: {
    url: env('MIGRATION_DATABASE_URL'),
    shadowDatabaseUrl: env('SHADOW_DATABASE_URL'),
  },
});
