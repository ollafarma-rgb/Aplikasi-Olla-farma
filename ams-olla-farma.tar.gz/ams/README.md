# AMS — Apotek Management System

Sistem manajemen apotek berbasis web untuk **Apotek OLLA FARMA** (PT OLLA FARMA MANDIRI, Banda Aceh).
Modular monolith: Next.js 16.4 + TypeScript 6 + PostgreSQL 16 + Prisma 7.10.

## Status

| Fase | Isi | Status |
| --- | --- | --- |
| 1 | Arsitektur, ERD, skema, matriks izin | Disetujui 12 Nov 2026 |
| 2 | Fondasi: migrasi identitas/RBAC/audit, autentikasi, layout | Selesai 12 Nov 2026 — lihat `docs/phase-reports/fase-2.md` |
| 3 | Master data: obat (satuan berjenjang, barcode), referensi, pemasok, karyawan/pengguna | Selesai 12 Nov 2026 — lihat `docs/phase-reports/fase-3.md` |
| 4 | Persediaan: batch, kartu stok, saldo awal, penyesuaian (maker-checker), stok opname | Selesai 12 Nov 2026 — lihat `docs/phase-reports/fase-4.md` |
| 5 | Pengadaan: Surat Pesanan, penerimaan barang (maker-checker, membentuk batch), retur pembelian | Selesai 13 Nov 2026 — lihat `docs/phase-reports/fase-5.md` |
| 6–11 | Penjualan/kasir → produksi | Belum dimulai |

## Struktur

```text
prisma/            schema.prisma (hanya tabel yang sudah dimigrasi), migrations/, seed
src/app/           halaman Next.js: (auth) login, (account) ganti sandi, (app) dashboard/obat/pemasok/persediaan/penyesuaian/opname/pengadaan/karyawan
src/modules/       domain: authentication, medicines, references, suppliers, users, inventory, procurement (service, actions, schemas)
src/lib/           auth, permissions, database, errors, numbering, money, audit
infra/db/          hak akses pengguna database aplikasi
tests/             unit (Vitest), integration/db (SQL di PostgreSQL asli), e2e (Playwright)
docs/              ADR, ERD draf 62 tabel, runbook, laporan fase
```

Mulai dari `docs/runbooks/local-setup.md`.

## Aturan pengembangan

- Logika bisnis hanya di `src/modules/*/service.ts`; halaman dan Server Action tetap tipis.
- Setiap perubahan skema lewat migrasi baru; jangan mengubah migrasi yang sudah diterapkan.
- Izin dicek di server dengan kode izin (`requireActionPermission('sales.create')`), bukan nama peran.
- Tidak ada angka contoh di dashboard produksi; data contoh hanya di seed development.
