'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utilities/cn';

export interface ShellNavItem {
  href: string;
  label: string;
  group: string;
}

const GROUP_LABELS: Record<string, string> = {
  utama: 'Utama',
  farmasi: 'Kefarmasian',
  transaksi: 'Transaksi',
  keuangan: 'Keuangan & Laporan',
  admin: 'Administrasi',
};

export function SidebarNav({ items }: { items: ShellNavItem[] }) {
  const pathname = usePathname();
  const groups = [...new Set(items.map((i) => i.group))];
  return (
    <nav aria-label="Menu utama" className="space-y-4 p-3">
      {groups.map((g) => (
        <div key={g}>
          <p className="px-2 pb-1 text-xs font-semibold uppercase tracking-wide text-gray-400">{GROUP_LABELS[g] ?? g}</p>
          <ul className="space-y-0.5">
            {items.filter((i) => i.group === g).map((item) => {
              const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={active ? 'page' : undefined}
                    className={cn(
                      'block rounded-md px-2 py-1.5 text-sm',
                      active ? 'bg-brand-50 font-medium text-brand-800' : 'text-gray-700 hover:bg-gray-100',
                    )}
                  >
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
}
