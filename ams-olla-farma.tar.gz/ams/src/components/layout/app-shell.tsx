import Link from 'next/link';
import type { ReactNode } from 'react';
import { logoutAction } from '@/modules/authentication/actions';
import { Button } from '@/components/ui/button';
import { ConnectionBanner } from './connection-banner';
import { SidebarNav, type ShellNavItem } from './sidebar-nav';

interface AppShellProps {
  nav: ShellNavItem[];
  fullName: string;
  roleNames: string[];
  children: ReactNode;
}

/** Kerangka aplikasi: sidebar (desktop) / menu atas (ponsel), top bar, konten. */
export function AppShell({ nav, fullName, roleNames, children }: AppShellProps) {
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[240px_1fr]">
      <aside className="hidden border-r border-gray-200 bg-white lg:block">
        <div className="flex h-14 items-center border-b border-gray-200 px-4">
          <Link href="/dashboard" className="font-semibold text-brand-700">AMS · OLLA FARMA</Link>
        </div>
        <SidebarNav items={nav} />
      </aside>

      <div className="flex min-w-0 flex-col">
        <header className="flex h-14 items-center justify-between gap-3 border-b border-gray-200 bg-white px-4">
          <details className="relative lg:hidden">
            <summary className="cursor-pointer list-none rounded-md px-2 py-1 text-sm font-medium text-gray-700 hover:bg-gray-100">
              Menu
            </summary>
            <div className="absolute left-0 z-20 mt-2 w-64 rounded-md border border-gray-200 bg-white shadow-lg">
              <SidebarNav items={nav} />
            </div>
          </details>
          <div className="min-w-0 flex-1 text-right lg:text-left">
            <p className="truncate text-sm font-medium">{fullName}</p>
            <p className="truncate text-xs text-gray-500">{roleNames.join(', ')}</p>
          </div>
          <Link href="/akun/ganti-sandi" className="hidden text-sm text-gray-600 hover:text-gray-900 sm:inline">
            Ganti sandi
          </Link>
          <form action={logoutAction}>
            <Button type="submit" variant="secondary" size="sm">Keluar</Button>
          </form>
        </header>
        <ConnectionBanner />
        <main className="flex-1 p-4 lg:p-6">{children}</main>
      </div>
    </div>
  );
}
