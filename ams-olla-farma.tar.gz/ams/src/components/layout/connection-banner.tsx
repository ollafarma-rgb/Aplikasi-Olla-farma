'use client';

import { useOnlineStatus } from './use-online-status';

/** Banner merah saat browser kehilangan koneksi (Part 6: online-only). */
export function ConnectionBanner() {
  const online = useOnlineStatus();
  if (online) return null;
  return (
    <div role="alert" className="bg-danger-600 px-4 py-2 text-sm font-medium text-white">
      Koneksi terputus. Data yang belum dikonfirmasi server BELUM tersimpan.
    </div>
  );
}
