'use client';

import { useFormStatus } from 'react-dom';
import { Button, type ButtonProps } from './button';

/** Tombol submit yang nonaktif selama permintaan berjalan (mencegah klik ganda). */
export function SubmitButton({ children, pendingText = 'Menyimpan…', ...props }: ButtonProps & { pendingText?: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending || props.disabled} {...props}>
      {pending ? pendingText : children}
    </Button>
  );
}
