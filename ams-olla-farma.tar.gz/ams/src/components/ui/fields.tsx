import type { ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react';
import { cn } from '@/lib/utilities/cn';

const control = (error?: string) =>
  cn(
    'w-full rounded-md border bg-white px-3 text-sm outline-none focus:border-brand-600 focus:ring-2 focus:ring-brand-100',
    error ? 'border-danger-600' : 'border-gray-300',
  );

function Wrap({ id, label, error, hint, children }: { id: string; label: string; error?: string; hint?: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-gray-800">{label}</label>
      {children}
      {hint && !error ? <p id={`${id}-hint`} className="text-xs text-gray-500">{hint}</p> : null}
      {error ? <p id={`${id}-error`} className="text-xs text-danger-700">{error}</p> : null}
    </div>
  );
}

interface SelectFieldProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  name: string;
  error?: string;
  hint?: string;
  options: { value: string; label: string }[];
  placeholder?: string;
}

export function SelectField({ label, name, error, hint, options, placeholder, className, ...props }: SelectFieldProps) {
  const id = props.id ?? `field-${name}`;
  return (
    <Wrap id={id} label={label} error={error} hint={hint}>
      <select id={id} name={name} aria-invalid={error ? true : undefined} aria-describedby={error ? `${id}-error` : undefined}
        className={cn(control(error), 'h-10', className)} {...props}>
        {placeholder !== undefined ? <option value="">{placeholder}</option> : null}
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </Wrap>
  );
}

interface TextAreaFieldProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  name: string;
  error?: string;
}

export function TextAreaField({ label, name, error, className, ...props }: TextAreaFieldProps) {
  const id = props.id ?? `field-${name}`;
  return (
    <Wrap id={id} label={label} error={error}>
      <textarea id={id} name={name} rows={3} aria-invalid={error ? true : undefined} className={cn(control(error), 'py-2', className)} {...props} />
    </Wrap>
  );
}

export function CheckboxField({ label, name, defaultChecked, error, disabled, hint }: {
  label: string; name: string; defaultChecked?: boolean; error?: string; disabled?: boolean; hint?: string;
}) {
  const id = `field-${name}`;
  return (
    <div>
      <label htmlFor={id} className={cn('flex items-start gap-2 text-sm', disabled && 'opacity-60')}>
        <input id={id} type="checkbox" name={name} defaultChecked={defaultChecked} disabled={disabled}
          className="mt-0.5 h-4 w-4 rounded border-gray-300 accent-brand-600" aria-invalid={error ? true : undefined} />
        <span>
          {label}
          {hint ? <span className="block text-xs text-gray-500">{hint}</span> : null}
        </span>
      </label>
      {error ? <p className="mt-1 text-xs text-danger-700">{error}</p> : null}
    </div>
  );
}
