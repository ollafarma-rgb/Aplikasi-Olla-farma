import type { InputHTMLAttributes } from 'react';
import { cn } from '@/lib/utilities/cn';

interface FormFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  name: string;
  error?: string;
  hint?: string;
}

/** Label + input + pesan error yang terhubung untuk pembaca layar. */
export function FormField({ label, name, error, hint, className, id, ...props }: FormFieldProps) {
  const inputId = id ?? `field-${name}`;
  const describedBy = [error ? `${inputId}-error` : null, hint ? `${inputId}-hint` : null].filter(Boolean).join(' ') || undefined;
  return (
    <div className="space-y-1.5">
      <label htmlFor={inputId} className="block text-sm font-medium text-gray-800">
        {label}
      </label>
      <input
        id={inputId}
        name={name}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy}
        className={cn(
          'h-10 w-full rounded-md border bg-white px-3 text-sm outline-none',
          'focus:border-brand-600 focus:ring-2 focus:ring-brand-100',
          error ? 'border-danger-600' : 'border-gray-300',
          className,
        )}
        {...props}
      />
      {hint && !error ? <p id={`${inputId}-hint`} className="text-xs text-gray-500">{hint}</p> : null}
      {error ? <p id={`${inputId}-error`} className="text-xs text-danger-700">{error}</p> : null}
    </div>
  );
}
