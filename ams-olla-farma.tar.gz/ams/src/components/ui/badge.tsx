import type { ReactNode } from 'react';
import { cn } from '@/lib/utilities/cn';

const tones = {
  gray: 'bg-gray-100 text-gray-700',
  green: 'bg-brand-50 text-brand-800',
  red: 'bg-danger-50 text-danger-700',
  amber: 'bg-amber-50 text-amber-800',
  blue: 'bg-sky-50 text-sky-800',
};

export function Badge({ tone = 'gray', children }: { tone?: keyof typeof tones; children: ReactNode }) {
  return <span className={cn('inline-flex items-center rounded px-1.5 py-0.5 text-xs font-medium', tones[tone])}>{children}</span>;
}
