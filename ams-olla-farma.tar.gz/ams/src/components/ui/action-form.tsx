'use client';

import { useActionState, type ReactNode } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from './alert';

/**
 * Form sederhana untuk tombol aksi (aktifkan, hapus, buka kunci, dsb.):
 * menampilkan pesan sukses/gagal dari server di atas tombol.
 */
export function ActionForm({ action, children, className, confirmText }: {
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  children: ReactNode;
  className?: string;
  confirmText?: string;
}) {
  const [state, formAction] = useActionState(action, initialActionState);
  return (
    <form
      action={formAction}
      className={className}
      onSubmit={confirmText ? (e) => { if (!window.confirm(confirmText)) e.preventDefault(); } : undefined}
    >
      {state.message ? <div className="mb-2"><Alert tone={state.ok ? 'success' : 'error'}>{state.message}</Alert></div> : null}
      {children}
    </form>
  );
}

/** Nilai awal input: pakai nilai terakhir yang dikirim bila submit gagal. */
export function valueOf(state: ActionState, initial: Record<string, string>, key: string): string {
  if (!state.ok && state.values && key in state.values) return state.values[key];
  return initial[key] ?? '';
}

export function checkedOf(state: ActionState, initial: Record<string, string>, key: string): boolean {
  if (!state.ok && state.values) return state.values[key] === 'on';
  return initial[key] === 'on';
}
