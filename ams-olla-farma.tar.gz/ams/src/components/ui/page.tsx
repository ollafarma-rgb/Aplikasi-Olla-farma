import Link from 'next/link';
import type { ReactNode } from 'react';

export function PageHeader({ title, description, actions, back }: {
  title: string; description?: string; actions?: ReactNode; back?: { href: string; label: string };
}) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        {back ? <Link href={back.href} className="text-sm text-gray-600 hover:text-gray-900">← {back.label}</Link> : null}
        <h1 className="text-xl font-semibold">{title}</h1>
        {description ? <p className="mt-0.5 text-sm text-gray-600">{description}</p> : null}
      </div>
      {actions ? <div className="flex gap-2">{actions}</div> : null}
    </div>
  );
}

export function Section({ title, children, actions }: { title: string; children: ReactNode; actions?: ReactNode }) {
  return (
    <section className="rounded-lg border border-gray-200 bg-white">
      <div className="flex items-center justify-between border-b border-gray-200 px-4 py-3">
        <h2 className="text-sm font-semibold">{title}</h2>
        {actions}
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

export function EmptyState({ children }: { children: ReactNode }) {
  return <p className="rounded-md border border-dashed border-gray-300 bg-white px-4 py-8 text-center text-sm text-gray-600">{children}</p>;
}

export function LinkButton({ href, children, variant = 'primary' }: { href: string; children: ReactNode; variant?: 'primary' | 'secondary' }) {
  const cls = variant === 'primary'
    ? 'bg-brand-600 text-white hover:bg-brand-700'
    : 'border border-gray-300 bg-white text-gray-800 hover:bg-gray-50';
  return <Link href={href} className={`inline-flex h-10 items-center rounded-md px-4 text-sm font-medium ${cls}`}>{children}</Link>;
}

/** Navigasi halaman: mempertahankan parameter pencarian lain. */
export function Pagination({ page, pages, total, params, basePath }: {
  page: number; pages: number; total: number; params: Record<string, string | undefined>; basePath: string;
}) {
  const href = (p: number) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) q.set(k, v);
    q.set('page', String(p));
    return `${basePath}?${q.toString()}`;
  };
  return (
    <div className="mt-3 flex items-center justify-between text-sm text-gray-600">
      <span>{total} data · halaman {page} dari {pages}</span>
      <div className="flex gap-2">
        {page > 1 ? <Link className="rounded-md border border-gray-300 bg-white px-3 py-1 hover:bg-gray-50" href={href(page - 1)}>Sebelumnya</Link> : null}
        {page < pages ? <Link className="rounded-md border border-gray-300 bg-white px-3 py-1 hover:bg-gray-50" href={href(page + 1)}>Berikutnya</Link> : null}
      </div>
    </div>
  );
}
