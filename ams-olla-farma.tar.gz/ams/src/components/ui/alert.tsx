import type { ReactNode } from 'react';
import { cn } from '@/lib/utilities/cn';

export function Alert({ tone = 'info', children }: { tone?: 'info' | 'error' | 'success'; children: ReactNode }) {
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={cn(
        'rounded-md border px-3 py-2 text-sm',
        tone === 'error' && 'border-danger-600/30 bg-danger-50 text-danger-700',
        tone === 'success' && 'border-brand-200 bg-brand-50 text-brand-800',
        tone === 'info' && 'border-gray-200 bg-white text-gray-700',
      )}
    >
      {children}
    </div>
  );
}
