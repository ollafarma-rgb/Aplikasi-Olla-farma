'use server';

import { revalidatePath } from 'next/cache';
import { runFormAction } from '@/lib/actions';
import type { ActionState } from '@/lib/forms';
import {
  addLicense, createUser, removeLicense, resetUserPassword, setUserActive, unlockUser, updateUser,
} from './service';

const done = (state: ActionState, id?: string) => {
  if (state.ok) {
    revalidatePath('/karyawan');
    if (id) revalidatePath(`/karyawan/${id}`);
  }
  return state;
};

export async function createUserAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  return done(await runFormAction(fd, 'users.manage', async (actor, values) => {
    const r = await createUser(values, actor);
    return { message: 'Akun dibuat.', data: { id: r.id, username: values.username.trim().toLowerCase(), temporaryPassword: r.temporaryPassword } };
  }));
}

export async function updateUserAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  return done(await runFormAction(fd, 'users.manage', async (actor, values) => {
    await updateUser(id, values, actor);
    return 'Data karyawan tersimpan. Bila peran diubah, karyawan perlu login ulang.';
  }), id);
}

export async function setUserActiveAction(id: string, active: boolean, _prev: ActionState, fd: FormData): Promise<ActionState> {
  return done(await runFormAction(fd, 'users.manage', async (actor) => {
    await setUserActive(id, active, actor);
    return active ? 'Akun diaktifkan.' : 'Akun dinonaktifkan dan semua sesinya diputus.';
  }), id);
}

export async function resetPasswordAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  return done(await runFormAction(fd, 'users.manage', async (actor) => {
    const temporaryPassword = await resetUserPassword(id, actor);
    return { message: 'Sandi direset.', data: { temporaryPassword } };
  }), id);
}

export async function unlockUserAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  return done(await runFormAction(fd, 'users.manage', async (actor) => {
    await unlockUser(id, actor);
    return 'Kunci akun dibuka.';
  }), id);
}

export async function addLicenseAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  return done(await runFormAction(fd, 'users.manage', async (actor, values) => {
    await addLicense(id, values, actor);
    return 'Izin praktik ditambahkan.';
  }), id);
}

export async function removeLicenseAction(id: string, licenseId: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  return done(await runFormAction(fd, 'users.manage', async (actor) => {
    await removeLicense(id, licenseId, actor);
    return 'Izin praktik dihapus.';
  }), id);
}
