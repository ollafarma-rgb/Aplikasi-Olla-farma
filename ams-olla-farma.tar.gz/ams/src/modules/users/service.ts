import 'server-only';
import { randomInt } from 'node:crypto';
import { z } from 'zod';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { hashPassword } from '../../lib/auth/password';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import type { DbTransaction } from '../../lib/database/client';
import { AppError } from '../../lib/errors';
import { optionalText, text } from '../../lib/forms';
import { ROLES, type RoleCode } from '../../lib/permissions/catalog';
import { parseOrThrow } from '../../lib/validation';

const ROLE_CODES = ROLES.map((r) => r.code) as [RoleCode, ...RoleCode[]];

/** Huruf/angka tanpa yang mirip (0/O, 1/l/I) agar mudah dibacakan ke karyawan. */
const ALPHABET = 'abcdefghjkmnpqrstuvwxyz23456789';

export function generateTemporaryPassword(): string {
  const group = () => Array.from({ length: 4 }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');
  return `${group()}-${group()}-${group()}`;
}

function rolesFromForm(raw: Record<string, unknown>): string[] {
  return ROLE_CODES.filter((c) => raw[`role_${c}`] === 'on');
}

const profileSchema = z.object({
  full_name: text(150, 'Nama lengkap'),
  phone: optionalText(30, 'Telepon').refine((v) => v === null || /^[0-9+()\s-]{6,30}$/.test(v), 'Nomor telepon tidak valid.'),
  roles: z.array(z.enum(ROLE_CODES)).min(1, 'Pilih minimal satu peran.'),
});

const createSchema = profileSchema.extend({
  username: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9._-]{3,50}$/, 'Nama pengguna 3–50 karakter: huruf kecil, angka, titik, minus, garis bawah.'),
});

const licenseSchema = z.object({
  license_type: z.enum(['STR', 'SIPA', 'SIPTTK', 'OTHER'], { message: 'Jenis izin wajib dipilih.' }),
  number: text(100, 'Nomor izin'),
  valid_until: z
    .string()
    .trim()
    .optional()
    .transform((v) => (v ? v : null))
    .refine((v) => v === null || /^\d{4}-\d{2}-\d{2}$/.test(v), 'Tanggal tidak valid.'),
});

export async function listUsers(actor: Actor) {
  assertCan(actor, 'employees.view');
  const users = await prisma.user.findMany({
    orderBy: [{ is_active: 'desc' }, { full_name: 'asc' }],
    select: {
      id: true, username: true, full_name: true, phone: true, is_active: true, locked_until: true, last_login_at: true,
      roles: { select: { role: { select: { code: true, name: true } } } },
      licenses: { select: { license_type: true, valid_until: true } },
    },
  });
  const soon = Date.now() + 90 * 24 * 3600 * 1000;
  return users.map((u) => ({
    ...u,
    roles: u.roles.map((r) => r.role),
    locked: u.locked_until !== null && u.locked_until.getTime() > Date.now(),
    licenseExpiringSoon: u.licenses.some((l) => l.valid_until !== null && l.valid_until.getTime() < soon),
  }));
}

export async function getUser(id: string, actor: Actor) {
  assertCan(actor, 'employees.view');
  const u = await prisma.user.findUnique({
    where: { id },
    select: {
      id: true, username: true, full_name: true, phone: true, is_active: true, locked_until: true,
      failed_login_count: true, must_change_password: true, last_login_at: true, created_at: true,
      roles: { select: { role: { select: { code: true } } } },
      licenses: { orderBy: { created_at: 'asc' } },
    },
  });
  if (!u) throw new AppError('NOT_FOUND');
  return {
    ...u,
    roleCodes: u.roles.map((r) => r.role.code as RoleCode),
    locked: u.locked_until !== null && u.locked_until.getTime() > Date.now(),
  };
}

async function activeOwnerCount(tx: DbTransaction, excludeUserId?: string): Promise<number> {
  return tx.user.count({
    where: { is_active: true, roles: { some: { role: { code: 'OWNER' } } }, ...(excludeUserId ? { id: { not: excludeUserId } } : {}) },
  });
}

async function setRoles(tx: DbTransaction, userId: string, codes: readonly string[]) {
  const roles = await tx.role.findMany({ where: { code: { in: [...codes] } }, select: { id: true } });
  await tx.userRole.deleteMany({ where: { user_id: userId } });
  await tx.userRole.createMany({ data: roles.map((r) => ({ user_id: userId, role_id: r.id })) });
}

/** Buat akun karyawan. Sandi sementara dikembalikan SEKALI untuk diberikan langsung ke karyawan. */
export async function createUser(raw: Record<string, unknown>, actor: Actor): Promise<{ id: string; temporaryPassword: string }> {
  assertCan(actor, 'users.manage');
  const input = parseOrThrow(createSchema, { ...raw, roles: rolesFromForm(raw) });
  const temporaryPassword = generateTemporaryPassword();
  const password_hash = await hashPassword(temporaryPassword);
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const u = await tx.user.create({
        data: { username: input.username, full_name: input.full_name, phone: input.phone, password_hash, must_change_password: true },
      });
      await setRoles(tx, u.id, input.roles);
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'user.created', entity: 'user', entity_id: u.id,
        after: { username: input.username, full_name: input.full_name, roles: input.roles },
      });
      return { id: u.id, temporaryPassword };
    }),
  );
}

export async function updateUser(id: string, raw: Record<string, unknown>, actor: Actor): Promise<void> {
  assertCan(actor, 'users.manage');
  const input = parseOrThrow(profileSchema, { ...raw, roles: rolesFromForm(raw) });
  await withDbErrors(() =>
    withTransaction(async (tx) => {
      const current = await tx.user.findUnique({ where: { id }, include: { roles: { include: { role: true } } } });
      if (!current) throw new AppError('NOT_FOUND');
      const before = current.roles.map((r) => r.role.code).sort();
      const after = [...input.roles].sort();
      const losesOwner = before.includes('OWNER') && !after.includes('OWNER');
      if (losesOwner && id === actor.id) {
        throw new AppError('VALIDATION_ERROR', undefined, { roles: 'Anda tidak bisa mencabut peran Pemilik dari akun sendiri.' });
      }
      if (losesOwner && current.is_active && (await activeOwnerCount(tx, id)) === 0) {
        throw new AppError('VALIDATION_ERROR', undefined, { roles: 'Harus ada minimal satu Pemilik aktif.' });
      }
      await tx.user.update({ where: { id }, data: { full_name: input.full_name, phone: input.phone } });
      const rolesChanged = before.join() !== after.join();
      if (rolesChanged) {
        await setRoles(tx, id, input.roles);
        // Peran berubah: paksa login ulang agar izin baru langsung berlaku.
        await tx.user.update({ where: { id }, data: { session_version: { increment: 1 } } });
      }
      await writeAudit(tx, {
        ...auditMeta(actor), action: rolesChanged ? 'user.roles.changed' : 'user.updated', entity: 'user', entity_id: id,
        before: { full_name: current.full_name, phone: current.phone, roles: before },
        after: { full_name: input.full_name, phone: input.phone, roles: after },
      });
    }),
  );
}

export async function setUserActive(id: string, active: boolean, actor: Actor): Promise<void> {
  assertCan(actor, 'users.manage');
  if (!active && id === actor.id) throw new AppError('VALIDATION_ERROR', 'Anda tidak bisa menonaktifkan akun sendiri.');
  await withTransaction(async (tx) => {
    const u = await tx.user.findUnique({ where: { id }, include: { roles: { include: { role: true } } } });
    if (!u) throw new AppError('NOT_FOUND');
    if (u.is_active === active) return;
    if (!active && u.roles.some((r) => r.role.code === 'OWNER') && (await activeOwnerCount(tx, id)) === 0) {
      throw new AppError('VALIDATION_ERROR', 'Harus ada minimal satu Pemilik aktif.');
    }
    await tx.user.update({
      where: { id },
      data: active ? { is_active: true } : { is_active: false, session_version: { increment: 1 } },
    });
    await writeAudit(tx, { ...auditMeta(actor), action: active ? 'user.activated' : 'user.deactivated', entity: 'user', entity_id: id });
  });
}

export async function resetUserPassword(id: string, actor: Actor): Promise<string> {
  assertCan(actor, 'users.manage');
  const temporaryPassword = generateTemporaryPassword();
  const password_hash = await hashPassword(temporaryPassword);
  await withTransaction(async (tx) => {
    const u = await tx.user.findUnique({ where: { id }, select: { id: true } });
    if (!u) throw new AppError('NOT_FOUND');
    await tx.user.update({
      where: { id },
      data: { password_hash, must_change_password: true, failed_login_count: 0, locked_until: null, session_version: { increment: 1 } },
    });
    await writeAudit(tx, { ...auditMeta(actor), action: 'user.password.reset', entity: 'user', entity_id: id });
  });
  return temporaryPassword;
}

export async function unlockUser(id: string, actor: Actor): Promise<void> {
  assertCan(actor, 'users.manage');
  await withTransaction(async (tx) => {
    const u = await tx.user.findUnique({ where: { id }, select: { failed_login_count: true, locked_until: true } });
    if (!u) throw new AppError('NOT_FOUND');
    await tx.user.update({ where: { id }, data: { failed_login_count: 0, locked_until: null } });
    await writeAudit(tx, {
      ...auditMeta(actor), action: 'user.unlocked', entity: 'user', entity_id: id,
      before: { failed_login_count: u.failed_login_count, locked_until: u.locked_until?.toISOString() ?? null },
    });
  });
}

export async function addLicense(userId: string, raw: unknown, actor: Actor): Promise<void> {
  assertCan(actor, 'users.manage');
  const input = parseOrThrow(licenseSchema, raw);
  await withTransaction(async (tx) => {
    const l = await tx.employeeLicense.create({
      data: { user_id: userId, license_type: input.license_type, number: input.number, valid_until: input.valid_until ? new Date(`${input.valid_until}T00:00:00Z`) : null },
    });
    await writeAudit(tx, { ...auditMeta(actor), action: 'user.license.added', entity: 'user', entity_id: userId, after: { id: l.id, ...input } });
  });
}

export async function removeLicense(userId: string, licenseId: string, actor: Actor): Promise<void> {
  assertCan(actor, 'users.manage');
  await withTransaction(async (tx) => {
    const l = await tx.employeeLicense.findFirst({ where: { id: licenseId, user_id: userId } });
    if (!l) throw new AppError('NOT_FOUND');
    await tx.employeeLicense.delete({ where: { id: licenseId } });
    await writeAudit(tx, {
      ...auditMeta(actor), action: 'user.license.removed', entity: 'user', entity_id: userId,
      before: { license_type: l.license_type, number: l.number, valid_until: l.valid_until?.toISOString().slice(0, 10) ?? null },
    });
  });
}
