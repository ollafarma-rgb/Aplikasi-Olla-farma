import { z } from 'zod';
import { requiredId, optionalText, money } from '../../lib/forms';

// ─── Record Payment ───────────────────────────────────────────────────────────

export const recordPaymentSchema = z.object({
  receivable_id: requiredId('ID piutang'),
  amount: money('Jumlah pembayaran'),
  paid_at: z.string().datetime({ offset: true }).optional(),
  reference: z.string().max(100).optional(),
  notes: optionalText(300, 'Catatan'),
});

export type RecordPaymentInput = z.infer<typeof recordPaymentSchema>;

// ─── Write Off ───────────────────────────────────────────────────────────────

export const writeOffReceivableSchema = z.object({
  id: requiredId('ID piutang'),
  notes: optionalText(500, 'Alasan penghapusan'),
});

export type WriteOffReceivableInput = z.infer<typeof writeOffReceivableSchema>;

// ─── List / Filter ───────────────────────────────────────────────────────────

export const listReceivablesSchema = z.object({
  customer_id: z.string().uuid().optional(),
  status: z.enum(['OPEN', 'PARTIAL', 'PAID', 'WRITTEN_OFF', 'ALL']).default('ALL'),
  overdue_only: z.boolean().default(false),
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(1).max(100).default(20),
});

export type ListReceivablesInput = z.infer<typeof listReceivablesSchema>;
