'use server';

import { z } from 'zod';
import { requireActor } from '../../lib/auth/server';
import { translateDbError } from '../../lib/database/errors';
import { AppError } from '../../lib/errors';
import { type ActionState } from '../../lib/forms';
import { fieldErrors } from '../../lib/validation';
import * as svc from './service';

function fail(error: unknown): ActionState {
  const appErr = error instanceof AppError ? error : translateDbError(error);
  if (appErr instanceof AppError) {
    return {
      ok:          false,
      code:        appErr.code,
      message:     appErr.message ?? 'Tidak dapat menyimpan.',
      fields:      appErr.fields,
      submittedAt: Date.now(),
    };
  }
  if (error instanceof z.ZodError) {
    return { ok: false, code: 'VALIDATION_ERROR', fields: fieldErrors(error), submittedAt: Date.now() };
  }
  throw error;
}

// ─────────────────────────── List ─────────────────────────────

export async function listReceivablesAction(raw?: {
  customer_id?: string;
  status?: string;
  overdue_only?: boolean;
  page?: number;
  limit?: number;
}): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.receivable.view');
    const data  = await svc.listReceivables(actor, raw ?? {});
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Get By ID ────────────────────────

export async function getReceivableAction(id: string): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.receivable.view');
    const data  = await svc.getReceivable(actor, id);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Record Payment ───────────────────

export async function recordPaymentAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.receivable.manage');
    const raw = {
      receivable_id: formData.get('receivable_id'),
      amount:        formData.get('amount'),
      paid_at:       formData.get('paid_at') || undefined,
      reference:     formData.get('reference') || undefined,
      notes:         formData.get('notes') || undefined,
    };
    const data = await svc.recordReceivablePayment(actor, raw);
    return { ok: true, data, message: `Pembayaran ${(data as any).payment_no} berhasil dicatat.`, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Write Off ────────────────────────

export async function writeOffReceivableAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.receivable.manage');
    const raw = {
      id:    formData.get('id'),
      notes: formData.get('notes') || undefined,
    };
    const data = await svc.writeOffReceivable(actor, raw);
    return { ok: true, data, message: 'Piutang berhasil dihapuskan.', submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Aging Report ─────────────────────

export async function getAgingReportAction(): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.receivable.view');
    const data  = await svc.getAgingReport(actor);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}
