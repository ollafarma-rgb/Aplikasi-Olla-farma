import 'server-only';
import { Prisma } from '@/generated/prisma/client';
import type { CustomerReceivable, ReceivablePayment } from '@/generated/prisma/models';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import type { DbTransaction } from '../../lib/database/client';
import { nextNumber } from '../../lib/database/context';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import { parseOrThrow } from '../../lib/validation';
import {
  recordPaymentSchema,
  writeOffReceivableSchema,
  listReceivablesSchema,
  type RecordPaymentInput,
  type WriteOffReceivableInput,
  type ListReceivablesInput,
} from './schemas';

// ─── Periode helper ───────────────────────────────────────────────────────────

function toPeriod(d: Date): string {
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`;
}

// ─── Internal: dibuat dari dalam sales transaction ────────────────────────────

/**
 * Dipanggil dari dalam transaksi sales saat payment_method === 'RECEIVABLE'.
 * due_date dihitung 30 hari dari tanggal penjualan (default kredit apotek).
 */
export async function createReceivableInTx(
  tx: DbTransaction,
  params: {
    sale_id: string;
    customer_id: string;
    amount: Prisma.Decimal;
    sale_date: Date;
    notes?: string | null;
  },
): Promise<string> {
  const dueDate = new Date(params.sale_date);
  dueDate.setDate(dueDate.getDate() + 30);

  const receivable = await tx.customerReceivable.create({
    data: {
      id: crypto.randomUUID(),
      sale_id: params.sale_id,
      customer_id: params.customer_id,
      amount: params.amount,
      paid_amount: new Prisma.Decimal(0),
      due_date: dueDate,
      status: 'OPEN',
      notes: params.notes ?? null,
    },
    select: { id: true },
  });

  return receivable.id;
}

// ─── Record Payment ───────────────────────────────────────────────────────────

export async function recordReceivablePayment(
  actor: Actor,
  input: unknown,
) {
  assertCan(actor, 'finance.receivable.manage');
  const data = parseOrThrow(recordPaymentSchema, input) as RecordPaymentInput;

  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const receivable = await tx.customerReceivable.findUnique({
        where: { id: data.receivable_id },
        select: {
          id: true,
          customer_id: true,
          amount: true,
          paid_amount: true,
          status: true,
        },
      });
      if (!receivable) throw new AppError('NOT_FOUND', 'Piutang tidak ditemukan.');
      if (receivable.status === 'PAID' || receivable.status === 'WRITTEN_OFF') {
        throw new AppError('INVALID_STATE_TRANSITION', `Piutang sudah ${receivable.status === 'PAID' ? 'lunas' : 'dihapuskan'}.`);
      }

      const amount = new Prisma.Decimal(data.amount);
      const remaining = receivable.amount.minus(receivable.paid_amount);

      if (amount.gt(remaining)) {
        throw new AppError(
          'VALIDATION_ERROR',
          `Jumlah pembayaran (${amount.toFixed(2)}) melebihi sisa piutang (${remaining.toFixed(2)}).`,
        );
      }

      const paidAt = data.paid_at ? new Date(data.paid_at) : new Date();
      const period = toPeriod(paidAt);
      const n = await nextNumber(tx, 'BPR', period);
      const paymentNo = `BPR/${period}/${String(n).padStart(5, '0')}`;

      const newPaidAmount = receivable.paid_amount.plus(amount);
      const newStatus = newPaidAmount.gte(receivable.amount) ? 'PAID' : 'PARTIAL';

      await tx.receivablePayment.create({
        data: {
          id: crypto.randomUUID(),
          payment_no: paymentNo,
          receivable_id: receivable.id,
          amount,
          paid_at: paidAt,
          reference: data.reference ?? null,
          received_by: actor.id,
          notes: data.notes ?? null,
        },
      });

      await tx.customerReceivable.update({
        where: { id: receivable.id },
        data: {
          paid_amount: newPaidAmount,
          status: newStatus,
        },
      });

      // Update credit_used pelanggan
      await tx.customer.update({
        where: { id: receivable.customer_id },
        data: { credit_used: { decrement: amount } },
      });

      await writeAudit(tx, {
        ...auditMeta(actor),
        action: 'receivable.payment_recorded',
        entity: 'customer_receivables',
        entity_id: receivable.id,
        after: {
          payment_no: paymentNo,
          amount: amount.toFixed(2),
          paid_at: paidAt.toISOString(),
          new_status: newStatus,
        },
      });

      return { payment_no: paymentNo, status: newStatus };
    }),
  );
}

// ─── Write Off ────────────────────────────────────────────────────────────────

export async function writeOffReceivable(actor: Actor, input: unknown) {
  assertCan(actor, 'finance.receivable.manage');
  const data: WriteOffReceivableInput = parseOrThrow(writeOffReceivableSchema, input);

  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const receivable = await tx.customerReceivable.findUnique({
        where: { id: data.id },
        select: { id: true, customer_id: true, amount: true, paid_amount: true, status: true },
      });
      if (!receivable) throw new AppError('NOT_FOUND', 'Piutang tidak ditemukan.');
      if (receivable.status === 'PAID' || receivable.status === 'WRITTEN_OFF') {
        throw new AppError('INVALID_STATE_TRANSITION', `Piutang tidak dapat dihapus karena status: ${receivable.status}.`);
      }

      // Sisa yang belum dibayar → kurangi credit_used
      const remaining = receivable.amount.minus(receivable.paid_amount);

      await tx.customerReceivable.update({
        where: { id: data.id },
        data: {
          status: 'WRITTEN_OFF',
          notes: (data.notes ?? null) as string | null,
        },
      });

      // Kurangi credit_used sebesar sisa yang dihapus
      if (remaining.gt(0)) {
        await tx.customer.update({
          where: { id: receivable.customer_id },
          data: { credit_used: { decrement: remaining } },
        });
      }

      await writeAudit(tx, {
        ...auditMeta(actor),
        action: 'receivable.written_off',
        entity: 'customer_receivables',
        entity_id: data.id,
        after: {
          notes: data.notes ?? null,
          written_off_amount: remaining.toFixed(2),
        },
      });

      return { id: data.id, status: 'WRITTEN_OFF' as const };
    }),
  );
}

// ─── List / Get ───────────────────────────────────────────────────────────────

export async function listReceivables(actor: Actor, input: unknown) {
  assertCan(actor, 'finance.receivable.manage');
  const params = parseOrThrow(listReceivablesSchema, input) as ListReceivablesInput;

  const where: Record<string, unknown> = {};
  if (params.customer_id) where.customer_id = params.customer_id;
  if (params.status !== 'ALL') where.status = params.status;
  if (params.overdue_only) {
    where.due_date = { lt: new Date() };
    // Status harus masih OPEN atau PARTIAL
    where.status = { in: ['OPEN', 'PARTIAL'] };
  }

  const skip = (params.page - 1) * params.limit;

  const [items, total] = await Promise.all([
    prisma.customerReceivable.findMany({
      where,
      orderBy: { due_date: 'asc' },
      skip,
      take: params.limit,
      select: {
        id: true,
        sale_id: true,
        customer_id: true,
        amount: true,
        paid_amount: true,
        due_date: true,
        status: true,
        notes: true,
        created_at: true,
      },
    }),
    prisma.customerReceivable.count({ where }),
  ]);

  type ReceivableRow = Pick<CustomerReceivable, 'id' | 'sale_id' | 'customer_id' | 'amount' | 'paid_amount' | 'due_date' | 'status' | 'notes' | 'created_at'>;
  return {
    items: (items as ReceivableRow[]).map((r) => ({
      ...r,
      amount: r.amount.toFixed(2),
      paid_amount: r.paid_amount.toFixed(2),
      remaining: r.amount.minus(r.paid_amount).toFixed(2),
      is_overdue: r.due_date < new Date() && r.status !== 'PAID' && r.status !== 'WRITTEN_OFF',
    })),
    total,
    page: params.page,
    limit: params.limit,
    totalPages: Math.ceil(total / params.limit),
  };
}

export async function getReceivable(actor: Actor, id: string) {
  assertCan(actor, 'finance.receivable.view');
  const receivable = await prisma.customerReceivable.findUnique({
    where: { id },
    select: {
      id: true,
      sale_id: true,
      customer_id: true,
      amount: true,
      paid_amount: true,
      due_date: true,
      status: true,
      notes: true,
      created_at: true,
      updated_at: true,
    },
  });
  if (!receivable) throw new AppError('NOT_FOUND', 'Piutang tidak ditemukan.');

  // Ambil riwayat pembayaran
  const payments = await prisma.receivablePayment.findMany({
    where: { receivable_id: id },
    orderBy: { paid_at: 'desc' },
    select: {
      id: true,
      payment_no: true,
      amount: true,
      paid_at: true,
      reference: true,
      received_by: true,
      notes: true,
      created_at: true,
    },
  });

  return {
    ...receivable,
    amount: receivable.amount.toFixed(2),
    paid_amount: receivable.paid_amount.toFixed(2),
    remaining: receivable.amount.minus(receivable.paid_amount).toFixed(2),
    is_overdue: receivable.due_date < new Date() && receivable.status !== 'PAID' && receivable.status !== 'WRITTEN_OFF',
    payments: (payments as Pick<ReceivablePayment, 'id' | 'payment_no' | 'amount' | 'paid_at' | 'reference' | 'received_by' | 'notes' | 'created_at'>[]).map((p) => ({
      ...p,
      amount: p.amount.toFixed(2),
    })),
  };
}

// ─── Aging Report ─────────────────────────────────────────────────────────────

export interface AgingBucket {
  label: string;
  min_days: number;
  max_days: number | null;
  count: number;
  total_amount: string;
  total_remaining: string;
}

export async function getAgingReport(actor: Actor): Promise<{
  as_of: string;
  buckets: AgingBucket[];
  grand_total_remaining: string;
}> {
  assertCan(actor, 'finance.receivable.view');

  const now = new Date();

  // Ambil semua piutang OPEN dan PARTIAL
  const receivables = await prisma.customerReceivable.findMany({
    where: { status: { in: ['OPEN', 'PARTIAL'] } },
    select: {
      amount: true,
      paid_amount: true,
      due_date: true,
    },
  });

  const buckets: AgingBucket[] = [
    { label: '0–30 hari', min_days: 0, max_days: 30, count: 0, total_amount: '0', total_remaining: '0' },
    { label: '31–60 hari', min_days: 31, max_days: 60, count: 0, total_amount: '0', total_remaining: '0' },
    { label: '61–90 hari', min_days: 61, max_days: 90, count: 0, total_amount: '0', total_remaining: '0' },
    { label: '> 90 hari', min_days: 91, max_days: null, count: 0, total_amount: '0', total_remaining: '0' },
  ];

  let grandTotal = new Prisma.Decimal(0);

  for (const r of receivables) {
    const daysOverdue = Math.floor((now.getTime() - r.due_date.getTime()) / (1000 * 60 * 60 * 24));
    if (daysOverdue < 0) continue; // Belum jatuh tempo, skip dari aging

    const remaining = r.amount.minus(r.paid_amount);
    grandTotal = grandTotal.plus(remaining);

    const bucket = buckets.find(
      (b) =>
        daysOverdue >= b.min_days &&
        (b.max_days === null || daysOverdue <= b.max_days),
    );
    if (bucket) {
      bucket.count++;
      bucket.total_amount = new Prisma.Decimal(bucket.total_amount).plus(r.amount).toFixed(2);
      bucket.total_remaining = new Prisma.Decimal(bucket.total_remaining).plus(remaining).toFixed(2);
    }
  }

  return {
    as_of: now.toISOString(),
    buckets,
    grand_total_remaining: grandTotal.toFixed(2),
  };
}
