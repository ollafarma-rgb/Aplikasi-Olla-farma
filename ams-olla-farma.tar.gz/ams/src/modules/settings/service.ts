import 'server-only';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';

export interface PharmacyProfile {
  name: string;
  legal_entity: string;
  nib: string;
  kbli: string;
  address: string;
  phone: string;
  email: string;
  operating_hours: string;
  sia_number: string | null;
  responsible_pharmacist: string;
}

export async function getPharmacyProfile(): Promise<PharmacyProfile> {
  const row = await prisma.pharmacySetting.findFirst({
    where: { key: 'pharmacy.profile' },
  });
  const data = (row?.value_json ?? {}) as Record<string, unknown>;
  return {
    name: (data['name'] as string) ?? '',
    legal_entity: (data['legal_entity'] as string) ?? '',
    nib: (data['nib'] as string) ?? '',
    kbli: (data['kbli'] as string) ?? '',
    address: (data['address'] as string) ?? '',
    phone: (data['phone'] as string) ?? '',
    email: (data['email'] as string) ?? '',
    operating_hours: (data['operating_hours'] as string) ?? '',
    sia_number: (data['sia_number'] as string | null) ?? null,
    responsible_pharmacist: (data['responsible_pharmacist'] as string) ?? '',
  };
}

export async function getAllSettings(): Promise<Record<string, unknown>> {
  const rows = await prisma.pharmacySetting.findMany({
    orderBy: { key: 'asc' },
  });
  const result: Record<string, unknown> = {};
  for (const row of rows) {
    result[row.key] = row.value_json;
  }
  return result;
}

export async function updatePharmacyProfile(actor: Actor, data: Partial<PharmacyProfile>) {
  assertCan(actor, 'settings.manage');

  const existing = await prisma.pharmacySetting.findFirst({
    where: { key: 'pharmacy.profile' },
  });

  const current = (existing?.value_json ?? {}) as Record<string, unknown>;
  const merged = { ...current, ...data };

  if (typeof merged['name'] !== 'string' || !merged['name'].trim()) {
    throw new AppError('VALIDATION_ERROR', 'Nama apotek wajib diisi.');
  }

  return withTransaction(async (tx) => {
    if (existing) {
      await tx.pharmacySetting.update({
        where: { id: existing.id },
        data: { value_json: merged, updated_by: actor.id },
      });
    } else {
      await tx.pharmacySetting.create({
        data: { key: 'pharmacy.profile', value_json: merged, updated_by: actor.id },
      });
    }

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'settings.profile_updated',
      entity: 'pharmacy_settings',
      entity_id: 'pharmacy.profile',
      after: merged,
    });
  });
}

export async function getReceiptSettings(): Promise<{ paper_width_mm: number; show_pharmacist_name: boolean; footer: string }> {
  const row = await prisma.pharmacySetting.findFirst({ where: { key: 'receipt' } });
  const d = (row?.value_json ?? {}) as Record<string, unknown>;
  return {
    paper_width_mm: (d['paper_width_mm'] as number) ?? 80,
    show_pharmacist_name: (d['show_pharmacist_name'] as boolean) ?? true,
    footer: (d['footer'] as string) ?? '',
  };
}

export async function updateReceiptSettings(
  actor: Actor,
  data: { paper_width_mm?: number; show_pharmacist_name?: boolean; footer?: string },
) {
  assertCan(actor, 'settings.manage');

  const existing = await prisma.pharmacySetting.findFirst({ where: { key: 'receipt' } });
  const current = (existing?.value_json ?? {}) as Record<string, unknown>;
  const merged = { ...current, ...data };

  return withTransaction(async (tx) => {
    if (existing) {
      await tx.pharmacySetting.update({
        where: { id: existing.id },
        data: { value_json: merged, updated_by: actor.id },
      });
    } else {
      await tx.pharmacySetting.create({
        data: { key: 'receipt', value_json: merged, updated_by: actor.id },
      });
    }

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'settings.receipt_updated',
      entity: 'pharmacy_settings',
      entity_id: 'receipt',
      after: merged,
    });
  });
}
