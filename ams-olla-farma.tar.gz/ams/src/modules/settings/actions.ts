'use server';

import { requireActor } from '../../lib/auth/server';
import { updatePharmacyProfile, updateReceiptSettings } from './service';

export async function savePharmacyProfileAction(formData: FormData) {
  const actor = await requireActor();
  await updatePharmacyProfile(actor, {
    name: formData.get('name')?.toString() ?? '',
    legal_entity: formData.get('legal_entity')?.toString() ?? '',
    nib: formData.get('nib')?.toString() ?? '',
    kbli: formData.get('kbli')?.toString() ?? '',
    address: formData.get('address')?.toString() ?? '',
    phone: formData.get('phone')?.toString() ?? '',
    email: formData.get('email')?.toString() ?? '',
    operating_hours: formData.get('operating_hours')?.toString() ?? '',
    sia_number: formData.get('sia_number')?.toString() || null,
    responsible_pharmacist: formData.get('responsible_pharmacist')?.toString() ?? '',
  });
}

export async function saveReceiptSettingsAction(formData: FormData) {
  const actor = await requireActor();
  await updateReceiptSettings(actor, {
    paper_width_mm: Number(formData.get('paper_width_mm') ?? 80),
    show_pharmacist_name: formData.get('show_pharmacist_name') === 'true',
    footer: formData.get('footer')?.toString() ?? '',
  });
}
