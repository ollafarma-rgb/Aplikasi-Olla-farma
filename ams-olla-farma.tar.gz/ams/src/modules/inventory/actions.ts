'use server';

import { revalidatePath } from 'next/cache';
import { runFormAction } from '../../lib/actions';
import { requireActor } from '../../lib/auth/server';
import { AppError } from '../../lib/errors';
import { translateDbError } from '../../lib/database/errors';
import { fieldErrors } from '../../lib/validation';
import { type ActionState } from '../../lib/forms';
import { z } from 'zod';
import {
  approveAdjustment, cancelAdjustment, cancelOpname, createAdjustment,
  createOpname, moveBucket, postOpname, saveOpnameCounts, createOpeningBalance,
  type AdjustmentItemInput,
} from './service';
import { type StockBucket } from './schemas';

// Saldo awal -------------------------------------------------------------------
export async function openingBalanceAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'inventory.adjust.approve', async (actor, values) => {
    const r = await createOpeningBalance(actor, values);
    return { message: `Saldo awal ${r.refNo} tercatat.`, data: { medicineId: r.medicineId, refNo: r.refNo } };
  });
  if (state.ok) revalidatePath('/persediaan');
  return state;
}

// Pindah bucket (karantina/rusak) ----------------------------------------------
export async function moveBucketAction(medicineId: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'inventory.quarantine.create', async (actor, values) => {
    const r = await moveBucket(actor, values);
    return `Stok dipindah (${r.refNo}).`;
  });
  if (state.ok) revalidatePath(`/persediaan/${medicineId}`);
  return state;
}

// Penyesuaian: header + item dinamis dari FormData -----------------------------
function parseAdjustmentItems(fd: FormData): AdjustmentItemInput[] {
  const ids = String(fd.get('batch_ids') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  const items: AdjustmentItemInput[] = [];
  for (const id of ids) {
    const rawDelta = String(fd.get(`delta_${id}`) ?? '').trim();
    if (rawDelta === '' || rawDelta === '0') continue;
    const delta = Number(rawDelta);
    if (!Number.isInteger(delta)) throw new AppError('VALIDATION_ERROR', `Selisih batch harus bilangan bulat.`);
    const bucket = String(fd.get(`bucket_${id}`) ?? 'SALEABLE') as StockBucket;
    const reason = String(fd.get(`reason_${id}`) ?? '').trim() || null;
    items.push({ batch_id: id, bucket, qty_delta: delta, reason });
  }
  return items;
}

export async function createAdjustmentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    await requireActor('inventory.adjust.create');
    const items = parseAdjustmentItems(fd);
    const header = { reason_code: String(fd.get('reason_code') ?? ''), notes: String(fd.get('notes') ?? '') };
    const actor = await requireActor('inventory.adjust.create');
    const r = await createAdjustment(actor, header, items);
    revalidatePath('/penyesuaian');
    return { ok: true, message: `Penyesuaian ${r.adjNo} dibuat sebagai draf.`, data: { id: r.id, adjNo: r.adjNo }, submittedAt: Date.now() };
  } catch (error) {
    const appErr = error instanceof AppError ? error : translateDbError(error);
    if (appErr instanceof AppError) {
      return { ok: false, code: appErr.code, message: appErr.message ?? 'Tidak dapat menyimpan.', fields: appErr.fields, submittedAt: Date.now() };
    }
    if (error instanceof z.ZodError) return { ok: false, code: 'VALIDATION_ERROR', fields: fieldErrors(error), submittedAt: Date.now() };
    throw error;
  }
}

export async function approveAdjustmentAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'inventory.adjust.approve', async (actor) => {
    await approveAdjustment(actor, id);
    return 'Penyesuaian disetujui dan stok diperbarui.';
  });
  if (state.ok) { revalidatePath('/penyesuaian'); revalidatePath(`/penyesuaian/${id}`); }
  return state;
}

export async function cancelAdjustmentAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'inventory.adjust.create', async (actor) => {
    await cancelAdjustment(actor, id);
    return 'Penyesuaian dibatalkan.';
  });
  if (state.ok) { revalidatePath('/penyesuaian'); revalidatePath(`/penyesuaian/${id}`); }
  return state;
}

// Opname -----------------------------------------------------------------------
export async function createOpnameAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'inventory.opname.count', async (actor, values) => {
    const r = await createOpname(actor, values);
    return { message: `Opname ${r.opnameNo} dimulai.`, data: { id: r.id, opnameNo: r.opnameNo } };
  });
  if (state.ok) revalidatePath('/opname');
  return state;
}

export async function saveOpnameCountsAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('inventory.opname.count');
    const ids = String(fd.get('item_ids') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
    const counts: Record<string, number | null> = {};
    for (const itemId of ids) {
      const raw = String(fd.get(`count_${itemId}`) ?? '').trim();
      if (raw === '') { counts[itemId] = null; continue; }
      if (!/^\d+$/.test(raw)) throw new AppError('VALIDATION_ERROR', 'Jumlah hitung harus bilangan bulat ≥ 0.');
      counts[itemId] = Number(raw);
    }
    await saveOpnameCounts(actor, id, counts);
    revalidatePath(`/opname/${id}`);
    return { ok: true, message: 'Hasil hitung tersimpan.', submittedAt: Date.now() };
  } catch (error) {
    if (error instanceof AppError) return { ok: false, code: error.code, message: error.message, submittedAt: Date.now() };
    throw error;
  }
}

export async function postOpnameAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'inventory.opname.post', async (actor) => {
    const r = await postOpname(actor, id);
    return r.diffs ? `Opname diposting; ${r.diffs} selisih dikoreksi.` : 'Opname diposting; tidak ada selisih.';
  });
  if (state.ok) { revalidatePath('/opname'); revalidatePath(`/opname/${id}`); revalidatePath('/persediaan'); }
  return state;
}

export async function cancelOpnameAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'inventory.opname.count', async (actor) => {
    await cancelOpname(actor, id);
    return 'Opname dibatalkan.';
  });
  if (state.ok) { revalidatePath('/opname'); revalidatePath(`/opname/${id}`); }
  return state;
}
