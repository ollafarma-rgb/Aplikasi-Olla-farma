import { z } from 'zod';
import { intField, money, optionalText, requiredId, text } from '../../lib/forms';

export const STOCK_BUCKETS = ['SALEABLE', 'QUARANTINE', 'DAMAGED'] as const;
export type StockBucket = (typeof STOCK_BUCKETS)[number];

export const BUCKET_LABELS: Record<StockBucket, string> = {
  SALEABLE: 'Siap jual',
  QUARANTINE: 'Karantina',
  DAMAGED: 'Rusak',
};

export const MOVEMENT_LABELS: Record<string, string> = {
  OPENING: 'Saldo awal',
  ADJUSTMENT: 'Penyesuaian',
  OPNAME: 'Stok opname',
  QUARANTINE_MOVE: 'Pindah karantina',
  DISPOSAL: 'Pemusnahan',
};

/** Alasan penyesuaian stok (manajemen bisa menambah lewat catatan bebas). */
export const ADJUSTMENT_REASONS = ['KOREKSI', 'RUSAK', 'HILANG', 'KADALUARSA', 'DONASI', 'LAINNYA'] as const;
export const ADJUSTMENT_REASON_LABELS: Record<string, string> = {
  KOREKSI: 'Koreksi pencatatan',
  RUSAK: 'Barang rusak',
  HILANG: 'Hilang / selisih',
  KADALUARSA: 'Kedaluwarsa',
  DONASI: 'Donasi / hibah keluar',
  LAINNYA: 'Lainnya',
};

/** Tanggal ISO YYYY-MM-DD. */
const dateString = (label: string) =>
  z.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/, `${label} wajib diisi (format tanggal).`);

export const openingBalanceSchema = z.object({
  medicine_id: requiredId('Obat'),
  batch_no: text(50, 'Nomor batch'),
  expiry_date: dateString('Tanggal kedaluwarsa'),
  qty: intField('Jumlah', 1),
  unit_cost: money('HPP per satuan'),
  note: optionalText(300, 'Catatan'),
});
export type OpeningBalanceInput = z.output<typeof openingBalanceSchema>;

export const quarantineMoveSchema = z.object({
  batch_id: requiredId('Batch'),
  from_bucket: z.enum(STOCK_BUCKETS),
  to_bucket: z.enum(STOCK_BUCKETS),
  qty: intField('Jumlah', 1),
  reason: optionalText(300, 'Alasan'),
});

export const adjustmentHeaderSchema = z.object({
  reason_code: z.enum(ADJUSTMENT_REASONS),
  notes: optionalText(500, 'Catatan'),
});

export const opnameHeaderSchema = z.object({
  medicine_id: z
    .string()
    .trim()
    .optional()
    .transform((v) => (v ? v : null))
    .refine((v) => v === null || /^[0-9a-f-]{36}$/i.test(v), 'Pilihan obat tidak valid.'),
  scope_note: optionalText(300, 'Catatan lingkup'),
});

export const stockFilterSchema = z.object({
  q: z.string().trim().max(100).optional().default(''),
  view: z.preprocess((v) => (v === '' ? undefined : v), z.enum(['semua', 'menipis', 'ed']).optional().default('semua')),
  page: z.preprocess((v) => (v === '' ? undefined : v), z.coerce.number().int().min(1).max(10_000).optional().default(1)),
});
