import 'server-only';
import { Prisma } from '@/generated/prisma/client';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import type { DbTransaction } from '../../lib/database/client';
import { nextNumber, setActor } from '../../lib/database/context';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import { parseOrThrow } from '../../lib/validation';
import {
  adjustmentHeaderSchema, openingBalanceSchema, opnameHeaderSchema, quarantineMoveSchema,
  stockFilterSchema, STOCK_BUCKETS, type StockBucket,
} from './schemas';

export const PAGE_SIZE = 20;
/** Ambang "akan kedaluwarsa" dalam hari. */
export const EXPIRY_SOON_DAYS = 90;

// -- Util ----------------------------------------------------------------------
function periodYYMM(): string {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
  return `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
}
function formatDocNo(prefix: string, period: string, n: number): string {
  return `${prefix}-${period}-${String(n).padStart(4, '0')}`;
}
function todayJakarta(): string {
  return new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })).toISOString().slice(0, 10);
}

interface MovementInput {
  batchId: string;
  type: 'OPENING' | 'ADJUSTMENT' | 'OPNAME' | 'QUARANTINE_MOVE' | 'DISPOSAL';
  from: StockBucket | null;
  to: StockBucket | null;
  qty: number;
  unitCost: string;
  refType: string;
  refId: string | null;
  refNo: string;
  reason: string | null;
  approvalId: string | null;
}

/** Terapkan satu pergerakan stok lewat fungsi SQL (kunci batch + perbarui cache). */
async function applyMovement(tx: DbTransaction, p: MovementInput): Promise<void> {
  await tx.$queryRaw`SELECT ams_apply_stock_movement(
    ${p.batchId}::uuid, ${p.type}::"MovementType",
    ${p.from}::"StockBucket", ${p.to}::"StockBucket",
    ${p.qty}::int, ${p.unitCost}::numeric,
    ${p.refType}, ${p.refId}::uuid, ${p.refNo}, ${p.reason}, ${null}::date, ${p.approvalId}::uuid)`;
}

async function bucketQty(tx: DbTransaction, batchId: string, bucket: StockBucket): Promise<number> {
  const col = bucket === 'SALEABLE' ? 'qty_saleable' : bucket === 'QUARANTINE' ? 'qty_quarantine' : 'qty_damaged';
  const rows = await tx.$queryRaw<{ q: number }[]>(Prisma.sql`
    SELECT ${Prisma.raw(`"${col}"`)} AS q FROM "medicine_batches" WHERE "id" = ${batchId}::uuid`);
  if (!rows.length) throw new AppError('NOT_FOUND', 'Batch tidak ditemukan.');
  return Number(rows[0].q);
}

// -- Daftar stok (ringkasan per obat) ------------------------------------------
export interface StockRow {
  id: string; sku: string; name: string; generic_name: string | null;
  min_stock: number; saleable: number; quarantine: number; damaged: number;
  value: string; nearest_expiry: string | null; expired: boolean; expiring_soon: boolean; low: boolean;
}

export async function listStock(actor: Actor, raw: Record<string, unknown>) {
  assertCan(actor, 'inventory.view');
  const f = parseOrThrow(stockFilterSchema, raw);
  const today = todayJakarta();
  const conds: Prisma.Sql[] = [Prisma.sql`m."is_active" = true`];
  if (f.q) conds.push(Prisma.sql`(m."name" ILIKE ${'%' + f.q + '%'} OR m."generic_name" ILIKE ${'%' + f.q + '%'} OR m."sku" = ${f.q.toUpperCase()})`);
  const where = Prisma.join(conds, ' AND ');

  let having = Prisma.empty;
  if (f.view === 'menipis') {
    having = Prisma.sql`HAVING COALESCE(SUM(b."qty_saleable"), 0) <= m."min_stock"`;
  } else if (f.view === 'ed') {
    having = Prisma.sql`HAVING MIN(b."expiry_date") FILTER (WHERE (b."qty_saleable" + b."qty_quarantine" + b."qty_damaged") > 0) <= (${today}::date + ${EXPIRY_SOON_DAYS})`;
  }

  const offset = (f.page - 1) * PAGE_SIZE;
  const rows = await prisma.$queryRaw<Array<Omit<StockRow, 'expired' | 'expiring_soon' | 'low'> & { value: string }>>(Prisma.sql`
    SELECT m."id", m."sku", m."name", m."generic_name", m."min_stock",
      COALESCE(SUM(b."qty_saleable"), 0)::int AS saleable,
      COALESCE(SUM(b."qty_quarantine"), 0)::int AS quarantine,
      COALESCE(SUM(b."qty_damaged"), 0)::int AS damaged,
      ROUND(COALESCE(SUM((b."qty_saleable" + b."qty_quarantine" + b."qty_damaged") * b."unit_cost"), 0))::bigint::text AS value,
      MIN(b."expiry_date") FILTER (WHERE (b."qty_saleable" + b."qty_quarantine" + b."qty_damaged") > 0)::text AS nearest_expiry
    FROM "medicines" m LEFT JOIN "medicine_batches" b ON b."medicine_id" = m."id"
    WHERE ${where}
    GROUP BY m."id" ${having}
    ORDER BY m."name" ASC
    LIMIT ${PAGE_SIZE} OFFSET ${offset}`);

  const countRows = await prisma.$queryRaw<{ n: bigint }[]>(Prisma.sql`
    SELECT COUNT(*)::bigint AS n FROM (
      SELECT m."id"
      FROM "medicines" m LEFT JOIN "medicine_batches" b ON b."medicine_id" = m."id"
      WHERE ${where}
      GROUP BY m."id" ${having}) t`);
  const total = Number(countRows[0]?.n ?? 0);

  const items: StockRow[] = rows.map((r) => {
    const exp = r.nearest_expiry;
    return {
      ...r,
      saleable: Number(r.saleable), quarantine: Number(r.quarantine), damaged: Number(r.damaged),
      min_stock: Number(r.min_stock),
      expired: exp !== null && exp < today,
      expiring_soon: exp !== null && exp >= today && exp <= addDays(today, EXPIRY_SOON_DAYS),
      low: Number(r.saleable) <= Number(r.min_stock),
    };
  });
  return { items, total, page: f.page, pageSize: PAGE_SIZE, view: f.view, q: f.q };
}

function addDays(iso: string, days: number): string {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** Nilai total persediaan (seluruh bucket) untuk kartu ringkasan. */
export async function inventoryValue(actor: Actor): Promise<string> {
  assertCan(actor, 'inventory.view');
  const rows = await prisma.$queryRaw<{ v: string }[]>(Prisma.sql`
    SELECT ROUND(COALESCE(SUM((b."qty_saleable" + b."qty_quarantine" + b."qty_damaged") * b."unit_cost"), 0))::bigint::text AS v
    FROM "medicine_batches" b`);
  return rows[0]?.v ?? '0';
}

// -- Detail per obat: batch + kartu stok ---------------------------------------
export async function getMedicineStock(actor: Actor, medicineId: string) {
  assertCan(actor, 'inventory.view');
  const medicine = await prisma.medicine.findUnique({
    where: { id: medicineId },
    select: { id: true, sku: true, name: true, generic_name: true, min_stock: true, base_unit: { select: { code: true } } },
  });
  if (!medicine) throw new AppError('NOT_FOUND');
  const batches = await prisma.medicineBatch.findMany({
    where: { medicine_id: medicineId },
    orderBy: [{ expiry_date: 'asc' }, { received_at: 'asc' }],
  });
  const movements = await prisma.stockMovement.findMany({
    where: { medicine_id: medicineId },
    orderBy: { occurred_at: 'desc' },
    take: 100,
    include: { user: { select: { full_name: true } }, batch: { select: { batch_no: true } } },
  });
  return { medicine, batches, movements };
}

// -- Saldo awal ----------------------------------------------------------------
export async function createOpeningBalance(actor: Actor, raw: Record<string, string>) {
  assertCan(actor, 'inventory.adjust.approve', 'Saldo awal hanya bisa dicatat apoteker atau pemilik.');
  const input = parseOrThrow(openingBalanceSchema, raw);
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const med = await tx.medicine.findUnique({ where: { id: input.medicine_id }, select: { id: true, is_active: true } });
      if (!med) throw new AppError('VALIDATION_ERROR', undefined, { medicine_id: 'Obat tidak ditemukan.' });
      if (!med.is_active) throw new AppError('VALIDATION_ERROR', undefined, { medicine_id: 'Obat nonaktif tidak bisa diberi stok.' });

      await setActor(tx, actor.id, 'Saldo awal');
      const period = periodYYMM();
      const refNo = formatDocNo('SALDO', period, await nextNumber(tx, 'SALDO', period));
      const batch = await tx.medicineBatch.create({
        data: {
          medicine_id: input.medicine_id, batch_no: input.batch_no, expiry_date: new Date(input.expiry_date),
          source: 'OPENING', unit_cost: input.unit_cost, qty_received: input.qty, note: input.note,
        },
      });
      await applyMovement(tx, {
        batchId: batch.id, type: 'OPENING', from: null, to: 'SALEABLE', qty: input.qty, unitCost: input.unit_cost,
        refType: 'OPENING', refId: batch.id, refNo, reason: input.note, approvalId: null,
      });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'inventory.opening_balance', entity: 'medicine_batch', entity_id: batch.id,
        after: { medicine_id: input.medicine_id, batch_no: input.batch_no, qty: input.qty, unit_cost: input.unit_cost, ref_no: refNo },
      });
      return { id: batch.id, medicineId: input.medicine_id, refNo };
    }),
  );
}

// -- Pindah bucket (karantina / rusak) -----------------------------------------
export async function moveBucket(actor: Actor, raw: Record<string, string>) {
  assertCan(actor, 'inventory.quarantine.create');
  const input = parseOrThrow(quarantineMoveSchema, raw);
  if (input.from_bucket === input.to_bucket) {
    throw new AppError('VALIDATION_ERROR', undefined, { to_bucket: 'Pilih bucket tujuan yang berbeda.' });
  }
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const batch = await tx.medicineBatch.findUnique({ where: { id: input.batch_id }, select: { id: true, medicine_id: true, unit_cost: true } });
      if (!batch) throw new AppError('VALIDATION_ERROR', undefined, { batch_id: 'Batch tidak ditemukan.' });
      await setActor(tx, actor.id, 'Pindah bucket');
      const period = periodYYMM();
      const refNo = formatDocNo('KRT', period, await nextNumber(tx, 'KRT', period));
      await applyMovement(tx, {
        batchId: batch.id, type: 'QUARANTINE_MOVE', from: input.from_bucket, to: input.to_bucket, qty: input.qty,
        unitCost: batch.unit_cost.toString(), refType: 'quarantine_move', refId: batch.id, refNo, reason: input.reason, approvalId: null,
      });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'inventory.bucket_move', entity: 'medicine_batch', entity_id: batch.id,
        after: { from: input.from_bucket, to: input.to_bucket, qty: input.qty, ref_no: refNo },
      });
      return { medicineId: batch.medicine_id, refNo };
    }),
  );
}

// -- Penyesuaian stok ----------------------------------------------------------
export interface AdjustmentItemInput { batch_id: string; bucket: StockBucket; qty_delta: number; reason: string | null }

export async function createAdjustment(actor: Actor, header: Record<string, string>, items: AdjustmentItemInput[]) {
  assertCan(actor, 'inventory.adjust.create');
  const h = parseOrThrow(adjustmentHeaderSchema, header);
  const clean = items.filter((i) => i.qty_delta !== 0);
  if (!clean.length) throw new AppError('VALIDATION_ERROR', 'Isi minimal satu baris dengan selisih tidak nol.');
  for (const i of clean) {
    if (!/^[0-9a-f-]{36}$/i.test(i.batch_id)) throw new AppError('VALIDATION_ERROR', 'Batch tidak valid.');
    if (!STOCK_BUCKETS.includes(i.bucket)) throw new AppError('VALIDATION_ERROR', 'Bucket tidak valid.');
  }
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const period = periodYYMM();
      const adjNo = formatDocNo('ADJ', period, await nextNumber(tx, 'ADJ', period));
      const adj = await tx.stockAdjustment.create({
        data: {
          adj_no: adjNo, reason_code: h.reason_code, notes: h.notes, created_by: actor.id,
          items: { create: clean.map((i) => ({ batch_id: i.batch_id, bucket: i.bucket, qty_delta: i.qty_delta, reason: i.reason })) },
        },
      });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'inventory.adjustment_created', entity: 'stock_adjustment', entity_id: adj.id,
        after: { adj_no: adjNo, reason_code: h.reason_code, items: clean.length },
      });
      return { id: adj.id, adjNo };
    }),
  );
}

export async function approveAdjustment(actor: Actor, id: string) {
  assertCan(actor, 'inventory.adjust.approve');
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const adj = await tx.stockAdjustment.findUnique({ where: { id }, include: { items: { include: { batch: { select: { unit_cost: true } } } } } });
      if (!adj) throw new AppError('NOT_FOUND');
      if (adj.status !== 'DRAFT') throw new AppError('VALIDATION_ERROR', 'Penyesuaian ini sudah diproses.');
      if (adj.created_by === actor.id) throw new AppError('FORBIDDEN', 'Anda tidak boleh menyetujui penyesuaian yang Anda buat sendiri.');

      await setActor(tx, actor.id, 'Posting penyesuaian stok');
      const approval = await tx.approval.create({
        data: { action_code: 'inventory.adjust.approve', requested_by: adj.created_by, approved_by: actor.id, ref_type: 'stock_adjustment', ref_id: adj.id, reason: adj.reason_code },
      });
      for (const it of adj.items) {
        const positive = it.qty_delta > 0;
        await applyMovement(tx, {
          batchId: it.batch_id, type: 'ADJUSTMENT', from: positive ? null : it.bucket, to: positive ? it.bucket : null,
          qty: Math.abs(it.qty_delta), unitCost: it.batch.unit_cost.toString(), refType: 'stock_adjustment', refId: adj.id,
          refNo: adj.adj_no, reason: it.reason ?? adj.reason_code, approvalId: approval.id,
        });
      }
      await tx.stockAdjustment.update({ where: { id: adj.id }, data: { status: 'POSTED', posted_at: new Date(), approval_id: approval.id } });
      await writeAudit(tx, { ...auditMeta(actor), action: 'inventory.adjustment_posted', entity: 'stock_adjustment', entity_id: adj.id, after: { adj_no: adj.adj_no } });
      return { id: adj.id };
    }),
  );
}

export async function cancelAdjustment(actor: Actor, id: string) {
  assertCan(actor, 'inventory.adjust.create');
  await withTransaction(async (tx) => {
    const adj = await tx.stockAdjustment.findUnique({ where: { id }, select: { id: true, status: true, created_by: true } });
    if (!adj) throw new AppError('NOT_FOUND');
    if (adj.status !== 'DRAFT') throw new AppError('VALIDATION_ERROR', 'Hanya draf yang bisa dibatalkan.');
    await tx.stockAdjustment.update({ where: { id }, data: { status: 'CANCELLED' } });
    await writeAudit(tx, { ...auditMeta(actor), action: 'inventory.adjustment_cancelled', entity: 'stock_adjustment', entity_id: id });
  });
}

export async function listAdjustments(actor: Actor) {
  assertCan(actor, 'inventory.view');
  return prisma.stockAdjustment.findMany({
    orderBy: { created_at: 'desc' }, take: 100,
    include: { creator: { select: { full_name: true } }, _count: { select: { items: true } } },
  });
}

export async function getAdjustment(actor: Actor, id: string) {
  assertCan(actor, 'inventory.view');
  const adj = await prisma.stockAdjustment.findUnique({
    where: { id },
    include: {
      creator: { select: { full_name: true } },
      items: { include: { batch: { include: { medicine: { select: { name: true, sku: true } } } } } },
    },
  });
  if (!adj) throw new AppError('NOT_FOUND');
  return adj;
}

// -- Stok opname ---------------------------------------------------------------
export async function createOpname(actor: Actor, raw: Record<string, string>) {
  assertCan(actor, 'inventory.opname.count');
  const h = parseOrThrow(opnameHeaderSchema, raw);
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const batches = await tx.medicineBatch.findMany({
        where: h.medicine_id ? { medicine_id: h.medicine_id } : { qty_saleable: { gt: 0 } },
        select: { id: true, qty_saleable: true },
        orderBy: [{ expiry_date: 'asc' }],
      });
      if (!batches.length) throw new AppError('VALIDATION_ERROR', 'Tidak ada batch untuk dihitung pada lingkup ini.');
      const period = periodYYMM();
      const opnameNo = formatDocNo('OPN', period, await nextNumber(tx, 'OPN', period));
      const op = await tx.stockOpname.create({
        data: {
          opname_no: opnameNo, scope_note: h.scope_note, status: 'COUNTING', created_by: actor.id,
          items: { create: batches.map((b) => ({ batch_id: b.id, bucket: 'SALEABLE', system_qty: b.qty_saleable })) },
        },
      });
      await writeAudit(tx, { ...auditMeta(actor), action: 'inventory.opname_started', entity: 'stock_opname', entity_id: op.id, after: { opname_no: opnameNo, items: batches.length } });
      return { id: op.id, opnameNo };
    }),
  );
}

export async function saveOpnameCounts(actor: Actor, id: string, counts: Record<string, number | null>) {
  assertCan(actor, 'inventory.opname.count');
  await withTransaction(async (tx) => {
    const op = await tx.stockOpname.findUnique({ where: { id }, select: { id: true, status: true } });
    if (!op) throw new AppError('NOT_FOUND');
    if (op.status !== 'COUNTING') throw new AppError('VALIDATION_ERROR', 'Opname ini sudah tidak dalam tahap menghitung.');
    for (const [itemId, counted] of Object.entries(counts)) {
      await tx.stockOpnameItem.update({ where: { id: itemId }, data: { counted_qty: counted } });
    }
  });
}

export async function postOpname(actor: Actor, id: string) {
  assertCan(actor, 'inventory.opname.post');
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const op = await tx.stockOpname.findUnique({ where: { id }, include: { items: { include: { batch: { select: { unit_cost: true } } } } } });
      if (!op) throw new AppError('NOT_FOUND');
      if (op.status !== 'COUNTING') throw new AppError('VALIDATION_ERROR', 'Opname ini sudah diposting atau dibatalkan.');
      if (op.created_by === actor.id) throw new AppError('FORBIDDEN', 'Anda tidak boleh memposting opname yang Anda buat sendiri.');

      await setActor(tx, actor.id, 'Posting selisih opname');
      const approval = await tx.approval.create({
        data: { action_code: 'inventory.opname.post', requested_by: op.created_by, approved_by: actor.id, ref_type: 'stock_opname', ref_id: op.id, reason: 'Posting selisih stok opname' },
      });

      const counted = op.items.filter((i) => i.counted_qty !== null);
      const diffs: Array<{ batch_id: string; bucket: StockBucket; delta: number; unitCost: string }> = [];
      for (const it of counted) {
        const cur = await bucketQty(tx, it.batch_id, it.bucket as StockBucket);
        const delta = (it.counted_qty as number) - cur;
        if (delta !== 0) diffs.push({ batch_id: it.batch_id, bucket: it.bucket as StockBucket, delta, unitCost: it.batch.unit_cost.toString() });
      }

      let adjustmentId: string | null = null;
      if (diffs.length) {
        const period = periodYYMM();
        const adjNo = formatDocNo('ADJ', period, await nextNumber(tx, 'ADJ', period));
        const adj = await tx.stockAdjustment.create({
          data: {
            adj_no: adjNo, reason_code: 'OPNAME', notes: `Selisih stok opname ${op.opname_no}`, created_by: op.created_by,
            status: 'POSTED', posted_at: new Date(), approval_id: approval.id,
            items: { create: diffs.map((d) => ({ batch_id: d.batch_id, bucket: d.bucket, qty_delta: d.delta })) },
          },
        });
        adjustmentId = adj.id;
        for (const d of diffs) {
          const positive = d.delta > 0;
          await applyMovement(tx, {
            batchId: d.batch_id, type: 'OPNAME', from: positive ? null : d.bucket, to: positive ? d.bucket : null,
            qty: Math.abs(d.delta), unitCost: d.unitCost, refType: 'stock_opname', refId: op.id, refNo: op.opname_no,
            reason: 'Selisih opname', approvalId: approval.id,
          });
        }
      }

      await tx.stockOpname.update({ where: { id: op.id }, data: { status: 'POSTED', posted_at: new Date(), approved_by: actor.id, adjustment_id: adjustmentId } });
      await writeAudit(tx, { ...auditMeta(actor), action: 'inventory.opname_posted', entity: 'stock_opname', entity_id: op.id, after: { opname_no: op.opname_no, diffs: diffs.length } });
      return { id: op.id, diffs: diffs.length };
    }),
  );
}

export async function cancelOpname(actor: Actor, id: string) {
  assertCan(actor, 'inventory.opname.count');
  await withTransaction(async (tx) => {
    const op = await tx.stockOpname.findUnique({ where: { id }, select: { status: true } });
    if (!op) throw new AppError('NOT_FOUND');
    if (op.status !== 'COUNTING') throw new AppError('VALIDATION_ERROR', 'Hanya opname yang sedang dihitung bisa dibatalkan.');
    await tx.stockOpname.update({ where: { id }, data: { status: 'CANCELLED' } });
    await writeAudit(tx, { ...auditMeta(actor), action: 'inventory.opname_cancelled', entity: 'stock_opname', entity_id: id });
  });
}

export async function listOpnames(actor: Actor) {
  assertCan(actor, 'inventory.view');
  return prisma.stockOpname.findMany({
    orderBy: { started_at: 'desc' }, take: 100,
    include: { creator: { select: { full_name: true } }, _count: { select: { items: true } } },
  });
}

export async function getOpname(actor: Actor, id: string) {
  assertCan(actor, 'inventory.view');
  const op = await prisma.stockOpname.findUnique({
    where: { id },
    include: {
      creator: { select: { full_name: true } }, approver: { select: { full_name: true } },
      items: { include: { batch: { include: { medicine: { select: { name: true, sku: true } } } } }, orderBy: { id: 'asc' } },
    },
  });
  if (!op) throw new AppError('NOT_FOUND');
  return op;
}

/** Obat aktif untuk dropdown (saldo awal, penyesuaian). */
export async function listMedicineOptions(actor: Actor) {
  assertCan(actor, 'inventory.view');
  const rows = await prisma.medicine.findMany({
    where: { is_active: true },
    select: { id: true, name: true, sku: true, base_unit: { select: { code: true } } },
    orderBy: { name: 'asc' },
    take: 2000,
  });
  return rows.map((m) => ({ id: m.id, label: `${m.name} (${m.sku}) · ${m.base_unit.code}` }));
}
