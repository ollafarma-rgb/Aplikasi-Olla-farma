import 'server-only';
import { z } from 'zod';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import { checkbox, optionalText, text } from '../../lib/forms';
import { parseOrThrow } from '../../lib/validation';

/**
 * Data referensi obat: kategori, satuan, pabrik, lokasi rak.
 * Kategori/pabrik/lokasi dikelola pemegang medicines.manage; satuan oleh settings.manage.
 */

export const REFERENCE_KINDS = ['kategori', 'satuan', 'pabrik', 'lokasi'] as const;
export type ReferenceKind = (typeof REFERENCE_KINDS)[number];

export const STORAGE_CONDITIONS = ['ROOM', 'COOL', 'REFRIGERATED', 'SPECIAL_CABINET'] as const;
export const STORAGE_LABELS: Record<(typeof STORAGE_CONDITIONS)[number], string> = {
  ROOM: 'Suhu ruang',
  COOL: 'Sejuk (8–15 °C)',
  REFRIGERATED: 'Lemari pendingin (2–8 °C)',
  SPECIAL_CABINET: 'Lemari khusus narkotika/psikotropika',
};

const schemas = {
  kategori: z.object({ name: text(100, 'Nama kategori'), is_active: checkbox }),
  satuan: z.object({
    code: z.string().trim().toUpperCase().regex(/^[A-Z0-9]{1,20}$/, 'Kode satuan 1–20 huruf besar/angka.'),
    name: text(50, 'Nama satuan'),
    is_active: checkbox,
  }),
  pabrik: z.object({ name: text(150, 'Nama pabrik'), country: optionalText(80, 'Negara') }),
  lokasi: z.object({
    code: z.string().trim().toUpperCase().regex(/^[A-Z0-9._-]{1,30}$/, 'Kode lokasi 1–30 huruf besar/angka/titik/minus.'),
    name: text(100, 'Nama lokasi'),
    condition: z.enum(STORAGE_CONDITIONS, { message: 'Kondisi penyimpanan wajib dipilih.' }),
  }),
} as const;

function permissionFor(kind: ReferenceKind) {
  return kind === 'satuan' ? ('settings.manage' as const) : ('medicines.manage' as const);
}

/** Semua referensi untuk pilihan di form obat (hanya yang aktif kecuali diminta). */
export async function referenceOptions() {
  const [categories, units, manufacturers, locations] = await Promise.all([
    prisma.category.findMany({ orderBy: { name: 'asc' } }),
    prisma.unit.findMany({ orderBy: { code: 'asc' } }),
    prisma.manufacturer.findMany({ orderBy: { name: 'asc' } }),
    prisma.storageLocation.findMany({ orderBy: { code: 'asc' } }),
  ]);
  return { categories, units, manufacturers, locations };
}

export async function listReferences(kind: ReferenceKind, actor: Actor) {
  assertCan(actor, 'medicines.view');
  switch (kind) {
    case 'kategori':
      return (await prisma.category.findMany({ orderBy: { name: 'asc' }, include: { _count: { select: { medicines: true } } } }))
        .map((r) => ({ id: r.id, label: r.name, detail: r.is_active ? 'Aktif' : 'Nonaktif', used: r._count.medicines, values: { name: r.name, is_active: r.is_active ? 'on' : '' } }));
    case 'satuan':
      return (await prisma.unit.findMany({ orderBy: { code: 'asc' }, include: { _count: { select: { medicines_base: true, conversions: true } } } }))
        .map((r) => ({ id: r.id, label: `${r.code} — ${r.name}`, detail: r.is_active ? 'Aktif' : 'Nonaktif', used: r._count.medicines_base + r._count.conversions, values: { code: r.code, name: r.name, is_active: r.is_active ? 'on' : '' } }));
    case 'pabrik':
      return (await prisma.manufacturer.findMany({ orderBy: { name: 'asc' }, include: { _count: { select: { medicines: true } } } }))
        .map((r) => ({ id: r.id, label: r.name, detail: r.country ?? '', used: r._count.medicines, values: { name: r.name, country: r.country ?? '' } }));
    case 'lokasi':
      return (await prisma.storageLocation.findMany({ orderBy: { code: 'asc' }, include: { _count: { select: { medicines: true } } } }))
        .map((r) => ({ id: r.id, label: `${r.code} — ${r.name}`, detail: STORAGE_LABELS[r.condition], used: r._count.medicines, values: { code: r.code, name: r.name, condition: r.condition } }));
  }
}

export async function saveReference(kind: ReferenceKind, id: string | null, raw: unknown, actor: Actor): Promise<void> {
  assertCan(actor, permissionFor(kind));
  const data = parseOrThrow(schemas[kind] as z.ZodType<Record<string, unknown>>, raw);
  await withDbErrors(() =>
    withTransaction(async (tx) => {
      let entityId = id;
      const delegate = {
        kategori: tx.category,
        satuan: tx.unit,
        pabrik: tx.manufacturer,
        lokasi: tx.storageLocation,
      }[kind] as unknown as {
        create(a: { data: Record<string, unknown> }): Promise<{ id: string }>;
        update(a: { where: { id: string }; data: Record<string, unknown> }): Promise<{ id: string }>;
      };
      if (id) {
        await delegate.update({ where: { id }, data });
      } else {
        entityId = (await delegate.create({ data })).id;
      }
      await writeAudit(tx, {
        ...auditMeta(actor), action: id ? 'reference.updated' : 'reference.created',
        entity: kind, entity_id: entityId, after: data,
      });
    }),
  );
}

/** Hapus referensi yang belum pernah dipakai. Yang sudah dipakai ditolak database (RESTRICT). */
export async function deleteReference(kind: ReferenceKind, id: string, actor: Actor): Promise<void> {
  assertCan(actor, permissionFor(kind));
  await withDbErrors(() =>
    withTransaction(async (tx) => {
      const delegate = { kategori: tx.category, satuan: tx.unit, pabrik: tx.manufacturer, lokasi: tx.storageLocation }[kind] as unknown as {
        delete(a: { where: { id: string } }): Promise<unknown>;
      };
      try {
        await delegate.delete({ where: { id } });
      } catch (e) {
        if ((e as { code?: string }).code === 'P2025') throw new AppError('NOT_FOUND');
        throw e;
      }
      await writeAudit(tx, { ...auditMeta(actor), action: 'reference.deleted', entity: kind, entity_id: id });
    }),
  );
}
