'use server';

import { revalidatePath } from 'next/cache';
import { runFormAction } from '@/lib/actions';
import type { ActionState } from '@/lib/forms';
import { deleteReference, saveReference, type ReferenceKind } from './service';

const PERM = (kind: ReferenceKind) => (kind === 'satuan' ? 'settings.manage' : 'medicines.manage') as 'settings.manage' | 'medicines.manage';

export async function saveReferenceAction(kind: ReferenceKind, id: string | null, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, PERM(kind), async (actor, values) => {
    await saveReference(kind, id, values, actor);
    return id ? 'Perubahan tersimpan.' : 'Data ditambahkan.';
  });
  if (state.ok) revalidatePath('/obat/referensi');
  return state;
}

export async function deleteReferenceAction(kind: ReferenceKind, id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, PERM(kind), async (actor) => {
    await deleteReference(kind, id, actor);
    return 'Data dihapus.';
  });
  if (state.ok) revalidatePath('/obat/referensi');
  return state;
}
