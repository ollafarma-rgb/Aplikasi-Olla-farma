import 'server-only';
import { Prisma } from '@/generated/prisma/client';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import type { DbTransaction } from '../../lib/database/client';
import { nextNumber, setActor } from '../../lib/database/context';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import { parseOrThrow } from '../../lib/validation';
import type { StockBucket } from '../inventory/schemas';
import { resolveApplicableDiscount } from '../discounts/service';
import { createReceivableInTx } from '../receivables/service';
import {
  customerSchema,
  openSessionSchema,
  closeSessionSchema,
  saleHeaderSchema,
  purchaseInvoiceSchema,
  supplierPaymentSchema,
  saleReturnHeaderSchema,
  prescriptionHeaderSchema,
  type SaleItemInput,
  type PrescriptionItemInput,
  type SaleReturnItemInput,
} from './schemas';

// ─────────────────────────── helpers ───────────────────────────

function periodYYMM(): string {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
  return `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
}

function formatDocNo(prefix: string, period: string, n: number): string {
  return `${prefix}-${period}-${String(n).padStart(4, '0')}`;
}

async function applyStockMovement(
  tx: DbTransaction,
  p: {
    batchId: string;
    type: string;
    from: StockBucket | null;
    to: StockBucket | null;
    qty: number;
    unitCost: string;
    refType: string;
    refId: string;
    refNo: string;
    reason: string | null;
    approvalId: string | null;
  },
): Promise<void> {
  await tx.$queryRaw`SELECT ams_apply_stock_movement(
    ${p.batchId}::uuid, ${p.type}::"MovementType",
    ${p.from}::"StockBucket", ${p.to}::"StockBucket",
    ${p.qty}::int, ${p.unitCost}::numeric,
    ${p.refType}, ${p.refId}::uuid, ${p.refNo}, ${p.reason}, ${null}::date, ${p.approvalId}::uuid)`;
}

export const PAGE_SIZE = 20;

// ─────────────────────────── Customer ───────────────────────────

export async function listCustomers(actor: Actor) {
  assertCan(actor, 'sales.create');
  return prisma.customer.findMany({
    where: { is_active: true },
    orderBy: { name: 'asc' },
    select: {
      id: true, code: true, name: true, phone: true,
      credit_limit: true, credit_used: true,
    },
  });
}

export async function listCustomersAll(actor: Actor) {
  assertCan(actor, 'customers.view_basic');
  return prisma.customer.findMany({
    orderBy: { name: 'asc' },
    select: {
      id: true, code: true, name: true, phone: true,
      address: true, is_active: true,
      credit_limit: true, credit_used: true,
    },
  });
}

export async function createCustomer(actor: Actor, raw: unknown): Promise<{ id: string; code: string; name: string; [key: string]: unknown }> {
  assertCan(actor, 'sales.create');
  const input = parseOrThrow(customerSchema, raw);
  return withDbErrors(() =>
    prisma.customer.create({
      data: {
        code: input.code,
        name: input.name,
        phone: input.phone ?? null,
        address: input.address ?? null,
        date_of_birth: input.date_of_birth ? new Date(input.date_of_birth) : null,
        credit_limit: new Prisma.Decimal(input.credit_limit ?? '0'),
        notes: input.notes ?? null,
      },
    }),
  );
}

export async function updateCustomer(actor: Actor, id: string, raw: unknown) {
  assertCan(actor, 'sales.create');
  const input = parseOrThrow(customerSchema, raw);
  return withDbErrors(() =>
    prisma.customer.update({
      where: { id },
      data: {
        code: input.code,
        name: input.name,
        phone: input.phone ?? null,
        address: input.address ?? null,
        date_of_birth: input.date_of_birth ? new Date(input.date_of_birth) : null,
        credit_limit: new Prisma.Decimal(input.credit_limit ?? '0'),
        notes: input.notes ?? null,
      },
    }),
  );
}

// ─────────────────────────── Sesi Kasir ───────────────────────────

export async function getOpenSession(actor: Actor) {
  assertCan(actor, 'pos.access');
  return prisma.saleSession.findFirst({
    where: { cashier_id: actor.id, status: 'OPEN' },
    include: {
      _count: { select: { sales: { where: { status: 'ACTIVE' } } } },
    },
  });
}

export async function openSession(actor: Actor, raw: unknown) {
  assertCan(actor, 'pos.access');
  const input = parseOrThrow(openSessionSchema, raw);

  const existing = await prisma.saleSession.findFirst({
    where: { cashier_id: actor.id, status: 'OPEN' },
  });
  if (existing) {
    throw new AppError('VALIDATION_ERROR', 'Sesi kasir sudah terbuka. Tutup sesi sebelumnya terlebih dahulu.');
  }

  const period = periodYYMM();
  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const n = await nextNumber(tx, 'SFT', period);
    const sessionNo = formatDocNo('SFT', period, n);
    const session = await tx.saleSession.create({
      data: {
        session_no: sessionNo,
        cashier_id: actor.id,
        opening_cash: new Prisma.Decimal(input.opening_cash),
        notes: input.notes ?? null,
      },
    });
    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'sales.session_opened',
      entity: 'sale_sessions',
      entity_id: session.id,
      after: { session_no: sessionNo, opening_cash: input.opening_cash },
    });
    return session;
  });
}

export async function closeSession(actor: Actor, sessionId: string, raw: unknown) {
  assertCan(actor, 'pos.access');
  const input = parseOrThrow(closeSessionSchema, raw);

  const session = await prisma.saleSession.findUnique({ where: { id: sessionId } });
  if (!session) throw new AppError('NOT_FOUND');
  if (session.cashier_id !== actor.id) throw new AppError('FORBIDDEN', 'Bukan sesi kasir Anda.');
  if (session.status !== 'OPEN') {
    throw new AppError('VALIDATION_ERROR', 'Sesi sudah ditutup.');
  }

  const cashAgg = await prisma.sale.aggregate({
    where: { session_id: sessionId, status: 'ACTIVE', payment_method: 'CASH' },
    _sum: { amount_paid: true },
  });
  const totalCashIn = cashAgg._sum.amount_paid ?? new Prisma.Decimal(0);
  const expectedCash = session.opening_cash.plus(totalCashIn);
  const closingCash = new Prisma.Decimal(input.closing_cash);
  const difference = closingCash.minus(expectedCash);

  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const updated = await tx.saleSession.update({
      where: { id: sessionId },
      data: {
        status: 'CLOSED',
        closed_at: new Date(),
        closing_cash: closingCash,
        expected_cash: expectedCash,
        cash_difference: difference,
        notes: input.notes ?? null,
      },
    });
    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'sales.session_closed',
      entity: 'sale_sessions',
      entity_id: sessionId,
      after: { closing_cash: input.closing_cash, cash_difference: difference.toFixed(2) },
    });
    return updated;
  });
}

// ─────────────────────────── Penjualan ───────────────────────────

export async function createSale(actor: Actor, rawHeader: unknown, items: SaleItemInput[]) {
  assertCan(actor, 'sales.create');
  const header = parseOrThrow(saleHeaderSchema, rawHeader);

  if (items.length === 0) {
    throw new AppError('VALIDATION_ERROR', 'Minimal satu item penjualan.');
  }

  const session = await prisma.saleSession.findFirst({
    where: { cashier_id: actor.id, status: 'OPEN' },
  });
  if (!session) {
    throw new AppError('VALIDATION_ERROR', 'Tidak ada sesi kasir yang terbuka. Buka sesi terlebih dahulu.');
  }

  if (header.payment_method === 'RECEIVABLE') {
    if (!header.customer_id) {
      throw new AppError('VALIDATION_ERROR', undefined, {
        customer_id: 'Pelanggan wajib dipilih untuk penjualan piutang.',
      });
    }
    const customer = await prisma.customer.findUnique({ where: { id: header.customer_id } });
    if (!customer) throw new AppError('NOT_FOUND', 'Pelanggan tidak ditemukan.');
    if (customer.credit_limit.lte(0)) {
      throw new AppError('VALIDATION_ERROR', 'Pelanggan tidak memiliki batas piutang (kredit).');
    }
  }

  const period = periodYYMM();

  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const n = await nextNumber(tx, 'PJ', period);
    const invoiceNo = formatDocNo('TRJ', period, n);

    let subtotal = new Prisma.Decimal(0);

    type LineData = {
      medicine_id:      string;
      batch_id:         string;
      unit_id:          string;
      qty:              number;
      qty_base:         number;
      unit_price:       Prisma.Decimal;
      discount_pct:     Prisma.Decimal;
      line_total:       Prisma.Decimal;
      unit_cost:        Prisma.Decimal;
      discount_rule_id: string | null;
    };
    const lines: LineData[] = [];
    const saleAt = new Date();

    for (const item of items) {
      const unitPrice = new Prisma.Decimal(item.unit_price);

      // Ambil batch + medicine.category_id untuk resolusi diskon
      const batch = await tx.medicineBatch.findUnique({
        where: { id: item.batch_id },
        select: {
          unit_cost:    true,
          qty_saleable: true,
          is_recalled:  true,
          medicine: { select: { category_id: true } },
        },
      });
      if (!batch) {
        throw new AppError('VALIDATION_ERROR', undefined, { batch_id: 'Batch tidak ditemukan.' });
      }
      if (batch.is_recalled) {
        throw new AppError('VALIDATION_ERROR', 'Batch ini tidak dapat dijual (sudah direcall).');
      }
      if (batch.qty_saleable < item.qty) {
        throw new AppError(
          'VALIDATION_ERROR',
          `Stok saleable tidak mencukupi. Tersedia: ${batch.qty_saleable}, dibutuhkan: ${item.qty}.`,
        );
      }

      // Resolusi diskon otomatis (qty_base = qty karena satuan dasar)
      const resolved = await resolveApplicableDiscount(tx, {
        medicine_id:  item.medicine_id,
        category_id:  batch.medicine?.category_id ?? null,
        qty_base:     item.qty,
        at:           saleAt,
      });

      // Hitung discount_pct efektif
      let effectiveDiscPct: Prisma.Decimal;
      if (resolved) {
        if (resolved.type === 'PERCENT') {
          effectiveDiscPct = new Prisma.Decimal(resolved.value);
        } else {
          // AMOUNT: konversi ke persen dari unit_price
          effectiveDiscPct = unitPrice.gt(0)
            ? new Prisma.Decimal(resolved.value).div(unitPrice).times(100)
            : new Prisma.Decimal(0);
        }
      } else {
        // Gunakan discount_pct manual dari input kasir jika tidak ada auto-diskon
        effectiveDiscPct = new Prisma.Decimal(item.discount_pct);
      }

      const lineTotal = unitPrice.times(item.qty).times(
        new Prisma.Decimal(1).minus(effectiveDiscPct.div(100))
      );

      lines.push({
        medicine_id:      item.medicine_id,
        batch_id:         item.batch_id,
        unit_id:          item.unit_id,
        qty:              item.qty,
        qty_base:         item.qty, // simplifikasi: asumsi satuan dasar
        unit_price:       unitPrice,
        discount_pct:     effectiveDiscPct,
        line_total:       lineTotal,
        unit_cost:        batch.unit_cost,
        discount_rule_id: resolved?.rule_id ?? null,
      });
      subtotal = subtotal.plus(lineTotal);
    }

    const totalAmount = subtotal;
    const amountPaid = new Prisma.Decimal(header.amount_paid);
    const changeGiven =
      header.payment_method === 'CASH' ? amountPaid.minus(totalAmount) : new Prisma.Decimal(0);

    if (header.payment_method === 'CASH' && amountPaid.lt(totalAmount)) {
      throw new AppError('VALIDATION_ERROR', undefined, {
        amount_paid: 'Jumlah bayar kurang dari total tagihan.',
      });
    }

    const sale = await tx.sale.create({
      data: {
        invoice_no: invoiceNo,
        session_id: session.id,
        cashier_id: actor.id,
        customer_id: header.customer_id ?? null,
        prescription_id: header.prescription_id ?? null,
        payment_method: header.payment_method,
        subtotal,
        discount_amount: new Prisma.Decimal(0),
        total_amount: totalAmount,
        amount_paid: amountPaid,
        change_given: changeGiven,
        notes: header.notes ?? null,
      },
    });

    for (const li of lines) {
      await tx.saleItem.create({
        data: {
          sale_id:          sale.id,
          medicine_id:      li.medicine_id,
          batch_id:         li.batch_id,
          unit_id:          li.unit_id,
          qty:              li.qty,
          qty_base:         li.qty_base,
          unit_price:       li.unit_price,
          unit_cost:        li.unit_cost,
          discount_pct:     li.discount_pct,
          line_total:       li.line_total,
          discount_rule_id: li.discount_rule_id ?? null,
        },
      });

      await applyStockMovement(tx, {
        batchId: li.batch_id,
        type: 'SALE',
        from: 'SALEABLE',
        to: null,
        qty: li.qty,
        unitCost: li.unit_cost.toString(),
        refType: 'sale',
        refId: sale.id,
        refNo: invoiceNo,
        reason: null,
        approvalId: null,
      });
    }

    if (header.payment_method === 'RECEIVABLE' && header.customer_id) {
      await tx.customer.update({
        where: { id: header.customer_id },
        data: { credit_used: { increment: totalAmount } },
      });
      // Buat record piutang — 1 penjualan = 1 piutang (UNIQUE sale_id)
      await createReceivableInTx(tx, {
        sale_id: sale.id,
        customer_id: header.customer_id,
        amount: totalAmount,
        sale_date: saleAt,
      });
    }

    if (header.prescription_id) {
      await tx.prescription.update({
        where: { id: header.prescription_id },
        data: { status: 'DISPENSED' },
      });
    }

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'sales.sale_created',
      entity: 'sales',
      entity_id: sale.id,
      after: {
        invoice_no: invoiceNo,
        total_amount: totalAmount.toFixed(2),
        payment_method: header.payment_method,
      },
    });

    return { ...sale, saleNo: sale.invoice_no };
  });
}

export async function cancelSale(actor: Actor, saleId: string, reason?: string) {
  assertCan(actor, 'sales.create');

  const sale = await prisma.sale.findUnique({
    where: { id: saleId },
    include: {
      items: { select: { batch_id: true, qty: true, unit_cost: true } },
      session: { select: { cashier_id: true } },
    },
  });
  if (!sale) throw new AppError('NOT_FOUND');
  // Kasir ybs atau aktor yang punya izin approve pembatalan (apoteker, owner) boleh membatalkan
  const canCancelAny = actor.permissions.has('sales.cancel.approve');
  if (!canCancelAny && sale.cashier_id !== actor.id && sale.session.cashier_id !== actor.id) {
    throw new AppError('FORBIDDEN', 'Hanya kasir yang bersangkutan yang dapat membatalkan transaksi.');
  }
  if (sale.status === 'CANCELLED') {
    throw new AppError('VALIDATION_ERROR', 'Transaksi sudah dibatalkan.');
  }

  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);

    for (const item of sale.items) {
      await applyStockMovement(tx, {
        batchId: item.batch_id,
        type: 'ADJUSTMENT',
        from: null,
        to: 'SALEABLE',
        qty: item.qty,
        unitCost: item.unit_cost.toString(),
        refType: 'sale_cancel',
        refId: sale.id,
        refNo: sale.invoice_no,
        reason: reason ?? 'Pembatalan penjualan',
        approvalId: null,
      });
    }

    if (sale.payment_method === 'RECEIVABLE' && sale.customer_id) {
      await tx.customer.update({
        where: { id: sale.customer_id },
        data: { credit_used: { decrement: sale.total_amount } },
      });
    }

    const updated = await tx.sale.update({
      where: { id: saleId },
      data: {
        status: 'CANCELLED',
        cancelled_at: new Date(),
        cancelled_by: actor.id,
      },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'sales.sale_cancelled',
      entity: 'sales',
      entity_id: saleId,
      after: { reason: reason ?? null },
    });

    return updated;
  });
}

export async function getSaleDetail(actor: Actor, saleId: string) {
  assertCan(actor, 'sales.create');
  return prisma.sale.findUnique({
    where: { id: saleId },
    include: {
      cashier: { select: { id: true, full_name: true } },
      customer: { select: { id: true, name: true, phone: true } },
      prescription: true,
      items: {
        include: {
          medicine: { select: { id: true, name: true } },
          batch: { select: { id: true, batch_no: true, expiry_date: true } },
          unit: { select: { id: true, name: true } },
        },
      },
    },
  });
}

export async function listSales(
  actor: Actor,
  params: { sessionId?: string; startDate?: Date; endDate?: Date; status?: string; page?: number },
) {
  assertCan(actor, 'sales.create');
  const page = Math.max(1, params.page ?? 1);
  return prisma.sale.findMany({
    where: {
      session_id: params.sessionId,
      status: (params.status as 'ACTIVE' | 'CANCELLED') ?? undefined,
      sold_at: { gte: params.startDate, lte: params.endDate },
    },
    include: {
      cashier: { select: { full_name: true } },
      customer: { select: { id: true, name: true } },
      _count: { select: { items: true } },
    },
    orderBy: { sold_at: 'desc' },
    skip: (page - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  });
}

// ─────────────────────────── Resep ───────────────────────────

export async function createPrescription(
  actor: Actor,
  rawHeader: unknown,
  items: PrescriptionItemInput[],
) {
  assertCan(actor, 'rx.create');
  const header = parseOrThrow(prescriptionHeaderSchema, rawHeader);
  if (items.length === 0) throw new AppError('VALIDATION_ERROR', 'Minimal satu item resep.');

  const period = periodYYMM();
  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const n = await nextNumber(tx, 'RX', period);
    const rxNo = formatDocNo('RX', period, n);

    const rx = await tx.prescription.create({
      data: {
        rx_no: rxNo,
        customer_id: header.customer_id ?? null,
        doctor_name: header.doctor_name,
        doctor_sip: header.doctor_sip ?? null,
        clinic_name: header.clinic_name ?? null,
        prescribed_at: new Date(header.prescribed_at),
        notes: header.notes ?? null,
        created_by: actor.id,
        items: {
          create: items.map(it => ({
            medicine_id: it.medicine_id,
            qty_prescribed: it.qty_prescribed,
            instructions: it.instructions,
            notes: it.notes ?? null,
          })),
        },
      },
      include: { items: true },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'rx.created',
      entity: 'prescriptions',
      entity_id: rx.id,
      after: { rx_no: rxNo, doctor_name: header.doctor_name },
    });

    return rx;
  });
}

export async function verifyPrescription(actor: Actor, rxId: string) {
  assertCan(actor, 'rx.verify');

  const rx = await prisma.prescription.findUnique({ where: { id: rxId } });
  if (!rx) throw new AppError('NOT_FOUND');
  if (rx.created_by === actor.id) {
    throw new AppError('FORBIDDEN', 'Verifikator tidak boleh sama dengan pembuat resep.');
  }
  if (rx.status !== 'PENDING') {
    throw new AppError('VALIDATION_ERROR', 'Resep sudah diverifikasi atau dibatalkan.');
  }

  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const updated = await tx.prescription.update({
      where: { id: rxId },
      data: { status: 'VERIFIED', verified_by: actor.id, verified_at: new Date() },
    });
    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'rx.verified',
      entity: 'prescriptions',
      entity_id: rxId,
      after: { rx_no: rx.rx_no },
    });
    return updated;
  });
}

export async function getPrescriptionDetail(actor: Actor, rxId: string) {
  assertCan(actor, 'rx.verify');
  return prisma.prescription.findUnique({
    where: { id: rxId },
    include: {
      customer: { select: { id: true, name: true } },
      creator: { select: { id: true, full_name: true } },
      verifier: { select: { id: true, full_name: true } },
      items: {
        include: { medicine: { select: { id: true, name: true } } },
      },
      sale: { select: { id: true, invoice_no: true, sold_at: true } },
    },
  });
}

// ─────────────────────────── Retur Penjualan ───────────────────────────

export async function createSaleReturnDraft(
  actor: Actor,
  rawHeader: unknown,
  items: SaleReturnItemInput[],
) {
  assertCan(actor, 'sales.create');
  const header = parseOrThrow(saleReturnHeaderSchema, rawHeader);
  if (items.length === 0) throw new AppError('VALIDATION_ERROR', 'Minimal satu item retur.');

  const sale = await prisma.sale.findUnique({
    where: { id: header.sale_id },
    include: { items: { select: { id: true, qty: true } } },
  });
  if (!sale) throw new AppError('NOT_FOUND', 'Transaksi penjualan tidak ditemukan.');
  if (sale.status === 'CANCELLED') {
    throw new AppError('VALIDATION_ERROR', 'Tidak bisa meretur transaksi yang sudah dibatalkan.');
  }

  for (const retItem of items) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const saleItem = sale.items.find((si: any) => si.id === retItem.sale_item_id);
    if (!saleItem) {
      throw new AppError('VALIDATION_ERROR', 'Item penjualan tidak ditemukan dalam transaksi ini.');
    }
    if (retItem.qty > saleItem.qty) {
      throw new AppError(
        'VALIDATION_ERROR',
        `Qty retur (${retItem.qty}) melebihi qty jual (${saleItem.qty}).`,
      );
    }
  }

  const period = periodYYMM();
  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const n = await nextNumber(tx, 'RJ', period);
    const returnNo = formatDocNo('RS', period, n);

    // Buat header dulu (hindari nested create yang menyebabkan Rust panic di relation.rs)
    const saleReturn = await tx.saleReturn.create({
      data: {
        return_no: returnNo,
        sale_id: header.sale_id,
        received_by: actor.id,
        notes: header.notes ?? null,
      },
    });

    // Buat items secara terpisah
    await tx.saleReturnItem.createMany({
      data: items.map(it => ({
        return_id: saleReturn.id,
        sale_item_id: it.sale_item_id,
        batch_id: it.batch_id,
        qty: it.qty,
        qty_base: it.qty,
        unit_price: new Prisma.Decimal(0),
        disposition: it.disposition,
        reason: it.reason,
      })),
    });

    // Ambil ulang dengan items
    const saleReturnWithItems = await tx.saleReturn.findUniqueOrThrow({
      where: { id: saleReturn.id },
      include: { items: true },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'sales.return_drafted',
      entity: 'sale_returns',
      entity_id: saleReturn.id,
      after: { return_no: returnNo, sale_id: header.sale_id },
    });

    return saleReturnWithItems;
  });
}

export async function postSaleReturn(actor: Actor, saleReturnId: string, notes?: string) {
  assertCan(actor, 'sales.create');

  const sr = await prisma.saleReturn.findUnique({
    where: { id: saleReturnId },
    include: {
      items: {
        include: {
          sale_item: { select: { unit_price: true, unit_cost: true } },
        },
      },
      sale: { select: { id: true, payment_method: true, customer_id: true } },
    },
  });
  if (!sr) throw new AppError('NOT_FOUND');
  if (sr.status !== 'DRAFT') throw new AppError('VALIDATION_ERROR', 'Retur sudah diposting atau dibatalkan.');
  if (sr.received_by === actor.id) {
    throw new AppError('FORBIDDEN', 'Checker tidak boleh sama dengan maker (four-eyes principle).');
  }

  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);

    let totalReturnValue = new Prisma.Decimal(0);

    for (const item of sr.items) {
      const targetBucket: StockBucket | null =
        item.disposition === 'RESTOCK'
          ? 'SALEABLE'
          : item.disposition === 'QUARANTINE'
          ? 'QUARANTINE'
          : null;

      if (targetBucket !== null) {
        await applyStockMovement(tx, {
          batchId: item.batch_id,
          type: 'SALE_RETURN',
          from: null,
          to: targetBucket,
          qty: item.qty,
          unitCost: item.sale_item.unit_cost.toString(),
          refType: 'sale_return',
          refId: sr.id,
          refNo: sr.return_no,
          reason: item.reason,
          approvalId: null,
        });
      }

      const lineValue = item.sale_item.unit_price.times(item.qty);
      totalReturnValue = totalReturnValue.plus(lineValue);
    }

    if (sr.sale.payment_method === 'RECEIVABLE' && sr.sale.customer_id && totalReturnValue.gt(0)) {
      await tx.customer.update({
        where: { id: sr.sale.customer_id },
        data: { credit_used: { decrement: totalReturnValue } },
      });
    }

    const approval = await tx.approval.create({
      data: {
        action_code: 'sales.return.approve',
        requested_by: sr.received_by,
        approved_by: actor.id,
        ref_type: 'sale_return',
        ref_id: sr.id,
        reason: notes ?? `Retur ${sr.return_no} disetujui`,
      },
    });

    await tx.saleReturn.update({
      where: { id: saleReturnId },
      data: {
        status: 'POSTED',
        posted_at: new Date(),
        approval_id: approval.id,
      },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'sales.return_posted',
      entity: 'sale_returns',
      entity_id: sr.id,
      after: { return_no: sr.return_no },
    });

    return { id: sr.id };
  });
}

// ─────────────────────────── Faktur Pembelian ───────────────────────────

export async function createPurchaseInvoice(actor: Actor, raw: unknown) {
  assertCan(actor, 'procurement.receive.post');
  const input = parseOrThrow(purchaseInvoiceSchema, raw);

  const gr = await prisma.goodsReceipt.findUnique({
    where: { id: input.gr_id },
    include: {
      purchase_invoice: { select: { id: true } },
      items: { select: { qty: true, unit_cost: true } },
    },
  });
  if (!gr) throw new AppError('NOT_FOUND', 'Penerimaan barang tidak ditemukan.');
  if (gr.purchase_invoice) {
    throw new AppError('VALIDATION_ERROR', 'Faktur untuk penerimaan barang ini sudah dibuat.');
  }
  if (gr.status !== 'POSTED') {
    throw new AppError('VALIDATION_ERROR', 'Penerimaan barang belum diposting.');
  }

  const subtotal = gr.items.reduce(
    (sum, item) => sum.plus(item.unit_cost.times(item.qty)),
    new Prisma.Decimal(0),
  );

  const period = periodYYMM();
  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const n = await nextNumber(tx, 'PI', period);
    const invoiceNo = formatDocNo('FKT', period, n);

    const invoice = await tx.purchaseInvoice.create({
      data: {
        invoice_no: invoiceNo,
        supplier_inv_no: input.supplier_inv_no ?? null,
        gr_id: input.gr_id,
        supplier_id: gr.supplier_id,
        invoice_date: new Date(input.invoice_date),
        due_date: new Date(input.due_date),
        subtotal,
        tax_amount: new Prisma.Decimal(0), // Non-PKP
        total_amount: subtotal,
        notes: input.notes ?? null,
        created_by: actor.id,
      },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'finance.invoice_created',
      entity: 'purchase_invoices',
      entity_id: invoice.id,
      after: { invoice_no: invoiceNo, total_amount: subtotal.toFixed(2) },
    });

    return { ...invoice, invNo: invoice.invoice_no };
  });
}

export async function listPurchaseInvoices(
  actor: Actor,
  params: { supplierId?: string; status?: string; page?: number },
) {
  assertCan(actor, 'finance.view');
  const page = Math.max(1, params.page ?? 1);
  return prisma.purchaseInvoice.findMany({
    where: {
      supplier_id: params.supplierId,
      status: (params.status as 'UNPAID' | 'PARTIAL' | 'PAID') ?? undefined,
    },
    include: {
      supplier: { select: { id: true, name: true } },
      gr: { select: { id: true, gr_no: true } },
    },
    orderBy: { due_date: 'asc' },
    skip: (page - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
  });
}

export async function getPurchaseInvoiceDetail(actor: Actor, invoiceId: string) {
  assertCan(actor, 'procurement.view');
  return prisma.purchaseInvoice.findUnique({
    where: { id: invoiceId ?? undefined },
    include: {
      supplier: true,
      gr: {
        include: {
          items: {
            include: { medicine: { select: { name: true } } },
          },
        },
      },
      payments: { orderBy: { payment_date: 'asc' } },
      creator: { select: { full_name: true } },
    },
  });
}

// ─────────────────────────── Pembayaran ke Pemasok ───────────────────────────

export async function recordSupplierPayment(actor: Actor, raw: unknown) {
  assertCan(actor, 'finance.payable.pay');
  const input = parseOrThrow(supplierPaymentSchema, raw);

  const invoice = await prisma.purchaseInvoice.findUnique({
    where: { id: input.invoice_id },
    select: {
      id: true, supplier_id: true, status: true,
      total_amount: true, amount_paid: true, invoice_no: true,
    },
  });
  if (!invoice) throw new AppError('NOT_FOUND', 'Faktur tidak ditemukan.');
  if (invoice.status === 'PAID') throw new AppError('VALIDATION_ERROR', 'Faktur sudah lunas.');

  const payAmount = new Prisma.Decimal(input.amount);
  const remaining = invoice.total_amount.minus(invoice.amount_paid);
  if (payAmount.gt(remaining)) {
    throw new AppError(
      'VALIDATION_ERROR',
      `Jumlah bayar melebihi sisa utang. Sisa: Rp ${remaining.toFixed(0)}.`,
    );
  }

  const period = periodYYMM();
  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);
    const n = await nextNumber(tx, 'BYR', period);
    const payNo = formatDocNo('PAY', period, n);

    const payment = await tx.supplierPayment.create({
      data: {
        payment_no: payNo,
        invoice_id: invoice.id,
        supplier_id: invoice.supplier_id,
        payment_date: new Date(input.payment_date),
        amount: payAmount,
        reference_no: input.reference_no ?? null,
        notes: input.notes ?? null,
        paid_by: actor.id,
      },
    });

    const newAmountPaid = invoice.amount_paid.plus(payAmount);
    const newStatus = newAmountPaid.gte(invoice.total_amount) ? 'PAID' : 'PARTIAL';

    await tx.purchaseInvoice.update({
      where: { id: invoice.id },
      data: { amount_paid: newAmountPaid, status: newStatus },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'finance.payment_recorded',
      entity: 'supplier_payments',
      entity_id: payment.id,
      after: {
        payment_no: payNo,
        invoice_no: invoice.invoice_no,
        amount: payAmount.toFixed(0),
        status: newStatus,
      },
    });

    return payment;
  });
}

// ─── Customer Detail & History ─────────────────────────────────────────────

export async function getCustomerDetail(actor: Actor, customerId: string) {
  assertCan(actor, 'customers.view_basic');

  const customer = await prisma.customer.findUnique({
    where: { id: customerId },
    select: {
      id: true,
      code: true,
      name: true,
      phone: true,
      address: true,
      date_of_birth: true,
      credit_limit: true,
      credit_used: true,
      notes: true,
      is_active: true,
      created_at: true,
      _count: {
        select: {
          sales: { where: { status: 'ACTIVE' } },
          prescriptions: true,
          receivables: true,
        },
      },
    },
  });

  if (!customer) throw new AppError('NOT_FOUND', 'Pelanggan tidak ditemukan.');
  return customer;
}

export async function getCustomerPrescriptions(actor: Actor, customerId: string) {
  assertCan(actor, 'customers.view_basic');

  return prisma.prescription.findMany({
    where: { customer_id: customerId },
    orderBy: { prescribed_at: 'desc' },
    select: {
      id: true,
      rx_no: true,
      prescribed_at: true,
      status: true,
      doctor_name: true,
      doctor_sip: true,
      clinic_name: true,
      notes: true,
      items: {
        select: {
          id: true,
          qty_prescribed: true,
          instructions: true,
          notes: true,
          medicine: { select: { id: true, name: true, generic_name: true } },
        },
      },
      sale: {
        select: {
          id: true,
          invoice_no: true,
          sold_at: true,
          total_amount: true,
        },
      },
    },
  });
}

export async function getCustomerSales(actor: Actor, customerId: string) {
  assertCan(actor, 'customers.view_basic');

  return prisma.sale.findMany({
    where: { customer_id: customerId },
    orderBy: { sold_at: 'desc' },
    take: 100,
    select: {
      id: true,
      invoice_no: true,
      sold_at: true,
      status: true,
      payment_method: true,
      subtotal: true,
      discount_amount: true,
      total_amount: true,
      amount_paid: true,
      cashier: { select: { name: true } },
      items: {
        select: {
          id: true,
          qty: true,
          unit_price: true,
          line_total: true,
          medicine: { select: { name: true } },
          unit: { select: { name: true } },
        },
      },
      receivable: {
        select: {
          id: true,
          amount: true,
          paid_amount: true,
          status: true,
        },
      },
    },
  });
}
