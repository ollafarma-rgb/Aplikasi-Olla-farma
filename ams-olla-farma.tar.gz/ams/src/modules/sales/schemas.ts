import { z } from 'zod';
import { intField, money, optionalId, optionalText, requiredId, text } from '../../lib/forms';

const emptyToUndefined = (v: unknown) => (v === '' ? undefined : v);
const dateString = (label: string) =>
  z.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/, `${label} wajib diisi (format tanggal).`);

// ---- Label konstan ----
export const PAYMENT_METHOD_LABELS: Record<string, string> = {
  CASH: 'Tunai',
  RECEIVABLE: 'Piutang',
};

export const SALE_STATUS_LABELS: Record<string, string> = {
  ACTIVE: 'Aktif',
  CANCELLED: 'Dibatalkan',
};

export const SESSION_STATUS_LABELS: Record<string, string> = {
  OPEN: 'Terbuka',
  CLOSED: 'Ditutup',
};

export const PRESCRIPTION_STATUS_LABELS: Record<string, string> = {
  PENDING: 'Menunggu verifikasi',
  VERIFIED: 'Terverifikasi',
  DISPENSED: 'Sudah diserahkan',
  CANCELLED: 'Dibatalkan',
};

export const SALE_RETURN_STATUS_LABELS: Record<string, string> = {
  DRAFT: 'Draf',
  POSTED: 'Diposting',
  CANCELLED: 'Dibatalkan',
};

export const INVOICE_STATUS_LABELS: Record<string, string> = {
  UNPAID: 'Belum dibayar',
  PARTIAL: 'Dibayar sebagian',
  PAID: 'Lunas',
};

export const RETURN_DISPOSITION_LABELS: Record<string, string> = {
  RESTOCK: 'Kembalikan ke stok',
  QUARANTINE: 'Masuk karantina',
  DISPOSE: 'Langsung dibuang',
};

// ---- Pelanggan ----
export const customerSchema = z.object({
  code: text(20, 'Kode pelanggan'),
  name: text(200, 'Nama pelanggan'),
  phone: optionalText(30, 'Telepon'),
  address: optionalText(500, 'Alamat'),
  date_of_birth: z.preprocess(emptyToUndefined, dateString('Tanggal lahir').optional()),
  credit_limit: z.preprocess(
    emptyToUndefined,
    z.string().optional().transform(v => v ? v.replace(/\./g, '').replace(',', '.') : '0')
      .refine(v => /^\d{1,16}(\.\d{1,2})?$/.test(v), 'Batas piutang harus angka.')
  ),
  notes: optionalText(500, 'Catatan'),
});
export type CustomerInput = z.output<typeof customerSchema>;

// ---- Sesi Kasir ----
export const openSessionSchema = z.object({
  opening_cash: money('Kas awal'),
  notes: optionalText(500, 'Catatan'),
});
export type OpenSessionInput = z.output<typeof openSessionSchema>;

export const closeSessionSchema = z.object({
  closing_cash: money('Kas akhir hitungan'),
  notes: optionalText(500, 'Catatan'),
});
export type CloseSessionInput = z.output<typeof closeSessionSchema>;

// ---- Penjualan ----
export interface SaleItemInput {
  medicine_id: string;
  batch_id: string;
  unit_id: string;
  qty: number;
  unit_price: string;
  discount_pct: string;
}

export const saleHeaderSchema = z.object({
  customer_id: optionalId,
  prescription_id: optionalId,
  payment_method: z.enum(['CASH', 'RECEIVABLE']),
  amount_paid: money('Jumlah bayar'),
  notes: optionalText(500, 'Catatan'),
});
export type SaleHeaderInput = z.output<typeof saleHeaderSchema>;

// ---- Resep ----
export const prescriptionHeaderSchema = z.object({
  customer_id: optionalId,
  doctor_name: text(200, 'Nama dokter'),
  doctor_sip: optionalText(50, 'SIP dokter'),
  clinic_name: optionalText(200, 'Nama klinik/RS'),
  prescribed_at: dateString('Tanggal resep'),
  notes: optionalText(500, 'Catatan'),
});
export type PrescriptionHeaderInput = z.output<typeof prescriptionHeaderSchema>;

export interface PrescriptionItemInput {
  medicine_id: string;
  qty_prescribed: number;
  instructions: string;
  notes?: string;
}

// ---- Retur Penjualan ----
export const saleReturnHeaderSchema = z.object({
  sale_id: requiredId('Transaksi penjualan'),
  notes: optionalText(500, 'Catatan'),
});
export type SaleReturnHeaderInput = z.output<typeof saleReturnHeaderSchema>;

export interface SaleReturnItemInput {
  sale_item_id: string;
  batch_id: string;
  qty: number;
  disposition: 'RESTOCK' | 'QUARANTINE' | 'DISPOSE';
  reason: string;
}

// ---- Faktur Pembelian ----
export const purchaseInvoiceSchema = z.object({
  gr_id: requiredId('Penerimaan barang'),
  supplier_inv_no: optionalText(100, 'Nomor faktur pemasok'),
  invoice_date: dateString('Tanggal faktur'),
  due_date: dateString('Tanggal jatuh tempo'),
  notes: optionalText(500, 'Catatan'),
});
export type PurchaseInvoiceInput = z.output<typeof purchaseInvoiceSchema>;

// ---- Pembayaran ke Pemasok ----
export const supplierPaymentSchema = z.object({
  invoice_id: requiredId('Faktur'),
  payment_date: dateString('Tanggal bayar'),
  amount: money('Jumlah bayar'),
  reference_no: optionalText(100, 'Nomor referensi/bukti'),
  notes: optionalText(300, 'Catatan'),
});
export type SupplierPaymentInput = z.output<typeof supplierPaymentSchema>;
