'use server';

import { z } from 'zod';
import { requireActor } from '../../lib/auth/server';
import { translateDbError } from '../../lib/database/errors';
import { AppError } from '../../lib/errors';
import { type ActionState } from '../../lib/forms';
import { fieldErrors } from '../../lib/validation';
import type { SaleItemInput, PrescriptionItemInput, SaleReturnItemInput } from './schemas';
import * as svc from './service';

function fail(error: unknown): ActionState {
  const appErr = error instanceof AppError ? error : translateDbError(error);
  if (appErr instanceof AppError) {
    return {
      ok: false,
      code: appErr.code,
      message: appErr.message ?? 'Tidak dapat menyimpan.',
      fields: appErr.fields,
      submittedAt: Date.now(),
    };
  }
  if (error instanceof z.ZodError) {
    return { ok: false, code: 'VALIDATION_ERROR', fields: fieldErrors(error), submittedAt: Date.now() };
  }
  throw error;
}

// ─────────────── Customer ───────────────

export async function listCustomersAction(): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const data = await svc.listCustomers(actor);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function createCustomerAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const result = await svc.createCustomer(actor, Object.fromEntries(fd) as Record<string, string>);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function updateCustomerAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const result = await svc.updateCustomer(actor, id, Object.fromEntries(fd) as Record<string, string>);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────── Sesi Kasir ───────────────

export async function getOpenSessionAction(): Promise<ActionState> {
  try {
    const actor = await requireActor('pos.access');
    const data = await svc.getOpenSession(actor);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function openSessionAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('pos.access');
    const result = await svc.openSession(actor, Object.fromEntries(fd) as Record<string, string>);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function closeSessionAction(sessionId: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('pos.access');
    const result = await svc.closeSession(actor, sessionId, Object.fromEntries(fd) as Record<string, string>);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────── Penjualan ───────────────

export async function createSaleAction(rawHeader: unknown, items: SaleItemInput[]): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const result = await svc.createSale(actor, rawHeader, items);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function cancelSaleAction(saleId: string, reason?: string): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const result = await svc.cancelSale(actor, saleId, reason);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function getSaleDetailAction(saleId: string): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const data = await svc.getSaleDetail(actor, saleId);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function listSalesAction(params: {
  sessionId?: string;
  startDate?: Date;
  endDate?: Date;
  status?: string;
  page?: number;
}): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const data = await svc.listSales(actor, params);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────── Resep ───────────────

export async function createPrescriptionAction(
  rawHeader: unknown,
  items: PrescriptionItemInput[],
): Promise<ActionState> {
  try {
    const actor = await requireActor('rx.verify');
    const result = await svc.createPrescription(actor, rawHeader, items);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function verifyPrescriptionAction(rxId: string): Promise<ActionState> {
  try {
    const actor = await requireActor('rx.verify');
    const result = await svc.verifyPrescription(actor, rxId);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function getPrescriptionDetailAction(rxId: string): Promise<ActionState> {
  try {
    const actor = await requireActor('rx.verify');
    const data = await svc.getPrescriptionDetail(actor, rxId);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────── Retur Penjualan ───────────────

export async function createSaleReturnDraftAction(
  rawHeader: unknown,
  items: SaleReturnItemInput[],
): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const result = await svc.createSaleReturnDraft(actor, rawHeader, items);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function postSaleReturnAction(saleReturnId: string, notes?: string): Promise<ActionState> {
  try {
    const actor = await requireActor('sales.create');
    const result = await svc.postSaleReturn(actor, saleReturnId, notes);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────── Faktur Pembelian ───────────────

export async function createPurchaseInvoiceAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.view');
    const result = await svc.createPurchaseInvoice(actor, Object.fromEntries(fd) as Record<string, string>);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function listPurchaseInvoicesAction(params: {
  supplierId?: string;
  status?: string;
  page?: number;
}): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.view');
    const data = await svc.listPurchaseInvoices(actor, params);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

export async function getPurchaseInvoiceDetailAction(invoiceId: string): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.view');
    const data = await svc.getPurchaseInvoiceDetail(actor, invoiceId);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────── Pembayaran ke Pemasok ───────────────

export async function recordSupplierPaymentAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor('finance.payable.pay');
    const result = await svc.recordSupplierPayment(actor, Object.fromEntries(fd) as Record<string, string>);
    return { ok: true, data: result, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}
