import { z } from 'zod';
import { checkbox, intField, money, optionalId, optionalInt, optionalMoney, optionalText, requiredId, text } from '../../lib/forms';

export const PRODUCT_TYPES = ['PRESCRIPTION_DRUG', 'OTC', 'LIMITED_OTC', 'MEDICAL_DEVICE', 'SUPPLEMENT', 'VITAMIN', 'MEDICAL_SUPPLY', 'OTHER'] as const;
export const DRUG_CLASSES = ['BEBAS', 'BEBAS_TERBATAS', 'KERAS', 'NARKOTIKA', 'PSIKOTROPIKA', 'NON_OBAT'] as const;

export type ProductTypeCode = (typeof PRODUCT_TYPES)[number];
export type DrugClassCode = (typeof DRUG_CLASSES)[number];

export const PRODUCT_TYPE_LABELS: Record<ProductTypeCode, string> = {
  PRESCRIPTION_DRUG: 'Obat resep',
  OTC: 'Obat bebas (OTC)',
  LIMITED_OTC: 'Obat bebas terbatas',
  MEDICAL_DEVICE: 'Alat kesehatan',
  SUPPLEMENT: 'Suplemen',
  VITAMIN: 'Vitamin',
  MEDICAL_SUPPLY: 'Bahan medis habis pakai',
  OTHER: 'Produk lain',
};

export const DRUG_CLASS_LABELS: Record<DrugClassCode, string> = {
  BEBAS: 'Obat bebas',
  BEBAS_TERBATAS: 'Obat bebas terbatas',
  KERAS: 'Obat keras',
  NARKOTIKA: 'Narkotika',
  PSIKOTROPIKA: 'Psikotropika',
  NON_OBAT: 'Bukan obat',
};

export const medicineSchema = z.object({
  sku: z
    .string()
    .trim()
    .max(50, 'SKU maksimal 50 karakter.')
    .optional()
    .transform((v) => (v ? v.toUpperCase() : null))
    .refine((v) => v === null || /^[A-Z0-9._-]+$/.test(v), 'SKU hanya huruf, angka, titik, minus, garis bawah.'),
  barcode: optionalText(64, 'Barcode').refine((v) => v === null || /^[0-9A-Za-z-]{4,64}$/.test(v), 'Barcode hanya huruf, angka, dan minus (4–64 karakter).'),
  name: text(200, 'Nama obat'),
  generic_name: optionalText(200, 'Nama generik'),
  brand: optionalText(100, 'Merek'),
  category_id: optionalId,
  product_type: z.enum(PRODUCT_TYPES, { message: 'Jenis produk wajib dipilih.' }),
  drug_class: z.enum(DRUG_CLASSES, { message: 'Golongan wajib dipilih.' }),
  dosage_form: optionalText(50, 'Bentuk sediaan'),
  strength: optionalText(50, 'Kekuatan'),
  manufacturer_id: optionalId,
  registration_no: optionalText(50, 'Nomor izin edar'),
  base_unit_id: requiredId('Satuan dasar'),
  purchase_unit_id: requiredId('Satuan beli'),
  sales_unit_id: requiredId('Satuan jual'),
  default_purchase_price: optionalMoney('Harga beli'),
  selling_price: optionalMoney('Harga jual'),
  min_stock: intField('Stok minimum'),
  max_stock: optionalInt('Stok maksimum'),
  storage_location_id: optionalId,
  requires_prescription: checkbox,
  is_owa: checkbox,
  is_precursor: checkbox,
  is_oot: checkbox,
  is_lasa: checkbox,
  is_high_alert: checkbox,
  price_reason: optionalText(200, 'Alasan perubahan harga'),
});

export type MedicineInput = z.infer<typeof medicineSchema>;

export const conversionSchema = z.object({
  unit_id: requiredId('Satuan'),
  factor_to_base: intField('Isi per satuan', 2, 100_000),
  barcode: optionalText(64, 'Barcode').refine((v) => v === null || /^[0-9A-Za-z-]{4,64}$/.test(v), 'Barcode hanya huruf, angka, dan minus (4–64 karakter).'),
  selling_price: optionalMoney('Harga jual satuan'),
  price_reason: optionalText(200, 'Alasan perubahan harga'),
});

export type ConversionInput = z.infer<typeof conversionSchema>;

/** String kosong dari form (mis. "Semua golongan") diperlakukan sebagai tidak diisi. */
const emptyToUndefined = (v: unknown) => (v === '' ? undefined : v);

export const medicineFilterSchema = z.object({
  q: z.string().trim().max(100).optional().default(''),
  status: z.preprocess(emptyToUndefined, z.enum(['aktif', 'nonaktif', 'semua']).optional().default('aktif')),
  golongan: z.preprocess(emptyToUndefined, z.enum(DRUG_CLASSES).optional()),
  page: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(10_000).optional().default(1)),
});

export type MedicineFilter = z.infer<typeof medicineFilterSchema>;

export { money };
