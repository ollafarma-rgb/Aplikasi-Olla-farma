import type { DrugClassCode, MedicineInput, ProductTypeCode } from './schemas';

/**
 * Aturan regulasi dan konsistensi data obat. Sama dengan CHECK constraint di
 * migrasi 002, ditulis ulang di sini agar pengguna mendapat pesan per field
 * sebelum menyentuh database. Database tetap penjaga terakhir.
 */

const RX_CLASSES: readonly DrugClassCode[] = ['KERAS', 'NARKOTIKA', 'PSIKOTROPIKA'];

const TYPE_CLASS: Partial<Record<ProductTypeCode, readonly DrugClassCode[]>> = {
  PRESCRIPTION_DRUG: RX_CLASSES,
  OTC: ['BEBAS'],
  LIMITED_OTC: ['BEBAS_TERBATAS'],
  MEDICAL_DEVICE: ['NON_OBAT'],
  MEDICAL_SUPPLY: ['NON_OBAT'],
};

type RuleInput = Pick<
  MedicineInput,
  'product_type' | 'drug_class' | 'requires_prescription' | 'is_owa' | 'registration_no' |
  'min_stock' | 'max_stock' | 'base_unit_id' | 'purchase_unit_id' | 'sales_unit_id'
>;

export function medicineRuleErrors(input: RuleInput, conversionUnitIds: readonly string[] = []): Record<string, string> {
  const e: Record<string, string> = {};

  const allowed = TYPE_CLASS[input.product_type];
  if (allowed && !allowed.includes(input.drug_class)) {
    e.drug_class = 'Golongan tidak sesuai dengan jenis produk.';
  }
  if ((input.drug_class === 'NARKOTIKA' || input.drug_class === 'PSIKOTROPIKA') && !input.requires_prescription) {
    e.requires_prescription = 'Narkotika dan psikotropika wajib resep.';
  }
  if (input.is_owa && input.drug_class !== 'KERAS') {
    e.is_owa = 'Tanda OWA hanya untuk obat keras.';
  } else if (input.is_owa && input.requires_prescription) {
    e.is_owa = 'Obat OWA tidak ditandai wajib resep.';
  }
  if (input.drug_class === 'KERAS' && !input.requires_prescription && !input.is_owa) {
    e.requires_prescription = 'Obat keras wajib resep, kecuali ditandai OWA.';
  }
  if (input.drug_class !== 'NON_OBAT' && !input.registration_no) {
    e.registration_no = 'Nomor izin edar (NIE) wajib diisi untuk obat.';
  }
  if (input.max_stock !== null && input.max_stock < input.min_stock) {
    e.max_stock = 'Stok maksimum tidak boleh lebih kecil dari stok minimum.';
  }
  const available = new Set([input.base_unit_id, ...conversionUnitIds]);
  if (!available.has(input.purchase_unit_id)) {
    e.purchase_unit_id = 'Satuan beli harus satuan dasar atau sudah ada di daftar konversi.';
  }
  if (!available.has(input.sales_unit_id)) {
    e.sales_unit_id = 'Satuan jual harus satuan dasar atau sudah ada di daftar konversi.';
  }
  return e;
}

/** Field yang hanya boleh diubah pemegang izin medicines.regulatory.manage. */
export const REGULATORY_FIELDS = ['drug_class', 'requires_prescription', 'is_owa', 'is_precursor', 'is_oot'] as const;

/** Obat ini butuh izin regulasi untuk dibuat (golongan berisiko tinggi). */
export function isHighControl(input: Pick<MedicineInput, 'drug_class' | 'is_precursor' | 'is_oot'>): boolean {
  return input.drug_class === 'NARKOTIKA' || input.drug_class === 'PSIKOTROPIKA' || input.is_precursor || input.is_oot;
}

export function formatSku(n: number): string {
  return `OBT-${String(n).padStart(6, '0')}`;
}
