'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { runFormAction } from '@/lib/actions';
import type { ActionState } from '@/lib/forms';
import { createMedicine, removeConversion, saveConversion, setMedicineActive, updateMedicine } from './service';

export async function createMedicineAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  let target = '';
  const state = await runFormAction(fd, 'medicines.manage', async (actor, values) => {
    const r = await createMedicine(values, actor);
    target = `/obat/${r.id}?${r.activeNote ? 'nonaktif=1' : 'baru=1'}`;
  });
  if (!state.ok) return state;
  revalidatePath('/obat');
  redirect(target);
}

export async function updateMedicineAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'medicines.manage', async (actor, values) => {
    await updateMedicine(id, values, actor);
    return 'Data obat tersimpan.';
  });
  if (state.ok) revalidatePath(`/obat/${id}`);
  return state;
}

export async function setMedicineActiveAction(id: string, active: boolean, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'medicines.manage', async (actor) => {
    await setMedicineActive(id, active, actor);
    return active ? 'Obat diaktifkan.' : 'Obat dinonaktifkan dan tidak tampil di kasir.';
  });
  if (state.ok) revalidatePath(`/obat/${id}`);
  return state;
}

export async function saveConversionAction(medicineId: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'medicines.manage', async (actor, values) => {
    await saveConversion(medicineId, values, actor);
    return 'Satuan konversi tersimpan.';
  });
  if (state.ok) revalidatePath(`/obat/${medicineId}`);
  return state;
}

export async function removeConversionAction(medicineId: string, conversionId: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  const state = await runFormAction(fd, 'medicines.manage', async (actor) => {
    await removeConversion(medicineId, conversionId, actor);
    return 'Satuan konversi dihapus.';
  });
  if (state.ok) revalidatePath(`/obat/${medicineId}`);
  return state;
}
