import 'server-only';
import { assertCan, auditMeta, can, type Actor } from '../../lib/auth/actor';
import { writeAudit, diffFields } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import { nextNumber, setActor } from '../../lib/database/context';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import type { Prisma } from '@/generated/prisma/client';
import { formatSku, isHighControl, medicineRuleErrors, REGULATORY_FIELDS } from './rules';
import { conversionSchema, medicineFilterSchema, medicineSchema, type MedicineInput } from './schemas';
import { normalizeMoney, parseOrThrow } from '../../lib/validation';

export const PAGE_SIZE = 20;

const parse = parseOrThrow;

function assertRules(input: MedicineInput, conversionUnitIds: string[]) {
  const errors = medicineRuleErrors(input, conversionUnitIds);
  if (Object.keys(errors).length) throw new AppError('VALIDATION_ERROR', undefined, errors);
}

/** Field yang dibandingkan untuk audit dan pemeriksaan izin. */
function snapshot(m: Record<string, unknown>) {
  const keys = [
    'sku', 'barcode', 'name', 'generic_name', 'brand', 'category_id', 'product_type', 'drug_class', 'dosage_form',
    'strength', 'manufacturer_id', 'registration_no', 'base_unit_id', 'purchase_unit_id', 'sales_unit_id',
    'default_purchase_price', 'selling_price', 'min_stock', 'max_stock', 'storage_location_id',
    'requires_prescription', 'is_owa', 'is_precursor', 'is_oot', 'is_lasa', 'is_high_alert',
  ];
  const money = new Set(['default_purchase_price', 'selling_price']);
  return Object.fromEntries(keys.map((k) => [k, money.has(k) ? normalizeMoney(m[k]) : m[k] === undefined ? null : m[k]]));
}

export async function listMedicines(rawFilter: unknown, actor: Actor) {
  assertCan(actor, 'medicines.view');
  const f = parse(medicineFilterSchema, rawFilter);
  const where: Prisma.MedicineWhereInput = {
    ...(f.status === 'aktif' ? { is_active: true } : f.status === 'nonaktif' ? { is_active: false } : {}),
    ...(f.golongan ? { drug_class: f.golongan } : {}),
    ...(f.q
      ? {
          OR: [
            { name: { contains: f.q, mode: 'insensitive' } },
            { generic_name: { contains: f.q, mode: 'insensitive' } },
            { brand: { contains: f.q, mode: 'insensitive' } },
            { sku: { equals: f.q.toUpperCase() } },
            { barcode: { equals: f.q } },
            { conversions: { some: { barcode: { equals: f.q } } } },
          ],
        }
      : {}),
  };
  const [total, rows] = await Promise.all([
    prisma.medicine.count({ where }),
    prisma.medicine.findMany({
      where,
      orderBy: [{ name: 'asc' }, { id: 'asc' }],
      skip: (f.page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
      select: {
        id: true, sku: true, barcode: true, name: true, generic_name: true, brand: true,
        drug_class: true, requires_prescription: true, is_owa: true, is_active: true, is_lasa: true, is_high_alert: true,
        selling_price: true, min_stock: true,
        base_unit: { select: { code: true } },
        category: { select: { name: true } },
      },
    }),
  ]);
  const showCost = can(actor, 'medicines.view_cost');
  return {
    filter: f,
    total,
    pages: Math.max(1, Math.ceil(total / PAGE_SIZE)),
    items: rows.map((r) => ({ ...r, selling_price: r.selling_price.toString() })),
    showCost,
  };
}

export async function getMedicine(id: string, actor: Actor) {
  assertCan(actor, 'medicines.view');
  const m = await prisma.medicine.findUnique({
    where: { id },
    include: {
      base_unit: true, purchase_unit: true, sales_unit: true, category: true, manufacturer: true, storage_location: true,
      conversions: { include: { unit: true }, orderBy: { factor_to_base: 'asc' } },
      price_history: { include: { unit: true, changer: { select: { full_name: true } } }, orderBy: { changed_at: 'desc' }, take: 20 },
    },
  });
  if (!m) throw new AppError('NOT_FOUND');
  const showCost = can(actor, 'medicines.view_cost');
  return {
    ...m,
    selling_price: m.selling_price.toString(),
    default_purchase_price: showCost ? (m.default_purchase_price?.toString() ?? null) : null,
    conversions: m.conversions.map((c) => ({ ...c, selling_price: c.selling_price?.toString() ?? null })),
    price_history: m.price_history
      .filter((h) => showCost || h.price_type !== 'PURCHASE_DEFAULT')
      .map((h) => ({ ...h, id: h.id.toString(), old_price: h.old_price?.toString() ?? null, new_price: h.new_price?.toString() ?? null })),
    showCost,
  };
}

export async function createMedicine(raw: unknown, actor: Actor): Promise<{ id: string; activeNote: string | null }> {
  assertCan(actor, 'medicines.manage');
  const input = parse(medicineSchema, raw);
  assertRules(input, []);
  if (isHighControl(input)) {
    assertCan(actor, 'medicines.regulatory.manage', 'Obat narkotika, psikotropika, prekursor, atau OOT hanya bisa didaftarkan apoteker.');
  }
  const canPrice = can(actor, 'medicines.price.manage');
  const hasPrice = canPrice && input.selling_price !== null;

  return withDbErrors(() =>
    withTransaction(async (tx) => {
      await setActor(tx, actor.id, input.price_reason ?? 'Harga awal');
      const sku = input.sku ?? formatSku(await nextNumber(tx, 'SKU', 'ALL'));
      const created = await tx.medicine.create({
        data: {
          sku,
          barcode: input.barcode,
          name: input.name,
          generic_name: input.generic_name,
          brand: input.brand,
          category_id: input.category_id,
          product_type: input.product_type,
          drug_class: input.drug_class,
          dosage_form: input.dosage_form,
          strength: input.strength,
          manufacturer_id: input.manufacturer_id,
          registration_no: input.registration_no,
          base_unit_id: input.base_unit_id,
          purchase_unit_id: input.purchase_unit_id,
          sales_unit_id: input.sales_unit_id,
          default_purchase_price: canPrice ? input.default_purchase_price : null,
          selling_price: hasPrice ? input.selling_price! : '0',
          min_stock: input.min_stock,
          max_stock: input.max_stock,
          storage_location_id: input.storage_location_id,
          requires_prescription: input.requires_prescription,
          is_owa: input.is_owa,
          is_precursor: input.is_precursor,
          is_oot: input.is_oot,
          is_lasa: input.is_lasa,
          is_high_alert: input.is_high_alert,
          // Obat tanpa harga jual belum boleh tampil di kasir.
          is_active: hasPrice,
        },
      });
      await writeAudit(tx, { ...auditMeta(actor), action: 'medicine.created', entity: 'medicine', entity_id: created.id, after: snapshot(created) });
      return {
        id: created.id,
        activeNote: hasPrice ? null : 'Obat disimpan sebagai NONAKTIF karena belum ada harga jual. Apoteker/Pemilik perlu mengisi harga lalu mengaktifkannya.',
      };
    }),
  );
}

export async function updateMedicine(id: string, raw: unknown, actor: Actor): Promise<void> {
  assertCan(actor, 'medicines.manage');
  const input = parse(medicineSchema, raw);

  await withDbErrors(() =>
    withTransaction(async (tx) => {
      const current = await tx.medicine.findUnique({ where: { id }, include: { conversions: { select: { unit_id: true } } } });
      if (!current) throw new AppError('NOT_FOUND');
      assertRules(input, current.conversions.map((c) => c.unit_id));

      const canPrice = can(actor, 'medicines.price.manage');
      const next = {
        sku: input.sku ?? current.sku,
        barcode: input.barcode,
        name: input.name,
        generic_name: input.generic_name,
        brand: input.brand,
        category_id: input.category_id,
        product_type: input.product_type,
        drug_class: input.drug_class,
        dosage_form: input.dosage_form,
        strength: input.strength,
        manufacturer_id: input.manufacturer_id,
        registration_no: input.registration_no,
        base_unit_id: input.base_unit_id,
        purchase_unit_id: input.purchase_unit_id,
        sales_unit_id: input.sales_unit_id,
        // Tanpa izin harga, harga lama dipertahankan apa pun isi form.
        default_purchase_price: canPrice ? input.default_purchase_price : current.default_purchase_price,
        selling_price: canPrice && input.selling_price !== null ? input.selling_price : current.selling_price,
        min_stock: input.min_stock,
        max_stock: input.max_stock,
        storage_location_id: input.storage_location_id,
        requires_prescription: input.requires_prescription,
        is_owa: input.is_owa,
        is_precursor: input.is_precursor,
        is_oot: input.is_oot,
        is_lasa: input.is_lasa,
        is_high_alert: input.is_high_alert,
      };

      const diff = diffFields(snapshot(current), snapshot(next));
      if (!diff) return;
      const changed = Object.keys(diff.after);
      if (changed.some((k) => (REGULATORY_FIELDS as readonly string[]).includes(k))) {
        assertCan(actor, 'medicines.regulatory.manage', 'Golongan dan tanda regulasi hanya bisa diubah apoteker.');
      }
      if (changed.includes('base_unit_id')) {
        // Mengganti satuan dasar mengubah arti seluruh angka stok. Dikunci mulai Fase 4.
        if (current.conversions.length) {
          throw new AppError('VALIDATION_ERROR', undefined, { base_unit_id: 'Hapus dulu semua konversi sebelum mengganti satuan dasar.' });
        }
      }
      if ((changed.includes('selling_price') || changed.includes('default_purchase_price')) && !input.price_reason) {
        throw new AppError('VALIDATION_ERROR', undefined, { price_reason: 'Isi alasan perubahan harga.' });
      }

      await setActor(tx, actor.id, input.price_reason);
      await tx.medicine.update({ where: { id }, data: next });
      await writeAudit(tx, { ...auditMeta(actor), action: 'medicine.updated', entity: 'medicine', entity_id: id, ...diff });
    }),
  );
}

export async function setMedicineActive(id: string, active: boolean, actor: Actor): Promise<void> {
  assertCan(actor, 'medicines.manage');
  await withTransaction(async (tx) => {
    const m = await tx.medicine.findUnique({ where: { id }, select: { is_active: true, selling_price: true } });
    if (!m) throw new AppError('NOT_FOUND');
    if (m.is_active === active) return;
    if (active && m.selling_price.lte(0)) {
      throw new AppError('VALIDATION_ERROR', 'Isi harga jual lebih dulu sebelum mengaktifkan obat.');
    }
    await tx.medicine.update({ where: { id }, data: { is_active: active } });
    await writeAudit(tx, { ...auditMeta(actor), action: active ? 'medicine.activated' : 'medicine.deactivated', entity: 'medicine', entity_id: id });
  });
}

export async function saveConversion(medicineId: string, raw: unknown, actor: Actor): Promise<void> {
  assertCan(actor, 'medicines.manage');
  const input = parse(conversionSchema, raw);
  const canPrice = can(actor, 'medicines.price.manage');
  await withDbErrors(() =>
    withTransaction(async (tx) => {
      const existing = await tx.medicineUnitConversion.findUnique({ where: { medicine_id_unit_id: { medicine_id: medicineId, unit_id: input.unit_id } } });
      const price = canPrice ? input.selling_price : (existing?.selling_price ?? null);
      if (existing && canPrice && normalizeMoney(existing.selling_price) !== normalizeMoney(input.selling_price) && !input.price_reason) {
        throw new AppError('VALIDATION_ERROR', undefined, { price_reason: 'Isi alasan perubahan harga.' });
      }
      await setActor(tx, actor.id, input.price_reason ?? (existing ? null : 'Harga awal satuan'));
      const saved = await tx.medicineUnitConversion.upsert({
        where: { medicine_id_unit_id: { medicine_id: medicineId, unit_id: input.unit_id } },
        create: { medicine_id: medicineId, unit_id: input.unit_id, factor_to_base: input.factor_to_base, barcode: input.barcode, selling_price: price },
        update: { factor_to_base: input.factor_to_base, barcode: input.barcode, selling_price: price },
      });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'medicine.conversion.saved', entity: 'medicine', entity_id: medicineId,
        before: existing ? { unit_id: existing.unit_id, factor_to_base: existing.factor_to_base, barcode: existing.barcode, selling_price: existing.selling_price?.toString() ?? null } : null,
        after: { unit_id: saved.unit_id, factor_to_base: saved.factor_to_base, barcode: saved.barcode, selling_price: saved.selling_price?.toString() ?? null },
      });
    }),
  );
}

export async function removeConversion(medicineId: string, conversionId: string, actor: Actor): Promise<void> {
  assertCan(actor, 'medicines.manage');
  await withDbErrors(() =>
    withTransaction(async (tx) => {
      const c = await tx.medicineUnitConversion.findFirst({ where: { id: conversionId, medicine_id: medicineId } });
      if (!c) throw new AppError('NOT_FOUND');
      const m = await tx.medicine.findUniqueOrThrow({ where: { id: medicineId }, select: { purchase_unit_id: true, sales_unit_id: true } });
      if (m.purchase_unit_id === c.unit_id || m.sales_unit_id === c.unit_id) {
        throw new AppError('VALIDATION_ERROR', 'Satuan ini sedang dipakai sebagai satuan beli atau jual. Ganti dulu di data obat.');
      }
      await setActor(tx, actor.id, 'Konversi satuan dihapus');
      await tx.medicineUnitConversion.delete({ where: { id: conversionId } });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'medicine.conversion.removed', entity: 'medicine', entity_id: medicineId,
        before: { unit_id: c.unit_id, factor_to_base: c.factor_to_base, barcode: c.barcode },
      });
    }),
  );
}
