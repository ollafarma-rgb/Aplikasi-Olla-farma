import 'server-only';
import { Prisma } from '@/generated/prisma/client';
import { assertCan, type Actor } from '../../lib/auth/actor';
import { prisma } from '../../lib/database/client';

const JKT = 'Asia/Jakarta';

/** Awal hari ini dalam WIB (Asia/Jakarta) sebagai UTC Date */
function todayStartJkt(): Date {
  const now = new Date();
  const jkt = new Intl.DateTimeFormat('en-CA', { timeZone: JKT, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
  return new Date(`${jkt}T00:00:00+07:00`);
}

/** N hari lalu dari awal hari ini */
function daysAgoStart(n: number): Date {
  const d = todayStartJkt();
  d.setDate(d.getDate() - n);
  return d;
}

export interface DashboardKpi {
  salesToday: number;         // total penjualan hari ini (IDR)
  salesCount: number;         // jumlah transaksi hari ini
  stockCritical: number;      // jumlah SKU di bawah min_stock
  expiryWarning: number;      // jumlah batch ED < 30 hari
  receivableOpen: number;     // total piutang belum lunas (IDR)
  receivableCount: number;    // jumlah piutang terbuka
}

export interface SalesChartPoint {
  date: string;      // 'YYYY-MM-DD' WIB
  total: number;     // IDR
  count: number;
}

export async function getDashboardKpi(actor: Actor): Promise<DashboardKpi> {
  assertCan(actor, 'dashboard.operational.view');

  const todayStart = todayStartJkt();
  const tomorrowStart = new Date(todayStart);
  tomorrowStart.setDate(tomorrowStart.getDate() + 1);

  const [salesAgg, stockCritical, expiryWarning, receivableAgg] = await Promise.all([
    // Penjualan hari ini
    prisma.sale.aggregate({
      where: {
        sold_at: { gte: todayStart, lt: tomorrowStart },
        status: { not: 'CANCELLED' },
      },
      _sum: { total_amount: true },
      _count: { id: true },
    }),
    // Stok kritis: total stok (sum batch saleable) < min_stock
    prisma.$queryRaw<{ count: bigint }[]>`
      SELECT COUNT(*) AS count
      FROM medicines m
      WHERE m.is_active = true
        AND m.min_stock > 0
        AND (
          SELECT COALESCE(SUM(b.qty_saleable), 0)
          FROM medicine_batches b
          WHERE b.medicine_id = m.id
        ) < m.min_stock
    `,
    // Obat mendekati ED (< 30 hari ke depan, qty > 0)
    prisma.medicineBatch.count({
      where: {
        expiry_date: {
          lte: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          gte: new Date(),
        },
        qty_saleable: { gt: 0 },
      },
    }),
    // Piutang terbuka
    prisma.customerReceivable.aggregate({
      where: { status: { in: ['OPEN', 'PARTIAL'] } },
      _sum: { amount: true, paid_amount: true },
      _count: { id: true },
    }),
  ]);

  const receivableTotal = Number(receivableAgg._sum.amount ?? 0);
  const receivablePaid = Number(receivableAgg._sum.paid_amount ?? 0);

  return {
    salesToday: Number(salesAgg._sum.total_amount ?? 0),
    salesCount: salesAgg._count.id,
    stockCritical: Number((stockCritical[0]?.count ?? 0n)),
    expiryWarning,
    receivableOpen: receivableTotal - receivablePaid,
    receivableCount: receivableAgg._count.id,
  };
}

export async function getSalesChart(actor: Actor, days = 7): Promise<SalesChartPoint[]> {
  assertCan(actor, 'dashboard.operational.view');

  const startDate = daysAgoStart(days - 1);

  const rows = await prisma.$queryRaw<{ date_jkt: string; total: Prisma.Decimal; count: bigint }[]>`
    SELECT
      TO_CHAR(sold_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD') AS date_jkt,
      SUM(grand_total) AS total,
      COUNT(*) AS count
    FROM sales
    WHERE sold_at >= ${startDate}
      AND status != 'CANCELLED'
    GROUP BY date_jkt
    ORDER BY date_jkt ASC
  `;

  // Isi hari-hari yang tidak ada transaksi dengan 0
  const map = new Map(rows.map(r => [r.date_jkt, { total: Number(r.total), count: Number(r.count) }]));
  const result: SalesChartPoint[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = daysAgoStart(i);
    const key = d.toLocaleDateString('en-CA', { timeZone: JKT });
    result.push({ date: key, total: map.get(key)?.total ?? 0, count: map.get(key)?.count ?? 0 });
  }
  return result;
}

// ─── Laporan ─────────────────────────────────────────────────────────────────

export interface SalesReportRow {
  date: string;
  count: number;
  gross: number;
  discount: number;
  net: number;
}

export async function getSalesReport(
  actor: Actor,
  params: { from: Date; to: Date },
): Promise<{ rows: SalesReportRow[]; totals: { count: number; gross: number; discount: number; net: number } }> {
  assertCan(actor, 'reports.operational.view');

  const rows = await prisma.$queryRaw<{
    date_jkt: string;
    count: bigint;
    gross: Prisma.Decimal;
    discount: Prisma.Decimal;
    net: Prisma.Decimal;
  }[]>`
    SELECT
      TO_CHAR(sold_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD') AS date_jkt,
      COUNT(*)               AS count,
      SUM(subtotal)          AS gross,
      SUM(discount_amount)   AS discount,
      SUM(total_amount)      AS net
    FROM sales
    WHERE sold_at >= ${params.from}
      AND sold_at <  ${params.to}
      AND status != 'CANCELLED'
    GROUP BY date_jkt
    ORDER BY date_jkt ASC
  `;

  const mapped: SalesReportRow[] = rows.map(r => ({
    date: r.date_jkt,
    count: Number(r.count),
    gross: Number(r.gross),
    discount: Number(r.discount),
    net: Number(r.net),
  }));

  const totals = mapped.reduce(
    (acc, r) => ({
      count: acc.count + r.count,
      gross: acc.gross + r.gross,
      discount: acc.discount + r.discount,
      net: acc.net + r.net,
    }),
    { count: 0, gross: 0, discount: 0, net: 0 },
  );

  return { rows: mapped, totals };
}

export interface StockReportRow {
  sku: string;
  name: string;
  category: string;
  unit: string;
  qty_saleable: number;
  min_stock: number;
  hpp: number;        // HPP rata-rata (dari batch aktif)
  total_value: number;
  status: 'OK' | 'KRITIS' | 'HABIS';
}

export async function getStockReport(actor: Actor): Promise<StockReportRow[]> {
  assertCan(actor, 'reports.inventory.view');

  const rows = await prisma.$queryRaw<{
    sku: string;
    name: string;
    category: string | null;
    unit: string;
    qty_saleable: Prisma.Decimal;
    min_stock: number;
    avg_hpp: Prisma.Decimal | null;
  }[]>`
    SELECT
      m.sku,
      m.name,
      c.name AS category,
      u.name AS unit,
      COALESCE(SUM(b.qty_saleable), 0) AS qty_saleable,
      m.min_stock,
      AVG(b.cost_per_unit) FILTER (WHERE b.qty_saleable > 0) AS avg_hpp
    FROM medicines m
    LEFT JOIN categories c ON c.id = m.category_id
    JOIN units u ON u.id = m.base_unit_id
    LEFT JOIN medicine_batches b ON b.medicine_id = m.id
    WHERE m.is_active = true
    GROUP BY m.id, m.sku, m.name, c.name, u.name, m.min_stock
    ORDER BY m.name ASC
  `;

  return rows.map(r => {
    const qty = Number(r.qty_saleable);
    const hpp = Number(r.avg_hpp ?? 0);
    const status: StockReportRow['status'] =
      qty === 0 ? 'HABIS' : qty < r.min_stock ? 'KRITIS' : 'OK';
    return {
      sku: r.sku,
      name: r.name,
      category: r.category ?? '-',
      unit: r.unit,
      qty_saleable: qty,
      min_stock: r.min_stock,
      hpp,
      total_value: qty * hpp,
      status,
    };
  });
}
