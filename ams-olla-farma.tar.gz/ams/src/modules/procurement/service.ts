import 'server-only';
import { Prisma } from '@/generated/prisma/client';
import { assertCan, auditMeta, can, type Actor } from '../../lib/auth/actor';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import type { DbTransaction } from '../../lib/database/client';
import { nextNumber, setActor } from '../../lib/database/context';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import { parseOrThrow } from '../../lib/validation';
import type { StockBucket } from '../inventory/schemas';
import {
  grHeaderSchema, poHeaderSchema, procurementFilterSchema, returnHeaderSchema,
  PO_SPECIAL_TYPES, type GrItemInput, type PoItemInput, type PoType, type ReturnItemInput,
} from './schemas';

export const PAGE_SIZE = 20;

// -- Util ------------------------------------------------------------------------
function periodYYMM(): string {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));
  return `${String(now.getFullYear()).slice(2)}${String(now.getMonth() + 1).padStart(2, '0')}`;
}
function formatDocNo(prefix: string, period: string, n: number): string {
  return `${prefix}-${period}-${String(n).padStart(4, '0')}`;
}

async function applyMovement(tx: DbTransaction, p: {
  batchId: string; type: 'RECEIPT' | 'PURCHASE_RETURN'; from: StockBucket | null; to: StockBucket | null;
  qty: number; unitCost: string; refType: string; refId: string; refNo: string; reason: string | null; approvalId: string | null;
}): Promise<void> {
  await tx.$queryRaw`SELECT ams_apply_stock_movement(
    ${p.batchId}::uuid, ${p.type}::"MovementType",
    ${p.from}::"StockBucket", ${p.to}::"StockBucket",
    ${p.qty}::int, ${p.unitCost}::numeric,
    ${p.refType}, ${p.refId}::uuid, ${p.refNo}, ${p.reason}, ${null}::date, ${p.approvalId}::uuid)`;
}

/** Faktor konversi satuan -> satuan dasar untuk sebuah obat. */
async function unitFactorToBase(tx: DbTransaction, medicineId: string, unitId: string): Promise<number> {
  const med = await tx.medicine.findUnique({ where: { id: medicineId }, select: { base_unit_id: true } });
  if (!med) throw new AppError('VALIDATION_ERROR', undefined, { medicine_id: 'Obat tidak ditemukan.' });
  if (med.base_unit_id === unitId) return 1;
  const conv = await tx.medicineUnitConversion.findUnique({ where: { medicine_id_unit_id: { medicine_id: medicineId, unit_id: unitId } } });
  if (!conv) throw new AppError('VALIDATION_ERROR', 'Satuan ini belum punya konversi untuk obat tersebut.');
  return conv.factor_to_base;
}

function requireSpecialPermission(actor: Actor, type: PoType, action: 'create' | 'send') {
  if (PO_SPECIAL_TYPES.includes(type)) {
    if (!can(actor, 'procurement.po_special.sign')) {
      throw new AppError('FORBIDDEN', 'SP narkotika/psikotropika/prekursor/OOT wajib dibuat dan ditandatangani apoteker (APA).');
    }
    return;
  }
  const code = action === 'create' ? 'procurement.po.create' : 'procurement.po.approve';
  assertCan(actor, code);
}

// -- Opsi untuk form -------------------------------------------------------------
export async function listSupplierOptions(actor: Actor) {
  assertCan(actor, 'suppliers.view');
  const rows = await prisma.supplier.findMany({
    where: { status: 'ACTIVE' }, select: { id: true, name: true, code: true }, orderBy: { name: 'asc' }, take: 1000,
  });
  return rows.map((s) => ({ id: s.id, label: `${s.name} (${s.code})` }));
}

export async function listMedicinesForPurchase(actor: Actor) {
  assertCan(actor, 'procurement.view');
  const rows = await prisma.medicine.findMany({
    where: { is_active: true },
    select: { id: true, name: true, sku: true, purchase_unit: { select: { id: true, code: true } }, default_purchase_price: true },
    orderBy: { name: 'asc' }, take: 2000,
  });
  return rows.map((m) => ({
    id: m.id, label: `${m.name} (${m.sku})`, unitId: m.purchase_unit.id, unitCode: m.purchase_unit.code,
    defaultPrice: m.default_purchase_price ? m.default_purchase_price.toString() : '',
  }));
}

export async function listReceivablePurchaseOrders(actor: Actor) {
  assertCan(actor, 'procurement.receive.record');
  const rows = await prisma.purchaseOrder.findMany({
    where: { status: { in: ['SENT', 'PARTIAL'] } },
    select: { id: true, po_no: true, supplier: { select: { name: true } } },
    orderBy: { created_at: 'desc' }, take: 200,
  });
  return rows.map((p) => ({ id: p.id, label: `${p.po_no} · ${p.supplier.name}` }));
}

// -- Surat Pesanan -----------------------------------------------------------------
export async function createPurchaseOrder(actor: Actor, header: Record<string, string>, items: PoItemInput[]) {
  const h = parseOrThrow(poHeaderSchema, header);
  requireSpecialPermission(actor, h.order_type, 'create');
  const clean = items.filter((i) => i.medicine_id && i.qty_ordered > 0);
  if (!clean.length) throw new AppError('VALIDATION_ERROR', 'Tambahkan minimal satu baris obat dengan jumlah lebih dari 0.');
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      await setActor(tx, actor.id, 'Buat Surat Pesanan');
      const period = periodYYMM();
      const poNo = formatDocNo('SP', period, await nextNumber(tx, 'SP', period));
      const po = await tx.purchaseOrder.create({
        data: {
          po_no: poNo, supplier_id: h.supplier_id, order_type: h.order_type,
          expected_date: h.expected_date ? new Date(h.expected_date) : null, notes: h.notes, created_by: actor.id,
          items: {
            create: clean.map((i) => ({
              medicine_id: i.medicine_id, unit_id: i.unit_id, qty_ordered: i.qty_ordered,
              price: i.price, discount_pct: i.discount_pct || '0',
            })),
          },
        },
      });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'procurement.po_created', entity: 'purchase_order', entity_id: po.id,
        after: { po_no: poNo, order_type: h.order_type, items: clean.length },
      });
      return { id: po.id, poNo };
    }),
  );
}

export async function sendPurchaseOrder(actor: Actor, id: string) {
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const po = await tx.purchaseOrder.findUnique({ where: { id } });
      if (!po) throw new AppError('NOT_FOUND');
      if (po.status !== 'DRAFT') throw new AppError('INVALID_STATE_TRANSITION', 'Hanya SP draf yang bisa dikirim.');
      requireSpecialPermission(actor, po.order_type, 'send');
      await setActor(tx, actor.id, 'Kirim Surat Pesanan');
      await tx.purchaseOrder.update({ where: { id }, data: { status: 'SENT', signed_by: actor.id, signed_at: new Date() } });
      await writeAudit(tx, { ...auditMeta(actor), action: 'procurement.po_sent', entity: 'purchase_order', entity_id: id, after: { po_no: po.po_no } });
      return { id, poNo: po.po_no };
    }),
  );
}

export async function cancelPurchaseOrder(actor: Actor, id: string) {
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const po = await tx.purchaseOrder.findUnique({ where: { id } });
      if (!po) throw new AppError('NOT_FOUND');
      if (po.status === 'DRAFT') {
        assertCan(actor, 'procurement.po.create');
      } else if (po.status === 'SENT') {
        assertCan(actor, 'procurement.po.approve');
      } else {
        throw new AppError('INVALID_STATE_TRANSITION', 'SP yang sudah ada penerimaan tidak bisa dibatalkan.');
      }
      await setActor(tx, actor.id, 'Batalkan Surat Pesanan');
      await tx.purchaseOrder.update({ where: { id }, data: { status: 'CANCELLED', cancelled_at: new Date() } });
      await writeAudit(tx, { ...auditMeta(actor), action: 'procurement.po_cancelled', entity: 'purchase_order', entity_id: id });
    }),
  );
}

export async function listPurchaseOrders(actor: Actor, raw: Record<string, unknown>) {
  assertCan(actor, 'procurement.view');
  const f = parseOrThrow(procurementFilterSchema, raw);
  const where: Prisma.PurchaseOrderWhereInput = f.q
    ? { OR: [{ po_no: { contains: f.q, mode: 'insensitive' } }, { supplier: { name: { contains: f.q, mode: 'insensitive' } } }] }
    : {};
  const [items, total] = await Promise.all([
    prisma.purchaseOrder.findMany({
      where, orderBy: { created_at: 'desc' }, skip: (f.page - 1) * PAGE_SIZE, take: PAGE_SIZE,
      include: { supplier: { select: { name: true } }, creator: { select: { full_name: true } }, _count: { select: { items: true } } },
    }),
    prisma.purchaseOrder.count({ where }),
  ]);
  return { items, total, page: f.page, pageSize: PAGE_SIZE, q: f.q };
}

export async function getPurchaseOrder(actor: Actor, id: string) {
  assertCan(actor, 'procurement.view');
  const po = await prisma.purchaseOrder.findUnique({
    where: { id },
    include: {
      supplier: true, creator: { select: { full_name: true } }, signer: { select: { full_name: true } },
      items: { include: { medicine: { select: { name: true, sku: true } }, unit: { select: { code: true } } } },
      goods_receipts: { select: { id: true, gr_no: true, status: true, received_at: true } },
    },
  });
  if (!po) throw new AppError('NOT_FOUND');
  return po;
}

// -- Penerimaan Barang ---------------------------------------------------------------
export async function createGoodsReceipt(actor: Actor, headerOrPoId: Record<string, string> | string, items: GrItemInput[]) {
  assertCan(actor, 'procurement.receive.record');
  // Support both: createGoodsReceipt(actor, po_id, items) dan createGoodsReceipt(actor, {po_id,...}, items)
  const rawHeader = typeof headerOrPoId === 'string'
    ? { po_id: headerOrPoId, supplier_do_no: '', received_at: new Date().toISOString().slice(0, 10) }
    : headerOrPoId;
  const h = parseOrThrow(grHeaderSchema, rawHeader);
  const clean = items.filter((i) => i.po_item_id && i.qty > 0);
  if (!clean.length) throw new AppError('VALIDATION_ERROR', 'Tambahkan minimal satu baris dengan jumlah lebih dari 0.');
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const po = await tx.purchaseOrder.findUnique({ where: { id: h.po_id }, include: { items: true } });
      if (!po) throw new AppError('VALIDATION_ERROR', undefined, { po_id: 'Surat Pesanan tidak ditemukan.' });
      if (po.status !== 'SENT' && po.status !== 'PARTIAL') {
        throw new AppError('INVALID_STATE_TRANSITION', 'Penerimaan hanya untuk SP yang sudah terkirim.');
      }
      const poItemIds = new Set(po.items.map((i) => i.id));
      for (const it of clean) {
        if (!poItemIds.has(it.po_item_id)) throw new AppError('VALIDATION_ERROR', 'Baris SP tidak valid.');
      }
      await setActor(tx, actor.id, 'Catat penerimaan barang');
      const period = periodYYMM();
      const grNo = formatDocNo('GR', period, await nextNumber(tx, 'GR', period));
      const poItemById = new Map(po.items.map((i) => [i.id, i]));
      const gr = await tx.goodsReceipt.create({
        data: {
          gr_no: grNo, po_id: po.id, supplier_id: po.supplier_id, supplier_do_no: h.supplier_do_no,
          received_at: new Date(h.received_at), checked_by: actor.id,
          items: {
            create: await Promise.all(clean.map(async (i) => {
              const poItem = poItemById.get(i.po_item_id)!;
              const factor = await unitFactorToBase(tx, poItem.medicine_id, poItem.unit_id);
              return {
                po_item_id: i.po_item_id, medicine_id: poItem.medicine_id, unit_id: poItem.unit_id,
                qty: i.qty, qty_base: i.qty * factor, batch_no: i.batch_no, expiry_date: new Date(i.expiry_date),
                unit_cost: i.unit_cost, condition: i.condition, notes: i.notes,
              };
            })),
          },
        },
      });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'procurement.gr_created', entity: 'goods_receipt', entity_id: gr.id,
        after: { gr_no: grNo, po_no: po.po_no, items: clean.length },
      });
      return { id: gr.id, grNo };
    }),
  );
}

export async function postGoodsReceipt(actor: Actor, id: string) {
  assertCan(actor, 'procurement.receive.post');
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const gr = await tx.goodsReceipt.findUnique({ where: { id }, include: { items: true, po: { include: { items: true } } } });
      if (!gr) throw new AppError('NOT_FOUND');
      if (gr.status !== 'DRAFT') throw new AppError('INVALID_STATE_TRANSITION', 'Penerimaan ini sudah diproses.');
      // Maker-checker: GUDANG/TTK tidak boleh self-post. APOTEKER/OWNER (yang punya
      // procurement.po.approve) diizinkan self-post karena mereka adalah supervisi.
      const canSelfPost = can(actor, 'procurement.po.approve');
      if (gr.checked_by === actor.id && !canSelfPost) throw new AppError('FORBIDDEN', 'Anda tidak boleh memposting penerimaan yang Anda catat sendiri.');

      await setActor(tx, actor.id, 'Posting penerimaan barang');
      const receivedByPoItem = new Map<string, number>();
      for (const it of gr.items) {
        if (it.condition !== 'REJECTED') {
          const bucket: StockBucket = it.condition === 'DAMAGED' ? 'DAMAGED' : 'SALEABLE';
          const batch = await tx.medicineBatch.create({
            data: {
              medicine_id: it.medicine_id, batch_no: it.batch_no, expiry_date: it.expiry_date, source: 'RECEIPT',
              goods_receipt_item_id: it.id, unit_cost: it.unit_cost, qty_received: it.qty_base, updated_at: new Date(),
            },
          });
          await applyMovement(tx, {
            batchId: batch.id, type: 'RECEIPT', from: null, to: bucket, qty: it.qty_base, unitCost: it.unit_cost.toString(),
            refType: 'goods_receipt', refId: gr.id, refNo: gr.gr_no, reason: it.notes, approvalId: null,
          });
          if (it.po_item_id) receivedByPoItem.set(it.po_item_id, (receivedByPoItem.get(it.po_item_id) ?? 0) + it.qty_base);
        }
      }
      for (const [poItemId, addedBase] of receivedByPoItem) {
        await tx.purchaseOrderItem.update({ where: { id: poItemId }, data: { qty_received_base: { increment: addedBase } } });
      }
      await tx.goodsReceipt.update({ where: { id }, data: { status: 'POSTED', posted_by: actor.id, posted_at: new Date() } });

      if (gr.po) {
        const items = await tx.purchaseOrderItem.findMany({ where: { po_id: gr.po.id } });
        const factors = await Promise.all(items.map((i) => unitFactorToBase(tx, i.medicine_id, i.unit_id)));
        const allReceived = items.every((i, idx) => i.qty_received_base >= i.qty_ordered * factors[idx]);
        const anyReceived = items.some((i) => i.qty_received_base > 0);
        await tx.purchaseOrder.update({
          where: { id: gr.po.id },
          data: { status: allReceived ? 'RECEIVED' : anyReceived ? 'PARTIAL' : gr.po.status },
        });
      }
      await writeAudit(tx, { ...auditMeta(actor), action: 'procurement.gr_posted', entity: 'goods_receipt', entity_id: id, after: { gr_no: gr.gr_no } });
      return { id, grNo: gr.gr_no };
    }),
  );
}

export async function cancelGoodsReceipt(actor: Actor, id: string) {
  assertCan(actor, 'procurement.receive.record');
  await withTransaction(async (tx) => {
    const gr = await tx.goodsReceipt.findUnique({ where: { id }, select: { id: true, status: true } });
    if (!gr) throw new AppError('NOT_FOUND');
    if (gr.status !== 'DRAFT') throw new AppError('INVALID_STATE_TRANSITION', 'Hanya draf yang bisa dibatalkan.');
    await tx.goodsReceipt.update({ where: { id }, data: { status: 'CANCELLED' } });
    await writeAudit(tx, { ...auditMeta(actor), action: 'procurement.gr_cancelled', entity: 'goods_receipt', entity_id: id });
  });
}

export async function listGoodsReceipts(actor: Actor, raw: Record<string, unknown>) {
  assertCan(actor, 'procurement.view');
  const f = parseOrThrow(procurementFilterSchema, raw);
  const where: Prisma.GoodsReceiptWhereInput = f.q
    ? { OR: [{ gr_no: { contains: f.q, mode: 'insensitive' } }, { supplier: { name: { contains: f.q, mode: 'insensitive' } } }] }
    : {};
  const [items, total] = await Promise.all([
    prisma.goodsReceipt.findMany({
      where, orderBy: { created_at: 'desc' }, skip: (f.page - 1) * PAGE_SIZE, take: PAGE_SIZE,
      include: { supplier: { select: { name: true } }, checker: { select: { full_name: true } }, _count: { select: { items: true } } },
    }),
    prisma.goodsReceipt.count({ where }),
  ]);
  return { items, total, page: f.page, pageSize: PAGE_SIZE, q: f.q };
}

export async function getGoodsReceipt(actor: Actor, id: string) {
  assertCan(actor, 'procurement.view');
  const gr = await prisma.goodsReceipt.findUnique({
    where: { id },
    include: {
      supplier: true, po: { select: { po_no: true } }, checker: { select: { full_name: true } }, poster: { select: { full_name: true } },
      items: { include: { medicine: { select: { name: true, sku: true } }, unit: { select: { code: true } }, batch: { select: { id: true } } } },
    },
  });
  if (!gr) throw new AppError('NOT_FOUND');
  return gr;
}

// -- Retur Pembelian ------------------------------------------------------------------
export async function createPurchaseReturn(actor: Actor, header: Record<string, string>, items: ReturnItemInput[]) {
  assertCan(actor, 'procurement.return.create');
  const h = parseOrThrow(returnHeaderSchema, header);
  const clean = items.filter((i) => i.batch_id && i.qty > 0 && i.reason.trim());
  if (!clean.length) throw new AppError('VALIDATION_ERROR', 'Tambahkan minimal satu baris batch dengan jumlah dan alasan.');
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      await setActor(tx, actor.id, 'Buat retur pembelian');
      const period = periodYYMM();
      const returnNo = formatDocNo('RB', period, await nextNumber(tx, 'RB', period));
      const batches = await tx.medicineBatch.findMany({ where: { id: { in: clean.map((i) => i.batch_id) } } });
      const batchById = new Map(batches.map((b) => [b.id, b]));
      for (const i of clean) if (!batchById.has(i.batch_id)) throw new AppError('VALIDATION_ERROR', 'Batch tidak ditemukan.');
      const ret = await tx.purchaseReturn.create({
        data: {
          return_no: returnNo, supplier_id: h.supplier_id, notes: h.notes, created_by: actor.id,
          items: {
            create: clean.map((i) => ({
              batch_id: i.batch_id, bucket: i.bucket, qty: i.qty, unit_cost: batchById.get(i.batch_id)!.unit_cost, reason: i.reason,
            })),
          },
        },
      });
      await writeAudit(tx, {
        ...auditMeta(actor), action: 'procurement.return_created', entity: 'purchase_return', entity_id: ret.id,
        after: { return_no: returnNo, items: clean.length },
      });
      return { id: ret.id, returnNo };
    }),
  );
}

export async function approvePurchaseReturn(actor: Actor, id: string) {
  assertCan(actor, 'procurement.return.approve');
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      const ret = await tx.purchaseReturn.findUnique({ where: { id }, include: { items: true } });
      if (!ret) throw new AppError('NOT_FOUND');
      if (ret.status !== 'DRAFT') throw new AppError('INVALID_STATE_TRANSITION', 'Retur ini sudah diproses.');
      if (ret.created_by === actor.id) throw new AppError('FORBIDDEN', 'Anda tidak boleh menyetujui retur yang Anda buat sendiri.');

      await setActor(tx, actor.id, 'Posting retur pembelian');
      const approval = await tx.approval.create({
        data: { action_code: 'procurement.return.approve', requested_by: ret.created_by, approved_by: actor.id, ref_type: 'purchase_return', ref_id: ret.id, reason: ret.notes ?? 'Retur pembelian' },
      });
      for (const it of ret.items) {
        await applyMovement(tx, {
          batchId: it.batch_id, type: 'PURCHASE_RETURN', from: it.bucket, to: null, qty: it.qty, unitCost: it.unit_cost.toString(),
          refType: 'purchase_return', refId: ret.id, refNo: ret.return_no, reason: it.reason, approvalId: approval.id,
        });
      }
      await tx.purchaseReturn.update({ where: { id }, data: { status: 'POSTED', posted_at: new Date(), approval_id: approval.id } });
      await writeAudit(tx, { ...auditMeta(actor), action: 'procurement.return_posted', entity: 'purchase_return', entity_id: id, after: { return_no: ret.return_no } });
      return { id };
    }),
  );
}

export async function cancelPurchaseReturn(actor: Actor, id: string) {
  assertCan(actor, 'procurement.return.create');
  await withTransaction(async (tx) => {
    const ret = await tx.purchaseReturn.findUnique({ where: { id }, select: { id: true, status: true } });
    if (!ret) throw new AppError('NOT_FOUND');
    if (ret.status !== 'DRAFT') throw new AppError('INVALID_STATE_TRANSITION', 'Hanya draf yang bisa dibatalkan.');
    await tx.purchaseReturn.update({ where: { id }, data: { status: 'CANCELLED' } });
    await writeAudit(tx, { ...auditMeta(actor), action: 'procurement.return_cancelled', entity: 'purchase_return', entity_id: id });
  });
}

export async function listPurchaseReturns(actor: Actor, raw: Record<string, unknown>) {
  assertCan(actor, 'procurement.view');
  const f = parseOrThrow(procurementFilterSchema, raw);
  const where: Prisma.PurchaseReturnWhereInput = f.q
    ? { OR: [{ return_no: { contains: f.q, mode: 'insensitive' } }, { supplier: { name: { contains: f.q, mode: 'insensitive' } } }] }
    : {};
  const [items, total] = await Promise.all([
    prisma.purchaseReturn.findMany({
      where, orderBy: { created_at: 'desc' }, skip: (f.page - 1) * PAGE_SIZE, take: PAGE_SIZE,
      include: { supplier: { select: { name: true } }, creator: { select: { full_name: true } }, _count: { select: { items: true } } },
    }),
    prisma.purchaseReturn.count({ where }),
  ]);
  return { items, total, page: f.page, pageSize: PAGE_SIZE, q: f.q };
}

export async function getPurchaseReturn(actor: Actor, id: string) {
  assertCan(actor, 'procurement.view');
  const ret = await prisma.purchaseReturn.findUnique({
    where: { id },
    include: {
      supplier: true, creator: { select: { full_name: true } },
      items: { include: { batch: { include: { medicine: { select: { name: true, sku: true } } } } } },
    },
  });
  if (!ret) throw new AppError('NOT_FOUND');
  return ret;
}

// -- Batch tersedia untuk retur (per pemasok, lewat goods_receipt_item -> gr) ----
export async function listReturnableBatches(actor: Actor, supplierId: string) {
  assertCan(actor, 'procurement.return.create');
  const rows = await prisma.medicineBatch.findMany({
    where: {
      goods_receipt_item: { gr: { supplier_id: supplierId } },
      OR: [{ qty_saleable: { gt: 0 } }, { qty_quarantine: { gt: 0 } }, { qty_damaged: { gt: 0 } }],
    },
    include: { medicine: { select: { name: true, sku: true } } },
    orderBy: { received_at: 'desc' },
    take: 500,
  });
  return rows;
}
