'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { requireActor } from '../../lib/auth/server';
import { translateDbError } from '../../lib/database/errors';
import { AppError } from '../../lib/errors';
import { type ActionState } from '../../lib/forms';
import { fieldErrors } from '../../lib/validation';
import {
  approvePurchaseReturn, cancelGoodsReceipt, cancelPurchaseOrder, cancelPurchaseReturn,
  createGoodsReceipt, createPurchaseOrder, createPurchaseReturn, postGoodsReceipt, sendPurchaseOrder,
} from './service';
import type { PoType, ReceiptCondition } from './schemas';
import { STOCK_BUCKETS, type StockBucket } from '../inventory/schemas';

function fail(error: unknown): ActionState {
  const appErr = error instanceof AppError ? error : translateDbError(error);
  if (appErr instanceof AppError) {
    return { ok: false, code: appErr.code, message: appErr.message ?? 'Tidak dapat menyimpan.', fields: appErr.fields, submittedAt: Date.now() };
  }
  if (error instanceof z.ZodError) return { ok: false, code: 'VALIDATION_ERROR', fields: fieldErrors(error), submittedAt: Date.now() };
  throw error;
}

// -- Surat Pesanan -----------------------------------------------------------------
function parsePoItems(fd: FormData) {
  const ids = String(fd.get('row_ids') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  return ids
    .map((rid) => ({
      medicine_id: String(fd.get(`medicine_${rid}`) ?? ''),
      unit_id: String(fd.get(`unit_${rid}`) ?? ''),
      qty_ordered: Number(String(fd.get(`qty_${rid}`) ?? '0')) || 0,
      price: String(fd.get(`price_${rid}`) ?? '0').replace(/\./g, '').replace(',', '.'),
      discount_pct: String(fd.get(`discount_${rid}`) ?? '0').replace(',', '.'),
    }))
    .filter((i) => i.medicine_id && i.unit_id);
}

export async function createPurchaseOrderAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor();
    const header = {
      supplier_id: String(fd.get('supplier_id') ?? ''), order_type: String(fd.get('order_type') ?? 'REGULER') as PoType,
      expected_date: String(fd.get('expected_date') ?? ''), notes: String(fd.get('notes') ?? ''),
    };
    const r = await createPurchaseOrder(actor, header as unknown as Record<string, string>, parsePoItems(fd));
    revalidatePath('/pengadaan/sp');
    return { ok: true, message: `SP ${r.poNo} dibuat sebagai draf.`, data: { id: r.id, poNo: r.poNo }, submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

export async function sendPurchaseOrderAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  void fd;
  try {
    const actor = await requireActor();
    await sendPurchaseOrder(actor, id);
    revalidatePath('/pengadaan/sp'); revalidatePath(`/pengadaan/sp/${id}`);
    return { ok: true, message: 'SP dikirim ke pemasok.', submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

export async function cancelPurchaseOrderAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  void fd;
  try {
    const actor = await requireActor();
    await cancelPurchaseOrder(actor, id);
    revalidatePath('/pengadaan/sp'); revalidatePath(`/pengadaan/sp/${id}`);
    return { ok: true, message: 'SP dibatalkan.', submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

// -- Penerimaan Barang ---------------------------------------------------------------
function parseGrItems(fd: FormData) {
  const ids = String(fd.get('row_ids') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  return ids
    .map((rid) => ({
      po_item_id: String(fd.get(`po_item_${rid}`) ?? ''),
      qty: Number(String(fd.get(`qty_${rid}`) ?? '0')) || 0,
      batch_no: String(fd.get(`batch_no_${rid}`) ?? '').trim(),
      expiry_date: String(fd.get(`expiry_${rid}`) ?? ''),
      unit_cost: String(fd.get(`cost_${rid}`) ?? '0').replace(/\./g, '').replace(',', '.'),
      condition: (String(fd.get(`condition_${rid}`) ?? 'OK')) as ReceiptCondition,
      notes: String(fd.get(`notes_${rid}`) ?? '').trim() || null,
    }))
    .filter((i) => i.po_item_id);
}

export async function createGoodsReceiptAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor();
    const header = {
      po_id: String(fd.get('po_id') ?? ''), supplier_do_no: String(fd.get('supplier_do_no') ?? ''),
      received_at: String(fd.get('received_at') ?? ''),
    };
    const r = await createGoodsReceipt(actor, header, parseGrItems(fd));
    revalidatePath('/pengadaan/penerimaan');
    return { ok: true, message: `Penerimaan ${r.grNo} dicatat sebagai draf.`, data: { id: r.id, grNo: r.grNo }, submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

export async function postGoodsReceiptAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  void fd;
  try {
    const actor = await requireActor();
    await postGoodsReceipt(actor, id);
    revalidatePath('/pengadaan/penerimaan'); revalidatePath(`/pengadaan/penerimaan/${id}`); revalidatePath('/persediaan');
    return { ok: true, message: 'Penerimaan diposting; stok dan batch baru tercatat.', submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

export async function cancelGoodsReceiptAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  void fd;
  try {
    const actor = await requireActor();
    await cancelGoodsReceipt(actor, id);
    revalidatePath('/pengadaan/penerimaan'); revalidatePath(`/pengadaan/penerimaan/${id}`);
    return { ok: true, message: 'Penerimaan dibatalkan.', submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

// -- Retur Pembelian ------------------------------------------------------------------
function parseReturnItems(fd: FormData) {
  const ids = String(fd.get('row_ids') ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  return ids
    .map((rid) => ({
      batch_id: String(fd.get(`batch_${rid}`) ?? ''),
      bucket: (STOCK_BUCKETS.includes(String(fd.get(`bucket_${rid}`)) as StockBucket) ? String(fd.get(`bucket_${rid}`)) : 'SALEABLE') as StockBucket,
      qty: Number(String(fd.get(`qty_${rid}`) ?? '0')) || 0,
      reason: String(fd.get(`reason_${rid}`) ?? '').trim(),
    }))
    .filter((i) => i.batch_id);
}

export async function createPurchaseReturnAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  try {
    const actor = await requireActor();
    const header = { supplier_id: String(fd.get('supplier_id') ?? ''), notes: String(fd.get('notes') ?? '') };
    const r = await createPurchaseReturn(actor, header, parseReturnItems(fd));
    revalidatePath('/pengadaan/retur');
    return { ok: true, message: `Retur ${r.returnNo} dibuat sebagai draf.`, data: { id: r.id, returnNo: r.returnNo }, submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

export async function approvePurchaseReturnAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  void fd;
  try {
    const actor = await requireActor();
    await approvePurchaseReturn(actor, id);
    revalidatePath('/pengadaan/retur'); revalidatePath(`/pengadaan/retur/${id}`); revalidatePath('/persediaan');
    return { ok: true, message: 'Retur disetujui dan stok diperbarui.', submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}

export async function cancelPurchaseReturnAction(id: string, _prev: ActionState, fd: FormData): Promise<ActionState> {
  void fd;
  try {
    const actor = await requireActor();
    await cancelPurchaseReturn(actor, id);
    revalidatePath('/pengadaan/retur'); revalidatePath(`/pengadaan/retur/${id}`);
    return { ok: true, message: 'Retur dibatalkan.', submittedAt: Date.now() };
  } catch (error) {
    return fail(error);
  }
}
