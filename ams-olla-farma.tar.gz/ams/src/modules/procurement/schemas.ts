import { z } from 'zod';
import { intField, money, optionalId, optionalText, requiredId, text } from '../../lib/forms';
import { STOCK_BUCKETS } from '../inventory/schemas';

const emptyToUndefined = (v: unknown) => (v === '' ? undefined : v);

export const PO_TYPES = ['REGULER', 'NARKOTIKA', 'PSIKOTROPIKA', 'PREKURSOR', 'OOT'] as const;
export type PoType = (typeof PO_TYPES)[number];
export const PO_TYPE_LABELS: Record<PoType, string> = {
  REGULER: 'Reguler',
  NARKOTIKA: 'Narkotika',
  PSIKOTROPIKA: 'Psikotropika',
  PREKURSOR: 'Prekursor',
  OOT: 'Obat-Obat Tertentu (OOT)',
};
/** SP khusus wajib ditandatangani APA sendiri (procurement.po_special.sign). */
export const PO_SPECIAL_TYPES: readonly PoType[] = ['NARKOTIKA', 'PSIKOTROPIKA', 'PREKURSOR', 'OOT'];

export const PO_STATUS_LABELS: Record<string, string> = {
  DRAFT: 'Draf', SENT: 'Terkirim', PARTIAL: 'Diterima sebagian', RECEIVED: 'Diterima penuh', CANCELLED: 'Dibatalkan',
};
export const GR_STATUS_LABELS: Record<string, string> = { DRAFT: 'Draf', POSTED: 'Diposting', CANCELLED: 'Dibatalkan' };
export const RETURN_STATUS_LABELS: Record<string, string> = { DRAFT: 'Draf', POSTED: 'Diposting', CANCELLED: 'Dibatalkan' };

export const RECEIPT_CONDITIONS = ['OK', 'DAMAGED', 'REJECTED'] as const;
export type ReceiptCondition = (typeof RECEIPT_CONDITIONS)[number];
export const RECEIPT_CONDITION_LABELS: Record<ReceiptCondition, string> = {
  OK: 'Baik', DAMAGED: 'Rusak (tetap diterima, masuk bucket rusak)', REJECTED: 'Ditolak (tidak diterima)',
};

const dateString = (label: string) =>
  z.string().trim().regex(/^\d{4}-\d{2}-\d{2}$/, `${label} wajib diisi (format tanggal).`);

// -- Surat Pesanan ---------------------------------------------------------------
export const poHeaderSchema = z.object({
  supplier_id: requiredId('Pemasok'),
  order_type: z.enum(PO_TYPES),
  expected_date: z.preprocess(emptyToUndefined, dateString('Tanggal perkiraan datang').optional()),
  notes: optionalText(500, 'Catatan'),
});
export type PoHeaderInput = z.output<typeof poHeaderSchema>;

export interface PoItemInput {
  medicine_id: string;
  unit_id: string;
  qty_ordered: number;
  price: string;
  discount_pct: string;
}

// -- Penerimaan Barang -------------------------------------------------------------
export const grHeaderSchema = z.object({
  po_id: requiredId('Surat Pesanan'),
  supplier_do_no: optionalText(100, 'Nomor faktur/surat jalan pemasok'),
  received_at: dateString('Tanggal terima'),
});
export type GrHeaderInput = z.output<typeof grHeaderSchema>;

export interface GrItemInput {
  po_item_id: string;
  qty: number;
  batch_no: string;
  expiry_date: string;
  unit_cost: string;
  condition: ReceiptCondition;
  notes: string | null;
}

// -- Retur Pembelian ----------------------------------------------------------------
export const returnHeaderSchema = z.object({
  supplier_id: requiredId('Pemasok'),
  notes: optionalText(500, 'Catatan'),
});
export type ReturnHeaderInput = z.output<typeof returnHeaderSchema>;

export interface ReturnItemInput {
  batch_id: string;
  bucket: (typeof STOCK_BUCKETS)[number];
  qty: number;
  reason: string;
}

// -- Filter daftar --------------------------------------------------------------
export const procurementFilterSchema = z.object({
  q: z.string().trim().max(100).optional().default(''),
  page: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(10_000).optional().default(1)),
});

export { optionalId, intField, money, text };
