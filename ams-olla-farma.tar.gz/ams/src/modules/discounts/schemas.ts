import { z } from 'zod';
import {
  requiredId,
  optionalId,
  text,
  optionalText,
  money,
} from '../../lib/forms';

// ─────────────────────────── Enums ───────────────────────────

export const discountScopeEnum = z.enum(['ALL', 'CATEGORY', 'MEDICINE']);
export const discountTypeEnum  = z.enum(['PERCENT', 'AMOUNT']);

export type DiscountScope = z.infer<typeof discountScopeEnum>;
export type DiscountType  = z.infer<typeof discountTypeEnum>;

// ─────────────────────────── Create ───────────────────────────

export const createDiscountRuleSchema = z.object({
  code:         text(50,  'Kode diskon'),
  name:         text(150, 'Nama diskon'),
  scope:        discountScopeEnum,
  category_id:  optionalId,
  medicine_id:  optionalId,
  type:         discountTypeEnum,
  value:        money('Nilai diskon'),
  min_qty_base: z.number().int().min(1).default(1),
  starts_at:    z.string().datetime({ offset: true }).or(z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/)),
  ends_at:      z.string().datetime({ offset: true }).or(z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/)),
  notes:        optionalText(500, 'Catatan'),
}).superRefine((data, ctx) => {
  if (data.scope === 'CATEGORY' && !data.category_id) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Kategori wajib dipilih untuk scope CATEGORY.', path: ['category_id'] });
  }
  if (data.scope === 'MEDICINE' && !data.medicine_id) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Obat wajib dipilih untuk scope MEDICINE.', path: ['medicine_id'] });
  }
  if (data.scope === 'ALL' && (data.category_id || data.medicine_id)) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Scope ALL tidak boleh memiliki kategori/obat spesifik.', path: ['scope'] });
  }
  if (data.type === 'PERCENT') {
    const val = parseFloat(data.value);
    if (val > 100) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Diskon persentase tidak boleh melebihi 100%.', path: ['value'] });
    }
  }
  const start = new Date(data.starts_at);
  const end   = new Date(data.ends_at);
  if (!isNaN(start.getTime()) && !isNaN(end.getTime()) && end <= start) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Tanggal akhir harus setelah tanggal mulai.', path: ['ends_at'] });
  }
});

export type CreateDiscountRuleInput = z.output<typeof createDiscountRuleSchema>;

// ─────────────────────────── Approve ──────────────────────────

export const approveDiscountRuleSchema = z.object({
  id:     requiredId('ID aturan diskon'),
  action: z.enum(['APPROVE', 'REJECT']),
  notes:  optionalText(500, 'Catatan persetujuan'),
});

export type ApproveDiscountRuleInput = z.output<typeof approveDiscountRuleSchema>;

// ─────────────────────────── List filter ──────────────────────

export const listDiscountRulesSchema = z.object({
  status:      z.enum(['DRAFT', 'APPROVED', 'REJECTED', 'CANCELLED', 'ALL']).default('ALL'),
  scope:       discountScopeEnum.optional(),
  active_only: z.boolean().default(false), // hanya yang periode aktif sekarang
  medicine_id: optionalId,
  category_id: optionalId,
  page:        z.number().int().min(1).default(1),
  limit:       z.number().int().min(1).max(100).default(20),
});

export type ListDiscountRulesInput = z.output<typeof listDiscountRulesSchema>;

// ─────────────────────────── Apply (internal) ─────────────────

/** Input resolveApplicableDiscount — dipanggil dari sales service */
export interface ResolveDiscountInput {
  medicine_id:  string;
  category_id:  string | null;
  qty_base:     number;
  at:           Date;   // waktu transaksi
}

/** Hasil resolusi — satu aturan diskon terbaik atau null */
export interface ResolvedDiscount {
  rule_id:      string;
  type:         DiscountType;
  value:        string; // numeric string
  discount_pct: string; // selalu dalam persen (konversi AMOUNT → pct dari unit_price dilakukan di caller)
}
