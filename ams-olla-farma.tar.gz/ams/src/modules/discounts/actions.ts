'use server';

import { z } from 'zod';
import { requireActor } from '../../lib/auth/server';
import { translateDbError } from '../../lib/database/errors';
import { AppError } from '../../lib/errors';
import { type ActionState } from '../../lib/forms';
import { fieldErrors } from '../../lib/validation';
import * as svc from './service';

function fail(error: unknown): ActionState {
  const appErr = error instanceof AppError ? error : translateDbError(error);
  if (appErr instanceof AppError) {
    return {
      ok:          false,
      code:        appErr.code,
      message:     appErr.message ?? 'Tidak dapat menyimpan.',
      fields:      appErr.fields,
      submittedAt: Date.now(),
    };
  }
  if (error instanceof z.ZodError) {
    return { ok: false, code: 'VALIDATION_ERROR', fields: fieldErrors(error), submittedAt: Date.now() };
  }
  throw error;
}

// ─────────────────────────── List ─────────────────────────────

export async function listDiscountRulesAction(raw?: {
  status?: string;
  scope?: string;
  active_only?: boolean;
  page?: number;
  limit?: number;
}): Promise<ActionState> {
  try {
    const actor = await requireActor('pricing.discount_rules.manage');
    const data  = await svc.listDiscountRules(actor, raw ?? {});
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Get By ID ────────────────────────

export async function getDiscountRuleAction(id: string): Promise<ActionState> {
  try {
    const actor = await requireActor('pricing.discount_rules.manage');
    const data  = await svc.getDiscountRuleById(actor, id);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Create ───────────────────────────

export async function createDiscountRuleAction(
  _prev: ActionState,
  fd: FormData,
): Promise<ActionState> {
  try {
    const actor = await requireActor('pricing.discount_rules.manage');
    const raw = {
      code:         fd.get('code'),
      name:         fd.get('name'),
      scope:        fd.get('scope'),
      category_id:  fd.get('category_id') || undefined,
      medicine_id:  fd.get('medicine_id') || undefined,
      type:         fd.get('type'),
      value:        fd.get('value'),
      min_qty_base: fd.get('min_qty_base') ? Number(fd.get('min_qty_base')) : 1,
      starts_at:    fd.get('starts_at'),
      ends_at:      fd.get('ends_at'),
      notes:        fd.get('notes') || undefined,
    };
    const data = await svc.createDiscountRule(actor, raw);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Approve / Reject ─────────────────

export async function approveDiscountRuleAction(
  _prev: ActionState,
  fd: FormData,
): Promise<ActionState> {
  try {
    const actor = await requireActor('pricing.discount_rules.manage');
    const raw = {
      id:     fd.get('id'),
      action: fd.get('action'),
      notes:  fd.get('notes') || undefined,
    };
    const data = await svc.approveDiscountRule(actor, raw);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}

// ─────────────────────────── Cancel ───────────────────────────

export async function cancelDiscountRuleAction(id: string): Promise<ActionState> {
  try {
    const actor = await requireActor('pricing.discount_rules.manage');
    const data  = await svc.cancelDiscountRule(actor, id);
    return { ok: true, data, submittedAt: Date.now() };
  } catch (e) {
    return fail(e);
  }
}
