import 'server-only';
import { Prisma } from '@/generated/prisma/client';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import type { DbTransaction } from '../../lib/database/client';
import { setActor } from '../../lib/database/context';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import { parseOrThrow } from '../../lib/validation';
import {
  createDiscountRuleSchema,
  approveDiscountRuleSchema,
  listDiscountRulesSchema,
  type ResolveDiscountInput,
  type ResolvedDiscount,
} from './schemas';

// ─────────────────────────── CREATE ───────────────────────────

export async function createDiscountRule(actor: Actor, raw: unknown) {
  assertCan(actor, 'pricing.discount_rules.manage');
  const input = parseOrThrow(createDiscountRuleSchema, raw);

  // Cek duplikat kode
  const existing = await prisma.discountRule.findUnique({ where: { code: input.code } });
  if (existing) {
    throw new AppError('VALIDATION_ERROR', undefined, {
      code: `Kode diskon "${input.code}" sudah digunakan.`,
    });
  }

  // Validasi referensi kategori/obat
  if (input.scope === 'CATEGORY' && input.category_id) {
    const cat = await prisma.category.findUnique({ where: { id: input.category_id } });
    if (!cat) throw new AppError('NOT_FOUND', 'Kategori tidak ditemukan.');
  }
  if (input.scope === 'MEDICINE' && input.medicine_id) {
    const med = await prisma.medicine.findUnique({ where: { id: input.medicine_id } });
    if (!med) throw new AppError('NOT_FOUND', 'Obat tidak ditemukan.');
  }

  return withDbErrors(async () => {
    const rule = await prisma.discountRule.create({
      data: {
        code:         input.code,
        name:         input.name,
        scope:        input.scope,
        category_id:  input.category_id ?? null,
        medicine_id:  input.medicine_id ?? null,
        type:         input.type,
        value:        new Prisma.Decimal(input.value),
        min_qty_base: input.min_qty_base,
        starts_at:    new Date(input.starts_at),
        ends_at:      new Date(input.ends_at),
        status:       'DRAFT',
        created_by:   actor.id,
      },
      include: {
        category: { select: { id: true, name: true } },
        medicine: { select: { id: true, name: true } },
        creator:  { select: { id: true, full_name: true } },
      },
    });

    return rule;
  });
}

// ─────────────────────────── APPROVE / REJECT ─────────────────

export async function approveDiscountRule(actor: Actor, raw: unknown) {
  assertCan(actor, 'pricing.discount_rules.manage');
  const input = parseOrThrow(approveDiscountRuleSchema, raw);

  const rule = await prisma.discountRule.findUnique({ where: { id: input.id } });
  if (!rule) throw new AppError('NOT_FOUND', 'Aturan diskon tidak ditemukan.');

  if (rule.status !== 'DRAFT') {
    throw new AppError('INVALID_STATE_TRANSITION', `Aturan diskon tidak dalam status DRAFT (status saat ini: ${rule.status}).`);
  }

  // Maker-checker: creator tidak boleh approve sendiri
  if (rule.created_by === actor.id) {
    throw new AppError('FORBIDDEN', 'Pembuat aturan tidak dapat menyetujui sendiri (four-eyes principle).');
  }

  const newStatus = input.action === 'APPROVE' ? 'APPROVED' : 'REJECTED';

  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);

    const updated = await tx.discountRule.update({
      where: { id: input.id },
      data: {
        status:      newStatus,
        approved_by: actor.id,
        approved_at: new Date(),
        // Simpan catatan penolakan di field name jika ditolak (append suffix)
        // Notes tidak ada di model — gunakan audit trail saja
      },
      include: {
        category: { select: { id: true, name: true } },
        medicine: { select: { id: true, name: true } },
        creator:  { select: { id: true, full_name: true } },
        approver: { select: { id: true, full_name: true } },
      },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: input.action === 'APPROVE' ? 'discount.rule_approved' : 'discount.rule_rejected',
      entity: 'discount_rules',
      entity_id: rule.id,
      before: { status: 'DRAFT' },
      after:  { status: newStatus, notes: input.notes ?? null },
    });

    return updated;
  });
}

// ─────────────────────────── LIST ─────────────────────────────

export async function listDiscountRules(actor: Actor, raw?: unknown) {
  assertCan(actor, 'pricing.discount_rules.manage');
  const input = parseOrThrow(listDiscountRulesSchema, raw ?? {});

  const now = new Date();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const where: Record<string, any> = {};

  if (input.status !== 'ALL') {
    where.status = input.status as any;
  }
  if (input.scope) {
    where.scope = input.scope;
  }
  if (input.active_only) {
    where.status = 'APPROVED';
    where.starts_at = { lte: now };
    where.ends_at   = { gte: now };
  }
  if (input.medicine_id) {
    where.OR = [
      { scope: 'ALL' },
      { scope: 'MEDICINE',  medicine_id: input.medicine_id },
    ];
  }
  if (input.category_id) {
    where.OR = [
      { scope: 'ALL' },
      { scope: 'CATEGORY', category_id: input.category_id },
    ];
  }

  const skip = (input.page - 1) * input.limit;

  const [items, total] = await Promise.all([
    prisma.discountRule.findMany({
      where,
      orderBy: [{ starts_at: 'desc' }, { created_at: 'desc' }],
      skip,
      take: input.limit,
      include: {
        category: { select: { id: true, name: true } },
        medicine: { select: { id: true, name: true } },
        creator:  { select: { id: true, full_name: true } },
        approver: { select: { id: true, full_name: true } },
      },
    }),
    prisma.discountRule.count({ where }),
  ]);

  return {
    items,
    pagination: {
      page:  input.page,
      limit: input.limit,
      total,
      pages: Math.ceil(total / input.limit),
    },
  };
}

// ─────────────────────────── GET BY ID ────────────────────────

export async function getDiscountRuleById(actor: Actor, id: string) {
  assertCan(actor, 'pricing.discount_rules.manage');

  const rule = await prisma.discountRule.findUnique({
    where: { id },
    include: {
      category:   { select: { id: true, name: true } },
      medicine:   { select: { id: true, name: true } },
      creator:    { select: { id: true, full_name: true } },
      approver:   { select: { id: true, full_name: true } },
      sale_items: { select: { id: true }, take: 1 }, // cek apakah sudah dipakai
    },
  });
  if (!rule) throw new AppError('NOT_FOUND', 'Aturan diskon tidak ditemukan.');
  return rule;
}

// ─────────────────────────── CANCEL ───────────────────────────

export async function cancelDiscountRule(actor: Actor, id: string) {
  assertCan(actor, 'pricing.discount_rules.manage');

  const rule = await prisma.discountRule.findUnique({
    where: { id },
    include: { sale_items: { select: { id: true }, take: 1 } },
  });
  if (!rule) throw new AppError('NOT_FOUND', 'Aturan diskon tidak ditemukan.');

  if (rule.status === 'CANCELLED') {
    throw new AppError('VALIDATION_ERROR', 'Aturan diskon sudah dibatalkan.');
  }
  if (rule.status !== 'DRAFT') {
    throw new AppError('INVALID_STATE_TRANSITION', `Hanya aturan DRAFT yang dapat dibatalkan (status saat ini: ${rule.status}).`);
  }
  // Hanya pembuat yang bisa membatalkan
  if (rule.created_by !== actor.id) {
    throw new AppError('FORBIDDEN', 'Hanya pembuat aturan yang dapat membatalkannya.');
  }
  if (rule.sale_items.length > 0) {
    throw new AppError('VALIDATION_ERROR', 'Aturan diskon sudah digunakan dalam transaksi, tidak dapat dibatalkan.');
  }

  return withTransaction(async (tx) => {
    await setActor(tx, actor.id);

    const updated = await tx.discountRule.update({
      where: { id },
      data: { status: 'CANCELLED' },
    });

    await writeAudit(tx, {
      ...auditMeta(actor),
      action: 'discount.rule_cancelled',
      entity: 'discount_rules',
      entity_id: id,
      before: { status: rule.status },
      after:  { status: 'CANCELLED' },
    });

    return updated;
  });
}

// ─────────────────────── RESOLVE (internal) ───────────────────

/**
 * Resolusi diskon aktif terbaik untuk satu item penjualan.
 * Prioritas: MEDICINE > CATEGORY > ALL
 * Dipanggil dari dalam transaksi penjualan.
 */
export async function resolveApplicableDiscount(
  tx: DbTransaction,
  input: ResolveDiscountInput,
): Promise<ResolvedDiscount | null> {
  const { medicine_id, category_id, qty_base, at } = input;

  // Ambil semua aturan APPROVED yang aktif pada waktu transaksi
  const candidates = await tx.discountRule.findMany({
    where: {
      status:    'APPROVED',
      starts_at: { lte: at },
      ends_at:   { gte: at },
      min_qty_base: { lte: qty_base },
      OR: [
        { scope: 'ALL' },
        { scope: 'MEDICINE',  medicine_id },
        ...(category_id ? [{ scope: 'CATEGORY' as const, category_id }] : []),
      ],
    },
    orderBy: { value: 'desc' }, // tie-break: nilai terbesar
    select: { id: true, scope: true, type: true, value: true },
  });

  if (candidates.length === 0) return null;

  // Priority sort: MEDICINE=0, CATEGORY=1, ALL=2
  const priority: Record<string, number> = { MEDICINE: 0, CATEGORY: 1, ALL: 2 };
  type Candidate = { id: string; scope: string; type: string; value: Prisma.Decimal };
  candidates.sort((a: Candidate, b: Candidate) => {
    const pa = priority[a.scope] ?? 99;
    const pb = priority[b.scope] ?? 99;
    if (pa !== pb) return pa - pb;
    // Sama scope: nilai lebih besar menang
    return b.value.comparedTo(a.value);
  });

  const best = candidates[0];
  return {
    rule_id:      best.id,
    type:         best.type as 'PERCENT' | 'AMOUNT',
    value:        best.value.toString(),
    discount_pct: best.type === 'PERCENT' ? best.value.toString() : '0',
    // Catatan: untuk type AMOUNT, discount_pct = 0 — penghitungan aktual
    // dilakukan di sales service menggunakan value & unit_price
  };
}
