import 'server-only';
import { redactSecrets, type AuditEntry } from '../../lib/audit/types';
import type { RoleCode } from '../../lib/permissions/catalog';
import type { SessionRecord } from '../../lib/auth/session-token';
import { prisma, type DbClient, type DbTransaction } from '../../lib/database/client';
import { withTransaction } from '../../lib/database/transaction';
import type { AuthRepository, AuthUser } from './types';

type Db = DbClient | DbTransaction;

const userSelect = {
  id: true,
  username: true,
  full_name: true,
  password_hash: true,
  is_active: true,
  must_change_password: true,
  failed_login_count: true,
  locked_until: true,
  session_version: true,
  roles: { select: { role: { select: { code: true } } } },
} as const;

function toAuthUser(row: {
  id: string; username: string; full_name: string; password_hash: string; is_active: boolean;
  must_change_password: boolean; failed_login_count: number; locked_until: Date | null;
  session_version: number; roles: { role: { code: string } }[];
}): AuthUser {
  return { ...row, roles: row.roles.map((r) => r.role.code as RoleCode) };
}

/** Implementasi AuthRepository dengan Prisma. Tes unit memakai versi in-memory. */
export class PrismaAuthRepository implements AuthRepository {
  constructor(private readonly db: Db = prisma, private readonly inTransaction = false) {}

  async findUserByUsername(username: string) {
    const row = await this.db.user.findUnique({ where: { username }, select: userSelect });
    return row ? toAuthUser(row) : null;
  }

  async findUserById(id: string) {
    const row = await this.db.user.findUnique({ where: { id }, select: userSelect });
    return row ? toAuthUser(row) : null;
  }

  async updateLoginState(userId: string, s: { failed_login_count: number; locked_until: Date | null; last_login_at?: Date }) {
    await this.db.user.update({ where: { id: userId }, data: s });
  }

  async updatePassword(userId: string, passwordHash: string, mustChange: boolean) {
    await this.db.user.update({
      where: { id: userId },
      data: { password_hash: passwordHash, must_change_password: mustChange },
    });
  }

  async bumpSessionVersion(userId: string) {
    const row = await this.db.user.update({
      where: { id: userId },
      data: { session_version: { increment: 1 } },
      select: { session_version: true },
    });
    return row.session_version;
  }

  async createSession(s: SessionRecord & { ip: string | null; user_agent: string | null }) {
    await this.db.userSession.create({ data: s });
  }

  async findSession(id: string) {
    return this.db.userSession.findUnique({
      where: { id },
      select: {
        id: true, user_id: true, session_version: true, created_at: true,
        last_seen_at: true, expires_at: true, revoked_at: true,
      },
    });
  }

  async touchSession(id: string, at: Date) {
    await this.db.userSession.updateMany({ where: { id, revoked_at: null }, data: { last_seen_at: at } });
  }

  async revokeSession(id: string, at: Date) {
    await this.db.userSession.updateMany({ where: { id, revoked_at: null }, data: { revoked_at: at } });
  }

  async rateLimitHit(key: string, windowSeconds: number, max: number) {
    const rows = await this.db.$queryRaw<{ allowed: boolean }[]>`
      SELECT ams_rate_limit_hit(${key}, ${windowSeconds}::int, ${max}::int) AS allowed`;
    return rows[0]?.allowed === true;
  }

  async writeAudit(entry: AuditEntry) {
    await this.db.auditLog.create({
      data: {
        user_id: entry.user_id,
        action: entry.action,
        entity: entry.entity,
        entity_id: entry.entity_id ?? null,
        before_json: (redactSecrets(entry.before) ?? undefined) as object | undefined,
        after_json: (redactSecrets(entry.after) ?? undefined) as object | undefined,
        ip: entry.ip ?? null,
        user_agent: entry.user_agent?.slice(0, 300) ?? null,
      },
    });
  }

  async transaction<T>(fn: (repo: AuthRepository) => Promise<T>): Promise<T> {
    if (this.inTransaction) return fn(this);
    return withTransaction((tx) => fn(new PrismaAuthRepository(tx, true)));
  }
}
