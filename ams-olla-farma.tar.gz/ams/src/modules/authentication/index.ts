import 'server-only';
import { PrismaAuthRepository } from './repository';
import { createAuthService } from './service';

/** API publik modul autentikasi. Modul lain hanya mengimpor dari file ini. */
export const authService = createAuthService(new PrismaAuthRepository());
export type { AuthenticatedSession, RequestContext } from './types';
