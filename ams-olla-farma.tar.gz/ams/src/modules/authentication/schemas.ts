import { z } from 'zod';
import { PASSWORD_MAX_LENGTH } from '../../lib/auth/password';

/** Skema yang sama dipakai form (UX) dan server (otoritatif). */
export const loginSchema = z.object({
  username: z
    .string()
    .trim()
    .toLowerCase()
    .min(3, 'Nama pengguna minimal 3 karakter.')
    .max(50, 'Nama pengguna maksimal 50 karakter.'),
  password: z
    .string()
    .min(1, 'Kata sandi wajib diisi.')
    .max(PASSWORD_MAX_LENGTH, 'Kata sandi terlalu panjang.'),
});

export type LoginInput = z.infer<typeof loginSchema>;

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, 'Kata sandi lama wajib diisi.').max(PASSWORD_MAX_LENGTH),
    newPassword: z.string().max(PASSWORD_MAX_LENGTH, 'Kata sandi terlalu panjang.'),
    confirmPassword: z.string(),
  })
  .refine((v) => v.newPassword === v.confirmPassword, {
    message: 'Konfirmasi kata sandi tidak sama.',
    path: ['confirmPassword'],
  })
  .refine((v) => v.newPassword !== v.currentPassword, {
    message: 'Kata sandi baru harus berbeda dari yang lama.',
    path: ['newPassword'],
  });

export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;

export { fieldErrors } from '../../lib/validation';
