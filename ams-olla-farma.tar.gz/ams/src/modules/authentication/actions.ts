'use server';

import { redirect } from 'next/navigation';
import {
  clearSessionCookie,
  getCurrentUser,
  getRequestContext,
  requireActionPermission,
  setSessionCookie,
} from '@/lib/auth/server';
import { toFailure, type ErrorCode } from '@/lib/errors';
import { authService } from '.';

/**
 * Server Actions autentikasi: tipis, hanya menghubungkan form ke service.
 * Next.js memeriksa header Origin pada setiap Server Action (proteksi CSRF).
 */

export interface FormState {
  ok: boolean;
  code?: ErrorCode;
  message?: string;
  fields?: Record<string, string>;
}

export async function loginAction(_prev: FormState, formData: FormData): Promise<FormState> {
  let mustChange = false;
  try {
    const ctx = await getRequestContext();
    const result = await authService.login(
      { username: formData.get('username'), password: formData.get('password') },
      ctx,
    );
    await setSessionCookie(result.token, result.expiresAt);
    mustChange = result.mustChangePassword;
  } catch (error) {
    const f = toFailure(error);
    return { ok: false, code: f.code, message: f.message, fields: f.fields };
  }
  // redirect() melempar sinyal khusus Next.js, jadi dipanggil di luar try/catch.
  redirect(mustChange ? '/akun/ganti-sandi' : '/dashboard');
}

export async function logoutAction(): Promise<void> {
  const user = await getCurrentUser();
  if (user) await authService.logout(user, await getRequestContext());
  await clearSessionCookie();
  redirect('/login');
}

export async function changePasswordAction(_prev: FormState, formData: FormData): Promise<FormState> {
  try {
    const user = await requireActionPermission();
    const result = await authService.changePassword(
      user,
      {
        currentPassword: formData.get('currentPassword'),
        newPassword: formData.get('newPassword'),
        confirmPassword: formData.get('confirmPassword'),
      },
      await getRequestContext(),
    );
    await setSessionCookie(result.token, result.expiresAt);
  } catch (error) {
    const f = toFailure(error);
    return { ok: false, code: f.code, message: f.message, fields: f.fields };
  }
  redirect('/dashboard?sandi=diganti');
}
