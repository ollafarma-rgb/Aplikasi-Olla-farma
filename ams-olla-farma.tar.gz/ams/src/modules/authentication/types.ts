import type { AuditEntry } from '../../lib/audit/types';
import type { RoleCode } from '../../lib/permissions/catalog';
import type { SessionRecord } from '../../lib/auth/session-token';

export interface AuthUser {
  id: string;
  username: string;
  full_name: string;
  password_hash: string;
  is_active: boolean;
  must_change_password: boolean;
  failed_login_count: number;
  locked_until: Date | null;
  session_version: number;
  roles: RoleCode[];
}

export interface RequestContext {
  ip: string | null;
  userAgent: string | null;
  now: Date;
}

/**
 * Port penyimpanan untuk modul autentikasi. Implementasi produksi memakai
 * Prisma (repository.ts); tes unit memakai implementasi in-memory.
 */
export interface AuthRepository {
  findUserByUsername(username: string): Promise<AuthUser | null>;
  findUserById(id: string): Promise<AuthUser | null>;
  updateLoginState(
    userId: string,
    state: { failed_login_count: number; locked_until: Date | null; last_login_at?: Date },
  ): Promise<void>;
  updatePassword(userId: string, passwordHash: string, mustChange: boolean): Promise<void>;
  bumpSessionVersion(userId: string): Promise<number>;
  createSession(session: SessionRecord & { ip: string | null; user_agent: string | null }): Promise<void>;
  findSession(id: string): Promise<SessionRecord | null>;
  touchSession(id: string, at: Date): Promise<void>;
  revokeSession(id: string, at: Date): Promise<void>;
  rateLimitHit(key: string, windowSeconds: number, max: number): Promise<boolean>;
  writeAudit(entry: AuditEntry): Promise<void>;
  /** Jalankan beberapa langkah dalam satu transaksi database. */
  transaction<T>(fn: (repo: AuthRepository) => Promise<T>): Promise<T>;
}

export interface AuthenticatedSession {
  sessionId: string;
  user: Pick<AuthUser, 'id' | 'username' | 'full_name' | 'roles' | 'must_change_password'>;
}
