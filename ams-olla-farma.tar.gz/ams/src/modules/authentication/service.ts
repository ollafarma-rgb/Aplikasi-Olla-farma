import {
  getDummyHash,
  hashPassword,
  needsRehash,
  validatePasswordPolicy,
  verifyPassword,
} from '../../lib/auth/password';
import {
  checkSession,
  generateSessionToken,
  hashSessionToken,
  isWellFormedToken,
  SESSION_ABSOLUTE_MS,
} from '../../lib/auth/session-token';
import { afterFailedAttempt, afterSuccessfulLogin, isLocked, LOGIN_RATE_LIMIT } from '../../lib/auth/lockout';
import { AppError } from '../../lib/errors';
import { changePasswordSchema, fieldErrors, loginSchema } from './schemas';
import type { AuthenticatedSession, AuthRepository, RequestContext } from './types';

/** Pesan sama untuk username salah dan sandi salah, agar username tidak bisa ditebak. */
export const INVALID_CREDENTIALS = 'Nama pengguna atau kata sandi salah.';

export interface LoginResult {
  token: string;
  expiresAt: Date;
  mustChangePassword: boolean;
}

export function createAuthService(repo: AuthRepository) {
  return {
    async login(rawInput: unknown, ctx: RequestContext): Promise<LoginResult> {
      const parsed = loginSchema.safeParse(rawInput);
      if (!parsed.success) {
        throw new AppError('VALIDATION_ERROR', undefined, fieldErrors(parsed.error));
      }
      const { username, password } = parsed.data;

      const allowed = await repo.rateLimitHit(
        `login:${ctx.ip ?? 'unknown'}:${username}`,
        LOGIN_RATE_LIMIT.windowSeconds,
        LOGIN_RATE_LIMIT.max,
      );
      if (!allowed) throw new AppError('RATE_LIMITED');

      const user = await repo.findUserByUsername(username);
      if (!user) {
        await verifyPassword(password, await getDummyHash()); // samakan waktu respons
        await repo.writeAudit({
          user_id: null, action: 'auth.login.failed', entity: 'user', entity_id: null,
          after: { username, reason: 'unknown_user' }, ip: ctx.ip, user_agent: ctx.userAgent,
        });
        throw new AppError('UNAUTHENTICATED', INVALID_CREDENTIALS);
      }

      if (isLocked(user, ctx.now)) {
        await repo.writeAudit({
          user_id: user.id, action: 'auth.login.locked', entity: 'user', entity_id: user.id,
          ip: ctx.ip, user_agent: ctx.userAgent,
        });
        throw new AppError('ACCOUNT_LOCKED');
      }

      const passwordOk = await verifyPassword(password, user.password_hash);
      if (!passwordOk) {
        const next = afterFailedAttempt(user, ctx.now);
        await repo.transaction(async (tx) => {
          await tx.updateLoginState(user.id, next);
          await tx.writeAudit({
            user_id: user.id, action: 'auth.login.failed', entity: 'user', entity_id: user.id,
            after: { failed_login_count: next.failed_login_count, locked: next.locked_until !== null },
            ip: ctx.ip, user_agent: ctx.userAgent,
          });
        });
        throw next.locked_until ? new AppError('ACCOUNT_LOCKED') : new AppError('UNAUTHENTICATED', INVALID_CREDENTIALS);
      }

      // Sandi benar; akun nonaktif baru diberi tahu setelah sandi terbukti benar.
      if (!user.is_active) throw new AppError('ACCOUNT_INACTIVE');

      const token = generateSessionToken();
      const sessionId = hashSessionToken(token);
      const expiresAt = new Date(ctx.now.getTime() + SESSION_ABSOLUTE_MS);
      const rehash = needsRehash(user.password_hash) ? await hashPassword(password) : null;

      await repo.transaction(async (tx) => {
        await tx.updateLoginState(user.id, { ...afterSuccessfulLogin(), last_login_at: ctx.now });
        if (rehash) await tx.updatePassword(user.id, rehash, user.must_change_password);
        await tx.createSession({
          id: sessionId,
          user_id: user.id,
          session_version: user.session_version,
          created_at: ctx.now,
          last_seen_at: ctx.now,
          expires_at: expiresAt,
          revoked_at: null,
          ip: ctx.ip,
          user_agent: ctx.userAgent?.slice(0, 300) ?? null,
        });
        await tx.writeAudit({
          user_id: user.id, action: 'auth.login.success', entity: 'user', entity_id: user.id,
          ip: ctx.ip, user_agent: ctx.userAgent,
        });
      });

      return { token, expiresAt, mustChangePassword: user.must_change_password };
    },

    /** Validasi token dari cookie. Mengembalikan null bila sesi tidak sah. */
    async validateSession(token: string | undefined | null, now: Date): Promise<AuthenticatedSession | null> {
      if (!isWellFormedToken(token)) return null;
      const sessionId = hashSessionToken(token);
      const session = await repo.findSession(sessionId);
      if (!session) return null;
      const user = await repo.findUserById(session.user_id);
      if (!user) return null;
      const check = checkSession(session, user, now);
      if (!check.valid) {
        if (check.reason !== 'revoked') await repo.revokeSession(sessionId, now);
        return null;
      }
      if (check.shouldTouch) await repo.touchSession(sessionId, now);
      return {
        sessionId,
        user: {
          id: user.id,
          username: user.username,
          full_name: user.full_name,
          roles: user.roles,
          must_change_password: user.must_change_password,
        },
      };
    },

    async logout(session: AuthenticatedSession, ctx: RequestContext): Promise<void> {
      await repo.transaction(async (tx) => {
        await tx.revokeSession(session.sessionId, ctx.now);
        await tx.writeAudit({
          user_id: session.user.id, action: 'auth.logout', entity: 'user', entity_id: session.user.id,
          ip: ctx.ip, user_agent: ctx.userAgent,
        });
      });
    },

    /**
     * Ganti sandi: semua sesi lain otomatis keluar (session_version naik),
     * lalu sesi baru dibuat untuk perangkat ini.
     */
    async changePassword(session: AuthenticatedSession, rawInput: unknown, ctx: RequestContext): Promise<LoginResult> {
      const parsed = changePasswordSchema.safeParse(rawInput);
      if (!parsed.success) {
        throw new AppError('VALIDATION_ERROR', undefined, fieldErrors(parsed.error));
      }
      const user = await repo.findUserById(session.user.id);
      if (!user || !user.is_active) throw new AppError('UNAUTHENTICATED');

      const policyError = validatePasswordPolicy(parsed.data.newPassword, { username: user.username });
      if (policyError) throw new AppError('VALIDATION_ERROR', undefined, { newPassword: policyError });

      if (!(await verifyPassword(parsed.data.currentPassword, user.password_hash))) {
        throw new AppError('VALIDATION_ERROR', undefined, { currentPassword: 'Kata sandi lama salah.' });
      }

      const newHash = await hashPassword(parsed.data.newPassword);
      const token = generateSessionToken();
      const expiresAt = new Date(ctx.now.getTime() + SESSION_ABSOLUTE_MS);

      await repo.transaction(async (tx) => {
        await tx.updatePassword(user.id, newHash, false);
        const version = await tx.bumpSessionVersion(user.id);
        await tx.revokeSession(session.sessionId, ctx.now);
        await tx.createSession({
          id: hashSessionToken(token),
          user_id: user.id,
          session_version: version,
          created_at: ctx.now,
          last_seen_at: ctx.now,
          expires_at: expiresAt,
          revoked_at: null,
          ip: ctx.ip,
          user_agent: ctx.userAgent?.slice(0, 300) ?? null,
        });
        await tx.writeAudit({
          user_id: user.id, action: 'auth.password.changed', entity: 'user', entity_id: user.id,
          ip: ctx.ip, user_agent: ctx.userAgent,
        });
      });

      return { token, expiresAt, mustChangePassword: false };
    },

    /** Keluarkan paksa semua sesi seorang pengguna (dipakai Owner). */
    async revokeAllSessions(actorId: string, targetUserId: string, ctx: RequestContext): Promise<void> {
      await repo.transaction(async (tx) => {
        await tx.bumpSessionVersion(targetUserId);
        await tx.writeAudit({
          user_id: actorId, action: 'auth.sessions.revoked', entity: 'user', entity_id: targetUserId,
          ip: ctx.ip, user_agent: ctx.userAgent,
        });
      });
    },
  };
}

export type AuthService = ReturnType<typeof createAuthService>;
