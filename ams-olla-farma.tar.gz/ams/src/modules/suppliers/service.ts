import 'server-only';
import { z } from 'zod';
import { assertCan, auditMeta, type Actor } from '../../lib/auth/actor';
import { diffFields, writeAudit } from '../../lib/audit/write';
import { prisma } from '../../lib/database/client';
import { nextNumber } from '../../lib/database/context';
import { withDbErrors } from '../../lib/database/errors';
import { withTransaction } from '../../lib/database/transaction';
import { AppError } from '../../lib/errors';
import { intField, optionalText, text } from '../../lib/forms';
import { parseOrThrow } from '../../lib/validation';
import type { Prisma } from '@/generated/prisma/client';

export const SUPPLIER_STATUSES = ['ACTIVE', 'INACTIVE', 'BLOCKED'] as const;
export const SUPPLIER_STATUS_LABELS: Record<(typeof SUPPLIER_STATUSES)[number], string> = {
  ACTIVE: 'Aktif',
  INACTIVE: 'Tidak aktif',
  BLOCKED: 'Diblokir',
};

export const supplierSchema = z.object({
  name: text(150, 'Nama pemasok'),
  company_name: optionalText(200, 'Nama perusahaan'),
  address: optionalText(500, 'Alamat'),
  phone: optionalText(30, 'Telepon').refine((v) => v === null || /^[0-9+()\s-]{6,30}$/.test(v), 'Nomor telepon tidak valid.'),
  email: optionalText(150, 'Email').refine((v) => v === null || z.email().safeParse(v).success, 'Email tidak valid.'),
  sales_rep: optionalText(100, 'Nama sales'),
  npwp: optionalText(30, 'NPWP'),
  pbf_license_no: optionalText(100, 'Nomor izin PBF'),
  payment_term_days: intField('Termin pembayaran', 0, 365),
  status: z.enum(SUPPLIER_STATUSES, { message: 'Status wajib dipilih.' }),
  notes: optionalText(1000, 'Catatan'),
});

const emptyToUndefined = (v: unknown) => (v === '' ? undefined : v);
const filterSchema = z.object({
  q: z.string().trim().max(100).optional().default(''),
  status: z.preprocess(emptyToUndefined, z.enum([...SUPPLIER_STATUSES, 'SEMUA']).optional().default('ACTIVE')),
  page: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(10_000).optional().default(1)),
});

const PAGE_SIZE = 20;

export async function listSuppliers(raw: unknown, actor: Actor) {
  assertCan(actor, 'suppliers.view');
  const f = parseOrThrow(filterSchema, raw);
  const where: Prisma.SupplierWhereInput = {
    ...(f.status === 'SEMUA' ? {} : { status: f.status }),
    ...(f.q
      ? { OR: [{ name: { contains: f.q, mode: 'insensitive' } }, { company_name: { contains: f.q, mode: 'insensitive' } }, { code: { equals: f.q.toUpperCase() } }] }
      : {}),
  };
  const [total, items] = await Promise.all([
    prisma.supplier.count({ where }),
    prisma.supplier.findMany({ where, orderBy: [{ name: 'asc' }, { id: 'asc' }], skip: (f.page - 1) * PAGE_SIZE, take: PAGE_SIZE }),
  ]);
  return { filter: f, total, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)), items };
}

export async function getSupplier(id: string, actor: Actor) {
  assertCan(actor, 'suppliers.view');
  const s = await prisma.supplier.findUnique({ where: { id } });
  if (!s) throw new AppError('NOT_FOUND');
  return s;
}

export async function saveSupplier(id: string | null, raw: unknown, actor: Actor): Promise<string> {
  assertCan(actor, 'suppliers.manage');
  const data = parseOrThrow(supplierSchema, raw);
  return withDbErrors(() =>
    withTransaction(async (tx) => {
      if (!id) {
        const code = `PBF-${String(await nextNumber(tx, 'SUP', 'ALL')).padStart(4, '0')}`;
        const created = await tx.supplier.create({ data: { ...data, code } });
        await writeAudit(tx, { ...auditMeta(actor), action: 'supplier.created', entity: 'supplier', entity_id: created.id, after: { code, ...data } });
        return created.id;
      }
      const current = await tx.supplier.findUnique({ where: { id } });
      if (!current) throw new AppError('NOT_FOUND');
      const diff = diffFields(current as unknown as Record<string, unknown>, data);
      if (diff) {
        await tx.supplier.update({ where: { id }, data });
        await writeAudit(tx, { ...auditMeta(actor), action: 'supplier.updated', entity: 'supplier', entity_id: id, ...diff });
      }
      return id;
    }),
  );
}
