'use server';

import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { runFormAction } from '@/lib/actions';
import type { ActionState } from '@/lib/forms';
import { saveSupplier } from './service';

export async function saveSupplierAction(id: string | null, _prev: ActionState, fd: FormData): Promise<ActionState> {
  let savedId = '';
  const state = await runFormAction(fd, 'suppliers.manage', async (actor, values) => {
    savedId = await saveSupplier(id, values, actor);
    return 'Data pemasok tersimpan.';
  });
  if (!state.ok) return state;
  revalidatePath('/pemasok');
  if (!id) redirect(`/pemasok/${savedId}?baru=1`);
  revalidatePath(`/pemasok/${id}`);
  return state;
}
