'use client';

import { useActionState } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { valueOf } from '@/components/ui/action-form';
import { SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';

export function ConversionForm({ action, units, baseCode, canPrice }: {
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  units: { value: string; label: string }[];
  baseCode: string;
  canPrice: boolean;
}) {
  const [state, formAction] = useActionState(action, initialActionState);
  const v = (k: string) => valueOf(state, {}, k);
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-3 rounded-md bg-gray-50 p-3" noValidate>
      <p className="text-sm font-medium">Tambah atau ubah satuan</p>
      {state.message ? <Alert tone={state.ok ? 'success' : 'error'}>{state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai merah.' : state.message}</Alert> : null}
      <div className="grid gap-3 sm:grid-cols-4">
        <SelectField label="Satuan" name="unit_id" options={units} placeholder="— Pilih —" defaultValue={v('unit_id')} error={state.fields?.unit_id} />
        <FormField label={`Isi (dalam ${baseCode})`} name="factor_to_base" inputMode="numeric" defaultValue={v('factor_to_base')} error={state.fields?.factor_to_base} />
        <FormField label="Barcode" name="barcode" defaultValue={v('barcode')} error={state.fields?.barcode} />
        {canPrice ? <FormField label="Harga jual satuan (Rp, opsional)" name="selling_price" inputMode="decimal" defaultValue={v('selling_price')} error={state.fields?.selling_price} /> : null}
      </div>
      {canPrice ? <FormField label="Alasan perubahan harga (bila mengubah harga)" name="price_reason" defaultValue={v('price_reason')} error={state.fields?.price_reason} /> : null}
      <SubmitButton size="sm">Simpan satuan</SubmitButton>
    </form>
  );
}
