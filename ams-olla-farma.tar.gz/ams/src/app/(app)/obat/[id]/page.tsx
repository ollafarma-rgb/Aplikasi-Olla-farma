import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { formatRupiah } from '@/lib/money/format';
import { getMedicine } from '@/modules/medicines/service';
import { referenceOptions } from '@/modules/references/service';
import { DRUG_CLASS_LABELS, PRODUCT_TYPE_LABELS } from '@/modules/medicines/schemas';
import {
  removeConversionAction, saveConversionAction, setMedicineActiveAction, updateMedicineAction,
} from '@/modules/medicines/actions';
import { Alert } from '@/components/ui/alert';
import { ActionForm } from '@/components/ui/action-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PageHeader, Section } from '@/components/ui/page';
import { MedicineForm } from '../medicine-form';
import { toOptions } from '../options';
import { ConversionForm } from './conversion-form';

export const metadata: Metadata = { title: 'Detail obat' };

const PRICE_TYPE_LABEL: Record<string, string> = { SELLING: 'Harga jual', PURCHASE_DEFAULT: 'Harga beli acuan', SELLING_UNIT: 'Harga jual satuan' };
const dateTime = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });

export default async function MedicineDetailPage({ params, searchParams }: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ baru?: string; nonaktif?: string }>;
}) {
  const actor = await requirePageActor('medicines.view');
  const { id } = await params;
  const sp = await searchParams;
  let m;
  try {
    m = await getMedicine(id, actor);
  } catch (e) {
    if (e instanceof AppError && e.code === 'NOT_FOUND') notFound();
    throw e;
  }
  const canManage = can(actor, 'medicines.manage');
  const canPrice = can(actor, 'medicines.price.manage');
  const refs = await referenceOptions();
  const keep = [m.category_id, m.base_unit_id, ...m.conversions.map((c) => c.unit_id)].filter(Boolean) as string[];
  const opts = toOptions(refs, keep);
  const salesUnits = [
    { value: m.base_unit_id, label: `${m.base_unit.code} — ${m.base_unit.name} (satuan dasar)` },
    ...m.conversions.map((c) => ({ value: c.unit_id, label: `${c.unit.code} — isi ${c.factor_to_base} ${m.base_unit.code}` })),
  ];
  const yes = (b: boolean) => (b ? 'on' : '');
  const initial: Record<string, string> = {
    sku: m.sku, barcode: m.barcode ?? '', name: m.name, generic_name: m.generic_name ?? '', brand: m.brand ?? '',
    category_id: m.category_id ?? '', product_type: m.product_type, drug_class: m.drug_class, dosage_form: m.dosage_form ?? '',
    strength: m.strength ?? '', manufacturer_id: m.manufacturer_id ?? '', registration_no: m.registration_no ?? '',
    base_unit_id: m.base_unit_id, purchase_unit_id: m.purchase_unit_id, sales_unit_id: m.sales_unit_id,
    selling_price: m.selling_price, default_purchase_price: m.default_purchase_price ?? '',
    min_stock: String(m.min_stock), max_stock: m.max_stock === null ? '' : String(m.max_stock), storage_location_id: m.storage_location_id ?? '',
    requires_prescription: yes(m.requires_prescription), is_owa: yes(m.is_owa), is_precursor: yes(m.is_precursor),
    is_oot: yes(m.is_oot), is_lasa: yes(m.is_lasa), is_high_alert: yes(m.is_high_alert),
  };

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <PageHeader
        title={m.name}
        description={`${m.sku} · ${PRODUCT_TYPE_LABELS[m.product_type]} · ${DRUG_CLASS_LABELS[m.drug_class]}`}
        back={{ href: '/obat', label: 'Data Obat' }}
        actions={m.is_active ? <Badge tone="green">Aktif</Badge> : <Badge>Nonaktif</Badge>}
      />
      {sp.baru ? <Alert tone="success">Obat tersimpan. Tambahkan satuan lain (strip, box) di bawah bila perlu.</Alert> : null}
      {sp.nonaktif ? <Alert>Obat disimpan sebagai NONAKTIF karena belum ada harga jual. Apoteker atau pemilik perlu mengisi harga lalu mengaktifkannya.</Alert> : null}

      <Section title="Data obat">
        {canManage ? (
          <MedicineForm action={updateMedicineAction.bind(null, m.id)} initial={initial} options={{ ...opts, salesUnits }}
            canPrice={canPrice} canRegulatory={can(actor, 'medicines.regulatory.manage')} isNew={false} />
        ) : (
          <dl className="grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
            {[
              ['Nama generik', m.generic_name], ['Merek', m.brand], ['Kategori', m.category?.name], ['Barcode', m.barcode],
              ['Bentuk / kekuatan', [m.dosage_form, m.strength].filter(Boolean).join(' ')], ['Pabrik', m.manufacturer?.name],
              ['NIE', m.registration_no], ['Satuan dasar', m.base_unit.code], ['Harga jual', `${formatRupiah(m.selling_price)} / ${m.base_unit.code}`],
              ['Wajib resep', m.requires_prescription ? 'Ya' : 'Tidak'], ['Lokasi', m.storage_location?.name], ['Stok minimum', String(m.min_stock)],
            ].map(([k, val]) => (
              <div key={k} className="flex justify-between gap-4 border-b border-gray-100 py-1"><dt className="text-gray-600">{k}</dt><dd className="text-right">{val || '—'}</dd></div>
            ))}
          </dl>
        )}
      </Section>

      <Section title="Satuan dan konversi">
        <table className="mb-4 w-full text-sm">
          <thead className="text-left text-xs uppercase tracking-wide text-gray-500">
            <tr><th className="py-1">Satuan</th><th className="py-1">Isi</th><th className="py-1">Barcode</th><th className="py-1 text-right">Harga jual</th><th /></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            <tr>
              <td className="py-2 font-medium">{m.base_unit.code} <span className="text-xs text-gray-500">(dasar)</span></td>
              <td className="py-2">1 {m.base_unit.code}</td>
              <td className="py-2 font-mono text-xs">{m.barcode ?? '—'}</td>
              <td className="py-2 text-right">{formatRupiah(m.selling_price)}</td>
              <td />
            </tr>
            {m.conversions.map((c) => (
              <tr key={c.id}>
                <td className="py-2 font-medium">{c.unit.code}</td>
                <td className="py-2">{c.factor_to_base} {m.base_unit.code}</td>
                <td className="py-2 font-mono text-xs">{c.barcode ?? '—'}</td>
                <td className="py-2 text-right">{c.selling_price ? formatRupiah(c.selling_price) : <span className="text-gray-500">mengikuti satuan dasar</span>}</td>
                <td className="py-2 text-right">
                  {canManage ? (
                    <ActionForm action={removeConversionAction.bind(null, m.id, c.id)} confirmText={`Hapus satuan ${c.unit.code}?`}>
                      <Button type="submit" variant="ghost" size="sm">Hapus</Button>
                    </ActionForm>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {canManage ? (
          <ConversionForm action={saveConversionAction.bind(null, m.id)} baseCode={m.base_unit.code} canPrice={canPrice}
            units={opts.units.filter((u) => u.value !== m.base_unit_id)} />
        ) : null}
      </Section>

      <Section title="Riwayat harga">
        {m.price_history.length === 0 ? <p className="text-sm text-gray-600">Belum ada riwayat.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase tracking-wide text-gray-500">
                <tr><th className="py-1">Waktu</th><th className="py-1">Jenis</th><th className="py-1 text-right">Lama</th><th className="py-1 text-right">Baru</th><th className="py-1">Oleh</th><th className="py-1">Alasan</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {m.price_history.map((h) => (
                  <tr key={h.id}>
                    <td className="whitespace-nowrap py-1.5">{dateTime.format(h.changed_at)}</td>
                    <td className="py-1.5">{PRICE_TYPE_LABEL[h.price_type] ?? h.price_type} / {h.unit.code}</td>
                    <td className="py-1.5 text-right">{h.old_price ? formatRupiah(h.old_price) : '—'}</td>
                    <td className="py-1.5 text-right">{h.new_price ? formatRupiah(h.new_price) : '—'}</td>
                    <td className="py-1.5">{h.changer.full_name}</td>
                    <td className="py-1.5 text-gray-600">{h.reason ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Section>

      {canManage ? (
        <Section title="Status">
          <ActionForm action={setMedicineActiveAction.bind(null, m.id, !m.is_active)}
            confirmText={m.is_active ? 'Nonaktifkan obat ini? Obat tidak akan tampil di kasir.' : undefined}>
            <p className="mb-2 text-sm text-gray-600">Obat tidak pernah dihapus agar riwayat transaksi tetap utuh. Obat nonaktif tidak tampil di kasir.</p>
            <Button type="submit" variant={m.is_active ? 'danger' : 'primary'}>{m.is_active ? 'Nonaktifkan obat' : 'Aktifkan obat'}</Button>
          </ActionForm>
        </Section>
      ) : null}
    </div>
  );
}
