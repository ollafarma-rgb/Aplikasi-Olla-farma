import type { DrugClassCode } from '@/modules/medicines/schemas';

export function drugClassTone(d: DrugClassCode): 'gray' | 'green' | 'red' | 'amber' | 'blue' {
  switch (d) {
    case 'BEBAS': return 'green';
    case 'BEBAS_TERBATAS': return 'blue';
    case 'KERAS': return 'red';
    case 'NARKOTIKA':
    case 'PSIKOTROPIKA': return 'amber';
    default: return 'gray';
  }
}
