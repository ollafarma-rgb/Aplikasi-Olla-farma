import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { formatRupiah } from '@/lib/money/format';
import { listMedicines } from '@/modules/medicines/service';
import { DRUG_CLASS_LABELS, DRUG_CLASSES } from '@/modules/medicines/schemas';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';
import { drugClassTone } from './labels';

export const metadata: Metadata = { title: 'Data Obat' };

type SP = Promise<Record<string, string | undefined>>;

export default async function MedicinesPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('medicines.view');
  const sp = await searchParams;
  const data = await listMedicines(sp, actor);
  const f = data.filter;

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Data Obat"
        description="Katalog obat, alat kesehatan, dan BMHP."
        actions={can(actor, 'medicines.manage') ? (
          <>
            <LinkButton href="/obat/referensi" variant="secondary">Referensi</LinkButton>
            <LinkButton href="/obat/baru">Tambah obat</LinkButton>
          </>
        ) : null}
      />

      <form method="get" className="mb-3 flex flex-wrap gap-2" role="search">
        <input name="q" defaultValue={f.q} placeholder="Cari nama, generik, merek, SKU, atau scan barcode"
          aria-label="Cari obat" autoFocus
          className="h-10 min-w-0 flex-1 rounded-md border border-gray-300 bg-white px-3 text-sm focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-100" />
        <select name="golongan" defaultValue={f.golongan ?? ''} aria-label="Golongan" className="h-10 rounded-md border border-gray-300 bg-white px-2 text-sm">
          <option value="">Semua golongan</option>
          {DRUG_CLASSES.map((d) => <option key={d} value={d}>{DRUG_CLASS_LABELS[d]}</option>)}
        </select>
        <select name="status" defaultValue={f.status} aria-label="Status" className="h-10 rounded-md border border-gray-300 bg-white px-2 text-sm">
          <option value="aktif">Aktif</option>
          <option value="nonaktif">Nonaktif</option>
          <option value="semua">Semua</option>
        </select>
        <button type="submit" className="h-10 rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Cari</button>
      </form>

      {data.items.length === 0 ? (
        <EmptyState>{f.q ? `Tidak ada obat yang cocok dengan "${f.q}".` : 'Belum ada data obat.'}</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-3 py-2">Obat</th>
                <th className="px-3 py-2">SKU</th>
                <th className="px-3 py-2">Golongan</th>
                <th className="px-3 py-2 text-right">Harga jual</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {data.items.map((m) => (
                <tr key={m.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2">
                    <Link href={`/obat/${m.id}`} className="font-medium text-brand-800 hover:underline">{m.name}</Link>
                    <div className="text-xs text-gray-500">{[m.generic_name, m.brand, m.category?.name].filter(Boolean).join(' · ')}</div>
                    <div className="mt-0.5 flex gap-1">
                      {m.requires_prescription ? <Badge tone="red">Resep</Badge> : null}
                      {m.is_owa ? <Badge tone="amber">OWA</Badge> : null}
                      {m.is_lasa ? <Badge tone="amber">LASA</Badge> : null}
                      {m.is_high_alert ? <Badge tone="red">High alert</Badge> : null}
                    </div>
                  </td>
                  <td className="px-3 py-2 font-mono text-xs">{m.sku}</td>
                  <td className="px-3 py-2"><Badge tone={drugClassTone(m.drug_class)}>{DRUG_CLASS_LABELS[m.drug_class]}</Badge></td>
                  <td className="whitespace-nowrap px-3 py-2 text-right">{formatRupiah(m.selling_price)} / {m.base_unit.code}</td>
                  <td className="px-3 py-2">{m.is_active ? <Badge tone="green">Aktif</Badge> : <Badge>Nonaktif</Badge>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={f.page} pages={data.pages} total={data.total} basePath="/obat"
        params={{ q: f.q || undefined, golongan: f.golongan, status: f.status }} />
    </div>
  );
}
