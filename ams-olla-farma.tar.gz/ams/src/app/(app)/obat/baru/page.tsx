import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { referenceOptions } from '@/modules/references/service';
import { createMedicineAction } from '@/modules/medicines/actions';
import { PageHeader } from '@/components/ui/page';
import { MedicineForm } from '../medicine-form';
import { toOptions } from '../options';

export const metadata: Metadata = { title: 'Tambah obat' };

export default async function NewMedicinePage() {
  const actor = await requirePageActor('medicines.manage');
  const opts = toOptions(await referenceOptions());
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Tambah obat" back={{ href: '/obat', label: 'Data Obat' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        <MedicineForm action={createMedicineAction} initial={{ min_stock: '0' }} options={{ ...opts, salesUnits: opts.units }}
          canPrice={can(actor, 'medicines.price.manage')} canRegulatory={can(actor, 'medicines.regulatory.manage')} isNew />
      </div>
    </div>
  );
}
