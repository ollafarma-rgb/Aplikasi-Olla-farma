import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { listReferences, REFERENCE_KINDS, type ReferenceKind } from '@/modules/references/service';
import { deleteReferenceAction, saveReferenceAction } from '@/modules/references/actions';
import { ActionForm } from '@/components/ui/action-form';
import { Button } from '@/components/ui/button';
import { EmptyState, PageHeader, Section } from '@/components/ui/page';
import { cn } from '@/lib/utilities/cn';
import { ReferenceForm } from './reference-form';

export const metadata: Metadata = { title: 'Referensi obat' };

const LABELS: Record<ReferenceKind, string> = { kategori: 'Kategori', satuan: 'Satuan', pabrik: 'Pabrik', lokasi: 'Lokasi rak' };

export default async function ReferencesPage({ searchParams }: { searchParams: Promise<{ jenis?: string; edit?: string }> }) {
  const actor = await requirePageActor('medicines.view');
  const sp = await searchParams;
  const kind: ReferenceKind = (REFERENCE_KINDS as readonly string[]).includes(sp.jenis ?? '') ? (sp.jenis as ReferenceKind) : 'kategori';
  const rows = await listReferences(kind, actor);
  const canEdit = can(actor, kind === 'satuan' ? 'settings.manage' : 'medicines.manage');
  const editing = sp.edit ? rows.find((r) => r.id === sp.edit) : undefined;

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader title="Referensi obat" description="Data pilihan yang dipakai di form obat." back={{ href: '/obat', label: 'Data Obat' }} />
      <nav className="flex gap-1 border-b border-gray-200" aria-label="Jenis referensi">
        {REFERENCE_KINDS.map((k) => (
          <Link key={k} href={`/obat/referensi?jenis=${k}`} aria-current={k === kind ? 'page' : undefined}
            className={cn('-mb-px border-b-2 px-3 py-2 text-sm', k === kind ? 'border-brand-600 font-medium text-brand-800' : 'border-transparent text-gray-600 hover:text-gray-900')}>
            {LABELS[k]}
          </Link>
        ))}
      </nav>

      {canEdit ? (
        <Section title={editing ? `Ubah ${LABELS[kind].toLowerCase()}: ${editing.label}` : `Tambah ${LABELS[kind].toLowerCase()}`}
          actions={editing ? <Link href={`/obat/referensi?jenis=${kind}`} className="text-sm text-gray-600 hover:text-gray-900">Batal</Link> : null}>
          <ReferenceForm key={editing?.id ?? 'baru'} kind={kind} editing={Boolean(editing)} initial={editing?.values ?? {}}
            action={saveReferenceAction.bind(null, kind, editing?.id ?? null)} />
        </Section>
      ) : kind === 'satuan' ? <p className="text-sm text-gray-600">Satuan dikelola pemilik apotek.</p> : null}

      {rows.length === 0 ? <EmptyState>Belum ada data {LABELS[kind].toLowerCase()}.</EmptyState> : (
        <ul className="divide-y divide-gray-100 rounded-lg border border-gray-200 bg-white">
          {rows.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2 text-sm">
              <div>
                <p className="font-medium">{r.label}</p>
                <p className="text-xs text-gray-500">{[r.detail, `dipakai ${r.used} obat`].filter(Boolean).join(' · ')}</p>
              </div>
              {canEdit ? (
                <div className="flex items-center gap-2">
                  <Link href={`/obat/referensi?jenis=${kind}&edit=${r.id}`} className="text-sm text-brand-700 hover:underline">Ubah</Link>
                  {r.used === 0 ? (
                    <ActionForm action={deleteReferenceAction.bind(null, kind, r.id)} confirmText={`Hapus ${r.label}?`}>
                      <Button type="submit" variant="ghost" size="sm">Hapus</Button>
                    </ActionForm>
                  ) : null}
                </div>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
