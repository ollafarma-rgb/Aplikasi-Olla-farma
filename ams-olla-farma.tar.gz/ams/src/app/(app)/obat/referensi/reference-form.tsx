'use client';

import { useActionState } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { checkedOf, valueOf } from '@/components/ui/action-form';
import { CheckboxField, SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';

type Kind = 'kategori' | 'satuan' | 'pabrik' | 'lokasi';

const CONDITIONS = [
  { value: 'ROOM', label: 'Suhu ruang' },
  { value: 'COOL', label: 'Sejuk (8–15 °C)' },
  { value: 'REFRIGERATED', label: 'Lemari pendingin (2–8 °C)' },
  { value: 'SPECIAL_CABINET', label: 'Lemari khusus narkotika/psikotropika' },
];

export function ReferenceForm({ kind, action, initial, editing }: {
  kind: Kind;
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  initial: Record<string, string>;
  editing: boolean;
}) {
  const [state, formAction] = useActionState(action, initialActionState);
  const v = (k: string) => valueOf(state, initial, k);
  const e = (k: string) => state.fields?.[k];
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-3" noValidate>
      {state.message ? <Alert tone={state.ok ? 'success' : 'error'}>{state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai merah.' : state.message}</Alert> : null}
      <div className="grid gap-3 sm:grid-cols-3">
        {kind === 'satuan' || kind === 'lokasi' ? <FormField label="Kode" name="code" defaultValue={v('code')} error={e('code')} autoCapitalize="characters" /> : null}
        <FormField label={kind === 'pabrik' ? 'Nama pabrik' : kind === 'kategori' ? 'Nama kategori' : 'Nama'} name="name" defaultValue={v('name')} error={e('name')} />
        {kind === 'pabrik' ? <FormField label="Negara" name="country" defaultValue={v('country')} error={e('country')} /> : null}
        {kind === 'lokasi' ? <SelectField label="Kondisi penyimpanan" name="condition" options={CONDITIONS} defaultValue={v('condition') || 'ROOM'} error={e('condition')} /> : null}
      </div>
      {kind === 'kategori' || kind === 'satuan' ? <CheckboxField name="is_active" label="Aktif (tampil di pilihan)" defaultChecked={editing ? checkedOf(state, initial, 'is_active') : true} /> : null}
      <SubmitButton size="sm">{editing ? 'Simpan perubahan' : 'Tambah'}</SubmitButton>
    </form>
  );
}
