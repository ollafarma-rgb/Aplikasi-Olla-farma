import { STORAGE_LABELS } from '@/modules/references/service';

type Refs = {
  categories: { id: string; name: string; is_active: boolean }[];
  units: { id: string; code: string; name: string; is_active: boolean }[];
  manufacturers: { id: string; name: string }[];
  locations: { id: string; code: string; name: string; condition: keyof typeof STORAGE_LABELS }[];
};

/** Ubah data referensi menjadi pilihan dropdown (yang nonaktif disembunyikan, kecuali sedang dipakai). */
export function toOptions(r: Refs, keep: string[] = []) {
  const show = (active: boolean, id: string) => active || keep.includes(id);
  return {
    categories: r.categories.filter((c) => show(c.is_active, c.id)).map((c) => ({ value: c.id, label: c.name })),
    units: r.units.filter((u) => show(u.is_active, u.id)).map((u) => ({ value: u.id, label: `${u.code} — ${u.name}` })),
    manufacturers: r.manufacturers.map((m) => ({ value: m.id, label: m.name })),
    locations: r.locations.map((l) => ({ value: l.id, label: `${l.code} — ${l.name} (${STORAGE_LABELS[l.condition]})` })),
  };
}
