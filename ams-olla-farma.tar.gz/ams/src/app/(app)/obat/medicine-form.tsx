'use client';

import { useActionState } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { checkedOf, valueOf } from '@/components/ui/action-form';
import { CheckboxField, SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';
import { DRUG_CLASS_LABELS, DRUG_CLASSES, PRODUCT_TYPE_LABELS, PRODUCT_TYPES } from '@/modules/medicines/schemas';

type Option = { value: string; label: string };

export interface MedicineFormProps {
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  initial: Record<string, string>;
  options: { units: Option[]; categories: Option[]; manufacturers: Option[]; locations: Option[]; salesUnits: Option[] };
  canPrice: boolean;
  canRegulatory: boolean;
  isNew: boolean;
}

export function MedicineForm({ action, initial, options, canPrice, canRegulatory, isNew }: MedicineFormProps) {
  const [state, formAction] = useActionState(action, initialActionState);
  const v = (k: string) => valueOf(state, initial, k);
  const c = (k: string) => checkedOf(state, initial, k);
  const err = (k: string) => state.fields?.[k];
  // Pengguna tanpa izin regulasi tetap bisa mendaftarkan obat biasa; golongan
  // berisiko tinggi ditolak server dengan pesan jelas.
  const lockRegulatory = !isNew && !canRegulatory;

  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-6" noValidate>
      {state.message ? <Alert tone={state.ok ? 'success' : 'error'}>{state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai merah.' : state.message}</Alert> : null}

      <fieldset className="grid gap-4 sm:grid-cols-2">
        <legend className="mb-2 text-sm font-semibold text-gray-900">Identitas produk</legend>
        <FormField label="Nama obat / produk" name="name" defaultValue={v('name')} error={err('name')} required />
        <FormField label="Nama generik" name="generic_name" defaultValue={v('generic_name')} error={err('generic_name')} />
        <FormField label="Merek" name="brand" defaultValue={v('brand')} error={err('brand')} />
        <SelectField label="Kategori" name="category_id" defaultValue={v('category_id')} options={options.categories} placeholder="— Tanpa kategori —" error={err('category_id')} />
        <FormField label="SKU" name="sku" defaultValue={v('sku')} error={err('sku')} hint={isNew ? 'Kosongkan untuk dibuat otomatis (OBT-000001).' : undefined} />
        <FormField label="Barcode satuan dasar" name="barcode" defaultValue={v('barcode')} error={err('barcode')} inputMode="numeric" hint="Bisa diisi dengan scanner." />
        <FormField label="Bentuk sediaan" name="dosage_form" defaultValue={v('dosage_form')} error={err('dosage_form')} placeholder="tablet, sirup, salep…" />
        <FormField label="Kekuatan" name="strength" defaultValue={v('strength')} error={err('strength')} placeholder="500 mg" />
        <SelectField label="Pabrik" name="manufacturer_id" defaultValue={v('manufacturer_id')} options={options.manufacturers} placeholder="— Pilih —" error={err('manufacturer_id')} />
        <FormField label="Nomor izin edar (NIE)" name="registration_no" defaultValue={v('registration_no')} error={err('registration_no')} hint="Wajib untuk obat; boleh kosong untuk alkes/BMHP." />
      </fieldset>

      <fieldset className="grid gap-4 sm:grid-cols-2">
        <legend className="mb-2 text-sm font-semibold text-gray-900">Golongan dan regulasi</legend>
        {lockRegulatory ? <p className="text-xs text-gray-600 sm:col-span-2">Golongan dan tanda regulasi hanya bisa diubah apoteker.</p> : null}
        <SelectField label="Jenis produk" name="product_type" defaultValue={v('product_type')} placeholder="— Pilih —"
          options={PRODUCT_TYPES.map((p) => ({ value: p, label: PRODUCT_TYPE_LABELS[p] }))} error={err('product_type')} />
        <SelectField label="Golongan" name="drug_class" defaultValue={v('drug_class')} placeholder="— Pilih —"
          options={DRUG_CLASSES.map((d) => ({ value: d, label: DRUG_CLASS_LABELS[d] }))} error={err('drug_class')}
          disabled={lockRegulatory} />
        {lockRegulatory ? <input type="hidden" name="drug_class" value={initial.drug_class} /> : null}
        <div className="space-y-2 sm:col-span-2">
          {(['requires_prescription', 'is_owa', 'is_precursor', 'is_oot'] as const).map((k) => (
            <div key={k}>
              <CheckboxField name={k} defaultChecked={c(k)} error={err(k)} disabled={lockRegulatory}
                label={{ requires_prescription: 'Wajib resep dokter', is_owa: 'Obat Wajib Apotek (OWA)', is_precursor: 'Mengandung prekursor farmasi', is_oot: 'Obat-obat tertentu (OOT)' }[k]} />
              {lockRegulatory && initial[k] === 'on' ? <input type="hidden" name={k} value="on" /> : null}
            </div>
          ))}
          <CheckboxField name="is_lasa" defaultChecked={c('is_lasa')} label="LASA (look-alike sound-alike)" />
          <CheckboxField name="is_high_alert" defaultChecked={c('is_high_alert')} label="High alert" />
        </div>
      </fieldset>

      <fieldset className="grid gap-4 sm:grid-cols-3">
        <legend className="mb-2 text-sm font-semibold text-gray-900">Satuan</legend>
        <SelectField label="Satuan dasar (stok dihitung dalam satuan ini)" name="base_unit_id" defaultValue={v('base_unit_id')} options={options.units} placeholder="— Pilih —" error={err('base_unit_id')} />
        <SelectField label="Satuan beli" name="purchase_unit_id" defaultValue={v('purchase_unit_id')} options={options.salesUnits} placeholder="— Pilih —" error={err('purchase_unit_id')} />
        <SelectField label="Satuan jual" name="sales_unit_id" defaultValue={v('sales_unit_id')} options={options.salesUnits} placeholder="— Pilih —" error={err('sales_unit_id')} />
        {isNew ? <p className="text-xs text-gray-600 sm:col-span-3">Satuan lain (strip, box) ditambahkan setelah obat disimpan. Untuk sekarang pilih satuan dasar sebagai satuan beli dan jual bila belum ada konversi.</p> : null}
      </fieldset>

      <fieldset className="grid gap-4 sm:grid-cols-3">
        <legend className="mb-2 text-sm font-semibold text-gray-900">Harga dan stok</legend>
        {canPrice ? (
          <>
            <FormField label="Harga jual per satuan dasar (Rp)" name="selling_price" defaultValue={v('selling_price')} error={err('selling_price')} inputMode="decimal" />
            <FormField label="Harga beli acuan per satuan beli (Rp)" name="default_purchase_price" defaultValue={v('default_purchase_price')} error={err('default_purchase_price')} inputMode="decimal" />
            <FormField label="Alasan perubahan harga" name="price_reason" defaultValue={v('price_reason')} error={err('price_reason')} hint={isNew ? undefined : 'Wajib bila harga diubah.'} />
          </>
        ) : (
          <p className="text-xs text-gray-600 sm:col-span-3">Harga diisi apoteker atau pemilik.{isNew ? ' Obat baru disimpan nonaktif sampai harga diisi.' : ''}</p>
        )}
        <FormField label="Stok minimum" name="min_stock" defaultValue={v('min_stock') || '0'} error={err('min_stock')} inputMode="numeric" />
        <FormField label="Stok maksimum (opsional)" name="max_stock" defaultValue={v('max_stock')} error={err('max_stock')} inputMode="numeric" />
        <SelectField label="Lokasi penyimpanan" name="storage_location_id" defaultValue={v('storage_location_id')} options={options.locations} placeholder="— Pilih —" error={err('storage_location_id')} />
      </fieldset>

      <SubmitButton>{isNew ? 'Simpan obat' : 'Simpan perubahan'}</SubmitButton>
    </form>
  );
}
