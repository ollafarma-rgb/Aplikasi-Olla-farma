import { requirePageActor } from '@/lib/auth/server';
import { getPharmacyProfile, getReceiptSettings } from '@/modules/settings/service';
import { savePharmacyProfileAction, saveReceiptSettingsAction } from '@/modules/settings/actions';
import { revalidatePath } from 'next/cache';

async function handleSaveProfile(formData: FormData) {
  'use server';
  await savePharmacyProfileAction(formData);
  revalidatePath('/pengaturan');
}

async function handleSaveReceipt(formData: FormData) {
  'use server';
  await saveReceiptSettingsAction(formData);
  revalidatePath('/pengaturan');
}

export default async function PengaturanPage() {
  await requirePageActor('settings.manage');

  const [profile, receipt] = await Promise.all([
    getPharmacyProfile(),
    getReceiptSettings(),
  ]);

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Pengaturan</h1>
        <p className="text-sm text-gray-500 mt-1">Konfigurasi profil apotek dan sistem</p>
      </div>

      {/* Profil Apotek */}
      <section className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 bg-gray-50">
          <h2 className="text-base font-semibold text-gray-800">Profil Apotek</h2>
          <p className="text-xs text-gray-500 mt-0.5">Data ini tampil di struk dan dokumen resmi</p>
        </div>
        <form action={handleSaveProfile} className="p-6 space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Nama Apotek <span className="text-red-500">*</span></label>
              <input
                name="name"
                defaultValue={profile.name}
                required
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Badan Hukum</label>
              <input
                name="legal_entity"
                defaultValue={profile.legal_entity}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">NIB</label>
              <input
                name="nib"
                defaultValue={profile.nib}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">KBLI</label>
              <input
                name="kbli"
                defaultValue={profile.kbli}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nomor SIA</label>
              <input
                name="sia_number"
                defaultValue={profile.sia_number ?? ''}
                placeholder="Belum terbit"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Telepon</label>
              <input
                name="phone"
                defaultValue={profile.phone}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                name="email"
                type="email"
                defaultValue={profile.email}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Jam Operasional</label>
              <input
                name="operating_hours"
                defaultValue={profile.operating_hours}
                placeholder="mis. 08:00–22:00"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Apoteker Penanggung Jawab</label>
              <input
                name="responsible_pharmacist"
                defaultValue={profile.responsible_pharmacist}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Alamat Lengkap</label>
              <textarea
                name="address"
                defaultValue={profile.address}
                rows={3}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-blue-600 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              Simpan Profil
            </button>
          </div>
        </form>
      </section>

      {/* Pengaturan Struk */}
      <section className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 bg-gray-50">
          <h2 className="text-base font-semibold text-gray-800">Pengaturan Struk</h2>
          <p className="text-xs text-gray-500 mt-0.5">Konfigurasi printer thermal untuk POS</p>
        </div>
        <form action={handleSaveReceipt} className="p-6 space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Lebar Kertas (mm)</label>
              <select
                name="paper_width_mm"
                defaultValue={String(receipt.paper_width_mm)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              >
                <option value="58">58 mm</option>
                <option value="80">80 mm</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tampilkan Nama Apoteker</label>
              <select
                name="show_pharmacist_name"
                defaultValue={receipt.show_pharmacist_name ? 'true' : 'false'}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              >
                <option value="true">Ya, tampilkan</option>
                <option value="false">Tidak</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Pesan di Footer Struk</label>
              <input
                name="footer"
                defaultValue={receipt.footer}
                placeholder="mis. Semoga lekas sembuh"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="bg-blue-600 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              Simpan Pengaturan Struk
            </button>
          </div>
        </form>
      </section>

      {/* Info sistem — read only */}
      <section className="bg-gray-50 rounded-xl border border-gray-200 p-5">
        <h2 className="text-sm font-semibold text-gray-700 mb-3">Informasi Sistem</h2>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
          <div>
            <dt className="text-gray-500">Status Pajak</dt>
            <dd className="font-medium text-gray-800">Non-PKP (tidak memungut PPN)</dd>
          </div>
          <div>
            <dt className="text-gray-500">Diskon</dt>
            <dd className="font-medium text-gray-800">Berbasis aturan periode</dd>
          </div>
          <div>
            <dt className="text-gray-500">Zona Waktu</dt>
            <dd className="font-medium text-gray-800">Asia/Jakarta (WIB)</dd>
          </div>
          <div>
            <dt className="text-gray-500">Mata Uang</dt>
            <dd className="font-medium text-gray-800">IDR (Rupiah)</dd>
          </div>
        </dl>
      </section>
    </div>
  );
}
