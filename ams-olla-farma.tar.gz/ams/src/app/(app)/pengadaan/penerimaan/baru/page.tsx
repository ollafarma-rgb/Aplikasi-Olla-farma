import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { getPurchaseOrder, listReceivablePurchaseOrders } from '@/modules/procurement/service';
import { EmptyState, PageHeader } from '@/components/ui/page';
import { GoodsReceiptForm } from '../gr-form';

export const metadata: Metadata = { title: 'Catat penerimaan barang' };
type SP = Promise<{ po?: string }>;

export default async function NewGoodsReceiptPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('procurement.receive.record');
  const { po: poId } = await searchParams;
  const orders = await listReceivablePurchaseOrders(actor);

  if (!poId) {
    return (
      <div className="mx-auto max-w-2xl">
        <PageHeader title="Catat penerimaan barang" description="Pilih Surat Pesanan yang barangnya datang." back={{ href: '/pengadaan/penerimaan', label: 'Penerimaan Barang' }} />
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          {orders.length === 0 ? <EmptyState>Tidak ada SP yang sudah terkirim dan menunggu penerimaan.</EmptyState> : (
            <form method="get" className="flex flex-wrap items-end gap-2">
              <label className="flex-1">
                <span className="mb-1 block text-sm font-medium text-gray-800">Surat Pesanan</span>
                <select name="po" className="h-10 w-full rounded-md border border-gray-300 bg-white px-2 text-sm" defaultValue="">
                  <option value="" disabled>— Pilih SP —</option>
                  {orders.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
                </select>
              </label>
              <button type="submit" className="h-10 rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lanjut</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  const po = await getPurchaseOrder(actor, poId);
  const rows = po.items.map((it) => ({
    poItemId: it.id, label: `${it.medicine.name} (${it.medicine.sku})`, unitCode: it.unit.code,
    qtyOrdered: it.qty_ordered, qtyReceivedBase: it.qty_received_base,
  }));

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title={`Penerimaan untuk ${po.po_no}`} description={po.supplier.name} back={{ href: '/pengadaan/penerimaan/baru', label: 'Pilih SP lain' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        <GoodsReceiptForm poId={po.id} rows={rows} />
      </div>
    </div>
  );
}
