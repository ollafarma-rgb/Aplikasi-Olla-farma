import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { getGoodsReceipt } from '@/modules/procurement/service';
import { cancelGoodsReceiptAction, postGoodsReceiptAction } from '@/modules/procurement/actions';
import { GR_STATUS_LABELS, RECEIPT_CONDITION_LABELS } from '@/modules/procurement/schemas';
import { ActionForm } from '@/components/ui/action-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PageHeader, Section } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail penerimaan barang' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const statusTone = { DRAFT: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;

export default async function GoodsReceiptDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('procurement.view');
  const { id } = await params;
  let gr;
  try { gr = await getGoodsReceipt(actor, id); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }
  const isDraft = gr.status === 'DRAFT';
  const isChecker = gr.checked_by === actor.id;
  const canPost = can(actor, 'procurement.receive.post');

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader title={gr.gr_no} description={`${gr.supplier.name}${gr.po ? ` · ${gr.po.po_no}` : ''} · dicatat ${gr.checker.full_name} · ${dt.format(gr.received_at)}`}
        back={{ href: '/pengadaan/penerimaan', label: 'Penerimaan Barang' }} actions={<Badge tone={statusTone[gr.status]}>{GR_STATUS_LABELS[gr.status]}</Badge>} />
      {gr.supplier_do_no ? <p className="text-sm text-gray-600">No. faktur/surat jalan: {gr.supplier_do_no}</p> : null}

      <Section title="Rincian">
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Obat</th><th className="px-3 py-2">Batch</th><th className="px-3 py-2">ED</th><th className="px-3 py-2 text-right">Jumlah</th><th className="px-3 py-2">Kondisi</th><th className="px-3 py-2">Batch tercatat</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {gr.items.map((it) => (
                <tr key={it.id}>
                  <td className="px-3 py-2">{it.medicine.name}<div className="text-xs text-gray-500">{it.medicine.sku}</div></td>
                  <td className="px-3 py-2">{it.batch_no}</td>
                  <td className="px-3 py-2">{dt.format(it.expiry_date)}</td>
                  <td className="px-3 py-2 text-right">{it.qty} {it.unit.code} ({it.qty_base} satuan dasar)</td>
                  <td className="px-3 py-2">{RECEIPT_CONDITION_LABELS[it.condition]}</td>
                  <td className="px-3 py-2">{it.batch ? <Badge tone="green">Ya</Badge> : <span className="text-xs text-gray-400">—</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {isDraft ? (
        <Section title="Tindakan">
          {canPost ? (
            isChecker ? (
              <p className="text-sm text-gray-600">Anda mencatat penerimaan ini, jadi tidak bisa memposting sendiri. Minta apoteker atau pemilik lain untuk memposting.</p>
            ) : (
              <ActionForm action={postGoodsReceiptAction.bind(null, gr.id)} confirmText="Posting penerimaan ini? Batch baru dan stok akan langsung dibuat.">
                <Button type="submit">Posting &amp; buat batch</Button>
              </ActionForm>
            )
          ) : <p className="text-sm text-gray-600">Menunggu diposting apoteker atau pemilik.</p>}
          {can(actor, 'procurement.receive.record') ? (
            <div className="mt-3">
              <ActionForm action={cancelGoodsReceiptAction.bind(null, gr.id)} confirmText="Batalkan draf penerimaan ini?">
                <Button type="submit" variant="ghost">Batalkan draf</Button>
              </ActionForm>
            </div>
          ) : null}
        </Section>
      ) : gr.posted_at ? (
        <p className="text-sm text-gray-600">Diposting {gr.poster?.full_name ?? ''} · {dt.format(gr.posted_at)}.</p>
      ) : null}
    </div>
  );
}
