'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { createGoodsReceiptAction } from '@/modules/procurement/actions';
import { initialActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';
import { RECEIPT_CONDITIONS, RECEIPT_CONDITION_LABELS } from '@/modules/procurement/schemas';

type Row = { poItemId: string; label: string; unitCode: string; qtyOrdered: number; qtyReceivedBase: number };

export function GoodsReceiptForm({ poId, rows }: { poId: string; rows: Row[] }) {
  const [state, formAction] = useActionState(createGoodsReceiptAction, initialActionState);

  if (state.ok && state.data?.id) {
    return (
      <div className="space-y-3">
        <Alert tone="success">Penerimaan {state.data.grNo} dicatat sebagai draf. Minta apoteker/pemilik lain memposting.</Alert>
        <div className="flex gap-2">
          <Link href={`/pengadaan/penerimaan/${state.data.id}`} className="inline-flex h-10 items-center rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lihat draf</Link>
          <Link href="/pengadaan/penerimaan" className="inline-flex h-10 items-center rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Daftar penerimaan</Link>
        </div>
      </div>
    );
  }

  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message && !state.ok ? <Alert tone="error">{state.message}</Alert> : null}
      <input type="hidden" name="po_id" value={poId} />
      <input type="hidden" name="row_ids" value={rows.map((r) => r.poItemId).join(',')} />
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Nomor faktur/surat jalan pemasok (opsional)" name="supplier_do_no" error={state.fields?.supplier_do_no} />
        <FormField label="Tanggal terima" name="received_at" type="date" defaultValue={new Date().toISOString().slice(0, 10)} error={state.fields?.received_at} />
      </div>
      <div className="overflow-x-auto rounded-md border border-gray-200">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
            <tr>
              <th className="px-3 py-2">Obat (dipesan / sudah terima)</th><th className="px-3 py-2">Jumlah diterima</th>
              <th className="px-3 py-2">No. Batch</th><th className="px-3 py-2">ED</th><th className="px-3 py-2">HPP/satuan</th>
              <th className="px-3 py-2">Kondisi</th><th className="px-3 py-2">Catatan</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {rows.map((r) => (
              <tr key={r.poItemId}>
                <td className="px-3 py-2">{r.label}<div className="text-xs text-gray-500">{r.qtyOrdered} {r.unitCode} dipesan · {r.qtyReceivedBase} sudah masuk stok</div></td>
                <td className="px-3 py-2">
                  <input name={`qty_${r.poItemId}`} type="number" min={0} placeholder="0" className="h-9 w-20 rounded-md border border-gray-300 bg-white px-2 text-sm" />
                  <span className="ml-1 text-xs text-gray-500">{r.unitCode}</span>
                  <input type="hidden" name={`po_item_${r.poItemId}`} value={r.poItemId} />
                </td>
                <td className="px-3 py-2"><input name={`batch_no_${r.poItemId}`} className="h-9 w-28 rounded-md border border-gray-300 bg-white px-2 text-sm" /></td>
                <td className="px-3 py-2"><input name={`expiry_${r.poItemId}`} type="date" className="h-9 w-32 rounded-md border border-gray-300 bg-white px-2 text-sm" /></td>
                <td className="px-3 py-2"><input name={`cost_${r.poItemId}`} placeholder="per satuan dasar" className="h-9 w-28 rounded-md border border-gray-300 bg-white px-2 text-sm" /></td>
                <td className="px-3 py-2">
                  <select name={`condition_${r.poItemId}`} defaultValue="OK" className="h-9 rounded-md border border-gray-300 bg-white px-2 text-sm">
                    {RECEIPT_CONDITIONS.map((c) => <option key={c} value={c}>{RECEIPT_CONDITION_LABELS[c]}</option>)}
                  </select>
                </td>
                <td className="px-3 py-2"><input name={`notes_${r.poItemId}`} className="h-9 w-32 rounded-md border border-gray-300 bg-white px-2 text-sm" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-gray-500">
        Isi hanya baris yang memang datang pada pengiriman ini. HPP dan No. Batch diisi per satuan dasar obat. Batch baru dan stok terbentuk setelah apoteker/pemilik lain memposting draf ini.
      </p>
      <SubmitButton>Simpan sebagai draf</SubmitButton>
    </form>
  );
}
