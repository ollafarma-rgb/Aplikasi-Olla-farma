import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { listReturnableBatches, listSupplierOptions } from '@/modules/procurement/service';
import { EmptyState, PageHeader } from '@/components/ui/page';
import { PurchaseReturnForm } from '../return-form';

export const metadata: Metadata = { title: 'Buat retur pembelian' };
type SP = Promise<{ supplier?: string }>;
const dd = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });

export default async function NewPurchaseReturnPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('procurement.return.create');
  const { supplier } = await searchParams;
  const suppliers = await listSupplierOptions(actor);

  if (!supplier) {
    return (
      <div className="mx-auto max-w-2xl">
        <PageHeader title="Buat retur pembelian" description="Pilih pemasok tujuan retur." back={{ href: '/pengadaan/retur', label: 'Retur Pembelian' }} />
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          {suppliers.length === 0 ? <EmptyState>Belum ada pemasok aktif.</EmptyState> : (
            <form method="get" className="flex flex-wrap items-end gap-2">
              <label className="flex-1">
                <span className="mb-1 block text-sm font-medium text-gray-800">Pemasok</span>
                <select name="supplier" className="h-10 w-full rounded-md border border-gray-300 bg-white px-2 text-sm" defaultValue="">
                  <option value="" disabled>— Pilih pemasok —</option>
                  {suppliers.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
                </select>
              </label>
              <button type="submit" className="h-10 rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lanjut</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  const batches = await listReturnableBatches(actor, supplier);
  const rows = batches.map((b) => ({
    id: b.id,
    label: `${b.medicine.name} (${b.medicine.sku}) · ${b.batch_no} · ED ${dd.format(b.expiry_date)} · siap ${b.qty_saleable}, karantina ${b.qty_quarantine}, rusak ${b.qty_damaged}`,
  }));

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Buat retur pembelian" description={suppliers.find((s) => s.id === supplier)?.label}
        back={{ href: '/pengadaan/retur/baru', label: 'Pilih pemasok lain' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        {rows.length === 0 ? <EmptyState>Belum ada batch dari penerimaan pemasok ini yang bisa diretur.</EmptyState> : <PurchaseReturnForm supplierId={supplier} batches={rows} />}
      </div>
    </div>
  );
}
