'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { createPurchaseReturnAction } from '@/modules/procurement/actions';
import { initialActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';
import { BUCKET_LABELS, STOCK_BUCKETS } from '@/modules/inventory/schemas';

type Batch = { id: string; label: string };

export function PurchaseReturnForm({ supplierId, batches }: { supplierId: string; batches: Batch[] }) {
  const [state, formAction] = useActionState(createPurchaseReturnAction, initialActionState);

  if (state.ok && state.data?.id) {
    return (
      <div className="space-y-3">
        <Alert tone="success">Retur {state.data.returnNo} dibuat sebagai draf. Minta apoteker lain menyetujuinya.</Alert>
        <div className="flex gap-2">
          <Link href={`/pengadaan/retur/${state.data.id}`} className="inline-flex h-10 items-center rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lihat draf</Link>
          <Link href="/pengadaan/retur" className="inline-flex h-10 items-center rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Daftar retur</Link>
        </div>
      </div>
    );
  }

  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message && !state.ok ? <Alert tone="error">{state.message}</Alert> : null}
      <input type="hidden" name="supplier_id" value={supplierId} />
      <input type="hidden" name="row_ids" value={batches.map((b) => b.id).join(',')} />
      <FormField label="Catatan (opsional)" name="notes" error={state.fields?.notes} />
      <div className="overflow-x-auto rounded-md border border-gray-200">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
            <tr><th className="px-3 py-2">Batch</th><th className="px-3 py-2">Dari bucket</th><th className="px-3 py-2">Jumlah</th><th className="px-3 py-2">Alasan</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {batches.map((b) => (
              <tr key={b.id}>
                <td className="px-3 py-2">{b.label}</td>
                <td className="px-3 py-2">
                  <select name={`bucket_${b.id}`} defaultValue="SALEABLE" className="h-9 rounded-md border border-gray-300 bg-white px-2 text-sm">
                    {STOCK_BUCKETS.map((bk) => <option key={bk} value={bk}>{BUCKET_LABELS[bk]}</option>)}
                  </select>
                  <input type="hidden" name={`batch_${b.id}`} value={b.id} />
                </td>
                <td className="px-3 py-2">
                  <input name={`qty_${b.id}`} type="number" min={0} placeholder="0" className="h-9 w-20 rounded-md border border-gray-300 bg-white px-2 text-sm" />
                </td>
                <td className="px-3 py-2">
                  <input name={`reason_${b.id}`} className="h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-sm" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-gray-500">Isi hanya baris batch yang akan diretur. Stok berkurang setelah disetujui apoteker/pemilik lain (bukan pembuat retur ini).</p>
      <SubmitButton>Buat draf retur</SubmitButton>
    </form>
  );
}
