import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { getPurchaseReturn } from '@/modules/procurement/service';
import { approvePurchaseReturnAction, cancelPurchaseReturnAction } from '@/modules/procurement/actions';
import { RETURN_STATUS_LABELS } from '@/modules/procurement/schemas';
import { BUCKET_LABELS } from '@/modules/inventory/schemas';
import { ActionForm } from '@/components/ui/action-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PageHeader, Section } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail retur pembelian' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const statusTone = { DRAFT: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;

export default async function PurchaseReturnDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('procurement.view');
  const { id } = await params;
  let ret;
  try { ret = await getPurchaseReturn(actor, id); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }
  const isDraft = ret.status === 'DRAFT';
  const isCreator = ret.created_by === actor.id;
  const canApprove = can(actor, 'procurement.return.approve');

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader title={ret.return_no} description={`${ret.supplier.name} · dibuat ${ret.creator.full_name} · ${dt.format(ret.created_at)}`}
        back={{ href: '/pengadaan/retur', label: 'Retur Pembelian' }} actions={<Badge tone={statusTone[ret.status]}>{RETURN_STATUS_LABELS[ret.status]}</Badge>} />
      {ret.notes ? <p className="text-sm text-gray-600">{ret.notes}</p> : null}

      <Section title="Rincian">
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Obat</th><th className="px-3 py-2">Batch</th><th className="px-3 py-2">Bucket</th><th className="px-3 py-2 text-right">Jumlah</th><th className="px-3 py-2">Alasan</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {ret.items.map((it) => (
                <tr key={it.id}>
                  <td className="px-3 py-2">{it.batch.medicine.name}<div className="text-xs text-gray-500">{it.batch.medicine.sku}</div></td>
                  <td className="px-3 py-2">{it.batch.batch_no}</td>
                  <td className="px-3 py-2">{BUCKET_LABELS[it.bucket]}</td>
                  <td className="px-3 py-2 text-right">{it.qty}</td>
                  <td className="px-3 py-2 text-xs">{it.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {isDraft ? (
        <Section title="Tindakan">
          {canApprove ? (
            isCreator ? (
              <p className="text-sm text-gray-600">Anda membuat draf ini, jadi tidak bisa menyetujuinya sendiri. Minta apoteker atau pemilik lain untuk menyetujui.</p>
            ) : (
              <ActionForm action={approvePurchaseReturnAction.bind(null, ret.id)} confirmText="Setujui retur ini? Stok akan langsung dikurangi.">
                <Button type="submit">Setujui &amp; kurangi stok</Button>
              </ActionForm>
            )
          ) : <p className="text-sm text-gray-600">Menunggu persetujuan apoteker atau pemilik.</p>}
          {can(actor, 'procurement.return.create') ? (
            <div className="mt-3">
              <ActionForm action={cancelPurchaseReturnAction.bind(null, ret.id)} confirmText="Batalkan draf retur ini?">
                <Button type="submit" variant="ghost">Batalkan draf</Button>
              </ActionForm>
            </div>
          ) : null}
        </Section>
      ) : ret.posted_at ? (
        <p className="text-sm text-gray-600">Diposting {dt.format(ret.posted_at)}.</p>
      ) : null}
    </div>
  );
}
