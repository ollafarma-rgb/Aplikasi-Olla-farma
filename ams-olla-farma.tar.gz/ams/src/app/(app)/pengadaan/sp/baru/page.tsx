import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { listMedicinesForPurchase, listSupplierOptions } from '@/modules/procurement/service';
import { PageHeader } from '@/components/ui/page';
import { PurchaseOrderForm } from '../po-form';

export const metadata: Metadata = { title: 'Buat Surat Pesanan' };

export default async function NewPurchaseOrderPage() {
  const actor = await requirePageActor('procurement.view');
  const [suppliers, medicines] = await Promise.all([listSupplierOptions(actor), listMedicinesForPurchase(actor)]);
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Buat Surat Pesanan" description="Pilih pemasok, jenis SP, dan baris obat yang dipesan." back={{ href: '/pengadaan/sp', label: 'Surat Pesanan' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        <PurchaseOrderForm suppliers={suppliers} medicines={medicines} />
      </div>
    </div>
  );
}
