import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { getPurchaseOrder } from '@/modules/procurement/service';
import { cancelPurchaseOrderAction, sendPurchaseOrderAction } from '@/modules/procurement/actions';
import { PO_STATUS_LABELS, PO_TYPE_LABELS } from '@/modules/procurement/schemas';
import { ActionForm } from '@/components/ui/action-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PageHeader, Section } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail Surat Pesanan' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const money = new Intl.NumberFormat('id-ID');
const statusTone = { DRAFT: 'amber', SENT: 'blue', PARTIAL: 'amber', RECEIVED: 'green', CANCELLED: 'gray' } as const;

export default async function PurchaseOrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('procurement.view');
  const { id } = await params;
  let po;
  try { po = await getPurchaseOrder(actor, id); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }

  const canSend = po.order_type === 'REGULER' ? can(actor, 'procurement.po.approve') : can(actor, 'procurement.po_special.sign');
  const canCreate = po.order_type === 'REGULER' ? can(actor, 'procurement.po.create') : can(actor, 'procurement.po_special.sign');

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader title={po.po_no} description={`${po.supplier.name} · ${PO_TYPE_LABELS[po.order_type]} · dibuat ${po.creator.full_name} · ${dt.format(po.created_at)}`}
        back={{ href: '/pengadaan/sp', label: 'Surat Pesanan' }} actions={<Badge tone={statusTone[po.status]}>{PO_STATUS_LABELS[po.status]}</Badge>} />
      {po.notes ? <p className="text-sm text-gray-600">{po.notes}</p> : null}

      <Section title="Baris pesanan">
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Obat</th><th className="px-3 py-2">Satuan</th><th className="px-3 py-2 text-right">Dipesan</th><th className="px-3 py-2 text-right">Diterima</th><th className="px-3 py-2 text-right">Harga</th><th className="px-3 py-2 text-right">Diskon</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {po.items.map((it) => (
                <tr key={it.id}>
                  <td className="px-3 py-2">{it.medicine.name}<div className="text-xs text-gray-500">{it.medicine.sku}</div></td>
                  <td className="px-3 py-2">{it.unit.code}</td>
                  <td className="px-3 py-2 text-right">{it.qty_ordered}</td>
                  <td className="px-3 py-2 text-right">{it.qty_received_base}</td>
                  <td className="px-3 py-2 text-right">Rp{money.format(Number(it.price))}</td>
                  <td className="px-3 py-2 text-right">{Number(it.discount_pct)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {po.goods_receipts.length > 0 ? (
        <Section title="Penerimaan terkait">
          <ul className="space-y-1 text-sm">
            {po.goods_receipts.map((gr) => (
              <li key={gr.id}>
                <Link href={`/pengadaan/penerimaan/${gr.id}`} className="font-mono text-brand-800 hover:underline">{gr.gr_no}</Link>
                {' · '}{dt.format(gr.received_at)} · {gr.status}
              </li>
            ))}
          </ul>
        </Section>
      ) : null}

      {po.status === 'DRAFT' || po.status === 'SENT' ? (
        <Section title="Tindakan">
          <div className="flex flex-wrap gap-3">
            {po.status === 'DRAFT' && canSend ? (
              <ActionForm action={sendPurchaseOrderAction.bind(null, po.id)} confirmText="Kirim SP ini ke pemasok?">
                <Button type="submit">Kirim ke pemasok</Button>
              </ActionForm>
            ) : null}
            {canCreate ? (
              <ActionForm action={cancelPurchaseOrderAction.bind(null, po.id)} confirmText="Batalkan SP ini?">
                <Button type="submit" variant="ghost">Batalkan</Button>
              </ActionForm>
            ) : null}
            {po.status === 'SENT' && can(actor, 'procurement.receive.record') ? (
              <Link href={`/pengadaan/penerimaan/baru?po=${po.id}`} className="inline-flex h-10 items-center rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">
                Catat penerimaan barang
              </Link>
            ) : null}
          </div>
        </Section>
      ) : null}
      {po.signer ? <p className="text-xs text-gray-500">Ditandatangani {po.signer.full_name}{po.signed_at ? ` · ${dt.format(po.signed_at)}` : ''}.</p> : null}
    </div>
  );
}
