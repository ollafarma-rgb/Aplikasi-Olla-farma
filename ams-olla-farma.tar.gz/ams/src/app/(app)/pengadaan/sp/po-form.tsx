'use client';

import Link from 'next/link';
import { useActionState, useId, useState } from 'react';
import { createPurchaseOrderAction } from '@/modules/procurement/actions';
import { initialActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';
import { PO_TYPES, PO_TYPE_LABELS } from '@/modules/procurement/schemas';

type Option = { id: string; label: string };
type MedOption = { id: string; label: string; unitId: string; unitCode: string; defaultPrice: string };

const typeOptions = PO_TYPES.map((t) => ({ value: t, label: PO_TYPE_LABELS[t] }));

interface Row { key: string; medicineId: string; unitId: string; qty: string; price: string; discount: string }

export function PurchaseOrderForm({ suppliers, medicines }: { suppliers: Option[]; medicines: MedOption[] }) {
  const [state, formAction] = useActionState(createPurchaseOrderAction, initialActionState);
  const uid = useId();
  const [rows, setRows] = useState<Row[]>([{ key: `${uid}-0`, medicineId: '', unitId: '', qty: '', price: '', discount: '0' }]);

  if (state.ok && state.data?.id) {
    return (
      <div className="space-y-3">
        <Alert tone="success">SP {state.data.poNo} dibuat sebagai draf. Kirim ke pemasok setelah ditinjau.</Alert>
        <div className="flex gap-2">
          <Link href={`/pengadaan/sp/${state.data.id}`} className="inline-flex h-10 items-center rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lihat draf</Link>
          <Link href="/pengadaan/sp" className="inline-flex h-10 items-center rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Daftar SP</Link>
        </div>
      </div>
    );
  }

  function updateRow(key: string, patch: Partial<Row>) {
    setRows((rs) => rs.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  }
  function pickMedicine(key: string, medId: string) {
    const med = medicines.find((m) => m.id === medId);
    updateRow(key, { medicineId: medId, unitId: med?.unitId ?? '', price: med?.defaultPrice ?? '' });
  }

  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message && !state.ok ? <Alert tone="error">{state.message}</Alert> : null}
      <input type="hidden" name="row_ids" value={rows.map((r) => r.key).join(',')} />
      <div className="grid gap-4 sm:grid-cols-3">
        <SelectField label="Pemasok" name="supplier_id" options={suppliers.map((s) => ({ value: s.id, label: s.label }))}
          placeholder="— Pilih pemasok —" error={state.fields?.supplier_id} />
        <SelectField label="Jenis SP" name="order_type" defaultValue="REGULER" options={typeOptions} error={state.fields?.order_type}
          hint="SP khusus (narkotika/psikotropika/prekursor/OOT) wajib dibuat & ditandatangani apoteker." />
        <FormField label="Perkiraan tanggal datang (opsional)" name="expected_date" type="date" error={state.fields?.expected_date} />
      </div>
      <FormField label="Catatan (opsional)" name="notes" error={state.fields?.notes} />

      <div className="overflow-x-auto rounded-md border border-gray-200">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
            <tr><th className="px-3 py-2">Obat</th><th className="px-3 py-2">Satuan</th><th className="px-3 py-2">Jumlah</th><th className="px-3 py-2">Harga/satuan</th><th className="px-3 py-2">Diskon %</th><th></th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {rows.map((r) => {
              const med = medicines.find((m) => m.id === r.medicineId);
              return (
                <tr key={r.key}>
                  <td className="px-3 py-2">
                    <select value={r.medicineId} onChange={(e) => pickMedicine(r.key, e.target.value)}
                      className="h-9 w-56 rounded-md border border-gray-300 bg-white px-2 text-sm">
                      <option value="">— Pilih obat —</option>
                      {medicines.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
                    </select>
                    <input type="hidden" name={`medicine_${r.key}`} value={r.medicineId} />
                    <input type="hidden" name={`unit_${r.key}`} value={r.unitId} />
                  </td>
                  <td className="px-3 py-2 text-xs text-gray-600">{med?.unitCode ?? '—'}</td>
                  <td className="px-3 py-2">
                    <input name={`qty_${r.key}`} type="number" min={1} value={r.qty} onChange={(e) => updateRow(r.key, { qty: e.target.value })}
                      className="h-9 w-20 rounded-md border border-gray-300 bg-white px-2 text-sm" />
                  </td>
                  <td className="px-3 py-2">
                    <input name={`price_${r.key}`} value={r.price} onChange={(e) => updateRow(r.key, { price: e.target.value })}
                      className="h-9 w-28 rounded-md border border-gray-300 bg-white px-2 text-sm" />
                  </td>
                  <td className="px-3 py-2">
                    <input name={`discount_${r.key}`} value={r.discount} onChange={(e) => updateRow(r.key, { discount: e.target.value })}
                      className="h-9 w-20 rounded-md border border-gray-300 bg-white px-2 text-sm" />
                  </td>
                  <td className="px-3 py-2">
                    {rows.length > 1 ? (
                      <button type="button" onClick={() => setRows((rs) => rs.filter((x) => x.key !== r.key))} className="text-xs text-danger-700 hover:underline">Hapus</button>
                    ) : null}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <button type="button"
        onClick={() => setRows((rs) => [...rs, { key: `${uid}-${rs.length}-${Date.now()}`, medicineId: '', unitId: '', qty: '', price: '', discount: '0' }])}
        className="text-sm font-medium text-brand-700 hover:underline">+ Tambah baris</button>

      <SubmitButton>Buat draf SP</SubmitButton>
    </form>
  );
}
