import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { listPurchaseOrders } from '@/modules/procurement/service';
import { PO_STATUS_LABELS } from '@/modules/procurement/schemas';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Surat Pesanan' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });
const statusTone = { DRAFT: 'amber', SENT: 'blue', PARTIAL: 'amber', RECEIVED: 'green', CANCELLED: 'gray' } as const;
type SP = Promise<{ q?: string; page?: string }>;

export default async function PurchaseOrderListPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('procurement.view');
  const sp = await searchParams;
  const { items, total, page, pageSize, q } = await listPurchaseOrders(actor, sp);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Surat Pesanan" description="Pesanan pembelian ke pemasok." back={{ href: '/pengadaan', label: 'Pengadaan' }}
        actions={can(actor, 'procurement.po.create') || can(actor, 'procurement.po_special.sign') ? <LinkButton href="/pengadaan/sp/baru">Buat SP</LinkButton> : null} />
      <form method="get" className="mb-3">
        <input name="q" defaultValue={q} placeholder="Cari nomor SP atau nama pemasok…" className="h-10 w-full max-w-sm rounded-md border border-gray-300 bg-white px-3 text-sm sm:w-80" />
      </form>
      {items.length === 0 ? <EmptyState>Belum ada Surat Pesanan.</EmptyState> : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Nomor</th><th className="px-3 py-2">Pemasok</th><th className="px-3 py-2">Jenis</th><th className="px-3 py-2 text-right">Baris</th><th className="px-3 py-2">Dibuat</th><th className="px-3 py-2">Status</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((po) => (
                <tr key={po.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2"><Link href={`/pengadaan/sp/${po.id}`} className="font-mono text-brand-800 hover:underline">{po.po_no}</Link></td>
                  <td className="px-3 py-2">{po.supplier.name}</td>
                  <td className="px-3 py-2 text-xs">{po.order_type}</td>
                  <td className="px-3 py-2 text-right">{po._count.items}</td>
                  <td className="px-3 py-2 text-xs">{po.creator.full_name} · {dt.format(po.created_at)}</td>
                  <td className="px-3 py-2"><Badge tone={statusTone[po.status]}>{PO_STATUS_LABELS[po.status]}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={pages} total={total} params={{ q }} basePath="/pengadaan/sp" />
    </div>
  );
}
