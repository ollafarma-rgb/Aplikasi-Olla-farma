import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { prisma } from '@/lib/database/client';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Pengadaan' };

async function counts() {
  const [sp, gr, rb] = await Promise.all([
    prisma.purchaseOrder.count({ where: { status: { in: ['DRAFT', 'SENT', 'PARTIAL'] } } }),
    prisma.goodsReceipt.count({ where: { status: 'DRAFT' } }),
    prisma.purchaseReturn.count({ where: { status: 'DRAFT' } }),
  ]);
  return { sp, gr, rb };
}

export default async function ProcurementHubPage() {
  await requirePageActor('procurement.view');
  const c = await counts();
  const cards = [
    { href: '/pengadaan/sp', title: 'Surat Pesanan', desc: 'Buat dan kirim SP ke pemasok.', badge: `${c.sp} berjalan` },
    { href: '/pengadaan/penerimaan', title: 'Penerimaan Barang', desc: 'Catat dan posting barang datang menjadi batch & stok.', badge: `${c.gr} draf` },
    { href: '/pengadaan/retur', title: 'Retur Pembelian', desc: 'Kembalikan barang rusak/kedaluwarsa ke pemasok.', badge: `${c.rb} draf` },
  ];
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Pengadaan" description="Alur pembelian: Surat Pesanan → Penerimaan Barang (membuat batch) → Retur Pembelian bila diperlukan." />
      <div className="grid gap-4 sm:grid-cols-3">
        {cards.map((c) => (
          <Link key={c.href} href={c.href} className="block rounded-lg border border-gray-200 bg-white p-4 hover:border-brand-300 hover:shadow-sm">
            <h2 className="text-sm font-semibold">{c.title}</h2>
            <p className="mt-1 text-xs text-gray-600">{c.desc}</p>
            <p className="mt-3 text-xs font-medium text-brand-800">{c.badge}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
