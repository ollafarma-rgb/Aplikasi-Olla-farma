'use client';

import { useActionState } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { valueOf } from '@/components/ui/action-form';
import { SelectField, TextAreaField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';

const STATUS = [{ value: 'ACTIVE', label: 'Aktif' }, { value: 'INACTIVE', label: 'Tidak aktif' }, { value: 'BLOCKED', label: 'Diblokir' }];

export function SupplierForm({ action, initial, readOnly }: {
  action: (prev: ActionState, fd: FormData) => Promise<ActionState>;
  initial: Record<string, string>;
  readOnly?: boolean;
}) {
  const [state, formAction] = useActionState(action, initialActionState);
  const v = (k: string) => valueOf(state, initial, k);
  const e = (k: string) => state.fields?.[k];
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message ? <Alert tone={state.ok ? 'success' : 'error'}>{state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai merah.' : state.message}</Alert> : null}
      <fieldset disabled={readOnly} className="grid gap-4 sm:grid-cols-2">
        <FormField label="Nama pemasok (PBF)" name="name" defaultValue={v('name')} error={e('name')} />
        <FormField label="Nama perusahaan" name="company_name" defaultValue={v('company_name')} error={e('company_name')} />
        <FormField label="Nomor izin PBF" name="pbf_license_no" defaultValue={v('pbf_license_no')} error={e('pbf_license_no')} />
        <FormField label="NPWP" name="npwp" defaultValue={v('npwp')} error={e('npwp')} />
        <FormField label="Telepon" name="phone" type="tel" defaultValue={v('phone')} error={e('phone')} />
        <FormField label="Email" name="email" type="email" defaultValue={v('email')} error={e('email')} />
        <FormField label="Nama sales" name="sales_rep" defaultValue={v('sales_rep')} error={e('sales_rep')} />
        <FormField label="Termin pembayaran (hari)" name="payment_term_days" inputMode="numeric" defaultValue={v('payment_term_days') || '30'} error={e('payment_term_days')} />
        <SelectField label="Status" name="status" options={STATUS} defaultValue={v('status') || 'ACTIVE'} error={e('status')} />
        <div className="sm:col-span-2"><TextAreaField label="Alamat" name="address" defaultValue={v('address')} error={e('address')} /></div>
        <div className="sm:col-span-2"><TextAreaField label="Catatan" name="notes" defaultValue={v('notes')} error={e('notes')} /></div>
      </fieldset>
      {!readOnly ? <SubmitButton>Simpan pemasok</SubmitButton> : null}
    </form>
  );
}
