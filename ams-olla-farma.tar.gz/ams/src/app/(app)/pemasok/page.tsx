import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { listSuppliers, SUPPLIER_STATUS_LABELS } from '@/modules/suppliers/service';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Pemasok' };

export default async function SuppliersPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const actor = await requirePageActor('suppliers.view');
  const data = await listSuppliers(await searchParams, actor);
  const f = data.filter;
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Pemasok" description="Pedagang Besar Farmasi (PBF) dan pemasok lain."
        actions={can(actor, 'suppliers.manage') ? <LinkButton href="/pemasok/baru">Tambah pemasok</LinkButton> : null} />
      <form method="get" className="mb-3 flex flex-wrap gap-2" role="search">
        <input name="q" defaultValue={f.q} placeholder="Cari nama, perusahaan, atau kode" aria-label="Cari pemasok"
          className="h-10 min-w-0 flex-1 rounded-md border border-gray-300 bg-white px-3 text-sm focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-100" />
        <select name="status" defaultValue={f.status} aria-label="Status" className="h-10 rounded-md border border-gray-300 bg-white px-2 text-sm">
          <option value="ACTIVE">Aktif</option><option value="INACTIVE">Tidak aktif</option><option value="BLOCKED">Diblokir</option><option value="SEMUA">Semua</option>
        </select>
        <button type="submit" className="h-10 rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Cari</button>
      </form>
      {data.items.length === 0 ? <EmptyState>Belum ada pemasok yang cocok.</EmptyState> : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Pemasok</th><th className="px-3 py-2">Kode</th><th className="px-3 py-2">Kontak</th><th className="px-3 py-2">Termin</th><th className="px-3 py-2">Status</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {data.items.map((s) => (
                <tr key={s.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2"><Link href={`/pemasok/${s.id}`} className="font-medium text-brand-800 hover:underline">{s.name}</Link>
                    <div className="text-xs text-gray-500">{s.company_name}</div></td>
                  <td className="px-3 py-2 font-mono text-xs">{s.code}</td>
                  <td className="px-3 py-2 text-xs">{[s.sales_rep, s.phone].filter(Boolean).join(' · ') || '—'}</td>
                  <td className="px-3 py-2">{s.payment_term_days} hari</td>
                  <td className="px-3 py-2"><Badge tone={s.status === 'ACTIVE' ? 'green' : s.status === 'BLOCKED' ? 'red' : 'gray'}>{SUPPLIER_STATUS_LABELS[s.status]}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={f.page} pages={data.pages} total={data.total} basePath="/pemasok" params={{ q: f.q || undefined, status: f.status }} />
    </div>
  );
}
