import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { saveSupplierAction } from '@/modules/suppliers/actions';
import { PageHeader } from '@/components/ui/page';
import { SupplierForm } from '../supplier-form';

export const metadata: Metadata = { title: 'Tambah pemasok' };

export default async function NewSupplierPage() {
  await requirePageActor('suppliers.manage');
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Tambah pemasok" back={{ href: '/pemasok', label: 'Pemasok' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        <SupplierForm action={saveSupplierAction.bind(null, null)} initial={{}} />
      </div>
    </div>
  );
}
