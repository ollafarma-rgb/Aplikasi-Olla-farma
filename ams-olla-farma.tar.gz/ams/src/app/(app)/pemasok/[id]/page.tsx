import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { getSupplier } from '@/modules/suppliers/service';
import { saveSupplierAction } from '@/modules/suppliers/actions';
import { Alert } from '@/components/ui/alert';
import { PageHeader } from '@/components/ui/page';
import { SupplierForm } from '../supplier-form';

export const metadata: Metadata = { title: 'Detail pemasok' };

export default async function SupplierDetailPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ baru?: string }> }) {
  const actor = await requirePageActor('suppliers.view');
  const { id } = await params;
  const { baru } = await searchParams;
  let s;
  try { s = await getSupplier(id, actor); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }
  const initial = Object.fromEntries(Object.entries({
    name: s.name, company_name: s.company_name, address: s.address, phone: s.phone, email: s.email, sales_rep: s.sales_rep,
    npwp: s.npwp, pbf_license_no: s.pbf_license_no, payment_term_days: String(s.payment_term_days), status: s.status, notes: s.notes,
  }).map(([k, v]) => [k, v ?? '']));
  return (
    <div className="mx-auto max-w-3xl space-y-3">
      <PageHeader title={s.name} description={s.code} back={{ href: '/pemasok', label: 'Pemasok' }} />
      {baru ? <Alert tone="success">Pemasok tersimpan dengan kode {s.code}.</Alert> : null}
      <p className="text-sm text-gray-600">Riwayat pembelian dan saldo utang tampil di sini setelah modul pengadaan (Fase 5) selesai.</p>
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        <SupplierForm action={saveSupplierAction.bind(null, s.id)} initial={initial} readOnly={!can(actor, 'suppliers.manage')} />
      </div>
    </div>
  );
}
