import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { getStockReport } from '@/modules/dashboard/service';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Laporan Stok' };

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

const statusBadge: Record<string, string> = {
  OK:     'bg-green-100 text-green-800',
  KRITIS: 'bg-amber-100 text-amber-800',
  HABIS:  'bg-red-100 text-red-800',
};

type SP = Promise<{ filter?: string; q?: string }>;

export default async function StockReportPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('reports.inventory.view');
  const sp = await searchParams;

  const canViewCost = can(actor, 'medicines.view_cost');
  const rows = await getStockReport(actor);

  // filter client-side di server (data tidak besar, OK)
  const filter = sp.filter ?? 'all';
  const q = sp.q?.toLowerCase() ?? '';

  const filtered = rows.filter(r => {
    if (filter === 'kritis' && r.status !== 'KRITIS') return false;
    if (filter === 'habis'  && r.status !== 'HABIS')  return false;
    if (filter === 'ed')    return false; // ED ada di halaman persediaan
    if (q && !r.name.toLowerCase().includes(q) && !r.sku.toLowerCase().includes(q)) return false;
    return true;
  });

  const totalValue = filtered.reduce((s, r) => s + r.total_value, 0);
  const countKritis = rows.filter(r => r.status === 'KRITIS').length;
  const countHabis  = rows.filter(r => r.status === 'HABIS').length;

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Laporan Stok"
        description="Posisi stok dan nilai persediaan semua obat aktif."
        back={{ href: '/dashboard', label: 'Dashboard' }}
      />

      {/* Ringkasan */}
      <div className="mb-4 grid grid-cols-3 gap-3">
        <div className="rounded-lg border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Total SKU</p>
          <p className="mt-1 text-xl font-semibold">{rows.length}</p>
        </div>
        <div className={`rounded-lg border p-3 ${countKritis > 0 ? 'border-amber-200 bg-amber-50' : 'border-gray-200 bg-white'}`}>
          <p className="text-xs text-gray-500">Stok Kritis</p>
          <p className="mt-1 text-xl font-semibold text-amber-700">{countKritis}</p>
        </div>
        <div className={`rounded-lg border p-3 ${countHabis > 0 ? 'border-red-200 bg-red-50' : 'border-gray-200 bg-white'}`}>
          <p className="text-xs text-gray-500">Stok Habis</p>
          <p className="mt-1 text-xl font-semibold text-red-700">{countHabis}</p>
        </div>
      </div>

      {/* Filter */}
      <form method="get" className="mb-3 flex flex-wrap items-center gap-2">
        <input name="q" defaultValue={sp.q ?? ''} placeholder="Cari nama atau SKU…"
          className="h-9 w-full max-w-xs rounded-md border border-gray-300 bg-white px-3 text-sm" />
        {(['all', 'kritis', 'habis'] as const).map(f => (
          <a key={f} href={`?filter=${f}${q ? `&q=${q}` : ''}`}
            className={`rounded-md px-3 py-1.5 text-sm border transition-colors ${filter === f
              ? 'bg-brand-700 text-white border-brand-700'
              : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}>
            {f === 'all' ? 'Semua' : f === 'kritis' ? 'Kritis' : 'Habis'}
          </a>
        ))}
      </form>

      {/* Total nilai */}
      {canViewCost && (
        <div className="mb-3 rounded-md bg-blue-50 border border-blue-200 px-4 py-2 text-sm text-blue-800">
          Total nilai persediaan (HPP): <strong>{idr.format(totalValue)}</strong>
          {' '}— {filtered.length} SKU ditampilkan
        </div>
      )}

      {/* Tabel */}
      <div className="overflow-x-auto rounded-lg border border-gray-200">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-xs font-semibold uppercase text-gray-500">
            <tr>
              <th className="px-4 py-3 text-left">SKU</th>
              <th className="px-4 py-3 text-left">Nama Obat</th>
              <th className="px-4 py-3 text-left">Kategori</th>
              <th className="px-4 py-3 text-right">Stok</th>
              <th className="px-4 py-3 text-right">Min</th>
              {canViewCost && <th className="px-4 py-3 text-right">HPP</th>}
              {canViewCost && <th className="px-4 py-3 text-right">Nilai</th>}
              <th className="px-4 py-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={canViewCost ? 8 : 6} className="px-4 py-8 text-center text-gray-400">
                  Tidak ada data.
                </td>
              </tr>
            ) : filtered.map(r => (
              <tr key={r.sku} className="hover:bg-gray-50">
                <td className="px-4 py-2.5 font-mono text-xs text-gray-500">{r.sku}</td>
                <td className="px-4 py-2.5 font-medium">{r.name}</td>
                <td className="px-4 py-2.5 text-gray-500">{r.category}</td>
                <td className="px-4 py-2.5 text-right tabular-nums">
                  {r.qty_saleable.toLocaleString('id-ID')} {r.unit}
                </td>
                <td className="px-4 py-2.5 text-right tabular-nums text-gray-400">{r.min_stock}</td>
                {canViewCost && (
                  <td className="px-4 py-2.5 text-right tabular-nums text-gray-500">
                    {r.hpp > 0 ? idr.format(r.hpp) : '-'}
                  </td>
                )}
                {canViewCost && (
                  <td className="px-4 py-2.5 text-right tabular-nums">
                    {r.total_value > 0 ? idr.format(r.total_value) : '-'}
                  </td>
                )}
                <td className="px-4 py-2.5 text-center">
                  <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${statusBadge[r.status]}`}>
                    {r.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
