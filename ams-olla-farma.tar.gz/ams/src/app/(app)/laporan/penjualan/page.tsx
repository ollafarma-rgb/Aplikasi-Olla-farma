import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { getSalesReport } from '@/modules/dashboard/service';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Laporan Penjualan' };

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const dtFmt = new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' });

type SP = Promise<{ from?: string; to?: string; range?: string }>;

function defaultRange(): { from: string; to: string } {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  return { from: `${y}-${m}-01`, to: `${y}-${m}-${String(new Date(y, now.getMonth() + 1, 0).getDate()).padStart(2, '0')}` };
}

export default async function SalesReportPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('reports.operational.view');
  const sp = await searchParams;

  const def = defaultRange();
  const fromStr = sp.from ?? def.from;
  const toStr   = sp.to   ?? def.to;

  const fromDate = new Date(`${fromStr}T00:00:00+07:00`);
  const toDate   = new Date(`${toStr}T23:59:59+07:00`);

  const { rows, totals } = await getSalesReport(actor, { from: fromDate, to: toDate });

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader
        title="Laporan Penjualan"
        description="Rekapitulasi penjualan per hari dalam rentang waktu dipilih."
        back={{ href: '/dashboard', label: 'Dashboard' }}
      />

      {/* Filter */}
      <form method="get" className="mb-4 flex flex-wrap items-end gap-3">
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Dari</label>
          <input type="date" name="from" defaultValue={fromStr}
            className="h-9 rounded-md border border-gray-300 bg-white px-3 text-sm" />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-600 mb-1">Sampai</label>
          <input type="date" name="to" defaultValue={toStr}
            className="h-9 rounded-md border border-gray-300 bg-white px-3 text-sm" />
        </div>
        <button type="submit"
          className="h-9 rounded-md bg-brand-700 px-4 text-sm font-medium text-white hover:bg-brand-800">
          Tampilkan
        </button>
      </form>

      {/* Ringkasan */}
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: 'Total Transaksi', value: totals.count.toLocaleString('id-ID') },
          { label: 'Penjualan Bruto', value: idr.format(totals.gross) },
          { label: 'Total Diskon', value: idr.format(totals.discount) },
          { label: 'Penjualan Neto', value: idr.format(totals.net) },
        ].map(c => (
          <div key={c.label} className="rounded-lg border border-gray-200 bg-white p-3">
            <p className="text-xs text-gray-500">{c.label}</p>
            <p className="mt-1 text-lg font-semibold text-gray-900">{c.value}</p>
          </div>
        ))}
      </div>

      {/* Tabel */}
      {rows.length === 0 ? (
        <div className="rounded-lg border border-gray-200 bg-white p-8 text-center text-sm text-gray-500">
          Tidak ada transaksi dalam rentang ini.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-xs font-semibold uppercase text-gray-500">
              <tr>
                <th className="px-4 py-3 text-left">Tanggal</th>
                <th className="px-4 py-3 text-right">Transaksi</th>
                <th className="px-4 py-3 text-right">Bruto</th>
                <th className="px-4 py-3 text-right">Diskon</th>
                <th className="px-4 py-3 text-right">Neto</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {rows.map(r => (
                <tr key={r.date} className="hover:bg-gray-50">
                  <td className="px-4 py-2.5 font-medium">
                    {dtFmt.format(new Date(`${r.date}T00:00:00+07:00`))}
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums">{r.count}</td>
                  <td className="px-4 py-2.5 text-right tabular-nums">{idr.format(r.gross)}</td>
                  <td className="px-4 py-2.5 text-right tabular-nums text-red-600">
                    {r.discount > 0 ? `(${idr.format(r.discount)})` : '-'}
                  </td>
                  <td className="px-4 py-2.5 text-right tabular-nums font-medium">{idr.format(r.net)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50 text-xs font-semibold text-gray-700">
              <tr>
                <td className="px-4 py-2.5">TOTAL</td>
                <td className="px-4 py-2.5 text-right tabular-nums">{totals.count}</td>
                <td className="px-4 py-2.5 text-right tabular-nums">{idr.format(totals.gross)}</td>
                <td className="px-4 py-2.5 text-right tabular-nums text-red-600">
                  {totals.discount > 0 ? `(${idr.format(totals.discount)})` : '-'}
                </td>
                <td className="px-4 py-2.5 text-right tabular-nums">{idr.format(totals.net)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
}
