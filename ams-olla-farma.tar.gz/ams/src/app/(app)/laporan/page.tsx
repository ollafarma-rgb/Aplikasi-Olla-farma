import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Laporan' };

export default async function ReportsIndexPage() {
  const actor = await requirePageActor('reports.operational.view');

  const cards = [
    {
      href: '/laporan/penjualan',
      title: 'Laporan Penjualan',
      desc: 'Rekapitulasi penjualan per hari, bruto, diskon, dan neto dalam rentang waktu.',
      icon: '🧾',
      perm: 'reports.operational.view',
    },
    {
      href: '/laporan/stok',
      title: 'Laporan Stok',
      desc: 'Posisi stok semua obat aktif, stok kritis, dan nilai persediaan (HPP).',
      icon: '📦',
      perm: 'reports.inventory.view',
    },
    {
      href: '/keuangan/piutang/aging',
      title: 'Aging Piutang',
      desc: 'Distribusi piutang pelanggan berdasarkan umur tunggakan (0–30, 31–60, 61–90, >90 hari).',
      icon: '📋',
      perm: 'finance.receivable.view',
    },
  ] as const;

  const available = cards.filter(c => can(actor, c.perm));

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title="Laporan"
        description="Pilih laporan yang ingin ditampilkan."
        back={{ href: '/dashboard', label: 'Dashboard' }}
      />
      <div className="grid gap-3 sm:grid-cols-2">
        {available.map(c => (
          <Link key={c.href} href={c.href}
            className="flex gap-4 rounded-lg border border-gray-200 bg-white p-4 hover:border-brand-400 hover:shadow-sm transition-all">
            <span className="text-2xl">{c.icon}</span>
            <div>
              <p className="font-semibold text-gray-900">{c.title}</p>
              <p className="mt-0.5 text-xs text-gray-500">{c.desc}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
