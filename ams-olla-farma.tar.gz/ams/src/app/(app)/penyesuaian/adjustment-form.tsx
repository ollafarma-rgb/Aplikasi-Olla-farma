'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { createAdjustmentAction } from '@/modules/inventory/actions';
import { initialActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';
import { ADJUSTMENT_REASONS, ADJUSTMENT_REASON_LABELS, BUCKET_LABELS, STOCK_BUCKETS } from '@/modules/inventory/schemas';

type Batch = { id: string; label: string };
const reasonOptions = ADJUSTMENT_REASONS.map((r) => ({ value: r, label: ADJUSTMENT_REASON_LABELS[r] }));
const bucketOptions = STOCK_BUCKETS.map((b) => ({ value: b, label: BUCKET_LABELS[b] }));

export function AdjustmentForm({ batches }: { batches: Batch[] }) {
  const [state, formAction] = useActionState(createAdjustmentAction, initialActionState);
  if (state.ok && state.data?.id) {
    return (
      <div className="space-y-3">
        <Alert tone="success">Penyesuaian {state.data.adjNo} dibuat sebagai draf. Minta apoteker/pemilik menyetujuinya.</Alert>
        <div className="flex gap-2">
          <Link href={`/penyesuaian/${state.data.id}`} className="inline-flex h-10 items-center rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lihat draf</Link>
          <Link href="/penyesuaian" className="inline-flex h-10 items-center rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Daftar penyesuaian</Link>
        </div>
      </div>
    );
  }
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message && !state.ok ? <Alert tone="error">{state.message}</Alert> : null}
      <input type="hidden" name="batch_ids" value={batches.map((b) => b.id).join(',')} />
      <div className="grid gap-4 sm:grid-cols-2">
        <SelectField label="Alasan" name="reason_code" defaultValue="KOREKSI" options={reasonOptions} error={state.fields?.reason_code} />
        <FormField label="Catatan (opsional)" name="notes" error={state.fields?.notes} />
      </div>
      <div className="overflow-x-auto rounded-md border border-gray-200">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
            <tr><th className="px-3 py-2">Batch</th><th className="px-3 py-2">Bucket</th><th className="px-3 py-2">Selisih (+/−)</th><th className="px-3 py-2">Alasan baris</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {batches.map((b) => (
              <tr key={b.id}>
                <td className="px-3 py-2">{b.label}</td>
                <td className="px-3 py-2">
                  <select name={`bucket_${b.id}`} defaultValue="SALEABLE" className="h-9 rounded-md border border-gray-300 bg-white px-2 text-sm">
                    {bucketOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                </td>
                <td className="px-3 py-2">
                  <input name={`delta_${b.id}`} type="number" step={1} placeholder="0"
                    className="h-9 w-24 rounded-md border border-gray-300 bg-white px-2 text-sm" />
                </td>
                <td className="px-3 py-2">
                  <input name={`reason_${b.id}`} className="h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-sm" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-gray-500">Isi selisih hanya pada batch yang berubah. Nilai positif menambah, negatif mengurangi. Stok baru berubah setelah disetujui.</p>
      <SubmitButton>Buat draf penyesuaian</SubmitButton>
    </form>
  );
}
