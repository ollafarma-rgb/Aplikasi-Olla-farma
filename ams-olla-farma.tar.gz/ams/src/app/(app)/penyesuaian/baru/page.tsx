import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { getMedicineStock, listMedicineOptions } from '@/modules/inventory/service';
import { EmptyState, PageHeader } from '@/components/ui/page';
import { AdjustmentForm } from '../adjustment-form';

export const metadata: Metadata = { title: 'Buat penyesuaian' };
const dd = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });
type SP = Promise<{ medicine?: string }>;

export default async function NewAdjustmentPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('inventory.adjust.create');
  const { medicine } = await searchParams;
  const medicines = await listMedicineOptions(actor);

  if (!medicine) {
    return (
      <div className="mx-auto max-w-2xl">
        <PageHeader title="Buat penyesuaian" description="Pilih obat yang stoknya akan disesuaikan." back={{ href: '/penyesuaian', label: 'Penyesuaian' }} />
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          {medicines.length === 0 ? <EmptyState>Belum ada obat aktif.</EmptyState> : (
            <form method="get" className="flex flex-wrap items-end gap-2">
              <label className="flex-1">
                <span className="mb-1 block text-sm font-medium text-gray-800">Obat</span>
                <select name="medicine" className="h-10 w-full rounded-md border border-gray-300 bg-white px-2 text-sm" defaultValue="">
                  <option value="" disabled>— Pilih obat —</option>
                  {medicines.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
                </select>
              </label>
              <button type="submit" className="h-10 rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lanjut</button>
            </form>
          )}
        </div>
      </div>
    );
  }

  const { medicine: med, batches } = await getMedicineStock(actor, medicine);
  const rows = batches.map((b) => ({
    id: b.id,
    label: `${b.batch_no} · ED ${dd.format(b.expiry_date)} · siap ${b.qty_saleable}, karantina ${b.qty_quarantine}, rusak ${b.qty_damaged}`,
  }));
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title={`Penyesuaian: ${med.name}`} description={`${med.sku} · satuan ${med.base_unit.code}`} back={{ href: '/penyesuaian/baru', label: 'Pilih obat lain' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        {rows.length === 0 ? <EmptyState>Obat ini belum punya batch. Catat saldo awal lebih dulu.</EmptyState> : <AdjustmentForm batches={rows} />}
      </div>
    </div>
  );
}
