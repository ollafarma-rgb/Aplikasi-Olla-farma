import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { getAdjustment } from '@/modules/inventory/service';
import { approveAdjustmentAction, cancelAdjustmentAction } from '@/modules/inventory/actions';
import { ADJUSTMENT_REASON_LABELS, BUCKET_LABELS } from '@/modules/inventory/schemas';
import { ActionForm } from '@/components/ui/action-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PageHeader, Section } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail penyesuaian' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const statusTone = { DRAFT: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;
const statusLabel = { DRAFT: 'Draf', POSTED: 'Disetujui', CANCELLED: 'Dibatalkan' } as const;

export default async function AdjustmentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('inventory.view');
  const { id } = await params;
  let adj;
  try { adj = await getAdjustment(actor, id); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }
  const isDraft = adj.status === 'DRAFT';
  const isCreator = adj.created_by === actor.id;
  const canApprove = can(actor, 'inventory.adjust.approve');

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={adj.adj_no} description={`${ADJUSTMENT_REASON_LABELS[adj.reason_code] ?? adj.reason_code} · dibuat ${adj.creator.full_name} · ${dt.format(adj.created_at)}`}
        back={{ href: '/penyesuaian', label: 'Penyesuaian' }} actions={<Badge tone={statusTone[adj.status]}>{statusLabel[adj.status]}</Badge>} />
      {adj.notes ? <p className="text-sm text-gray-600">{adj.notes}</p> : null}

      <Section title="Rincian">
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Obat</th><th className="px-3 py-2">Batch</th><th className="px-3 py-2">Bucket</th><th className="px-3 py-2 text-right">Selisih</th><th className="px-3 py-2">Alasan</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {adj.items.map((it) => (
                <tr key={it.id}>
                  <td className="px-3 py-2">{it.batch.medicine.name}<div className="text-xs text-gray-500">{it.batch.medicine.sku}</div></td>
                  <td className="px-3 py-2">{it.batch.batch_no}</td>
                  <td className="px-3 py-2">{BUCKET_LABELS[it.bucket]}</td>
                  <td className={`px-3 py-2 text-right font-medium ${it.qty_delta < 0 ? 'text-danger-700' : 'text-brand-800'}`}>{it.qty_delta > 0 ? '+' : ''}{it.qty_delta}</td>
                  <td className="px-3 py-2 text-xs">{it.reason ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {isDraft ? (
        <Section title="Tindakan">
          {canApprove ? (
            isCreator ? (
              <p className="text-sm text-gray-600">Anda membuat draf ini, jadi tidak bisa menyetujuinya sendiri. Minta apoteker atau pemilik lain untuk menyetujui.</p>
            ) : (
              <ActionForm action={approveAdjustmentAction.bind(null, adj.id)} confirmText="Setujui penyesuaian ini? Stok akan langsung diperbarui.">
                <Button type="submit">Setujui &amp; perbarui stok</Button>
              </ActionForm>
            )
          ) : <p className="text-sm text-gray-600">Menunggu persetujuan apoteker atau pemilik.</p>}
          {can(actor, 'inventory.adjust.create') ? (
            <div className="mt-3">
              <ActionForm action={cancelAdjustmentAction.bind(null, adj.id)} confirmText="Batalkan draf penyesuaian ini?">
                <Button type="submit" variant="ghost">Batalkan draf</Button>
              </ActionForm>
            </div>
          ) : null}
        </Section>
      ) : adj.posted_at ? (
        <p className="text-sm text-gray-600">Diposting {dt.format(adj.posted_at)}.</p>
      ) : null}
    </div>
  );
}
