import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { listAdjustments } from '@/modules/inventory/service';
import { ADJUSTMENT_REASON_LABELS } from '@/modules/inventory/schemas';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Penyesuaian Stok' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const statusTone = { DRAFT: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;
const statusLabel = { DRAFT: 'Draf', POSTED: 'Disetujui', CANCELLED: 'Dibatalkan' } as const;

export default async function AdjustmentsPage() {
  const actor = await requirePageActor('inventory.view');
  const rows = await listAdjustments(actor);
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Penyesuaian Stok" description="Koreksi stok karena rusak, hilang, atau kedaluwarsa. Perubahan berlaku setelah disetujui apoteker/pemilik."
        actions={can(actor, 'inventory.adjust.create') ? <LinkButton href="/penyesuaian/baru">Buat penyesuaian</LinkButton> : null} />
      {rows.length === 0 ? <EmptyState>Belum ada penyesuaian stok.</EmptyState> : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Nomor</th><th className="px-3 py-2">Alasan</th><th className="px-3 py-2 text-right">Baris</th><th className="px-3 py-2">Dibuat</th><th className="px-3 py-2">Status</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rows.map((a) => (
                <tr key={a.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2"><Link href={`/penyesuaian/${a.id}`} className="font-mono text-brand-800 hover:underline">{a.adj_no}</Link></td>
                  <td className="px-3 py-2">{ADJUSTMENT_REASON_LABELS[a.reason_code] ?? a.reason_code}</td>
                  <td className="px-3 py-2 text-right">{a._count.items}</td>
                  <td className="px-3 py-2 text-xs">{a.creator.full_name} · {dt.format(a.created_at)}</td>
                  <td className="px-3 py-2"><Badge tone={statusTone[a.status]}>{statusLabel[a.status]}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
