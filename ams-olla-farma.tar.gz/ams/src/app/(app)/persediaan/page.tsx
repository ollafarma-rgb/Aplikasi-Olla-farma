import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { formatRupiah } from '@/lib/money/format';
import { inventoryValue, listStock, PAGE_SIZE } from '@/modules/inventory/service';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Persediaan' };
type SP = Promise<Record<string, string | undefined>>;
const d = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });

export default async function StockPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('inventory.view');
  const sp = await searchParams;
  const [data, totalValue] = await Promise.all([listStock(actor, sp), inventoryValue(actor)]);
  const pages = Math.max(1, Math.ceil(data.total / PAGE_SIZE));

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title="Persediaan" description="Stok per obat dari seluruh batch; klik obat untuk kartu stok dan batch."
        actions={can(actor, 'inventory.adjust.approve') ? <LinkButton href="/persediaan/saldo-awal">Catat saldo awal</LinkButton> : null} />

      <div className="mb-3 rounded-lg border border-gray-200 bg-white p-3 text-sm">
        Nilai persediaan saat ini: <span className="font-semibold text-brand-800">{formatRupiah(totalValue)}</span>
      </div>

      <form method="get" className="mb-3 flex flex-wrap gap-2" role="search">
        <input name="q" defaultValue={data.q} placeholder="Cari nama, generik, atau SKU" aria-label="Cari obat"
          className="h-10 min-w-0 flex-1 rounded-md border border-gray-300 bg-white px-3 text-sm focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-100" />
        <select name="view" defaultValue={data.view} aria-label="Tampilan" className="h-10 rounded-md border border-gray-300 bg-white px-2 text-sm">
          <option value="semua">Semua</option>
          <option value="menipis">Stok menipis</option>
          <option value="ed">Akan/sudah kedaluwarsa</option>
        </select>
        <button type="submit" className="h-10 rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Cari</button>
      </form>

      {data.items.length === 0 ? (
        <EmptyState>{data.q ? `Tidak ada obat yang cocok dengan "${data.q}".` : 'Belum ada stok. Mulai dengan mencatat saldo awal.'}</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-3 py-2">Obat</th>
                <th className="px-3 py-2 text-right">Siap jual</th>
                <th className="px-3 py-2 text-right">Karantina</th>
                <th className="px-3 py-2 text-right">Rusak</th>
                <th className="px-3 py-2 text-right">Nilai</th>
                <th className="px-3 py-2">ED terdekat</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {data.items.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2">
                    <Link href={`/persediaan/${r.id}`} className="font-medium text-brand-800 hover:underline">{r.name}</Link>
                    <div className="text-xs text-gray-500">{r.generic_name} · {r.sku}</div>
                  </td>
                  <td className="px-3 py-2 text-right">
                    {r.saleable}
                    {r.low ? <div><Badge tone="amber">Menipis (min {r.min_stock})</Badge></div> : null}
                  </td>
                  <td className="px-3 py-2 text-right">{r.quarantine || '—'}</td>
                  <td className="px-3 py-2 text-right">{r.damaged || '—'}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right">{formatRupiah(r.value)}</td>
                  <td className="px-3 py-2">
                    {r.nearest_expiry ? (
                      <>
                        {d.format(new Date(r.nearest_expiry))}
                        {r.expired ? <div><Badge tone="red">Kedaluwarsa</Badge></div> : r.expiring_soon ? <div><Badge tone="amber">Segera ED</Badge></div> : null}
                      </>
                    ) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={data.page} pages={pages} total={data.total} basePath="/persediaan"
        params={{ q: data.q || undefined, view: data.view }} />
    </div>
  );
}
