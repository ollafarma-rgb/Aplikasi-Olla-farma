import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { formatRupiah } from '@/lib/money/format';
import { getMedicineStock } from '@/modules/inventory/service';
import { moveBucketAction } from '@/modules/inventory/actions';
import { BUCKET_LABELS, MOVEMENT_LABELS } from '@/modules/inventory/schemas';
import { Badge } from '@/components/ui/badge';
import { PageHeader, Section } from '@/components/ui/page';
import { BucketMoveForm } from './bucket-move-form';

export const metadata: Metadata = { title: 'Kartu stok' };
const dd = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const today = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })).toISOString().slice(0, 10);

export default async function StockCardPage({ params }: { params: Promise<{ medicineId: string }> }) {
  const actor = await requirePageActor('inventory.view');
  const { medicineId } = await params;
  let data;
  try { data = await getMedicineStock(actor, medicineId); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }
  const { medicine, batches, movements } = data;
  const unit = medicine.base_unit.code;
  const canMove = can(actor, 'inventory.quarantine.create');
  const liveBatches = batches.filter((b) => b.qty_saleable + b.qty_quarantine + b.qty_damaged > 0)
    .map((b) => ({ id: b.id, label: `${b.batch_no} · ED ${dd.format(b.expiry_date)} · siap ${b.qty_saleable}` }));

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <PageHeader title={medicine.name} description={`${medicine.generic_name ?? ''} · ${medicine.sku} · satuan ${unit}`}
        back={{ href: '/persediaan', label: 'Persediaan' }} />

      <Section title="Batch">
        {batches.length === 0 ? <p className="text-sm text-gray-600">Belum ada batch.</p> : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
                <tr><th className="px-3 py-2">Batch</th><th className="px-3 py-2">ED</th><th className="px-3 py-2 text-right">HPP/sat</th>
                  <th className="px-3 py-2 text-right">Siap</th><th className="px-3 py-2 text-right">Karantina</th><th className="px-3 py-2 text-right">Rusak</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {batches.map((b) => {
                  const exp = b.expiry_date.toISOString().slice(0, 10);
                  return (
                    <tr key={b.id}>
                      <td className="px-3 py-2 font-medium">{b.batch_no}{b.is_recalled ? <Badge tone="red">Recall</Badge> : null}</td>
                      <td className="px-3 py-2">{dd.format(b.expiry_date)}{exp < today ? <Badge tone="red">ED</Badge> : null}</td>
                      <td className="px-3 py-2 text-right">{formatRupiah(b.unit_cost.toString())}</td>
                      <td className="px-3 py-2 text-right">{b.qty_saleable}</td>
                      <td className="px-3 py-2 text-right">{b.qty_quarantine}</td>
                      <td className="px-3 py-2 text-right">{b.qty_damaged}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Section>

      {canMove && liveBatches.length > 0 ? (
        <Section title="Pindah stok (karantina / rusak)">
          <BucketMoveForm action={moveBucketAction.bind(null, medicineId)} batches={liveBatches} />
        </Section>
      ) : null}

      <Section title="Kartu stok (100 pergerakan terakhir)">
        {movements.length === 0 ? <p className="text-sm text-gray-600">Belum ada pergerakan.</p> : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
                <tr><th className="px-3 py-2">Waktu</th><th className="px-3 py-2">Jenis</th><th className="px-3 py-2">Batch</th>
                  <th className="px-3 py-2">Dari→Ke</th><th className="px-3 py-2 text-right">Jumlah</th><th className="px-3 py-2">Ref</th><th className="px-3 py-2">Oleh</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {movements.map((m) => (
                  <tr key={m.id.toString()}>
                    <td className="whitespace-nowrap px-3 py-2 text-xs">{dt.format(m.occurred_at)}</td>
                    <td className="px-3 py-2">{MOVEMENT_LABELS[m.movement_type] ?? m.movement_type}</td>
                    <td className="px-3 py-2">{m.batch.batch_no}</td>
                    <td className="px-3 py-2 text-xs">{[m.bucket_from && BUCKET_LABELS[m.bucket_from], m.bucket_to && BUCKET_LABELS[m.bucket_to]].filter(Boolean).join(' → ')}</td>
                    <td className="px-3 py-2 text-right">{m.bucket_to ? '+' : '−'}{m.qty}</td>
                    <td className="px-3 py-2 font-mono text-xs">{m.ref_no}</td>
                    <td className="px-3 py-2 text-xs">{m.user.full_name}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Section>
    </div>
  );
}
