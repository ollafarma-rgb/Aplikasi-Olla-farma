'use client';

import { useActionState } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';
import { BUCKET_LABELS, STOCK_BUCKETS } from '@/modules/inventory/schemas';

type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;
type Batch = { id: string; label: string };

const bucketOptions = STOCK_BUCKETS.map((b) => ({ value: b, label: BUCKET_LABELS[b] }));

export function BucketMoveForm({ action, batches }: { action: Action; batches: Batch[] }) {
  const [state, formAction] = useActionState(action, initialActionState);
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="grid gap-3 sm:grid-cols-6" noValidate>
      {state.message ? <div className="sm:col-span-6"><Alert tone={state.ok ? 'success' : 'error'}>{state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai.' : state.message}</Alert></div> : null}
      <div className="sm:col-span-2">
        <SelectField label="Batch" name="batch_id" placeholder="— Pilih batch —" error={state.fields?.batch_id} options={batches.map((b) => ({ value: b.id, label: b.label }))} />
      </div>
      <SelectField label="Dari" name="from_bucket" defaultValue="SALEABLE" error={state.fields?.from_bucket} options={bucketOptions} />
      <SelectField label="Ke" name="to_bucket" defaultValue="QUARANTINE" error={state.fields?.to_bucket} options={bucketOptions} />
      <FormField label="Jumlah" name="qty" type="number" min={1} error={state.fields?.qty} />
      <div className="flex items-end"><SubmitButton size="md">Pindahkan</SubmitButton></div>
      <div className="sm:col-span-6"><FormField label="Alasan (opsional)" name="reason" error={state.fields?.reason} /></div>
    </form>
  );
}
