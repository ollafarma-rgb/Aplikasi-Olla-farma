import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { listMedicineOptions } from '@/modules/inventory/service';
import { openingBalanceAction } from '@/modules/inventory/actions';
import { EmptyState, PageHeader } from '@/components/ui/page';
import { OpeningForm } from './opening-form';

export const metadata: Metadata = { title: 'Saldo awal' };

export default async function OpeningBalancePage() {
  const actor = await requirePageActor('inventory.adjust.approve');
  const medicines = await listMedicineOptions(actor);
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Catat saldo awal" description="Masukkan stok awal per batch beserta HPP aktualnya. Setiap entri tercatat di kartu stok."
        back={{ href: '/persediaan', label: 'Persediaan' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        {medicines.length === 0 ? <EmptyState>Belum ada obat aktif. Tambahkan data obat lebih dulu.</EmptyState>
          : <OpeningForm action={openingBalanceAction} medicines={medicines} />}
      </div>
    </div>
  );
}
