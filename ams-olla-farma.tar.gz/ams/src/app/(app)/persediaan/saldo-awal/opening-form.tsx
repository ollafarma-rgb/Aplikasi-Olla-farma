'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';

type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;
type Option = { id: string; label: string };

export function OpeningForm({ action, medicines }: { action: Action; medicines: Option[] }) {
  const [state, formAction] = useActionState(action, initialActionState);
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message ? (
        <Alert tone={state.ok ? 'success' : 'error'}>
          {state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai merah.' : state.message}
        </Alert>
      ) : null}
      {state.ok && state.data?.medicineId ? (
        <Link href={`/persediaan/${state.data.medicineId}`} className="inline-block text-sm font-medium text-brand-700 hover:underline">
          Lihat kartu stok obat →
        </Link>
      ) : null}
      <SelectField label="Obat" name="medicine_id" placeholder="— Pilih obat —" error={state.fields?.medicine_id}
        options={medicines.map((m) => ({ value: m.id, label: m.label }))} />
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Nomor batch" name="batch_no" error={state.fields?.batch_no} />
        <FormField label="Tanggal kedaluwarsa" name="expiry_date" type="date" error={state.fields?.expiry_date} />
        <FormField label="Jumlah (satuan dasar)" name="qty" type="number" min={1} error={state.fields?.qty} />
        <FormField label="HPP per satuan (Rp)" name="unit_cost" inputMode="decimal" error={state.fields?.unit_cost}
          hint="Harga pokok aktual batch ini." />
      </div>
      <FormField label="Catatan (opsional)" name="note" error={state.fields?.note} />
      <SubmitButton>Catat saldo awal</SubmitButton>
    </form>
  );
}
