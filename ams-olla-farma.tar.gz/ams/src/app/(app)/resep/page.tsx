import { redirect } from 'next/navigation';

export default function ResepRedirectPage() {
  redirect('/penjualan/resep');
}
