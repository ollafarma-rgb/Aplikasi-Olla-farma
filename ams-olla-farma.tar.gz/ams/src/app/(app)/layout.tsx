import type { ReactNode } from 'react';
import { redirect } from 'next/navigation';
import { requireUser } from '@/lib/auth/server';
import { visibleNavItems } from '@/lib/navigation';
import { ROLES } from '@/lib/permissions/catalog';
import { AppShell } from '@/components/layout/app-shell';

/**
 * Semua halaman di grup (app) wajib login. Pengguna dengan sandi awal atau
 * sandi yang di-reset diarahkan dulu ke /akun/ganti-sandi (grup (account),
 * di luar layout ini), dan Server Action modul lain juga menolaknya
 * (lihat requireActionPermission).
 */
export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await requireUser();
  if (user.user.must_change_password) redirect('/akun/ganti-sandi');

  const nav = visibleNavItems(user.permissions).map(({ href, label, group }) => ({ href, label, group }));
  if (nav.length === 0) redirect('/tidak-diizinkan');

  const roleNames = user.user.roles.map((code) => ROLES.find((r) => r.code === code)?.name ?? code);

  return (
    <AppShell nav={nav} fullName={user.user.full_name} roleNames={roleNames}>
      {children}
    </AppShell>
  );
}
