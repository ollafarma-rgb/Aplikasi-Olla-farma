import { requirePageActor } from '@/lib/auth/server';
import {
  getCustomerDetail,
  getCustomerPrescriptions,
  getCustomerSales,
} from '@/modules/sales/service';
import { formatRupiah } from '@/lib/money/format';
import Link from 'next/link';

type CustomerDetail = Awaited<ReturnType<typeof getCustomerDetail>>;
type PrescriptionItem = Awaited<ReturnType<typeof getCustomerPrescriptions>>[number];
type SaleItem = Awaited<ReturnType<typeof getCustomerSales>>[number];

function formatDate(date: Date | null | undefined): string {
  if (!date) return '-';
  return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'long', year: 'numeric' }).format(date);
}

function formatDateTime(date: Date): string {
  return new Intl.DateTimeFormat('id-ID', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
    timeZone: 'Asia/Jakarta',
  }).format(date);
}

const STATUS_LABEL: Record<string, string> = {
  PENDING: 'Menunggu',
  VERIFIED: 'Terverifikasi',
  DISPENSED: 'Diberikan',
  ACTIVE: 'Aktif',
  CANCELLED: 'Dibatalkan',
};

const STATUS_COLOR: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-700',
  VERIFIED: 'bg-blue-100 text-blue-700',
  DISPENSED: 'bg-green-100 text-green-700',
  ACTIVE: 'bg-green-100 text-green-700',
  CANCELLED: 'bg-red-100 text-red-700',
  PAID: 'bg-green-100 text-green-700',
  PARTIAL: 'bg-yellow-100 text-yellow-700',
  UNPAID: 'bg-red-100 text-red-700',
  CASH: 'bg-gray-100 text-gray-700',
  RECEIVABLE: 'bg-orange-100 text-orange-700',
};

const PAYMENT_LABEL: Record<string, string> = {
  CASH: 'Tunai',
  RECEIVABLE: 'Piutang',
};

type Props = { params: Promise<{ id: string }>; searchParams: Promise<{ tab?: string }> };

export default async function PelangganDetailPage({ params, searchParams }: Props) {
  const { id } = await params;
  const { tab = 'kartu' } = await searchParams;

  const actor = await requirePageActor('customers.view_basic');

  const [customer, prescriptions, sales] = await Promise.all([
    getCustomerDetail(actor, id),
    getCustomerPrescriptions(actor, id),
    getCustomerSales(actor, id),
  ]);

  const creditAvailable = customer.credit_limit.minus(customer.credit_used);
  const creditUsedPct =
    customer.credit_limit.gt(0)
      ? Math.min(100, Math.round(customer.credit_used.div(customer.credit_limit).mul(100).toNumber()))
      : 0;

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
          <Link href="/pelanggan" className="hover:text-blue-600">Pelanggan</Link>
          <span>/</span>
          <span className="text-gray-900">{customer.name}</span>
        </div>
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{customer.name}</h1>
            <p className="text-sm text-gray-500 mt-1">
              Kode: <span className="font-mono">{customer.code}</span>
              {customer.phone && <> · {customer.phone}</>}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {customer.is_active ? (
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                Aktif
              </span>
            ) : (
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                Nonaktif
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="flex gap-1 -mb-px">
          {[
            { key: 'kartu', label: `Kartu Pasien` },
            { key: 'resep', label: `Riwayat Resep (${prescriptions.length})` },
            { key: 'pembelian', label: `Riwayat Pembelian (${sales.length})` },
          ].map((t) => (
            <Link
              key={t.key}
              href={`/pelanggan/${id}?tab=${t.key}`}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                tab === t.key
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {t.label}
            </Link>
          ))}
        </nav>
      </div>

      {/* TAB: KARTU PASIEN */}
      {tab === 'kartu' && (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {/* Info Dasar */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-4">
              Data Diri
            </h2>
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between">
                <dt className="text-gray-500">Nama Lengkap</dt>
                <dd className="font-medium text-gray-900">{customer.name}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Kode Pelanggan</dt>
                <dd className="font-mono text-gray-700">{customer.code}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Telepon</dt>
                <dd className="text-gray-700">{customer.phone ?? '-'}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Tanggal Lahir</dt>
                <dd className="text-gray-700">{formatDate(customer.date_of_birth)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Terdaftar Sejak</dt>
                <dd className="text-gray-700">{formatDate(customer.created_at)}</dd>
              </div>
              {customer.address && (
                <div>
                  <dt className="text-gray-500 mb-1">Alamat</dt>
                  <dd className="text-gray-700 text-xs leading-relaxed">{customer.address}</dd>
                </div>
              )}
            </dl>
          </div>

          {/* Kredit & Riwayat */}
          <div className="space-y-4">
            {/* Kredit */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-4">
                Informasi Kredit / Piutang
              </h2>
              {customer.credit_limit.lte(0) ? (
                <p className="text-sm text-gray-500">Pelanggan ini tidak memiliki limit kredit.</p>
              ) : (
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Limit Kredit</span>
                    <span className="font-medium">{formatRupiah(customer.credit_limit.toFixed(0))}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Terpakai</span>
                    <span className="font-medium text-orange-600">{formatRupiah(customer.credit_used.toFixed(0))}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Tersedia</span>
                    <span className={`font-medium ${creditAvailable.lte(0) ? 'text-red-600' : 'text-green-600'}`}>
                      {formatRupiah(creditAvailable.toFixed(0))}
                    </span>
                  </div>
                  <div className="mt-2">
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>Penggunaan kredit</span>
                      <span>{creditUsedPct}%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${creditUsedPct >= 90 ? 'bg-red-500' : creditUsedPct >= 70 ? 'bg-orange-400' : 'bg-green-500'}`}
                        style={{ width: `${creditUsedPct}%` }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Statistik */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-4">
                Statistik
              </h2>
              <div className="grid grid-cols-3 gap-3 text-center text-sm">
                <div className="bg-blue-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-blue-700">{customer._count.sales}</div>
                  <div className="text-xs text-blue-600 mt-1">Pembelian</div>
                </div>
                <div className="bg-purple-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-purple-700">{customer._count.prescriptions}</div>
                  <div className="text-xs text-purple-600 mt-1">Resep</div>
                </div>
                <div className="bg-orange-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-orange-700">{customer._count.receivables}</div>
                  <div className="text-xs text-orange-600 mt-1">Piutang</div>
                </div>
              </div>
            </div>
          </div>

          {/* Catatan Kesehatan */}
          {customer.notes && (
            <div className="md:col-span-2 bg-amber-50 border border-amber-200 rounded-xl p-5">
              <h2 className="text-sm font-semibold text-amber-800 uppercase tracking-wide mb-2">
                Catatan Kesehatan / Alergi
              </h2>
              <p className="text-sm text-amber-900 leading-relaxed whitespace-pre-wrap">{customer.notes}</p>
            </div>
          )}
        </div>
      )}

      {/* TAB: RIWAYAT RESEP */}
      {tab === 'resep' && (
        <div className="space-y-4">
          {prescriptions.length === 0 && (
            <div className="text-center py-12 text-gray-500 text-sm">
              Belum ada riwayat resep untuk pelanggan ini.
            </div>
          )}
          {prescriptions.map((rx: PrescriptionItem) => (
            <div key={rx.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="flex items-start justify-between px-5 py-4 border-b border-gray-100">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-sm font-medium text-gray-900">{rx.rx_no}</span>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLOR[rx.status] ?? 'bg-gray-100 text-gray-700'}`}>
                      {STATUS_LABEL[rx.status] ?? rx.status}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">
                    {formatDate(rx.prescribed_at)} · Dr. {rx.doctor_name}
                    {rx.clinic_name && ` · ${rx.clinic_name}`}
                    {rx.doctor_sip && ` (SIP: ${rx.doctor_sip})`}
                  </p>
                </div>
                {rx.sale && (
                  <Link
                    href={`/penjualan/${rx.sale.id}`}
                    className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                  >
                    {rx.sale.invoice_no} →
                  </Link>
                )}
              </div>
              {/* Item resep */}
              <div className="divide-y divide-gray-50">
                {rx.items.map((item: PrescriptionItem['items'][number]) => (
                  <div key={item.id} className="flex items-start justify-between px-5 py-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{item.medicine.name}</p>
                      {item.medicine.generic_name && (
                        <p className="text-xs text-gray-400">{item.medicine.generic_name}</p>
                      )}
                      {item.instructions && (
                        <p className="text-xs text-gray-500 mt-0.5 italic">{item.instructions}</p>
                      )}
                    </div>
                    <span className="text-sm font-medium text-gray-700 ml-4">{item.qty_prescribed}×</span>
                  </div>
                ))}
              </div>
              {rx.notes && (
                <div className="px-5 py-3 bg-gray-50 border-t border-gray-100">
                  <p className="text-xs text-gray-500 italic">{rx.notes}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* TAB: RIWAYAT PEMBELIAN */}
      {tab === 'pembelian' && (
        <div className="space-y-4">
          {sales.length === 0 && (
            <div className="text-center py-12 text-gray-500 text-sm">
              Belum ada riwayat pembelian untuk pelanggan ini.
            </div>
          )}
          {sales.map((sale: SaleItem) => {
            const totalItems = sale.items.reduce((s: number, i: SaleItem['items'][number]) => s + i.qty, 0);
            const receivable = sale.receivable;
            const remainingReceivable = receivable
              ? receivable.amount.minus(receivable.paid_amount)
              : null;

            return (
              <div key={sale.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="flex items-start justify-between px-5 py-4 border-b border-gray-100">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-sm font-medium text-gray-900">{sale.invoice_no}</span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLOR[sale.status] ?? 'bg-gray-100 text-gray-700'}`}>
                        {STATUS_LABEL[sale.status] ?? sale.status}
                      </span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${STATUS_COLOR[sale.payment_method] ?? 'bg-gray-100 text-gray-700'}`}>
                        {PAYMENT_LABEL[sale.payment_method] ?? sale.payment_method}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500">
                      {formatDateTime(sale.sold_at)} · Kasir: {sale.cashier.name}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-gray-900">{formatRupiah(sale.total_amount.toFixed(0))}</p>
                    <p className="text-xs text-gray-500">{totalItems} item</p>
                  </div>
                </div>

                {/* Item penjualan */}
                <div className="divide-y divide-gray-50">
                  {sale.items.map((item: SaleItem['items'][number]) => (
                    <div key={item.id} className="flex items-center justify-between px-5 py-2.5">
                      <span className="text-sm text-gray-700">{item.medicine.name}</span>
                      <div className="text-right ml-4">
                        <span className="text-xs text-gray-500">
                          {item.qty} {item.unit.name} × {formatRupiah(item.unit_price.toFixed(0))}
                        </span>
                        <span className="text-sm font-medium text-gray-900 ml-3">
                          {formatRupiah(item.line_total.toFixed(0))}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Footer: diskon & piutang */}
                {(sale.discount_amount.gt(0) || receivable) && (
                  <div className="px-5 py-3 bg-gray-50 border-t border-gray-100 flex flex-wrap gap-4 text-xs text-gray-600">
                    {sale.discount_amount.gt(0) && (
                      <span>Diskon: <strong className="text-red-600">-{formatRupiah(sale.discount_amount.toFixed(0))}</strong></span>
                    )}
                    {receivable && remainingReceivable && (
                      <span>
                        Piutang:{' '}
                        <span className={`font-medium ${receivable.status === 'PAID' ? 'text-green-700' : 'text-orange-600'}`}>
                          {STATUS_LABEL[receivable.status] ?? receivable.status}
                        </span>
                        {receivable.status !== 'PAID' && (
                          <> · Sisa {formatRupiah(remainingReceivable.toFixed(0))}</>
                        )}
                      </span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
