import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { ROLES } from '@/lib/permissions/catalog';
import { getUser } from '@/modules/users/service';
import {
  addLicenseAction, removeLicenseAction, resetPasswordAction, setUserActiveAction, unlockUserAction, updateUserAction,
} from '@/modules/users/actions';
import { ActionForm } from '@/components/ui/action-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PageHeader, Section } from '@/components/ui/page';
import { LicenseForm, ResetPasswordForm, UserForm } from '../user-forms';

export const metadata: Metadata = { title: 'Detail karyawan' };
const d = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });

export default async function UserDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('employees.view');
  const { id } = await params;
  let u;
  try { u = await getUser(id, actor); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }
  const canEdit = can(actor, 'users.manage');
  const self = u.id === actor.id;
  const initial: Record<string, string> = { full_name: u.full_name, phone: u.phone ?? '' };
  for (const r of u.roleCodes) initial[`role_${r}`] = 'on';

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title={u.full_name} description={u.username} back={{ href: '/karyawan', label: 'Karyawan' }}
        actions={<>{u.is_active ? <Badge tone="green">Aktif</Badge> : <Badge>Nonaktif</Badge>}{u.locked ? <Badge tone="red">Terkunci</Badge> : null}</>} />

      <Section title="Profil dan peran">
        <UserForm action={updateUserAction.bind(null, u.id)} roles={ROLES.map((r) => ({ code: r.code, name: r.name }))} initial={initial} isNew={false} canEdit={canEdit} />
      </Section>

      <Section title="Izin praktik">
        {u.licenses.length === 0 ? <p className="mb-3 text-sm text-gray-600">Belum ada izin praktik tercatat.</p> : (
          <ul className="mb-3 divide-y divide-gray-100 text-sm">
            {u.licenses.map((l) => (
              <li key={l.id} className="flex items-center justify-between py-2">
                <span><span className="font-medium">{l.license_type}</span> {l.number} · {l.valid_until ? `berlaku s.d. ${d.format(l.valid_until)}` : 'seumur hidup'}</span>
                {canEdit ? (
                  <ActionForm action={removeLicenseAction.bind(null, u.id, l.id)} confirmText="Hapus izin praktik ini?">
                    <Button type="submit" variant="ghost" size="sm">Hapus</Button>
                  </ActionForm>
                ) : null}
              </li>
            ))}
          </ul>
        )}
        {canEdit ? <LicenseForm action={addLicenseAction.bind(null, u.id)} /> : null}
      </Section>

      {canEdit ? (
        <Section title="Keamanan akun">
          <div className="space-y-4">
            {u.locked ? (
              <ActionForm action={unlockUserAction.bind(null, u.id)}>
                <p className="mb-2 text-sm text-gray-600">Akun terkunci setelah {u.failed_login_count} kali salah sandi.</p>
                <Button type="submit">Buka kunci akun</Button>
              </ActionForm>
            ) : null}
            {!self ? <ResetPasswordForm action={resetPasswordAction.bind(null, u.id)} /> : <p className="text-sm text-gray-600">Untuk akun sendiri, gunakan menu Ganti sandi.</p>}
            {!self ? (
              <ActionForm action={setUserActiveAction.bind(null, u.id, !u.is_active)}
                confirmText={u.is_active ? 'Nonaktifkan akun ini? Karyawan tidak bisa login lagi.' : undefined}>
                <Button type="submit" variant={u.is_active ? 'danger' : 'primary'}>{u.is_active ? 'Nonaktifkan akun' : 'Aktifkan akun'}</Button>
              </ActionForm>
            ) : null}
          </div>
        </Section>
      ) : null}
    </div>
  );
}
