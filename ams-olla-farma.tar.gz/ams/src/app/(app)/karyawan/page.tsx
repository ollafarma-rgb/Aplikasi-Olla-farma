import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { listUsers } from '@/modules/users/service';
import { Badge } from '@/components/ui/badge';
import { LinkButton, PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Karyawan & Pengguna' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });

export default async function UsersPage() {
  const actor = await requirePageActor('employees.view');
  const users = await listUsers(actor);
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title="Karyawan & Pengguna" description="Akun login, peran, dan izin praktik (STR/SIPA/SIPTTK)."
        actions={can(actor, 'users.manage') ? <LinkButton href="/karyawan/baru">Tambah karyawan</LinkButton> : null} />
      <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
            <tr><th className="px-3 py-2">Nama</th><th className="px-3 py-2">Peran</th><th className="px-3 py-2">Login terakhir</th><th className="px-3 py-2">Status</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-gray-50">
                <td className="px-3 py-2"><Link href={`/karyawan/${u.id}`} className="font-medium text-brand-800 hover:underline">{u.full_name}</Link>
                  <div className="text-xs text-gray-500">{u.username}</div></td>
                <td className="px-3 py-2">{u.roles.map((r) => r.name).join(', ')}</td>
                <td className="px-3 py-2 text-xs">{u.last_login_at ? dt.format(u.last_login_at) : 'Belum pernah'}</td>
                <td className="space-x-1 px-3 py-2">
                  {u.is_active ? <Badge tone="green">Aktif</Badge> : <Badge>Nonaktif</Badge>}
                  {u.locked ? <Badge tone="red">Terkunci</Badge> : null}
                  {u.licenseExpiringSoon ? <Badge tone="amber">Izin segera habis</Badge> : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
