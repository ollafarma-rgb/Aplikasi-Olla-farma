'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { initialActionState, type ActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { checkedOf, valueOf } from '@/components/ui/action-form';
import { CheckboxField, SelectField } from '@/components/ui/fields';
import { FormField } from '@/components/ui/form-field';
import { SubmitButton } from '@/components/ui/submit-button';
import { Button } from '@/components/ui/button';

type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;
export type RoleOption = { code: string; name: string };

/** Sandi sementara ditampilkan SEKALI; tidak disimpan di URL atau log. */
export function TemporaryPassword({ password, username }: { password: string; username?: string }) {
  return (
    <div className="rounded-md border border-amber-300 bg-amber-50 p-3 text-sm">
      <p className="font-medium text-amber-900">Sandi sementara{username ? ` untuk ${username}` : ''}:</p>
      <p className="my-1 select-all font-mono text-lg tracking-wider" data-testid="temporary-password">{password}</p>
      <p className="text-amber-900">Berikan langsung ke karyawan. Sandi ini hanya tampil sekali dan wajib diganti saat login pertama.</p>
    </div>
  );
}

export function UserForm({ action, roles, initial, isNew, canEdit }: {
  action: Action; roles: RoleOption[]; initial: Record<string, string>; isNew: boolean; canEdit: boolean;
}) {
  const [state, formAction] = useActionState(action, initialActionState);
  const v = (k: string) => valueOf(state, initial, k);
  if (isNew && state.ok && state.data?.temporaryPassword) {
    return (
      <div className="space-y-3">
        <Alert tone="success">Akun {state.data.username} berhasil dibuat.</Alert>
        <TemporaryPassword password={state.data.temporaryPassword} username={state.data.username} />
        <div className="flex gap-2">
          <Link href={`/karyawan/${state.data.id}`} className="inline-flex h-10 items-center rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Lihat akun</Link>
          <Link href="/karyawan" className="inline-flex h-10 items-center rounded-md border border-gray-300 bg-white px-4 text-sm font-medium hover:bg-gray-50">Kembali ke daftar</Link>
        </div>
      </div>
    );
  }
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message ? <Alert tone={state.ok ? 'success' : 'error'}>{state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai merah.' : state.message}</Alert> : null}
      <fieldset disabled={!canEdit} className="grid gap-4 sm:grid-cols-2">
        {isNew ? <FormField label="Nama pengguna (untuk login)" name="username" defaultValue={v('username')} error={state.fields?.username} autoCapitalize="none" hint="Huruf kecil, contoh: kasir.rina" /> : null}
        <FormField label="Nama lengkap" name="full_name" defaultValue={v('full_name')} error={state.fields?.full_name} />
        <FormField label="Telepon" name="phone" type="tel" defaultValue={v('phone')} error={state.fields?.phone} />
      </fieldset>
      <fieldset disabled={!canEdit} className="space-y-2">
        <legend className="mb-1 text-sm font-medium text-gray-800">Peran</legend>
        {roles.map((r) => <CheckboxField key={r.code} name={`role_${r.code}`} label={r.name} defaultChecked={checkedOf(state, initial, `role_${r.code}`)} />)}
        {state.fields?.roles ? <p className="text-xs text-danger-700">{state.fields.roles}</p> : null}
      </fieldset>
      {canEdit ? <SubmitButton>{isNew ? 'Buat akun' : 'Simpan perubahan'}</SubmitButton> : null}
    </form>
  );
}

export function ResetPasswordForm({ action }: { action: Action }) {
  const [state, formAction] = useActionState(action, initialActionState);
  return (
    <form action={formAction} className="space-y-2" onSubmit={(e) => { if (!window.confirm('Reset sandi karyawan ini? Semua sesinya akan diputus.')) e.preventDefault(); }}>
      {state.ok && state.data?.temporaryPassword ? <TemporaryPassword password={state.data.temporaryPassword} /> : null}
      {!state.ok && state.message ? <Alert tone="error">{state.message}</Alert> : null}
      <Button type="submit" variant="secondary">Reset sandi</Button>
    </form>
  );
}

export function LicenseForm({ action }: { action: Action }) {
  const [state, formAction] = useActionState(action, initialActionState);
  const v = (k: string) => valueOf(state, {}, k);
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="grid gap-3 rounded-md bg-gray-50 p-3 sm:grid-cols-4" noValidate>
      {state.message ? <div className="sm:col-span-4"><Alert tone={state.ok ? 'success' : 'error'}>{state.ok ? state.message : state.fields ? 'Periksa isian yang ditandai merah.' : state.message}</Alert></div> : null}
      <SelectField label="Jenis" name="license_type" defaultValue={v('license_type')} placeholder="— Pilih —" error={state.fields?.license_type}
        options={[{ value: 'STR', label: 'STR' }, { value: 'SIPA', label: 'SIPA' }, { value: 'SIPTTK', label: 'SIPTTK' }, { value: 'OTHER', label: 'Lainnya' }]} />
      <FormField label="Nomor" name="number" defaultValue={v('number')} error={state.fields?.number} />
      <FormField label="Berlaku sampai" name="valid_until" type="date" defaultValue={v('valid_until')} error={state.fields?.valid_until} hint="Kosongkan bila seumur hidup." />
      <div className="flex items-end"><SubmitButton size="md">Tambah izin</SubmitButton></div>
    </form>
  );
}
