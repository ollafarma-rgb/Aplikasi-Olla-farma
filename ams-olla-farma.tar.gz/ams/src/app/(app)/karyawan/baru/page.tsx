import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { ROLES } from '@/lib/permissions/catalog';
import { createUserAction } from '@/modules/users/actions';
import { PageHeader } from '@/components/ui/page';
import { UserForm } from '../user-forms';

export const metadata: Metadata = { title: 'Tambah karyawan' };

export default async function NewUserPage() {
  await requirePageActor('users.manage');
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Tambah karyawan" description="Sandi sementara dibuat otomatis dan wajib diganti saat login pertama." back={{ href: '/karyawan', label: 'Karyawan' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        <UserForm action={createUserAction} roles={ROLES.map((r) => ({ code: r.code, name: r.name }))} initial={{}} isNew canEdit />
      </div>
    </div>
  );
}
