import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { getDashboardKpi, getSalesChart } from '@/modules/dashboard/service';

export const metadata: Metadata = { title: 'Dashboard' };

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

function KpiCard({
  label, value, sub, tone, href,
}: { label: string; value: string; sub?: string; tone?: 'red' | 'amber' | 'green' | 'default'; href?: string }) {
  const toneClass = {
    red: 'border-red-200 bg-red-50',
    amber: 'border-amber-200 bg-amber-50',
    green: 'border-green-200 bg-green-50',
    default: 'border-gray-200 bg-white',
  }[tone ?? 'default'];

  const inner = (
    <div className={`rounded-lg border p-4 ${toneClass}`}>
      <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-gray-900">{value}</p>
      {sub && <p className="mt-0.5 text-xs text-gray-500">{sub}</p>}
    </div>
  );

  if (href) return <Link href={href} className="block hover:opacity-90">{inner}</Link>;
  return inner;
}

/** Bar chart sederhana tanpa library eksternal */
function SalesBarChart({ data }: { data: { date: string; total: number; count: number }[] }) {
  const max = Math.max(...data.map(d => d.total), 1);
  const dtFmt = new Intl.DateTimeFormat('id-ID', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'Asia/Jakarta' });

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-4">
      <h3 className="mb-4 text-sm font-semibold text-gray-700">Penjualan 7 Hari Terakhir</h3>
      <div className="flex items-end gap-1 h-32">
        {data.map(d => {
          const pct = Math.round((d.total / max) * 100);
          return (
            <div key={d.date} className="flex flex-1 flex-col items-center gap-1 group">
              <div
                className="relative w-full bg-brand-600 rounded-t hover:bg-brand-700 transition-colors"
                style={{ height: `${Math.max(pct, 2)}%` }}
              >
                {/* tooltip */}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block z-10
                                whitespace-nowrap rounded bg-gray-800 px-2 py-1 text-xs text-white shadow">
                  {idr.format(d.total)}<br />{d.count} transaksi
                </div>
              </div>
              <span className="text-[9px] text-gray-400 text-center leading-tight">
                {dtFmt.format(new Date(d.date + 'T00:00:00+07:00'))}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ sandi?: string }>;
}) {
  const actor = await requirePageActor('dashboard.operational.view');
  const { sandi } = await searchParams;

  const [kpi, chart] = await Promise.all([
    getDashboardKpi(actor),
    getSalesChart(actor, 7),
  ]);

  const canFinance = can(actor, 'dashboard.finance.view');

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {sandi === 'diganti' && (
        <div className="rounded-md bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-800">
          Kata sandi berhasil diganti. Sesi di perangkat lain telah dikeluarkan.
        </div>
      )}

      <div>
        <h1 className="text-xl font-semibold text-gray-900">Dashboard</h1>
        <p className="mt-0.5 text-sm text-gray-500">
          {new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' }).format(new Date())}
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <KpiCard
          label="Penjualan Hari Ini"
          value={idr.format(kpi.salesToday)}
          sub={`${kpi.salesCount} transaksi`}
          tone="green"
          href="/penjualan/sesi"
        />
        <KpiCard
          label="Stok Kritis"
          value={String(kpi.stockCritical)}
          sub="SKU di bawah minimum"
          tone={kpi.stockCritical > 0 ? 'red' : 'default'}
          href="/persediaan?filter=kritis"
        />
        <KpiCard
          label="Mendekati Kadaluarsa"
          value={String(kpi.expiryWarning)}
          sub="batch ED < 30 hari"
          tone={kpi.expiryWarning > 0 ? 'amber' : 'default'}
          href="/persediaan?filter=ed"
        />
        {canFinance && (
          <KpiCard
            label="Piutang Terbuka"
            value={idr.format(kpi.receivableOpen)}
            sub={`${kpi.receivableCount} piutang`}
            tone={kpi.receivableOpen > 0 ? 'amber' : 'default'}
            href="/keuangan/piutang"
          />
        )}
      </div>

      {/* Chart */}
      <SalesBarChart data={chart} />

      {/* Menu cepat laporan */}
      <div className="rounded-lg border border-gray-200 bg-white p-4">
        <h3 className="mb-3 text-sm font-semibold text-gray-700">Laporan</h3>
        <div className="flex flex-wrap gap-2">
          <Link href="/laporan/penjualan" className="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm hover:bg-gray-50">
            Laporan Penjualan
          </Link>
          <Link href="/laporan/stok" className="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm hover:bg-gray-50">
            Laporan Stok
          </Link>
          {canFinance && (
            <Link href="/keuangan/piutang/aging" className="rounded-md border border-gray-300 bg-white px-3 py-1.5 text-sm hover:bg-gray-50">
              Aging Piutang
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
