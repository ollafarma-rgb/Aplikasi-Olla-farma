import type { Metadata } from 'next';
import { requirePageActor } from '@/lib/auth/server';
import { listMedicineOptions } from '@/modules/inventory/service';
import { PageHeader } from '@/components/ui/page';
import { CreateOpnameForm } from '../opname-forms';

export const metadata: Metadata = { title: 'Mulai opname' };

export default async function NewOpnamePage() {
  const actor = await requirePageActor('inventory.opname.count');
  const medicines = await listMedicineOptions(actor);
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Mulai stok opname" description="Pilih lingkup, lalu hitung fisik dan isi hasilnya." back={{ href: '/opname', label: 'Stok Opname' }} />
      <div className="rounded-lg border border-gray-200 bg-white p-4"><CreateOpnameForm medicines={medicines} /></div>
    </div>
  );
}
