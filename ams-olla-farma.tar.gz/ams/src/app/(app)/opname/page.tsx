import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { listOpnames } from '@/modules/inventory/service';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Stok Opname' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const tone = { DRAFT: 'gray', COUNTING: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;
const label = { DRAFT: 'Draf', COUNTING: 'Menghitung', POSTED: 'Selesai', CANCELLED: 'Dibatalkan' } as const;

export default async function OpnamesPage() {
  const actor = await requirePageActor('inventory.view');
  const rows = await listOpnames(actor);
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title="Stok Opname" description="Hitung fisik stok dan posting selisihnya. Selisih dikoreksi otomatis saat diposting apoteker/pemilik."
        actions={can(actor, 'inventory.opname.count') ? <LinkButton href="/opname/baru">Mulai opname</LinkButton> : null} />
      {rows.length === 0 ? <EmptyState>Belum ada stok opname.</EmptyState> : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr><th className="px-3 py-2">Nomor</th><th className="px-3 py-2">Lingkup</th><th className="px-3 py-2 text-right">Item</th><th className="px-3 py-2">Dibuat</th><th className="px-3 py-2">Status</th></tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rows.map((o) => (
                <tr key={o.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2"><Link href={`/opname/${o.id}`} className="font-mono text-brand-800 hover:underline">{o.opname_no}</Link></td>
                  <td className="px-3 py-2">{o.scope_note ?? 'Semua stok siap jual'}</td>
                  <td className="px-3 py-2 text-right">{o._count.items}</td>
                  <td className="px-3 py-2 text-xs">{o.creator.full_name} · {dt.format(o.started_at)}</td>
                  <td className="px-3 py-2"><Badge tone={tone[o.status]}>{label[o.status]}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
