'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { createOpnameAction, saveOpnameCountsAction } from '@/modules/inventory/actions';
import { initialActionState } from '@/lib/forms';
import { Alert } from '@/components/ui/alert';
import { SubmitButton } from '@/components/ui/submit-button';

type Option = { id: string; label: string };
type Item = { id: string; medicine: string; sku: string; batch_no: string; system_qty: number; counted_qty: number | null };

export function CreateOpnameForm({ medicines }: { medicines: Option[] }) {
  const [state, formAction] = useActionState(createOpnameAction, initialActionState);
  if (state.ok && state.data?.id) {
    return (
      <div className="space-y-3">
        <Alert tone="success">Opname {state.data.opnameNo} dimulai. Silakan hitung fisik dan isi hasilnya.</Alert>
        <Link href={`/opname/${state.data.id}`} className="inline-flex h-10 items-center rounded-md bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">Mulai menghitung</Link>
      </div>
    );
  }
  return (
    <form action={formAction} key={state.submittedAt ?? 0} className="space-y-4" noValidate>
      {state.message && !state.ok ? <Alert tone="error">{state.message}</Alert> : null}
      <label className="block">
        <span className="mb-1 block text-sm font-medium text-gray-800">Lingkup obat</span>
        <select name="medicine_id" defaultValue="" className="h-10 w-full rounded-md border border-gray-300 bg-white px-2 text-sm">
          <option value="">Semua obat dengan stok siap jual</option>
          {medicines.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
        </select>
      </label>
      <label className="block">
        <span className="mb-1 block text-sm font-medium text-gray-800">Catatan lingkup (opsional)</span>
        <input name="scope_note" className="h-10 w-full rounded-md border border-gray-300 bg-white px-3 text-sm" placeholder="mis. Rak A, golongan keras" />
      </label>
      <p className="text-xs text-gray-500">Saat dimulai, jumlah sistem disalin sebagai acuan. Selisih dihitung dari stok terkini saat diposting.</p>
      <SubmitButton>Mulai opname</SubmitButton>
    </form>
  );
}

export function CountForm({ opnameId, items }: { opnameId: string; items: Item[] }) {
  const [state, formAction] = useActionState(saveOpnameCountsAction.bind(null, opnameId), initialActionState);
  return (
    <form action={formAction} className="space-y-3" noValidate>
      {state.message ? <Alert tone={state.ok ? 'success' : 'error'}>{state.message}</Alert> : null}
      <input type="hidden" name="item_ids" value={items.map((i) => i.id).join(',')} />
      <div className="overflow-x-auto rounded-md border border-gray-200">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
            <tr><th className="px-3 py-2">Obat</th><th className="px-3 py-2">Batch</th><th className="px-3 py-2 text-right">Sistem</th><th className="px-3 py-2">Hitung fisik</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {items.map((i) => (
              <tr key={i.id}>
                <td className="px-3 py-2">{i.medicine}<div className="text-xs text-gray-500">{i.sku}</div></td>
                <td className="px-3 py-2">{i.batch_no}</td>
                <td className="px-3 py-2 text-right">{i.system_qty}</td>
                <td className="px-3 py-2">
                  <input name={`count_${i.id}`} type="number" min={0} defaultValue={i.counted_qty ?? ''} placeholder="—"
                    className="h-9 w-24 rounded-md border border-gray-300 bg-white px-2 text-sm" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <SubmitButton>Simpan hasil hitung</SubmitButton>
    </form>
  );
}
