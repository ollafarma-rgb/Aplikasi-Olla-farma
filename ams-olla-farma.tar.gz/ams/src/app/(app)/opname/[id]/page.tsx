import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { AppError } from '@/lib/errors';
import { getOpname } from '@/modules/inventory/service';
import { cancelOpnameAction, postOpnameAction } from '@/modules/inventory/actions';
import { ActionForm } from '@/components/ui/action-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PageHeader, Section } from '@/components/ui/page';
import { CountForm } from '../opname-forms';

export const metadata: Metadata = { title: 'Detail opname' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const tone = { DRAFT: 'gray', COUNTING: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;
const label = { DRAFT: 'Draf', COUNTING: 'Menghitung', POSTED: 'Selesai', CANCELLED: 'Dibatalkan' } as const;

export default async function OpnameDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('inventory.view');
  const { id } = await params;
  let op;
  try { op = await getOpname(actor, id); } catch (e) { if (e instanceof AppError && e.code === 'NOT_FOUND') notFound(); throw e; }

  const counting = op.status === 'COUNTING';
  const isCreator = op.created_by === actor.id;
  const items = op.items.map((i) => ({
    id: i.id, medicine: i.batch.medicine.name, sku: i.batch.medicine.sku, batch_no: i.batch.batch_no,
    system_qty: i.system_qty, counted_qty: i.counted_qty,
  }));
  const counted = op.items.filter((i) => i.counted_qty !== null);
  const diffs = counted.filter((i) => (i.counted_qty as number) !== i.system_qty).length;

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <PageHeader title={op.opname_no} description={`${op.scope_note ?? 'Semua stok siap jual'} · dibuat ${op.creator.full_name} · ${dt.format(op.started_at)}`}
        back={{ href: '/opname', label: 'Stok Opname' }} actions={<Badge tone={tone[op.status]}>{label[op.status]}</Badge>} />

      {counting && can(actor, 'inventory.opname.count') ? (
        <Section title="Hitung fisik"><CountForm opnameId={op.id} items={items} /></Section>
      ) : (
        <Section title="Hasil hitung">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
                <tr><th className="px-3 py-2">Obat</th><th className="px-3 py-2">Batch</th><th className="px-3 py-2 text-right">Sistem</th><th className="px-3 py-2 text-right">Hitung</th><th className="px-3 py-2 text-right">Selisih</th></tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {op.items.map((i) => {
                  const diff = i.counted_qty === null ? null : i.counted_qty - i.system_qty;
                  return (
                    <tr key={i.id}>
                      <td className="px-3 py-2">{i.batch.medicine.name}<div className="text-xs text-gray-500">{i.batch.medicine.sku}</div></td>
                      <td className="px-3 py-2">{i.batch.batch_no}</td>
                      <td className="px-3 py-2 text-right">{i.system_qty}</td>
                      <td className="px-3 py-2 text-right">{i.counted_qty ?? '—'}</td>
                      <td className={`px-3 py-2 text-right font-medium ${diff && diff < 0 ? 'text-danger-700' : diff && diff > 0 ? 'text-brand-800' : 'text-gray-500'}`}>{diff === null ? '—' : diff > 0 ? `+${diff}` : diff}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Section>
      )}

      {counting ? (
        <Section title="Tindakan">
          {can(actor, 'inventory.opname.post') ? (
            isCreator ? (
              <p className="text-sm text-gray-600">Anda memulai opname ini, jadi tidak bisa memposting sendiri. Minta apoteker atau pemilik lain untuk memposting.</p>
            ) : (
              <ActionForm action={postOpnameAction.bind(null, op.id)} confirmText={`Posting opname? ${diffs} selisih akan dikoreksi ke stok.`}>
                <Button type="submit">Posting &amp; koreksi selisih ({diffs})</Button>
              </ActionForm>
            )
          ) : <p className="text-sm text-gray-600">Menunggu posting oleh apoteker atau pemilik.</p>}
          {can(actor, 'inventory.opname.count') ? (
            <div className="mt-3">
              <ActionForm action={cancelOpnameAction.bind(null, op.id)} confirmText="Batalkan opname ini?">
                <Button type="submit" variant="ghost">Batalkan opname</Button>
              </ActionForm>
            </div>
          ) : null}
        </Section>
      ) : op.posted_at ? (
        <p className="text-sm text-gray-600">Diposting {dt.format(op.posted_at)}{op.approver ? ` oleh ${op.approver.full_name}` : ''}.</p>
      ) : null}
    </div>
  );
}
