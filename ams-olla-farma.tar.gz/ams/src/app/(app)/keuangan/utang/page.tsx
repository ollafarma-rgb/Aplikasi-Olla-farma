import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { EmptyState, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Utang Dagang (AP)' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const statusTone = { UNPAID: 'red', PARTIAL: 'amber', PAID: 'green' } as const;
const statusLabel = { UNPAID: 'Belum Bayar', PARTIAL: 'Sebagian', PAID: 'Lunas' } as const;

type SP = Promise<{ page?: string; supplier?: string; status?: string }>;

export default async function APListPage({ searchParams }: { searchParams: SP }) {
  await requirePageActor('finance.view');
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page ?? 1));
  const pageSize = 25;

  const where = {
    ...(sp.status ? { status: sp.status } : {}),
    ...(sp.supplier ? { gr: { supplier: { name: { contains: sp.supplier, mode: 'insensitive' as const } } } } : {}),
  };

  const [items, total] = await Promise.all([
    prisma.purchaseInvoice.findMany({
      where,
      include: {
        gr: { include: { supplier: { select: { id: true, name: true } } } },
        payments: { select: { id: true, amount: true } },
      },
      orderBy: [{ status: 'asc' }, { due_date: 'asc' }],
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.purchaseInvoice.count({ where }),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  // Ringkasan
  const summary = await prisma.purchaseInvoice.aggregate({
    where: { status: { in: ['UNPAID', 'PARTIAL'] } },
    _sum: { subtotal: true, amount_paid: true },
  });
  const totalUtang = Number(summary._sum.subtotal ?? 0) - Number(summary._sum.amount_paid ?? 0);

  const suppliers = await prisma.supplier.findMany({ orderBy: { name: 'asc' }, select: { id: true, name: true } });

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Utang Dagang (AP)"
        description="Daftar semua faktur pembelian dan statusnya."
        back={{ href: '/keuangan', label: 'Keuangan' }}
      />

      {/* Ringkasan */}
      <div className="mb-4 rounded-lg border border-red-200 bg-red-50 p-4">
        <p className="text-xs text-red-600">Total Utang Belum Lunas</p>
        <p className="mt-1 text-xl font-bold text-red-800">{idr.format(totalUtang)}</p>
      </div>

      {/* Filter */}
      <form method="get" className="mb-3 flex flex-wrap gap-2">
        <select name="supplier" defaultValue={sp.supplier ?? ''} className="h-10 rounded-md border border-gray-300 bg-white px-3 text-sm">
          <option value="">Semua pemasok</option>
          {suppliers.map((s: any) => (
            <option key={s.id} value={s.name}>{s.name}</option>
          ))}
        </select>
        <select name="status" defaultValue={sp.status ?? ''} className="h-10 rounded-md border border-gray-300 bg-white px-3 text-sm">
          <option value="">Semua status</option>
          <option value="UNPAID">Belum Bayar</option>
          <option value="PARTIAL">Sebagian</option>
          <option value="PAID">Lunas</option>
        </select>
        <button type="submit" className="rounded-md border border-gray-300 bg-white px-4 text-sm hover:bg-gray-50">Filter</button>
        <a href="/keuangan/utang" className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm text-gray-600 hover:bg-gray-50">Reset</a>
      </form>

      {items.length === 0 ? (
        <EmptyState>Tidak ada utang dagang yang cocok.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-3 py-2">No. Faktur</th>
                <th className="px-3 py-2">Pemasok</th>
                <th className="px-3 py-2 text-right">Total</th>
                <th className="px-3 py-2 text-right">Sisa</th>
                <th className="px-3 py-2">Jatuh Tempo</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((inv: any) => {
                const remaining = Number(inv.subtotal) - Number(inv.amount_paid);
                const isOverdue = inv.status !== 'PAID' && new Date(inv.due_date) < new Date();
                return (
                  <tr key={inv.id} className={`hover:bg-gray-50 ${isOverdue ? 'bg-red-50' : ''}`}>
                    <td className="px-3 py-2">
                      <Link href={`/keuangan/faktur/${inv.id}`} className="font-mono text-brand-800 hover:underline">
                        {inv.inv_no}
                      </Link>
                    </td>
                    <td className="px-3 py-2">{inv.gr?.supplier?.name ?? '-'}</td>
                    <td className="px-3 py-2 text-right">{idr.format(Number(inv.subtotal))}</td>
                    <td className={`px-3 py-2 text-right font-medium ${remaining > 0 ? 'text-red-700' : 'text-gray-400'}`}>
                      {idr.format(remaining)}
                    </td>
                    <td className={`px-3 py-2 text-xs ${isOverdue ? 'font-semibold text-red-700' : ''}`}>
                      {dt.format(new Date(inv.due_date))}{isOverdue ? ' ⚠' : ''}
                    </td>
                    <td className="px-3 py-2">
                      <Badge tone={statusTone[inv.status as keyof typeof statusTone] ?? 'gray'}>
                        {statusLabel[inv.status as keyof typeof statusLabel] ?? inv.status}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={pages} total={total} params={{ status: sp.status, supplier: sp.supplier }} basePath="/keuangan/utang" />
    </div>
  );
}
