import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { listPurchaseInvoices } from '@/modules/sales/service';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Faktur Pembelian' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const statusTone = { UNPAID: 'red', PARTIAL: 'amber', PAID: 'green' } as const;
const statusLabel = { UNPAID: 'Belum Bayar', PARTIAL: 'Sebagian', PAID: 'Lunas' } as const;

type SP = Promise<{ q?: string; page?: string; status?: string }>;

export default async function PurchaseInvoiceListPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('finance.view');
  const sp = await searchParams;
  const { items, total, page, pageSize, q } = await listPurchaseInvoices(actor, {
    ...sp,
    page: sp.page ? Number(sp.page) : undefined,
  });
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Faktur Pembelian"
        description="Faktur dari pemasok atas penerimaan barang yang sudah diposting."
        back={{ href: '/keuangan', label: 'Keuangan' }}
        actions={can(actor, 'procurement.receive.record') ? (
          <LinkButton href="/keuangan/faktur/baru">Buat Faktur</LinkButton>
        ) : null}
      />
      <form method="get" className="mb-3 flex flex-wrap gap-2">
        <input
          name="q" defaultValue={q}
          placeholder="Cari nomor faktur atau pemasok…"
          className="h-10 w-full max-w-sm rounded-md border border-gray-300 bg-white px-3 text-sm"
        />
        <select name="status" defaultValue={sp.status ?? ''} className="h-10 rounded-md border border-gray-300 bg-white px-3 text-sm">
          <option value="">Semua status</option>
          <option value="UNPAID">Belum Bayar</option>
          <option value="PARTIAL">Sebagian</option>
          <option value="PAID">Lunas</option>
        </select>
        <button type="submit" className="rounded-md border border-gray-300 bg-white px-4 text-sm hover:bg-gray-50">Cari</button>
      </form>

      {items.length === 0 ? (
        <EmptyState>Belum ada faktur pembelian.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-3 py-2">No. Faktur</th>
                <th className="px-3 py-2">Pemasok</th>
                <th className="px-3 py-2">No. Faktur Pemasok</th>
                <th className="px-3 py-2 text-right">Total</th>
                <th className="px-3 py-2 text-right">Sudah Dibayar</th>
                <th className="px-3 py-2">Jatuh Tempo</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((inv: any) => {
                const isOverdue = inv.status !== 'PAID' && new Date(inv.due_date) < new Date();
                return (
                  <tr key={inv.id} className="hover:bg-gray-50">
                    <td className="px-3 py-2">
                      <Link href={`/keuangan/faktur/${inv.id}`} className="font-mono text-brand-800 hover:underline">
                        {inv.inv_no}
                      </Link>
                    </td>
                    <td className="px-3 py-2">{inv.gr?.supplier?.name ?? '-'}</td>
                    <td className="px-3 py-2 font-mono text-xs">{inv.supplier_inv_no ?? '-'}</td>
                    <td className="px-3 py-2 text-right">{idr.format(Number(inv.subtotal))}</td>
                    <td className="px-3 py-2 text-right">{idr.format(Number(inv.amount_paid))}</td>
                    <td className={`px-3 py-2 text-xs ${isOverdue ? 'font-semibold text-red-600' : ''}`}>
                      {dt.format(new Date(inv.due_date))}{isOverdue ? ' ⚠' : ''}
                    </td>
                    <td className="px-3 py-2">
                      <Badge tone={statusTone[inv.status as keyof typeof statusTone] ?? 'gray'}>
                        {statusLabel[inv.status as keyof typeof statusLabel] ?? inv.status}
                      </Badge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={pages} total={total} params={{ q, status: sp.status }} basePath="/keuangan/faktur" />
    </div>
  );
}
