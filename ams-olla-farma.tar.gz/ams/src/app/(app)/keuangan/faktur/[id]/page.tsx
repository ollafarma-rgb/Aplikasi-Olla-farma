import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { getPurchaseInvoiceDetail, recordSupplierPayment } from '@/modules/sales/service';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail Faktur Pembelian' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'long', timeZone: 'Asia/Jakarta' });
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const statusTone = { UNPAID: 'red', PARTIAL: 'amber', PAID: 'green' } as const;
const statusLabel = { UNPAID: 'Belum Dibayar', PARTIAL: 'Sebagian Dibayar', PAID: 'Lunas' } as const;

export default async function PurchaseInvoiceDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('finance.view');
  const { id } = await params;
  const inv = await getPurchaseInvoiceDetail(actor, id).catch(() => null);
  if (!inv) notFound();

  const canPay = can(actor, 'finance.payable.pay') && inv.status !== 'PAID';
  const remaining = Number(inv.subtotal) - Number(inv.amount_paid);
  const isOverdue = inv.status !== 'PAID' && new Date(inv.due_date) < new Date();

  async function handlePayment(fd: FormData) {
    'use server';
    const a = await (await import('@/lib/auth/server')).requirePageActor('finance.payable.pay');
    const { recordSupplierPayment: rsp } = await import('@/modules/sales/service');
    await rsp(a, {
      invoice_id: id,
      payment_date: String(fd.get('payment_date')),
      amount: String(fd.get('amount')).replace(/\./g, '').replace(',', '.'),
      reference_no: String(fd.get('reference_no') ?? '').trim() || null,
      notes: String(fd.get('notes') ?? '').trim() || null,
    });
  }

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title={`Faktur ${inv.inv_no}`}
        description={inv.gr?.supplier?.name ?? ''}
        back={{ href: '/keuangan/faktur', label: 'Faktur Pembelian' }}
      />

      {/* Info faktur */}
      <div className="grid gap-4 sm:grid-cols-4">
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Status</p>
          <div className="mt-1">
            <Badge tone={statusTone[inv.status as keyof typeof statusTone] ?? 'gray'}>
              {statusLabel[inv.status as keyof typeof statusLabel] ?? inv.status}
            </Badge>
          </div>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Total Faktur</p>
          <p className="mt-1 text-sm font-semibold">{idr.format(Number(inv.subtotal))}</p>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Sudah Dibayar</p>
          <p className="mt-1 text-sm font-semibold text-green-700">{idr.format(Number(inv.amount_paid))}</p>
        </div>
        <div className={`rounded-lg border p-4 ${isOverdue ? 'border-red-300 bg-red-50' : 'border-gray-200 bg-white'}`}>
          <p className={`text-xs ${isOverdue ? 'text-red-600' : 'text-gray-500'}`}>Jatuh Tempo</p>
          <p className={`mt-1 text-sm font-semibold ${isOverdue ? 'text-red-700' : ''}`}>{dt.format(new Date(inv.due_date))}</p>
        </div>
      </div>

      {/* Penerimaan barang */}
      {inv.gr && (
        <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-500">Penerimaan Barang</p>
              <Link href={`/pengadaan/penerimaan/${inv.gr_id}`} className="mt-1 font-mono text-sm text-brand-800 hover:underline">
                {inv.gr.gr_no}
              </Link>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500">No. Faktur Pemasok</p>
              <p className="mt-1 text-sm">{inv.supplier_inv_no ?? '-'}</p>
            </div>
          </div>
        </div>
      )}

      {/* Form bayar */}
      {canPay && (
        <div className="mt-4 rounded-lg border border-brand-200 bg-brand-50 p-4">
          <h2 className="mb-3 text-sm font-semibold text-brand-900">Catat Pembayaran</h2>
          <form action={handlePayment} className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-gray-700">Tanggal Bayar *</label>
              <input
                name="payment_date" type="date" required
                defaultValue={new Date().toISOString().split('T')[0]}
                className="mt-1 h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700">Jumlah (Rp) *</label>
              <input
                name="amount" type="text" required
                defaultValue={remaining.toFixed(0)}
                className="mt-1 h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-sm"
              />
              <p className="mt-0.5 text-xs text-gray-500">Sisa: {idr.format(remaining)}</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700">No. Referensi (transfer/cek)</label>
              <input name="reference_no" className="mt-1 h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700">Catatan</label>
              <input name="notes" className="mt-1 h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-sm" />
            </div>
            <div className="sm:col-span-2 flex justify-end">
              <button type="submit" className="rounded-md bg-brand-800 px-5 py-2 text-sm font-medium text-white hover:bg-brand-900">
                Simpan Pembayaran
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Riwayat pembayaran */}
      {inv.payments && inv.payments.length > 0 && (
        <div className="mt-4 rounded-lg border border-gray-200 bg-white">
          <div className="border-b border-gray-200 px-4 py-3">
            <h2 className="text-sm font-semibold">Riwayat Pembayaran</h2>
          </div>
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-xs uppercase text-gray-500">
              <tr>
                <th className="px-3 py-2 text-left">Tanggal</th>
                <th className="px-3 py-2 text-right">Jumlah</th>
                <th className="px-3 py-2 text-left">Referensi</th>
                <th className="px-3 py-2 text-left">Catatan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {inv.payments.map((pay: any) => (
                <tr key={pay.id}>
                  <td className="px-3 py-2">{dt.format(new Date(pay.payment_date))}</td>
                  <td className="px-3 py-2 text-right font-medium">{idr.format(Number(pay.amount))}</td>
                  <td className="px-3 py-2 font-mono text-xs">{pay.reference_no ?? '-'}</td>
                  <td className="px-3 py-2 text-xs text-gray-600">{pay.notes ?? '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
