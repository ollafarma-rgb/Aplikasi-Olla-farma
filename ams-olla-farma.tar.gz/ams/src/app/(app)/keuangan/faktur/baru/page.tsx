import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { prisma } from '@/lib/database/client';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Buat Faktur Pembelian' };

export default async function NewInvoicePage() {
  await requirePageActor('procurement.receive.record');

  // GR yang sudah POSTED dan belum punya faktur
  const eligibleGRs = await prisma.goodsReceipt.findMany({
    where: {
      status: 'POSTED',
      purchase_invoices: { none: {} },
    },
    include: {
      supplier: { select: { name: true } },
      items: { select: { qty: true, unit_cost: true } },
    },
    orderBy: { received_at: 'desc' },
    take: 100,
  });

  const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

  async function handleSubmit(fd: FormData) {
    'use server';
    const a = await (await import('@/lib/auth/server')).requirePageActor('procurement.receive.record');
    const { createPurchaseInvoice } = await import('@/modules/sales/service');
    const inv = await createPurchaseInvoice(a, {
      gr_id: String(fd.get('gr_id')),
      supplier_inv_no: String(fd.get('supplier_inv_no') ?? '').trim() || null,
      invoice_date: String(fd.get('invoice_date')),
      due_date: String(fd.get('due_date')),
      notes: String(fd.get('notes') ?? '').trim() || null,
    });
    redirect(`/keuangan/faktur/${inv.id}`);
  }

  const today = new Date().toISOString().split('T')[0];
  // Default jatuh tempo: 30 hari
  const due = new Date(); due.setDate(due.getDate() + 30);
  const dueStr = due.toISOString().split('T')[0];

  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="Buat Faktur Pembelian" back={{ href: '/keuangan/faktur', label: 'Faktur Pembelian' }} />
      <p className="mb-4 text-sm text-gray-600">
        Pilih penerimaan barang yang sudah diposting untuk dibuatkan faktur utang ke pemasok.
      </p>

      <form action={handleSubmit} className="space-y-4 rounded-lg border border-gray-200 bg-white p-5">
        <div>
          <label className="block text-xs font-medium text-gray-700">Penerimaan Barang *</label>
          <select name="gr_id" required className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm">
            <option value="">— Pilih penerimaan —</option>
            {eligibleGRs.map((gr: any) => {
              const total = gr.items.reduce((s: number, i: any) => s + Number(i.qty) * Number(i.unit_cost), 0);
              return (
                <option key={gr.id} value={gr.id}>
                  {gr.gr_no} · {gr.supplier.name} · {idr.format(total)}
                </option>
              );
            })}
          </select>
          {eligibleGRs.length === 0 && (
            <p className="mt-1 text-xs text-amber-700">Tidak ada penerimaan barang yang belum difakturkan.</p>
          )}
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-700">No. Faktur Pemasok</label>
          <input name="supplier_inv_no" placeholder="Nomor dari faktur pemasok" className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm" />
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="block text-xs font-medium text-gray-700">Tanggal Faktur *</label>
            <input name="invoice_date" type="date" required defaultValue={today} className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-700">Jatuh Tempo *</label>
            <input name="due_date" type="date" required defaultValue={dueStr} className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm" />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-gray-700">Catatan</label>
          <textarea name="notes" rows={2} className="mt-1 w-full rounded-md border border-gray-300 px-2 py-1 text-sm" />
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <a href="/keuangan/faktur" className="rounded-md border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">Batal</a>
          <button type="submit" className="rounded-md bg-brand-800 px-5 py-2 text-sm font-medium text-white hover:bg-brand-900">
            Buat Faktur
          </button>
        </div>
      </form>
    </div>
  );
}
