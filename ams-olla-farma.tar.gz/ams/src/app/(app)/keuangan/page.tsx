import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { prisma } from '@/lib/database/client';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Keuangan' };

async function counts() {
  const [fakturDraf, utangBelum, piutangAktif] = await Promise.all([
    prisma.purchaseInvoice.count({ where: { status: { in: ['UNPAID', 'PARTIAL'] } } }),
    prisma.purchaseInvoice.count({ where: { status: 'UNPAID' } }),
    prisma.customerReceivable.count({ where: { status: { in: ['OPEN', 'PARTIAL'] } } }),
  ]);
  return { fakturDraf, utangBelum, piutangAktif };
}

export default async function FinanceHubPage() {
  const actor = await requirePageActor('finance.view');
  const c = await counts();
  const canViewReceivables = can(actor, 'finance.receivable.view');

  const cards = [
    {
      href: '/keuangan/faktur',
      title: 'Faktur Pembelian',
      desc: 'Faktur dari pemasok atas penerimaan barang.',
      badge: `${c.fakturDraf} belum / sebagian dibayar`,
      badgeColor: c.fakturDraf > 0 ? 'text-amber-700' : 'text-gray-500',
      show: true,
    },
    {
      href: '/keuangan/utang',
      title: 'Utang Dagang (AP)',
      desc: 'Daftar utang ke pemasok dan riwayat pembayaran.',
      badge: `${c.utangBelum} faktur belum dibayar`,
      badgeColor: c.utangBelum > 0 ? 'text-red-700' : 'text-gray-500',
      show: true,
    },
    {
      href: '/keuangan/piutang',
      title: 'Piutang Pelanggan (AR)',
      desc: 'Tagihan kepada pelanggan dan riwayat pembayaran.',
      badge: `${c.piutangAktif} piutang aktif`,
      badgeColor: c.piutangAktif > 0 ? 'text-blue-700' : 'text-gray-500',
      show: canViewReceivables,
    },
  ].filter((c) => c.show);

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title="Keuangan"
        description="Faktur pembelian, utang dagang (AP), dan piutang pelanggan (AR)."
      />
      <div className="grid gap-4 sm:grid-cols-2">
        {cards.map((card) => (
          <Link
            key={card.href}
            href={card.href}
            className="block rounded-lg border border-gray-200 bg-white p-4 hover:border-brand-300 hover:shadow-sm"
          >
            <h2 className="text-sm font-semibold">{card.title}</h2>
            <p className="mt-1 text-xs text-gray-600">{card.desc}</p>
            <p className={`mt-3 text-xs font-medium ${card.badgeColor}`}>{card.badge}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
