import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/ui/page';
import { RecordPaymentForm, WriteOffForm } from './payment-client';

export const metadata: Metadata = { title: 'Detail Piutang' };

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const dtl = new Intl.DateTimeFormat('id-ID', { dateStyle: 'long', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const dts = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });

const statusTone = {
  OPEN:       'amber',
  PARTIAL:    'blue',
  PAID:       'green',
  WRITTEN_OFF:'gray',
} as const;
const statusLabel = {
  OPEN:       'Belum Dibayar',
  PARTIAL:    'Sebagian',
  PAID:       'Lunas',
  WRITTEN_OFF:'Dihapuskan',
} as const;

type Params = Promise<{ id: string }>;

export default async function PiutangDetailPage({ params }: { params: Params }) {
  const actor = await requirePageActor('finance.receivable.view');
  const { id } = await params;

  const receivable = await prisma.customerReceivable.findUnique({
    where: { id },
    include: {
      customer: { select: { id: true, name: true, phone: true } },
      sale:     { select: { id: true, invoice_no: true, created_at: true } },
    },
  });
  if (!receivable) notFound();

  const payments = await prisma.receivablePayment.findMany({
    where: { receivable_id: id },
    orderBy: { paid_at: 'desc' },
    include: {
      receiver: { select: { id: true, name: true } },
    },
  });

  const r = receivable as any;
  const now = new Date();
  const remaining = Number(r.amount) - Number(r.paid_amount);
  const isOverdue = r.due_date < now && r.status !== 'PAID' && r.status !== 'WRITTEN_OFF';
  const canManage = can(actor, 'finance.receivable.manage');
  const canPay    = canManage && (r.status === 'OPEN' || r.status === 'PARTIAL');
  const canWriteOff = canManage && (r.status === 'OPEN' || r.status === 'PARTIAL');

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader
        title="Detail Piutang"
        back={{ href: '/keuangan/piutang', label: 'Piutang Pelanggan' }}
      />

      <div className="space-y-4">
        {/* Status banner */}
        {isOverdue && (
          <div className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
            ⚠ Piutang ini <strong>sudah melewati tanggal jatuh tempo</strong>.
            Segera hubungi pelanggan untuk pembayaran.
          </div>
        )}

        {/* Info piutang */}
        <div className="rounded-lg border border-gray-200 bg-white">
          <div className="flex items-start justify-between border-b border-gray-200 px-4 py-3">
            <div>
              <p className="text-sm text-gray-500">{r.customer?.name ?? 'Pelanggan tidak diketahui'}</p>
              {r.customer?.phone && <p className="text-xs text-gray-400">{r.customer.phone}</p>}
            </div>
            <Badge tone={statusTone[r.status as keyof typeof statusTone] ?? 'gray'}>
              {statusLabel[r.status as keyof typeof statusLabel] ?? r.status}
            </Badge>
          </div>
          <dl className="divide-y divide-gray-100 px-4 text-sm">
            <Row label="No. Faktur">
              {r.sale ? (
                <a href={`/penjualan/${r.sale.id}`} className="text-brand-700 hover:underline">
                  {r.sale.invoice_no}
                </a>
              ) : '-'}
            </Row>
            <Row label="Tanggal Penjualan">
              {r.sale ? dts.format(new Date(r.sale.created_at)) : '-'}
            </Row>
            <Row label="Jatuh Tempo">
              <span className={isOverdue ? 'font-semibold text-red-700' : ''}>
                {dtl.format(new Date(r.due_date))}
              </span>
            </Row>
            <Row label="Jumlah Piutang">
              <span className="font-semibold">{idr.format(Number(r.amount))}</span>
            </Row>
            <Row label="Sudah Dibayar">
              <span className="text-brand-700">{idr.format(Number(r.paid_amount))}</span>
            </Row>
            <Row label="Sisa Tagihan">
              <span className={remaining > 0 ? 'font-bold text-red-700' : 'text-green-700'}>
                {idr.format(remaining)}
              </span>
            </Row>
            {r.notes && <Row label="Catatan">{r.notes}</Row>}
          </dl>
        </div>

        {/* Riwayat pembayaran */}
        {payments.length > 0 && (
          <div className="rounded-lg border border-gray-200 bg-white">
            <div className="border-b border-gray-200 px-4 py-3">
              <h3 className="text-sm font-semibold">Riwayat Pembayaran</h3>
            </div>
            <table className="min-w-full divide-y divide-gray-100 text-sm">
              <thead className="bg-gray-50 text-xs font-medium text-gray-500">
                <tr>
                  <th className="px-4 py-2 text-left">No. Bayar</th>
                  <th className="px-4 py-2 text-right">Jumlah</th>
                  <th className="px-4 py-2 text-left">Tanggal</th>
                  <th className="px-4 py-2 text-left">Diterima oleh</th>
                  <th className="px-4 py-2 text-left">Referensi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {(payments as any[]).map((p) => (
                  <tr key={p.id}>
                    <td className="px-4 py-2 font-mono text-xs">{p.payment_no}</td>
                    <td className="px-4 py-2 text-right font-medium text-brand-700">{idr.format(Number(p.amount))}</td>
                    <td className="px-4 py-2 text-xs">{dts.format(new Date(p.paid_at))}</td>
                    <td className="px-4 py-2 text-xs">{p.receiver?.name ?? '-'}</td>
                    <td className="px-4 py-2 text-xs text-gray-500">{p.reference ?? '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Form bayar */}
        {canPay && (
          <RecordPaymentForm
            receivableId={id}
            remaining={remaining}
          />
        )}

        {/* Write off */}
        {canWriteOff && (
          <WriteOffForm receivableId={id} />
        )}
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between py-2.5">
      <dt className="text-gray-500">{label}</dt>
      <dd className="text-right font-medium text-gray-900">{children}</dd>
    </div>
  );
}
