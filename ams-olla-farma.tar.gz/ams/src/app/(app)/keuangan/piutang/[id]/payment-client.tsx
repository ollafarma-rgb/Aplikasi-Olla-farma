'use client';

import { useActionState } from 'react';
import { type ActionState, initialActionState } from '@/lib/forms';
import { recordPaymentAction, writeOffReceivableAction } from '@/modules/receivables/actions';

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

// ── Record Payment Form ──────────────────────────────────────────────────────

export function RecordPaymentForm({ receivableId, remaining }: { receivableId: string; remaining: number }) {
  const [state, formAction, pending] = useActionState<ActionState, FormData>(
    recordPaymentAction,
    initialActionState,
  );

  return (
    <div className="rounded-lg border border-brand-200 bg-brand-50">
      <div className="border-b border-brand-200 px-4 py-3">
        <h3 className="text-sm font-semibold text-brand-900">Catat Pembayaran</h3>
        <p className="text-xs text-brand-700">
          Sisa tagihan: <span className="font-bold">{idr.format(remaining)}</span>
        </p>
      </div>
      <form action={formAction} className="space-y-3 px-4 py-4">
        <input type="hidden" name="receivable_id" value={receivableId} />

        {!state.ok && state.message && (
          <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
            {state.message}
          </div>
        )}

        {/* Jumlah */}
        <div>
          <label className="mb-1 block text-xs font-medium text-gray-700">
            Jumlah Pembayaran <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-gray-400">Rp</span>
            <input
              type="number"
              name="amount"
              min="1"
              max={remaining}
              step="1"
              className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
              placeholder={remaining.toString()}
            />
          </div>
          {state?.fields?.amount && (
            <p className="mt-1 text-xs text-red-600">{state.fields.amount}</p>
          )}
        </div>

        {/* Tanggal bayar */}
        <div>
          <label className="mb-1 block text-xs font-medium text-gray-700">Tanggal Bayar</label>
          <input
            type="datetime-local"
            name="paid_at"
            className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
          />
          <p className="mt-0.5 text-xs text-gray-400">Kosongkan untuk menggunakan waktu sekarang</p>
        </div>

        {/* Referensi */}
        <div>
          <label className="mb-1 block text-xs font-medium text-gray-700">Nomor Referensi</label>
          <input
            type="text"
            name="reference"
            maxLength={100}
            className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            placeholder="No. transfer / bukti bayar"
          />
        </div>

        {/* Catatan */}
        <div>
          <label className="mb-1 block text-xs font-medium text-gray-700">Catatan</label>
          <textarea
            name="notes"
            rows={2}
            maxLength={300}
            className="w-full resize-none rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            placeholder="Opsional"
          />
        </div>

        <button
          type="submit"
          disabled={pending}
          className="w-full rounded-md bg-brand-700 px-4 py-2 text-sm font-medium text-white hover:bg-brand-800 disabled:opacity-50"
        >
          {pending ? 'Menyimpan…' : 'Simpan Pembayaran'}
        </button>
      </form>
    </div>
  );
}

// ── Write-Off Form ───────────────────────────────────────────────────────────

export function WriteOffForm({ receivableId }: { receivableId: string }) {
  const [state, formAction, pending] = useActionState<ActionState, FormData>(
    writeOffReceivableAction,
    initialActionState,
  );

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    if (!window.confirm('Hapus piutang ini? Tindakan tidak dapat dibatalkan.')) {
      e.preventDefault();
    }
  }

  return (
    <div className="rounded-lg border border-red-200 bg-red-50">
      <div className="border-b border-red-200 px-4 py-3">
        <h3 className="text-sm font-semibold text-red-900">Hapus Piutang (Write-Off)</h3>
        <p className="text-xs text-red-700">
          Gunakan jika piutang tidak dapat ditagih. Tindakan tidak dapat dibatalkan.
        </p>
      </div>
      <form action={formAction} onSubmit={handleSubmit} className="space-y-3 px-4 py-4">
        <input type="hidden" name="id" value={receivableId} />

        {!state.ok && state.message && (
          <div className="rounded-md border border-red-300 bg-red-100 px-3 py-2 text-sm text-red-800">
            {state.message}
          </div>
        )}

        <div>
          <label className="mb-1 block text-xs font-medium text-gray-700">
            Alasan Penghapusan
          </label>
          <textarea
            name="notes"
            rows={2}
            maxLength={500}
            className="w-full resize-none rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-red-400 focus:outline-none focus:ring-1 focus:ring-red-400"
            placeholder="Contoh: Pelanggan tidak dapat ditemui, piutang sudah lewat 1 tahun"
          />
        </div>

        <button
          type="submit"
          disabled={pending}
          className="w-full rounded-md bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-50"
        >
          {pending ? 'Memproses…' : 'Hapus Piutang'}
        </button>
      </form>
    </div>
  );
}
