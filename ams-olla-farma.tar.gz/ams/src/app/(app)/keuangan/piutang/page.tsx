import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { EmptyState, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Piutang Pelanggan (AR)' };

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const dt  = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });

const statusTone = {
  OPEN:       'amber',
  PARTIAL:    'blue',
  PAID:       'green',
  WRITTEN_OFF:'gray',
} as const satisfies Record<string, 'amber' | 'blue' | 'green' | 'gray'>;

const statusLabel = {
  OPEN:       'Belum Dibayar',
  PARTIAL:    'Sebagian',
  PAID:       'Lunas',
  WRITTEN_OFF:'Dihapuskan',
} as const;

type SP = Promise<{ page?: string; status?: string; overdue?: string; customer?: string }>;

export default async function PiutangListPage({ searchParams }: { searchParams: SP }) {
  await requirePageActor('finance.receivable.view');
  const sp   = await searchParams;
  const page = Math.max(1, Number(sp.page ?? 1));
  const pageSize = 25;
  const now  = new Date();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const where: Record<string, any> = {};
  if (sp.status && sp.status !== 'ALL') where.status = sp.status;
  if (sp.overdue === '1') {
    where.due_date = { lt: now };
    where.status   = { in: ['OPEN', 'PARTIAL'] };
  }
  if (sp.customer) {
    where.customer = { name: { contains: sp.customer, mode: 'insensitive' } };
  }

  const [items, total] = await Promise.all([
    prisma.customerReceivable.findMany({
      where,
      orderBy: [{ due_date: 'asc' }, { created_at: 'desc' }],
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        customer: { select: { id: true, name: true } },
        sale:     { select: { id: true, invoice_no: true } },
      },
    }),
    prisma.customerReceivable.count({ where }),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  // Aging summary (overdue saja)
  const openPartial = await prisma.customerReceivable.findMany({
    where: { status: { in: ['OPEN', 'PARTIAL'] } },
    select: { amount: true, paid_amount: true, due_date: true },
  });
  const aging = { total: 0, overdue: 0, overdue30: 0, overdue60: 0, overdue90p: 0 };
  for (const r of openPartial) {
    const rem = Number(r.amount) - Number(r.paid_amount);
    aging.total += rem;
    const days = Math.floor((now.getTime() - r.due_date.getTime()) / 86400000);
    if (days > 0) {
      aging.overdue += rem;
      if (days <= 30) aging.overdue30 += rem;
      else if (days <= 60) aging.overdue60 += rem;
      else aging.overdue90p += rem;
    }
  }

  const statusFilters = [
    { value: '', label: 'Semua' },
    { value: 'OPEN',       label: 'Belum Dibayar' },
    { value: 'PARTIAL',    label: 'Sebagian' },
    { value: 'PAID',       label: 'Lunas' },
    { value: 'WRITTEN_OFF',label: 'Dihapuskan' },
  ];

  function filterHref(overrides: Record<string, string | undefined>) {
    const q = new URLSearchParams();
    const merged = { page: '1', status: sp.status, overdue: sp.overdue, customer: sp.customer, ...overrides };
    for (const [k, v] of Object.entries(merged)) if (v) q.set(k, v);
    return `/keuangan/piutang?${q.toString()}`;
  }

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Piutang Pelanggan (AR)"
        description="Daftar tagihan pelanggan dari penjualan dengan metode pembayaran Piutang."
        back={{ href: '/keuangan', label: 'Keuangan' }}
      />

      {/* Ringkasan */}
      <div className="mb-4 grid gap-3 sm:grid-cols-4">
        <div className="rounded-lg border border-gray-200 bg-white p-3">
          <p className="text-xs text-gray-500">Total Piutang Aktif</p>
          <p className="mt-0.5 text-lg font-semibold text-gray-900">{idr.format(aging.total)}</p>
        </div>
        <div className={`rounded-lg border p-3 ${aging.overdue30 > 0 ? 'border-amber-200 bg-amber-50' : 'border-gray-200 bg-white'}`}>
          <p className="text-xs text-amber-700">Jatuh Tempo 1–30 hr</p>
          <p className="mt-0.5 text-lg font-semibold text-amber-900">{idr.format(aging.overdue30)}</p>
        </div>
        <div className={`rounded-lg border p-3 ${aging.overdue60 > 0 ? 'border-orange-200 bg-orange-50' : 'border-gray-200 bg-white'}`}>
          <p className="text-xs text-orange-700">Jatuh Tempo 31–60 hr</p>
          <p className="mt-0.5 text-lg font-semibold text-orange-900">{idr.format(aging.overdue60)}</p>
        </div>
        <div className={`rounded-lg border p-3 ${aging.overdue90p > 0 ? 'border-red-200 bg-red-50' : 'border-gray-200 bg-white'}`}>
          <p className="text-xs text-red-700">Jatuh Tempo &gt;60 hr</p>
          <p className="mt-0.5 text-lg font-semibold text-red-900">{idr.format(aging.overdue90p)}</p>
        </div>
      </div>

      {/* Filter */}
      <div className="mb-3 flex flex-wrap items-center gap-2">
        {statusFilters.map((f) => (
          <Link
            key={f.value}
            href={filterHref({ status: f.value || undefined, overdue: undefined })}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              (sp.status ?? '') === f.value && !sp.overdue
                ? 'bg-brand-800 text-white'
                : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            {f.label}
          </Link>
        ))}
        <Link
          href={filterHref({ status: undefined, overdue: sp.overdue === '1' ? undefined : '1' })}
          className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
            sp.overdue === '1'
              ? 'bg-red-700 text-white'
              : 'border border-red-200 bg-white text-red-700 hover:bg-red-50'
          }`}
        >
          ⚠ Jatuh Tempo
        </Link>
      </div>

      {/* Tabel */}
      {items.length === 0 ? (
        <EmptyState>Belum ada piutang yang cocok dengan filter ini.</EmptyState>
      ) : (
        <div className="overflow-hidden rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full divide-y divide-gray-200 text-sm">
            <thead className="bg-gray-50 text-xs font-medium text-gray-500">
              <tr>
                <th className="px-4 py-3 text-left">Pelanggan</th>
                <th className="px-4 py-3 text-left">No. Faktur</th>
                <th className="px-4 py-3 text-right">Jumlah</th>
                <th className="px-4 py-3 text-right">Dibayar</th>
                <th className="px-4 py-3 text-right">Sisa</th>
                <th className="px-4 py-3 text-left">Jatuh Tempo</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((r: any) => {
                const remaining = Number(r.amount) - Number(r.paid_amount);
                const isOverdue = r.due_date < now && r.status !== 'PAID' && r.status !== 'WRITTEN_OFF';
                return (
                  <tr key={r.id} className={`hover:bg-gray-50 ${isOverdue ? 'bg-red-50/30' : ''}`}>
                    <td className="px-4 py-3 font-medium text-gray-900">
                      {r.customer ? (
                        <Link href={`/pelanggan/${r.customer.id}`} className="hover:text-blue-600 hover:underline">
                          {r.customer.name}
                        </Link>
                      ) : '(tanpa nama)'}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-gray-600">
                      {r.sale?.invoice_no ?? '-'}
                    </td>
                    <td className="px-4 py-3 text-right">{idr.format(Number(r.amount))}</td>
                    <td className="px-4 py-3 text-right text-brand-700">
                      {Number(r.paid_amount) > 0 ? idr.format(Number(r.paid_amount)) : '-'}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold">
                      {remaining > 0 ? idr.format(remaining) : '-'}
                    </td>
                    <td className="px-4 py-3 text-xs">
                      <span className={isOverdue ? 'font-medium text-red-700' : 'text-gray-600'}>
                        {dt.format(r.due_date)}
                        {isOverdue && ' ⚠'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={statusTone[r.status as keyof typeof statusTone] ?? 'gray'}>
                        {statusLabel[r.status as keyof typeof statusLabel] ?? r.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Link
                        href={`/keuangan/piutang/${r.id}`}
                        className="text-xs text-brand-700 hover:underline"
                      >
                        Detail →
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {pages > 1 && (
        <Pagination
          page={page}
          pages={pages}
          total={total}
          params={{ status: sp.status, overdue: sp.overdue, customer: sp.customer }}
          basePath="/keuangan/piutang"
        />
      )}
    </div>
  );
}
