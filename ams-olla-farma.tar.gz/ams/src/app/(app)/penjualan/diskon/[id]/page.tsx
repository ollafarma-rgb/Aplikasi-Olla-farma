import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/ui/page';
import { ApproveRejectForm, CancelForm } from './actions-client';

export const metadata: Metadata = { title: 'Detail Diskon' };

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const dtl = new Intl.DateTimeFormat('id-ID', { dateStyle: 'long', timeStyle: 'short', timeZone: 'Asia/Jakarta' });

const statusTone = {
  DRAFT:    'gray',
  APPROVED: 'green',
  REJECTED: 'red',
  CANCELLED:'red',
} as const;
const statusLabel = {
  DRAFT:    'Draf',
  APPROVED: 'Aktif',
  REJECTED: 'Ditolak',
  CANCELLED:'Dibatalkan',
} as const;
const scopeLabel: Record<string, string> = {
  ALL:      'Semua Produk',
  CATEGORY: 'Per Kategori',
  MEDICINE: 'Obat Spesifik',
};

type Params = Promise<{ id: string }>;

export default async function DiskonDetailPage({ params }: { params: Params }) {
  const actor = await requirePageActor('pricing.discount_rules.manage');
  const { id } = await params;

  const rule = await prisma.discountRule.findUnique({
    where: { id },
    include: {
      category: { select: { id: true, name: true } },
      medicine: { select: { id: true, name: true } },
      creator:  { select: { id: true, name: true } },
      approver: { select: { id: true, name: true } },
    },
  });
  if (!rule) notFound();

  const now = new Date();
  const isExpired = (rule as any).ends_at < now;
  const isActive  = (rule as any).status === 'APPROVED' && (rule as any).starts_at <= now && !isExpired;
  const canApprove = (rule as any).status === 'DRAFT' && actor.id !== (rule as any).created_by;
  const canCancel  = (rule as any).status === 'DRAFT' && actor.id === (rule as any).created_by;

  const r = rule as any;

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader
        title="Detail Diskon"
        back={{ href: '/penjualan/diskon', label: 'Diskon Periode' }}
      />

      <div className="space-y-4">
        {/* Status banner */}
        {r.status === 'DRAFT' && (
          <div className="rounded-md border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            Aturan diskon ini masih berstatus <strong>Draf</strong> dan belum berlaku.
            {actor.id === r.created_by
              ? ' Anda tidak dapat menyetujui aturan yang Anda buat sendiri.'
              : ' Silakan tinjau dan setujui atau tolak di bawah.'}
          </div>
        )}
        {isActive && (
          <div className="rounded-md border border-brand-200 bg-brand-50 px-4 py-3 text-sm text-brand-800">
            Diskon ini <strong>sedang aktif</strong> dan berlaku otomatis saat kasir memproses penjualan.
          </div>
        )}
        {isExpired && r.status === 'APPROVED' && (
          <div className="rounded-md border border-gray-200 bg-gray-50 px-4 py-3 text-sm text-gray-600">
            Periode diskon ini sudah berakhir.
          </div>
        )}

        {/* Info utama */}
        <div className="rounded-lg border border-gray-200 bg-white">
          <div className="border-b border-gray-200 px-4 py-3">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-mono text-xs text-gray-500">{r.code}</p>
                <h2 className="text-base font-semibold">{r.name}</h2>
              </div>
              <Badge tone={isActive ? 'green' : (statusTone[r.status as keyof typeof statusTone] ?? 'gray')}>
                {isActive ? 'Aktif' : (statusLabel[r.status as keyof typeof statusLabel] ?? r.status)}
              </Badge>
            </div>
          </div>
          <dl className="divide-y divide-gray-100 px-4 text-sm">
            <Row label="Lingkup">{scopeLabel[r.scope] ?? r.scope}</Row>
            {r.category && <Row label="Kategori">{r.category.name}</Row>}
            {r.medicine  && <Row label="Obat">{r.medicine.name}</Row>}
            <Row label="Tipe Diskon">
              {r.type === 'PERCENTAGE' ? 'Persentase' : 'Nominal (Rupiah)'}
            </Row>
            <Row label="Nilai">
              <span className="font-semibold text-brand-800">
                {r.type === 'PERCENTAGE'
                  ? `${Number(r.value).toFixed(1)}%`
                  : idr.format(Number(r.value))}
              </span>
            </Row>
            <Row label="Min. Kuantitas">{r.min_qty_base} satuan dasar</Row>
            <Row label="Periode Mulai">{dtl.format(new Date(r.starts_at))}</Row>
            <Row label="Periode Akhir">{dtl.format(new Date(r.ends_at))}</Row>
            {r.notes && <Row label="Catatan">{r.notes}</Row>}
          </dl>
        </div>

        {/* Riwayat maker-checker */}
        <div className="rounded-lg border border-gray-200 bg-white">
          <div className="border-b border-gray-200 px-4 py-3">
            <h3 className="text-sm font-semibold">Riwayat Persetujuan</h3>
          </div>
          <dl className="divide-y divide-gray-100 px-4 text-sm">
            <Row label="Dibuat oleh">{r.creator?.name ?? '-'}</Row>
            {r.approver && (
              <Row label={r.status === 'APPROVED' ? 'Disetujui oleh' : 'Ditolak oleh'}>
                {r.approver.name}
                {r.approved_at && (
                  <span className="ml-2 text-xs text-gray-500">
                    {dtl.format(new Date(r.approved_at))}
                  </span>
                )}
              </Row>
            )}
          </dl>
        </div>

        {/* Aksi */}
        {canApprove && (
          <ApproveRejectForm id={r.id} />
        )}
        {canCancel && (
          <CancelForm id={r.id} />
        )}
      </div>
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between py-2.5">
      <dt className="text-gray-500">{label}</dt>
      <dd className="text-right font-medium text-gray-900">{children}</dd>
    </div>
  );
}
