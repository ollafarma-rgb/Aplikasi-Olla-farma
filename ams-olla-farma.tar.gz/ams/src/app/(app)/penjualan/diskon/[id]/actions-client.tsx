'use client';

import { useActionState, useState } from 'react';
import { useRouter } from 'next/navigation';
import { initialActionState } from '@/lib/forms';
import { approveDiscountRuleAction, cancelDiscountRuleAction } from '@/modules/discounts/actions';
import { Alert } from '@/components/ui/alert';

export function ApproveRejectForm({ id }: { id: string }) {
  const router = useRouter();
  const [action, setAction] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [state, formAction, pending] = useActionState(
    async (prev: typeof initialActionState, fd: FormData) => {
      const result = await approveDiscountRuleAction(prev, fd);
      if (result.ok) router.push('/penjualan/diskon');
      return result;
    },
    initialActionState,
  );

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-4">
      <h3 className="mb-3 text-sm font-semibold text-gray-900">Tindakan Persetujuan</h3>

      {state.message && (
        <div className="mb-3">
          <Alert tone={state.ok ? 'success' : 'error'}>{state.message}</Alert>
        </div>
      )}

      <form action={formAction} className="space-y-3">
        <input type="hidden" name="id" value={id} />
        <input type="hidden" name="action" value={action} />

        {/* Pilih aksi */}
        <div className="flex gap-3">
          {(['APPROVE', 'REJECT'] as const).map((a) => (
            <label key={a} className="flex cursor-pointer items-center gap-2">
              <input
                type="radio"
                name="_action_choice"
                value={a}
                checked={action === a}
                onChange={() => setAction(a)}
                className="text-brand-600"
              />
              <span className="text-sm font-medium">
                {a === 'APPROVE' ? '✓ Setujui' : '✗ Tolak'}
              </span>
            </label>
          ))}
        </div>

        {/* Notes (wajib jika reject) */}
        {action === 'REJECT' && (
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="notes-reject">
              Alasan Penolakan <span className="text-red-500">*</span>
            </label>
            <textarea
              id="notes-reject"
              name="notes"
              rows={3}
              required={action === 'REJECT'}
              maxLength={500}
              placeholder="Jelaskan alasan penolakan…"
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            />
            {state.fields?.notes && <p className="mt-1 text-xs text-red-600">{state.fields.notes}</p>}
          </div>
        )}

        <button
          type="submit"
          disabled={pending}
          className={`rounded-md px-5 py-2 text-sm font-medium text-white disabled:opacity-60 ${
            action === 'APPROVE'
              ? 'bg-brand-800 hover:bg-brand-900'
              : 'bg-red-600 hover:bg-red-700'
          }`}
        >
          {pending
            ? 'Memproses…'
            : action === 'APPROVE'
              ? 'Setujui Diskon'
              : 'Tolak Diskon'}
        </button>
      </form>
    </div>
  );
}

export function CancelForm({ id }: { id: string }) {
  const router = useRouter();
  const [state, formAction, pending] = useActionState(
    async (prev: typeof initialActionState, _fd: FormData) => {
      const result = await cancelDiscountRuleAction(id);
      if (result.ok) router.push('/penjualan/diskon');
      return result;
    },
    initialActionState,
  );

  return (
    <div className="rounded-lg border border-red-100 bg-red-50 p-4">
      <h3 className="mb-1 text-sm font-semibold text-red-800">Batalkan Diskon</h3>
      <p className="mb-3 text-xs text-red-700">
        Diskon yang dibatalkan tidak dapat diaktifkan kembali.
      </p>

      {state.message && (
        <div className="mb-3">
          <Alert tone="error">{state.message}</Alert>
        </div>
      )}

      <form action={formAction}>
        <button
          type="submit"
          disabled={pending}
          onClick={(e) => {
            if (!window.confirm('Yakin ingin membatalkan diskon ini?')) e.preventDefault();
          }}
          className="rounded-md border border-red-300 bg-white px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-50 disabled:opacity-60"
        >
          {pending ? 'Memproses…' : 'Batalkan Diskon'}
        </button>
      </form>
    </div>
  );
}
