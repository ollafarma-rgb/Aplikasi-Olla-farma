import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { EmptyState, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Diskon Periode' };

const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const dt  = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });

const statusTone = {
  DRAFT:    'gray',
  APPROVED: 'green',
  REJECTED: 'red',
  CANCELLED:'red',
} as const satisfies Record<string, 'gray' | 'green' | 'red' | 'amber'>;

const statusLabel = {
  DRAFT:    'Draf',
  APPROVED: 'Aktif',
  REJECTED: 'Ditolak',
  CANCELLED:'Dibatalkan',
} as const;

const scopeLabel: Record<string, string> = {
  ALL:      'Semua Produk',
  CATEGORY: 'Kategori',
  MEDICINE: 'Obat Spesifik',
};

type SP = Promise<{ page?: string; status?: string; scope?: string }>;

export default async function DiskonPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('pricing.discount_rules.manage');
  const sp    = await searchParams;
  const page  = Math.max(1, Number(sp.page ?? 1));
  const pageSize = 25;
  const now   = new Date();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const where: Record<string, any> = {};
  if (sp.status && sp.status !== 'ALL') where.status = sp.status;
  if (sp.scope  && sp.scope  !== 'ALL') where.scope  = sp.scope;

  const [items, total] = await Promise.all([
    prisma.discountRule.findMany({
      where,
      orderBy: [{ starts_at: 'desc' }, { created_at: 'desc' }],
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        category: { select: { id: true, name: true } },
        medicine: { select: { id: true, name: true } },
        creator:  { select: { id: true, name: true } },
        approver: { select: { id: true, name: true } },
      },
    }),
    prisma.discountRule.count({ where }),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  // Ringkasan: hanya diskon aktif sekarang
  const activeCount = await prisma.discountRule.count({
    where: { status: 'APPROVED', starts_at: { lte: now }, ends_at: { gte: now } },
  });
  const draftCount = await prisma.discountRule.count({ where: { status: 'DRAFT' } });

  const statusFilters = [
    { value: '', label: 'Semua' },
    { value: 'DRAFT',    label: 'Draf' },
    { value: 'APPROVED', label: 'Aktif' },
    { value: 'REJECTED', label: 'Ditolak' },
    { value: 'CANCELLED',label: 'Dibatalkan' },
  ];
  const scopeFilters = [
    { value: '', label: 'Semua Lingkup' },
    { value: 'ALL',      label: 'Semua Produk' },
    { value: 'CATEGORY', label: 'Kategori' },
    { value: 'MEDICINE', label: 'Obat Spesifik' },
  ];

  function filterHref(overrides: Record<string, string | undefined>) {
    const q = new URLSearchParams();
    const merged = { page: '1', status: sp.status, scope: sp.scope, ...overrides };
    for (const [k, v] of Object.entries(merged)) if (v) q.set(k, v);
    return `/penjualan/diskon?${q.toString()}`;
  }

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Diskon Periode"
        description="Aturan diskon per periode — berlaku otomatis saat kasir memproses penjualan."
        back={{ href: '/penjualan', label: 'Penjualan' }}
        actions={can(actor, 'pricing.discount_rules.manage') ? (
          <Link
            href="/penjualan/diskon/baru"
            className="rounded-md bg-brand-800 px-4 py-2 text-sm font-medium text-white hover:bg-brand-900"
          >
            + Buat Diskon
          </Link>
        ) : null}
      />

      {/* Ringkasan */}
      <div className="mb-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-lg border border-brand-200 bg-brand-50 p-4">
          <p className="text-xs text-brand-700">Diskon Aktif Sekarang</p>
          <p className="mt-1 text-2xl font-semibold text-brand-900">{activeCount} aturan</p>
          <p className="mt-0.5 text-xs text-brand-600">Berlaku otomatis saat ini</p>
        </div>
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
          <p className="text-xs text-amber-700">Menunggu Persetujuan</p>
          <p className="mt-1 text-2xl font-semibold text-amber-900">{draftCount} aturan</p>
          <p className="mt-0.5 text-xs text-amber-600">Perlu disetujui manajer lain</p>
        </div>
      </div>

      {/* Filter */}
      <div className="mb-3 flex flex-wrap gap-2">
        {statusFilters.map((f) => (
          <Link
            key={f.value}
            href={filterHref({ status: f.value || undefined })}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              (sp.status ?? '') === f.value
                ? 'bg-brand-800 text-white'
                : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            {f.label}
          </Link>
        ))}
        <span className="mx-1 self-center text-gray-300">|</span>
        {scopeFilters.map((f) => (
          <Link
            key={f.value}
            href={filterHref({ scope: f.value || undefined })}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              (sp.scope ?? '') === f.value
                ? 'bg-gray-800 text-white'
                : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            {f.label}
          </Link>
        ))}
      </div>

      {/* Tabel */}
      {items.length === 0 ? (
        <EmptyState>Belum ada aturan diskon yang cocok.</EmptyState>
      ) : (
        <div className="overflow-hidden rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full divide-y divide-gray-200 text-sm">
            <thead className="bg-gray-50 text-xs font-medium text-gray-500">
              <tr>
                <th className="px-4 py-3 text-left">Kode / Nama</th>
                <th className="px-4 py-3 text-left">Lingkup</th>
                <th className="px-4 py-3 text-right">Diskon</th>
                <th className="px-4 py-3 text-left">Periode</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Pembuat</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((r: any) => {
                const isExpired = r.ends_at < now && r.status === 'APPROVED';
                const isActive  = r.status === 'APPROVED' && r.starts_at <= now && r.ends_at >= now;
                const displayStatus = isActive ? 'APPROVED' : r.status;

                return (
                  <tr key={r.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <p className="font-mono text-xs text-gray-500">{r.code}</p>
                      <p className="font-medium text-gray-900">{r.name}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-gray-700">{scopeLabel[r.scope] ?? r.scope}</p>
                      {r.category && <p className="text-xs text-gray-500">{r.category.name}</p>}
                      {r.medicine  && <p className="text-xs text-gray-500">{r.medicine.name}</p>}
                    </td>
                    <td className="px-4 py-3 text-right font-medium">
                      {r.type === 'PERCENTAGE'
                        ? `${Number(r.value).toFixed(1)}%`
                        : idr.format(Number(r.value))}
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-600">
                      <p>{dt.format(r.starts_at)}</p>
                      <p>s/d {dt.format(r.ends_at)}</p>
                      {isExpired && <span className="text-red-600">Kadaluarsa</span>}
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={isActive ? 'green' : (statusTone[displayStatus as keyof typeof statusTone] ?? 'gray')}>
                        {isActive ? 'Aktif' : (statusLabel[displayStatus as keyof typeof statusLabel] ?? displayStatus)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-600">
                      <p>{r.creator?.name ?? '-'}</p>
                      {r.approver && <p className="text-gray-400">✓ {r.approver.name}</p>}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Link
                        href={`/penjualan/diskon/${r.id}`}
                        className="text-xs text-brand-700 hover:underline"
                      >
                        Detail →
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {pages > 1 && (
        <Pagination
          page={page}
          pages={pages}
          total={total}
          params={{ status: sp.status, scope: sp.scope }}
          basePath="/penjualan/diskon"
        />
      )}
    </div>
  );
}
