'use client';

import { useActionState, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { initialActionState } from '@/lib/forms';
import { createDiscountRuleAction } from '@/modules/discounts/actions';
import { Alert } from '@/components/ui/alert';

export default function BuatDiskonPage() {
  const router = useRouter();
  const [state, formAction, pending] = useActionState(
    async (prev: typeof initialActionState, fd: FormData) => {
      const result = await createDiscountRuleAction(prev, fd);
      if (result.ok) router.push('/penjualan/diskon');
      return result;
    },
    initialActionState,
  );

  const [scope, setScope]       = useState('ALL');
  const [tipeDiskon, setTipe]   = useState('PERCENT');

  const err = (field: string) => state.fields?.[field];

  return (
    <div className="mx-auto max-w-2xl">
      {/* Header */}
      <div className="mb-4">
        <Link href="/penjualan/diskon" className="text-sm text-gray-600 hover:text-gray-900">
          ← Diskon Periode
        </Link>
        <h1 className="mt-1 text-xl font-semibold">Buat Aturan Diskon</h1>
        <p className="mt-0.5 text-sm text-gray-600">
          Diskon akan aktif setelah disetujui oleh manajer lain (maker–checker).
        </p>
      </div>

      {state.message && (
        <div className="mb-4">
          <Alert tone={state.ok ? 'success' : 'error'}>{state.message}</Alert>
        </div>
      )}

      <form action={formAction} className="space-y-5 rounded-lg border border-gray-200 bg-white p-6">
        {/* Kode & Nama */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="code">
              Kode Diskon <span className="text-red-500">*</span>
            </label>
            <input
              id="code"
              name="code"
              type="text"
              required
              maxLength={50}
              placeholder="mis. SALE-AUG-2025"
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            />
            {err('code') && <p className="mt-1 text-xs text-red-600">{err('code')}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="name">
              Nama Diskon <span className="text-red-500">*</span>
            </label>
            <input
              id="name"
              name="name"
              type="text"
              required
              maxLength={150}
              placeholder="mis. Diskon Akhir Bulan Agustus"
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            />
            {err('name') && <p className="mt-1 text-xs text-red-600">{err('name')}</p>}
          </div>
        </div>

        {/* Lingkup */}
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Lingkup Diskon <span className="text-red-500">*</span>
          </label>
          <div className="mt-1 flex gap-3">
            {(['ALL', 'CATEGORY', 'MEDICINE'] as const).map((s) => (
              <label key={s} className="flex cursor-pointer items-center gap-2">
                <input
                  type="radio"
                  name="scope"
                  value={s}
                  checked={scope === s}
                  onChange={() => setScope(s)}
                  className="text-brand-600"
                />
                <span className="text-sm">
                  {s === 'ALL' ? 'Semua Produk' : s === 'CATEGORY' ? 'Kategori' : 'Obat Spesifik'}
                </span>
              </label>
            ))}
          </div>
          {err('scope') && <p className="mt-1 text-xs text-red-600">{err('scope')}</p>}
        </div>

        {/* Kategori ID (jika CATEGORY) */}
        {scope === 'CATEGORY' && (
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="category_id">
              ID Kategori <span className="text-red-500">*</span>
            </label>
            <input
              id="category_id"
              name="category_id"
              type="text"
              placeholder="UUID kategori"
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 font-mono text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            />
            {err('category_id') && <p className="mt-1 text-xs text-red-600">{err('category_id')}</p>}
          </div>
        )}

        {/* Obat ID (jika MEDICINE) */}
        {scope === 'MEDICINE' && (
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="medicine_id">
              ID Obat <span className="text-red-500">*</span>
            </label>
            <input
              id="medicine_id"
              name="medicine_id"
              type="text"
              placeholder="UUID obat"
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 font-mono text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            />
            {err('medicine_id') && <p className="mt-1 text-xs text-red-600">{err('medicine_id')}</p>}
          </div>
        )}

        {/* Tipe & Nilai */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Tipe Diskon <span className="text-red-500">*</span>
            </label>
            <div className="mt-1 flex gap-4">
              {(['PERCENT', 'AMOUNT'] as const).map((t) => (
                <label key={t} className="flex cursor-pointer items-center gap-2">
                  <input
                    type="radio"
                    name="type"
                    value={t}
                    checked={tipeDiskon === t}
                    onChange={() => setTipe(t)}
                    className="text-brand-600"
                  />
                  <span className="text-sm">{t === 'PERCENT' ? 'Persentase (%)' : 'Nominal (Rp)'}</span>
                </label>
              ))}
            </div>
            {err('type') && <p className="mt-1 text-xs text-red-600">{err('type')}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="value">
              Nilai Diskon <span className="text-red-500">*</span>
            </label>
            <div className="relative mt-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-gray-500">
                {tipeDiskon === 'PERCENT' ? '%' : 'Rp'}
              </span>
              <input
                id="value"
                name="value"
                type="text"
                required
                placeholder={tipeDiskon === 'PERCENT' ? '10' : '5000'}
                className="block w-full rounded-md border border-gray-300 py-2 pl-9 pr-3 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
              />
            </div>
            {err('value') && <p className="mt-1 text-xs text-red-600">{err('value')}</p>}
          </div>
        </div>

        {/* Min Qty */}
        <div>
          <label className="block text-sm font-medium text-gray-700" htmlFor="min_qty_base">
            Minimum Kuantitas (satuan dasar)
          </label>
          <input
            id="min_qty_base"
            name="min_qty_base"
            type="number"
            defaultValue={1}
            min={1}
            className="mt-1 block w-32 rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
          />
          <p className="mt-1 text-xs text-gray-500">Diskon hanya berlaku jika jumlah beli ≥ nilai ini.</p>
          {err('min_qty_base') && <p className="mt-1 text-xs text-red-600">{err('min_qty_base')}</p>}
        </div>

        {/* Periode */}
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="starts_at">
              Tanggal Mulai <span className="text-red-500">*</span>
            </label>
            <input
              id="starts_at"
              name="starts_at"
              type="datetime-local"
              required
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            />
            {err('starts_at') && <p className="mt-1 text-xs text-red-600">{err('starts_at')}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700" htmlFor="ends_at">
              Tanggal Akhir <span className="text-red-500">*</span>
            </label>
            <input
              id="ends_at"
              name="ends_at"
              type="datetime-local"
              required
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
            />
            {err('ends_at') && <p className="mt-1 text-xs text-red-600">{err('ends_at')}</p>}
          </div>
        </div>

        {/* Catatan */}
        <div>
          <label className="block text-sm font-medium text-gray-700" htmlFor="notes">
            Catatan
          </label>
          <textarea
            id="notes"
            name="notes"
            rows={3}
            maxLength={500}
            placeholder="Keterangan tambahan (opsional)"
            className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-1 focus:ring-brand-500"
          />
          {err('notes') && <p className="mt-1 text-xs text-red-600">{err('notes')}</p>}
        </div>

        {/* Info maker-checker */}
        <div className="rounded-md border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-800">
          <strong>Alur Persetujuan:</strong> Diskon yang Anda buat akan berstatus <em>Draf</em> dan harus
          disetujui oleh manajer lain sebelum aktif. Pembuat tidak dapat menyetujui aturannya sendiri.
        </div>

        {/* Tombol */}
        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={pending}
            className="rounded-md bg-brand-800 px-5 py-2 text-sm font-medium text-white hover:bg-brand-900 disabled:opacity-60"
          >
            {pending ? 'Menyimpan…' : 'Simpan Diskon'}
          </button>
          <Link
            href="/penjualan/diskon"
            className="rounded-md border border-gray-300 bg-white px-5 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            Batal
          </Link>
        </div>
      </form>
    </div>
  );
}
