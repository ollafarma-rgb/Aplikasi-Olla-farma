import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { getSaleDetail } from '@/modules/sales/service';
import { prisma } from '@/lib/database/client';

export const metadata: Metadata = { title: 'Struk Penjualan' };
const dtShort = new Intl.DateTimeFormat('id-ID', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

export default async function ReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('sales.view_all');
  const { id } = await params;
  const sale = await getSaleDetail(actor, id).catch(() => null);
  if (!sale) notFound();

  const settingRow = await prisma.pharmacySetting.findFirst({ where: { key: 'apotek' } });
  const settingData = (settingRow?.value_json ?? {}) as Record<string, string>;
  const apotek = {
    name: settingData['pharmacy_name'] ?? 'APOTEK OLLA FARMA',
    address: settingData['address'] ?? '',
    phone: settingData['phone'] ?? '',
    sipa: settingData['sipa'] ?? '',
  };

  const grandTotal = Number(sale.grand_total);
  const amountPaid = Number(sale.amount_paid);
  const change = Math.max(0, amountPaid - grandTotal);

  return (
    <div className="min-h-screen bg-gray-100 p-4 print:bg-white print:p-0">
      {/* Tombol cetak (tidak muncul saat print) */}
      <div className="mb-4 flex justify-center print:hidden">
        <button
          onClick={() => window.print()}
          className="rounded-md bg-brand-800 px-6 py-2 text-sm font-medium text-white hover:bg-brand-900"
        >
          Cetak Struk
        </button>
      </div>

      {/* Struk 80mm */}
      <div
        className="mx-auto bg-white p-3 font-mono text-xs"
        style={{ width: '80mm', minHeight: '100mm' }}
      >
        {/* Header apotek */}
        <div className="border-b border-dashed border-gray-400 pb-2 text-center">
          <p className="text-sm font-bold">{apotek.name}</p>
          {apotek.address && <p className="text-[10px] text-gray-600">{apotek.address}</p>}
          {apotek.phone && <p className="text-[10px] text-gray-600">Telp: {apotek.phone}</p>}
          {apotek.sipa && <p className="text-[10px] text-gray-600">SIPA: {apotek.sipa}</p>}
        </div>

        {/* Info transaksi */}
        <div className="mt-2 border-b border-dashed border-gray-400 pb-2">
          <div className="flex justify-between">
            <span>No</span>
            <span className="font-semibold">{sale.sale_no}</span>
          </div>
          <div className="flex justify-between">
            <span>Tgl</span>
            <span>{dtShort.format(new Date(sale.sold_at))}</span>
          </div>
          <div className="flex justify-between">
            <span>Kasir</span>
            <span>{sale.cashier?.full_name ?? '-'}</span>
          </div>
          {sale.customer && (
            <div className="flex justify-between">
              <span>Pelanggan</span>
              <span>{sale.customer.name}</span>
            </div>
          )}
        </div>

        {/* Items */}
        <div className="mt-2 border-b border-dashed border-gray-400 pb-2">
          {sale.items.map((item: any, i: number) => {
            const price = Number(item.unit_price);
            const disc = Number(item.discount_pct);
            const lineTotal = Number(item.line_total);
            return (
              <div key={i} className="mb-1">
                <p className="truncate">{item.medicine?.name ?? item.medicine_id}</p>
                <div className="flex justify-between pl-2">
                  <span>{item.qty} × {idr.format(price)}{disc > 0 ? ` (-${disc}%)` : ''}</span>
                  <span>{idr.format(lineTotal)}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Totals */}
        <div className="mt-2 border-b border-dashed border-gray-400 pb-2">
          <div className="flex justify-between font-semibold">
            <span>TOTAL</span>
            <span>{idr.format(grandTotal)}</span>
          </div>
          {sale.payment_method === 'CASH' && (
            <>
              <div className="flex justify-between">
                <span>Bayar</span>
                <span>{idr.format(amountPaid)}</span>
              </div>
              <div className="flex justify-between">
                <span>Kembali</span>
                <span>{idr.format(change)}</span>
              </div>
            </>
          )}
          {sale.payment_method === 'RECEIVABLE' && (
            <div className="flex justify-between text-amber-700">
              <span>Piutang</span>
              <span>{idr.format(grandTotal)}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-2 text-center text-[10px] text-gray-500">
          <p>Terima kasih atas kepercayaan Anda.</p>
          <p>Simpan struk ini sebagai bukti pembelian.</p>
          {sale.prescription && (
            <p className="mt-1 font-medium">Resep Dr. {sale.prescription.doctor_name}</p>
          )}
        </div>
      </div>

      {/* Print style */}
      <style>{`
        @media print {
          @page { size: 80mm auto; margin: 0; }
          body { margin: 0; }
        }
      `}</style>
    </div>
  );
}
