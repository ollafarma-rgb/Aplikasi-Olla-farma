import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { getSaleDetail, cancelSale } from '@/modules/sales/service';
import { PAYMENT_METHOD_LABELS } from '@/modules/sales/schemas';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail Penjualan' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'long', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const statusTone = { PAID: 'green', CANCELLED: 'gray', PARTIAL_RETURN: 'amber', RETURNED: 'red' } as const;
const statusLabel = { PAID: 'Lunas', CANCELLED: 'Dibatalkan', PARTIAL_RETURN: 'Retur Sebagian', RETURNED: 'Diretur' } as const;

export default async function SaleDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('sales.view_all');
  const { id } = await params;
  const sale = await getSaleDetail(actor, id).catch(() => null);
  if (!sale) notFound();

  const canCancel = can(actor, 'sales.cancel.request') && sale.status === 'PAID';
  const canReturn = can(actor, 'sales.return.receive') && (sale.status === 'PAID' || sale.status === 'PARTIAL_RETURN');

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title={`Penjualan ${sale.sale_no}`}
        description={`${dt.format(new Date(sale.sold_at))} · ${sale.cashier?.full_name ?? '-'}`}
        back={{ href: '/penjualan/sesi', label: 'Riwayat Penjualan' }}
        actions={
          <div className="flex gap-2">
            <Link href={`/penjualan/${id}/struk`} target="_blank"
              className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm hover:bg-gray-50"
            >
              Cetak Struk
            </Link>
            {canReturn && (
              <Link href={`/penjualan/retur/baru?sale_id=${id}`}
                className="rounded-md border border-amber-300 bg-amber-50 px-4 py-2 text-sm text-amber-800 hover:bg-amber-100"
              >
                Retur
              </Link>
            )}
            {canCancel && (
              <form action={async () => {
                'use server';
                await cancelSale(actor, id);
              }}>
                <button type="submit" className="rounded-md border border-red-300 bg-red-50 px-4 py-2 text-sm text-red-700 hover:bg-red-100">
                  Batalkan
                </button>
              </form>
            )}
          </div>
        }
      />

      {/* Info transaksi */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Status</p>
          <div className="mt-1">
            <Badge tone={statusTone[sale.status as keyof typeof statusTone] ?? 'gray'}>
              {statusLabel[sale.status as keyof typeof statusLabel] ?? sale.status}
            </Badge>
          </div>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Metode Bayar</p>
          <p className="mt-1 text-sm font-medium">{PAYMENT_METHOD_LABELS[sale.payment_method] ?? sale.payment_method}</p>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Pelanggan</p>
          <p className="mt-1 text-sm font-medium">{sale.customer?.name ?? 'Umum'}</p>
        </div>
      </div>

      {/* Items */}
      <div className="mt-4 overflow-x-auto rounded-lg border border-gray-200 bg-white">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase text-gray-500">
            <tr>
              <th className="px-3 py-2">Obat</th>
              <th className="px-3 py-2 text-center">Qty</th>
              <th className="px-3 py-2 text-right">Harga Satuan</th>
              <th className="px-3 py-2 text-right">Diskon</th>
              <th className="px-3 py-2 text-right">Subtotal</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {sale.items.map((item: any) => (
              <tr key={item.id}>
                <td className="px-3 py-2">
                  <div className="font-medium">{item.medicine?.name ?? item.medicine_id}</div>
                  <div className="text-xs text-gray-500">Batch: {item.batch?.batch_no ?? item.batch_id}</div>
                </td>
                <td className="px-3 py-2 text-center">{item.qty} {item.unit?.name ?? ''}</td>
                <td className="px-3 py-2 text-right">{idr.format(Number(item.unit_price))}</td>
                <td className="px-3 py-2 text-right">
                  {Number(item.discount_pct) > 0 ? `${item.discount_pct}%` : '-'}
                </td>
                <td className="px-3 py-2 text-right font-medium">{idr.format(Number(item.line_total))}</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="border-t-2 border-gray-200 bg-gray-50">
            <tr>
              <td colSpan={3} className="px-3 py-2 text-xs text-gray-500">
                Dibayar: {idr.format(Number(sale.amount_paid))}
              </td>
              <td className="px-3 py-2 text-right text-xs font-medium text-gray-500">Total</td>
              <td className="px-3 py-2 text-right text-base font-semibold text-brand-800">
                {idr.format(Number(sale.grand_total))}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Resep terkait */}
      {sale.prescription && (
        <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Resep Terkait</p>
          <Link href={`/penjualan/resep/${sale.prescription.id}`} className="mt-1 text-sm text-brand-800 hover:underline">
            Dr. {sale.prescription.doctor_name} · {dt.format(new Date(sale.prescription.prescribed_at))}
          </Link>
        </div>
      )}

      {/* Catatan */}
      {sale.notes && (
        <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Catatan</p>
          <p className="mt-1 text-sm">{sale.notes}</p>
        </div>
      )}
    </div>
  );
}
