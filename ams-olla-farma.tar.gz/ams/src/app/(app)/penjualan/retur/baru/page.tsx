import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { prisma } from '@/lib/database/client';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Buat Retur Penjualan' };

export default async function NewSaleReturnPage({
  searchParams,
}: {
  searchParams: Promise<{ sale_id?: string }>;
}) {
  const actor = await requirePageActor('sales.return.receive');
  const sp = await searchParams;

  // Load sale yang dimaksud jika ada sale_id
  const sale = sp.sale_id
    ? await prisma.sale.findUnique({
        where: { id: sp.sale_id },
        include: {
          items: {
            include: {
              medicine: { select: { id: true, name: true } },
              batch: { select: { id: true, batch_no: true } },
              unit: { select: { id: true, name: true } },
            },
          },
          customer: true,
        },
      })
    : null;

  // Daftar sale untuk dipilih jika belum ada sale_id
  const recentSales = !sale
    ? await prisma.sale.findMany({
        where: { status: { in: ['PAID', 'PARTIAL_RETURN'] } },
        include: { customer: true },
        orderBy: { sold_at: 'desc' },
        take: 50,
      })
    : [];

  const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

  async function handleSubmit(fd: FormData) {
    'use server';
    const saleId = String(fd.get('sale_id'));
    const notes = String(fd.get('notes') ?? '');
    const items: Array<{ sale_item_id: string; batch_id: string; qty: number; disposition: string; reason: string }> = [];
    let i = 0;
    while (fd.get(`items[${i}][sale_item_id]`)) {
      const qty = Number(fd.get(`items[${i}][qty]`));
      if (qty > 0) {
        items.push({
          sale_item_id: String(fd.get(`items[${i}][sale_item_id]`)),
          batch_id: String(fd.get(`items[${i}][batch_id]`)),
          qty,
          disposition: String(fd.get(`items[${i}][disposition]`) ?? 'RESTOCK'),
          reason: String(fd.get(`items[${i}][reason]`) ?? 'Retur pelanggan'),
        });
      }
      i++;
    }
    const a = await (await import('@/lib/auth/server')).requirePageActor('sales.return.receive');
    const { createSaleReturnDraft } = await import('@/modules/sales/service');
    const ret = await createSaleReturnDraft(a, { sale_id: saleId, notes }, items as any);
    redirect(`/penjualan/retur/${ret.id}`);
  }

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Buat Retur Penjualan" back={{ href: '/penjualan/retur', label: 'Retur Penjualan' }} />

      <form action={handleSubmit} className="space-y-4">
        {!sale ? (
          /* Pilih transaksi */
          <div className="rounded-lg border border-gray-200 bg-white p-4">
            <h2 className="text-sm font-semibold">Pilih Transaksi Penjualan</h2>
            <select name="sale_id" required className="mt-2 h-9 w-full rounded-md border border-gray-300 px-2 text-sm">
              <option value="">— Pilih transaksi —</option>
              {recentSales.map((s: any) => (
                <option key={s.id} value={s.id}>
                  {s.sale_no} · {s.customer?.name ?? 'Umum'} · {idr.format(Number(s.grand_total))}
                </option>
              ))}
            </select>
          </div>
        ) : (
          <>
            <input type="hidden" name="sale_id" value={sale.id} />
            <div className="rounded-lg border border-gray-200 bg-white p-4">
              <div className="text-sm font-semibold">Transaksi: {(sale as any).sale_no}</div>
              {sale.customer && <div className="mt-1 text-xs text-gray-500">Pelanggan: {sale.customer.name}</div>}
            </div>

            {/* Item retur */}
            <div className="rounded-lg border border-gray-200 bg-white p-4">
              <h2 className="mb-3 text-sm font-semibold">Item yang Diretur</h2>
              <div className="space-y-3">
                {sale.items.map((item: any, idx: number) => (
                  <div key={item.id} className="rounded-md border border-dashed border-gray-300 p-3">
                    <input type="hidden" name={`items[${idx}][sale_item_id]`} value={item.id} />
                    <input type="hidden" name={`items[${idx}][batch_id]`} value={item.batch_id} />
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="font-medium text-sm">{item.medicine?.name}</span>
                        <span className="ml-2 text-xs text-gray-500">Batch {item.batch?.batch_no} · Terjual: {item.qty} {item.unit?.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <label className="text-xs text-gray-600">Qty Retur:</label>
                        <input
                          type="number" name={`items[${idx}][qty]`}
                          min={0} max={item.qty} defaultValue={0}
                          className="h-7 w-16 rounded border border-gray-300 px-1 text-xs text-center"
                        />
                      </div>
                    </div>
                    <div className="mt-2 grid gap-2 sm:grid-cols-2">
                      <div>
                        <label className="text-xs text-gray-600">Disposisi</label>
                        <select name={`items[${idx}][disposition]`} className="mt-1 h-8 w-full rounded border border-gray-300 px-1 text-xs">
                          <option value="RESTOCK">Kembalikan ke stok</option>
                          <option value="QUARANTINE">Karantina</option>
                          <option value="DISPOSE">Buang</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-xs text-gray-600">Alasan</label>
                        <input
                          name={`items[${idx}][reason]`}
                          defaultValue="Retur pelanggan"
                          className="mt-1 h-8 w-full rounded border border-gray-300 px-1 text-xs"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        <div>
          <label className="block text-xs font-medium text-gray-700">Catatan</label>
          <textarea name="notes" rows={2} className="mt-1 w-full rounded-md border border-gray-300 px-2 py-1 text-sm" />
        </div>

        <div className="flex justify-end gap-3">
          <a href="/penjualan/retur" className="rounded-md border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">Batal</a>
          <button type="submit" className="rounded-md bg-brand-800 px-5 py-2 text-sm font-medium text-white hover:bg-brand-900">
            Simpan Draf Retur
          </button>
        </div>
      </form>
    </div>
  );
}
