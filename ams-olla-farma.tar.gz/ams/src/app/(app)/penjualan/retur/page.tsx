import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Retur Penjualan' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });
const statusTone = { DRAFT: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;
const statusLabel = { DRAFT: 'Draf', POSTED: 'Diposting', CANCELLED: 'Dibatalkan' } as const;

type SP = Promise<{ page?: string }>;

export default async function SaleReturnListPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('sales.view_all');
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page ?? 1));
  const pageSize = 20;

  const [items, total] = await Promise.all([
    prisma.saleReturn.findMany({
      include: {
        sale: { select: { sale_no: true } },
        items: { select: { id: true } },
      },
      orderBy: { created_at: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.saleReturn.count(),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader
        title="Retur Penjualan"
        description="Barang dikembalikan dari pelanggan — dikembalikan ke stok atau dibuang."
        back={{ href: '/penjualan', label: 'Penjualan' }}
        actions={can(actor, 'sales.return.receive') ? <LinkButton href="/penjualan/retur/baru">Buat Retur</LinkButton> : null}
      />

      {items.length === 0 ? (
        <EmptyState>Belum ada retur penjualan.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-3 py-2">No. Retur</th>
                <th className="px-3 py-2">No. Penjualan</th>
                <th className="px-3 py-2 text-center">Item</th>
                <th className="px-3 py-2">Dibuat</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((ret: any) => (
                <tr key={ret.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2">
                    <Link href={`/penjualan/retur/${ret.id}`} className="font-mono text-brand-800 hover:underline">
                      {ret.return_no}
                    </Link>
                  </td>
                  <td className="px-3 py-2">
                    <Link href={`/penjualan/${ret.sale_id}`} className="font-mono text-xs text-gray-600 hover:underline">
                      {ret.sale?.sale_no}
                    </Link>
                  </td>
                  <td className="px-3 py-2 text-center">{ret.items.length}</td>
                  <td className="px-3 py-2 text-xs">{dt.format(new Date(ret.created_at))}</td>
                  <td className="px-3 py-2">
                    <Badge tone={statusTone[ret.status as keyof typeof statusTone] ?? 'gray'}>
                      {statusLabel[ret.status as keyof typeof statusLabel] ?? ret.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={pages} total={total} params={{}} basePath="/penjualan/retur" />
    </div>
  );
}
