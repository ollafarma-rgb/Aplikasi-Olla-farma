import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail Retur Penjualan' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'long', timeZone: 'Asia/Jakarta' });
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const statusTone = { DRAFT: 'amber', POSTED: 'green', CANCELLED: 'gray' } as const;
const statusLabel = { DRAFT: 'Draf', POSTED: 'Diposting', CANCELLED: 'Dibatalkan' } as const;
const dispLabel = { RESTOCK: 'Ke stok', QUARANTINE: 'Karantina', DISPOSE: 'Dibuang' } as const;
const dispTone = { RESTOCK: 'green', QUARANTINE: 'amber', DISPOSE: 'red' } as const;

export default async function SaleReturnDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('sales.view_all');
  const { id } = await params;

  const ret = await prisma.saleReturn.findUnique({
    where: { id },
    include: {
      sale: { select: { id: true, sale_no: true } },
      items: {
        include: {
          batch: { select: { batch_no: true } },
        },
      },
    },
  });
  if (!ret) notFound();

  // Load item detail dengan medicine
  const itemsWithMed = await Promise.all(
    ret.items.map(async (item: any) => {
      const si = await prisma.saleItem.findUnique({ where: { id: item.sale_item_id }, include: { medicine: { select: { name: true } }, unit: true } });
      return { ...item, medicine: si?.medicine, unit: si?.unit };
    })
  );

  const canPost = can(actor, 'sales.return.inspect') && ret.status === 'DRAFT' && (ret as any).created_by !== actor.id;
  const totalRetur = itemsWithMed.reduce((s: number, i: any) => s + Number(i.unit_price ?? 0) * i.qty, 0);

  async function handlePost() {
    'use server';
    const a = await (await import('@/lib/auth/server')).requirePageActor('sales.return.inspect');
    const { postSaleReturn } = await import('@/modules/sales/service');
    await postSaleReturn(a, id);
  }

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title={`Retur ${(ret as any).return_no}`}
        description={`Dari penjualan ${ret.sale?.sale_no}`}
        back={{ href: '/penjualan/retur', label: 'Retur Penjualan' }}
        actions={canPost ? (
          <form action={handlePost}>
            <button type="submit" className="rounded-md bg-green-700 px-4 py-2 text-sm font-medium text-white hover:bg-green-800">
              Posting Retur
            </button>
          </form>
        ) : null}
      />

      {/* Info */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Status</p>
          <div className="mt-1">
            <Badge tone={statusTone[ret.status as keyof typeof statusTone] ?? 'gray'}>
              {statusLabel[ret.status as keyof typeof statusLabel] ?? ret.status}
            </Badge>
          </div>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Penjualan Asal</p>
          <Link href={`/penjualan/${ret.sale_id}`} className="mt-1 block font-mono text-sm text-brand-800 hover:underline">
            {ret.sale?.sale_no}
          </Link>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Dibuat</p>
          <p className="mt-1 text-sm">{dt.format(new Date(ret.created_at))}</p>
        </div>
      </div>

      {/* Four-eyes notice */}
      {ret.status === 'DRAFT' && !canPost && (
        <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
          Retur draf. {(ret as any).created_by === actor.id
            ? 'Menunggu diposting oleh apoteker/pimpinan lain (four-eyes principle).'
            : 'Anda memiliki akses untuk memposting retur ini.'}
        </div>
      )}

      {/* Items */}
      <div className="mt-4 overflow-x-auto rounded-lg border border-gray-200 bg-white">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase text-gray-500">
            <tr>
              <th className="px-3 py-2">Obat</th>
              <th className="px-3 py-2 text-center">Qty</th>
              <th className="px-3 py-2 text-right">Harga Satuan</th>
              <th className="px-3 py-2 text-right">Nilai Retur</th>
              <th className="px-3 py-2">Disposisi</th>
              <th className="px-3 py-2">Alasan</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {itemsWithMed.map((item: any) => (
              <tr key={item.id}>
                <td className="px-3 py-2">
                  <div className="font-medium">{item.medicine?.name ?? '-'}</div>
                  <div className="text-xs text-gray-500">Batch: {item.batch?.batch_no ?? item.batch_id}</div>
                </td>
                <td className="px-3 py-2 text-center">{item.qty} {item.unit?.name ?? ''}</td>
                <td className="px-3 py-2 text-right">{idr.format(Number(item.unit_price ?? 0))}</td>
                <td className="px-3 py-2 text-right font-medium">{idr.format(Number(item.unit_price ?? 0) * item.qty)}</td>
                <td className="px-3 py-2">
                  <Badge tone={dispTone[item.disposition as keyof typeof dispTone] ?? 'gray'}>
                    {dispLabel[item.disposition as keyof typeof dispLabel] ?? item.disposition}
                  </Badge>
                </td>
                <td className="px-3 py-2 text-xs text-gray-600">{item.reason}</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="border-t-2 border-gray-200 bg-gray-50">
            <tr>
              <td colSpan={3} className="px-3 py-2 text-xs text-gray-500">Total nilai retur</td>
              <td className="px-3 py-2 text-right font-semibold text-brand-800">{idr.format(totalRetur)}</td>
              <td colSpan={2}></td>
            </tr>
          </tfoot>
        </table>
      </div>

      {ret.notes && (
        <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Catatan</p>
          <p className="mt-1 text-sm">{ret.notes}</p>
        </div>
      )}
    </div>
  );
}
