import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { prisma } from '@/lib/database/client';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Penjualan' };

async function counts(cashierId: string) {
  const [sesi, penjualan, resep, retur] = await Promise.all([
    prisma.saleSession.count({ where: { cashier_id: cashierId, status: 'OPEN' } }),
    prisma.sale.count({ where: { status: 'PAID', created_at: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } } }),
    prisma.prescription.count({ where: { status: 'PENDING' } }),
    prisma.saleReturn.count({ where: { status: 'DRAFT' } }),
  ]);
  return { sesi, penjualan, resep, retur };
}

export default async function SalesHubPage() {
  const actor = await requirePageActor('sales.view_all');
  const c = await counts(actor.id);

  const cards = [
    { href: '/penjualan/kasir', title: 'Kasir / POS', desc: 'Transaksi penjualan tunai dan piutang.', badge: c.sesi > 0 ? 'Sesi aktif' : 'Sesi tutup', badgeColor: c.sesi > 0 ? 'text-green-700' : 'text-amber-700' },
    { href: '/penjualan/sesi', title: 'Riwayat Sesi', desc: 'Laporan buka-tutup sesi kasir harian.', badge: `${c.penjualan} transaksi hari ini`, badgeColor: 'text-brand-800' },
    { href: '/penjualan/resep', title: 'Resep Dokter', desc: 'Kelola resep dan verifikasi apoteker.', badge: `${c.resep} menunggu verifikasi`, badgeColor: c.resep > 0 ? 'text-amber-700' : 'text-gray-500' },
    { href: '/penjualan/retur', title: 'Retur Penjualan', desc: 'Kembalikan barang dari pelanggan.', badge: `${c.retur} draf`, badgeColor: c.retur > 0 ? 'text-amber-700' : 'text-gray-500' },
    ...(can(actor, 'pricing.discount_rules.manage') ? [
      { href: '/penjualan/diskon', title: 'Diskon Periode', desc: 'Aturan diskon otomatis saat transaksi.', badge: '', badgeColor: 'text-gray-500' },
    ] : []),
  ];

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title="Penjualan"
        description="Kasir, resep dokter, dan retur penjualan."
        actions={can(actor, 'sales.create') ? (
          <Link href="/penjualan/kasir" className="rounded-md bg-brand-800 px-4 py-2 text-sm font-medium text-white hover:bg-brand-900">
            Buka Kasir
          </Link>
        ) : null}
      />
      <div className="grid gap-4 sm:grid-cols-2">
        {cards.map((card) => (
          <Link
            key={card.href}
            href={card.href}
            className="block rounded-lg border border-gray-200 bg-white p-4 hover:border-brand-300 hover:shadow-sm"
          >
            <h2 className="text-sm font-semibold">{card.title}</h2>
            <p className="mt-1 text-xs text-gray-600">{card.desc}</p>
            <p className={`mt-3 text-xs font-medium ${card.badgeColor}`}>{card.badge}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
