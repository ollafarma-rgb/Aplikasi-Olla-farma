import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { getPrescriptionDetail, verifyPrescription } from '@/modules/sales/service';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Detail Resep' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'long', timeZone: 'Asia/Jakarta' });
const statusTone = { PENDING: 'amber', VERIFIED: 'green', CANCELLED: 'gray' } as const;
const statusLabel = { PENDING: 'Menunggu Verifikasi', VERIFIED: 'Terverifikasi', CANCELLED: 'Dibatalkan' } as const;

export default async function PrescriptionDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const actor = await requirePageActor('sales.view_all');
  const { id } = await params;
  const rx = await getPrescriptionDetail(actor, id).catch(() => null);
  if (!rx) notFound();

  const canVerify = can(actor, 'rx.verify') && rx.status === 'PENDING' && rx.created_by !== actor.id;

  async function handleVerify() {
    'use server';
    const { verifyPrescription: vp } = await import('@/modules/sales/service');
    const a = await (await import('@/lib/auth/server')).requirePageActor('rx.verify');
    await vp(a, id);
  }

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader
        title={`Resep: Dr. ${rx.doctor_name}`}
        description={dt.format(new Date(rx.prescribed_at))}
        back={{ href: '/penjualan/resep', label: 'Resep Dokter' }}
        actions={canVerify ? (
          <form action={handleVerify}>
            <button type="submit" className="rounded-md bg-green-700 px-4 py-2 text-sm font-medium text-white hover:bg-green-800">
              Verifikasi Resep
            </button>
          </form>
        ) : null}
      />

      {/* Info resep */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Status</p>
          <div className="mt-1">
            <Badge tone={statusTone[rx.status as keyof typeof statusTone] ?? 'gray'}>
              {statusLabel[rx.status as keyof typeof statusLabel] ?? rx.status}
            </Badge>
          </div>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">SIP Dokter</p>
          <p className="mt-1 text-sm">{rx.doctor_sip ?? '-'}</p>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Klinik / RS</p>
          <p className="mt-1 text-sm">{rx.clinic_name ?? '-'}</p>
        </div>
      </div>

      {rx.customer && (
        <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Pelanggan</p>
          <p className="mt-1 text-sm font-medium">{rx.customer.name}</p>
        </div>
      )}

      {/* Item */}
      <div className="mt-4 overflow-x-auto rounded-lg border border-gray-200 bg-white">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 text-left text-xs uppercase text-gray-500">
            <tr>
              <th className="px-3 py-2">Obat</th>
              <th className="px-3 py-2 text-center">Qty</th>
              <th className="px-3 py-2">Aturan Pakai</th>
              <th className="px-3 py-2">Catatan</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {rx.items.map((item: any) => (
              <tr key={item.id}>
                <td className="px-3 py-2 font-medium">{item.medicine?.name ?? item.medicine_id}</td>
                <td className="px-3 py-2 text-center">{item.qty_prescribed}</td>
                <td className="px-3 py-2">{item.instructions}</td>
                <td className="px-3 py-2 text-xs text-gray-500">{item.notes ?? '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Four-eyes notice */}
      {rx.status === 'PENDING' && !canVerify && rx.created_by === actor.id && (
        <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
          Menunggu verifikasi apoteker lain (four-eyes principle — Anda tidak bisa memverifikasi resep yang Anda buat).
        </div>
      )}

      {rx.notes && (
        <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
          <p className="text-xs text-gray-500">Catatan</p>
          <p className="mt-1 text-sm">{rx.notes}</p>
        </div>
      )}
    </div>
  );
}
