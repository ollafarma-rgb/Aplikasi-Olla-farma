import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { can } from '@/lib/auth/actor';
import { prisma } from '@/lib/database/client';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Resep Dokter' };
const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeZone: 'Asia/Jakarta' });
const statusTone = { PENDING: 'amber', VERIFIED: 'green', CANCELLED: 'gray' } as const;
const statusLabel = { PENDING: 'Menunggu', VERIFIED: 'Terverifikasi', CANCELLED: 'Dibatalkan' } as const;

type SP = Promise<{ q?: string; page?: string; status?: string }>;

export default async function PrescriptionListPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('sales.view_all');
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page ?? 1));
  const pageSize = 20;
  const q = sp.q?.trim() ?? '';

  const where = {
    ...(q ? { OR: [
      { doctor_name: { contains: q, mode: 'insensitive' as const } },
      { customer: { name: { contains: q, mode: 'insensitive' as const } } },
    ] } : {}),
    ...(sp.status ? { status: sp.status } : {}),
  };

  const [items, total] = await Promise.all([
    prisma.prescription.findMany({
      where,
      include: { customer: true, items: { select: { id: true } } },
      orderBy: { prescribed_at: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.prescription.count({ where }),
  ]);

  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader
        title="Resep Dokter"
        description="Daftar resep yang masuk dan status verifikasi apoteker."
        back={{ href: '/penjualan', label: 'Penjualan' }}
        actions={can(actor, 'sales.create') ? <LinkButton href="/penjualan/resep/baru">Catat Resep</LinkButton> : null}
      />
      <form method="get" className="mb-3 flex flex-wrap gap-2">
        <input
          name="q" defaultValue={q}
          placeholder="Cari nama dokter atau pelanggan…"
          className="h-10 w-full max-w-xs rounded-md border border-gray-300 bg-white px-3 text-sm"
        />
        <select name="status" defaultValue={sp.status ?? ''} className="h-10 rounded-md border border-gray-300 bg-white px-3 text-sm">
          <option value="">Semua status</option>
          <option value="PENDING">Menunggu</option>
          <option value="VERIFIED">Terverifikasi</option>
          <option value="CANCELLED">Dibatalkan</option>
        </select>
        <button type="submit" className="rounded-md border border-gray-300 bg-white px-4 text-sm hover:bg-gray-50">Cari</button>
      </form>

      {items.length === 0 ? (
        <EmptyState>Belum ada resep.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-3 py-2">Dokter</th>
                <th className="px-3 py-2">Pelanggan</th>
                <th className="px-3 py-2 text-center">Item</th>
                <th className="px-3 py-2">Tgl Resep</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((rx: any) => (
                <tr key={rx.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2">
                    <Link href={`/penjualan/resep/${rx.id}`} className="text-brand-800 hover:underline">
                      Dr. {rx.doctor_name}
                    </Link>
                    {rx.clinic_name && <div className="text-xs text-gray-500">{rx.clinic_name}</div>}
                  </td>
                  <td className="px-3 py-2">{rx.customer?.name ?? 'Umum'}</td>
                  <td className="px-3 py-2 text-center">{rx.items.length}</td>
                  <td className="px-3 py-2 text-xs">{dt.format(new Date(rx.prescribed_at))}</td>
                  <td className="px-3 py-2">
                    <Badge tone={statusTone[rx.status as keyof typeof statusTone] ?? 'gray'}>
                      {statusLabel[rx.status as keyof typeof statusLabel] ?? rx.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={pages} total={total} params={{ q, status: sp.status }} basePath="/penjualan/resep" />
    </div>
  );
}
