import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { requirePageActor } from '@/lib/auth/server';
import { prisma } from '@/lib/database/client';
import { createPrescriptionAction } from '@/modules/sales/actions';
import { PageHeader } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Catat Resep Baru' };

export default async function NewPrescriptionPage() {
  const actor = await requirePageActor('sales.create');
  const customers = await prisma.customer.findMany({
    where: { is_active: true },
    orderBy: { name: 'asc' },
    select: { id: true, name: true },
  });
  const medicines = await prisma.medicine.findMany({
    where: { is_active: true },
    orderBy: { name: 'asc' },
    select: { id: true, name: true, sku: true },
  });

  async function handleSubmit(fd: FormData) {
    'use server';
    // Ambil items dari form (item[0][medicine_id], item[0][qty], dst)
    const items: Array<{ medicine_id: string; qty_prescribed: number; instructions: string; notes?: string }> = [];
    let i = 0;
    while (fd.get(`items[${i}][medicine_id]`)) {
      items.push({
        medicine_id: String(fd.get(`items[${i}][medicine_id]`)),
        qty_prescribed: Number(fd.get(`items[${i}][qty_prescribed]`)),
        instructions: String(fd.get(`items[${i}][instructions]`)),
        notes: String(fd.get(`items[${i}][notes]`) ?? ''),
      });
      i++;
    }
    // Build raw object
    const raw = {
      customer_id: fd.get('customer_id') as string || null,
      doctor_name: fd.get('doctor_name') as string,
      doctor_sip: fd.get('doctor_sip') as string || null,
      clinic_name: fd.get('clinic_name') as string || null,
      prescribed_at: fd.get('prescribed_at') as string,
      notes: fd.get('notes') as string || null,
    };
    const actor2 = await requirePageActor('sales.create');
    // We use service directly in server action
    const { createPrescription } = await import('@/modules/sales/service');
    const rx = await createPrescription(actor2, raw, items);
    redirect(`/penjualan/resep/${rx.id}`);
  }

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Catat Resep Baru" back={{ href: '/penjualan/resep', label: 'Resep Dokter' }} />

      <form action={handleSubmit} className="space-y-4">
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <h2 className="text-sm font-semibold text-gray-700">Data Dokter & Resep</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-gray-700">Nama Dokter *</label>
              <input name="doctor_name" required className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700">SIP Dokter</label>
              <input name="doctor_sip" className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700">Klinik / RS</label>
              <input name="clinic_name" className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700">Tanggal Resep *</label>
              <input
                name="prescribed_at" type="date" required
                defaultValue={new Date().toISOString().split('T')[0]}
                className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm"
              />
            </div>
          </div>
          <div className="mt-3">
            <label className="block text-xs font-medium text-gray-700">Pelanggan</label>
            <select name="customer_id" className="mt-1 h-9 w-full rounded-md border border-gray-300 px-2 text-sm">
              <option value="">— Umum —</option>
              {customers.map((c: any) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div className="mt-3">
            <label className="block text-xs font-medium text-gray-700">Catatan</label>
            <textarea name="notes" rows={2} className="mt-1 w-full rounded-md border border-gray-300 px-2 py-1 text-sm" />
          </div>
        </div>

        {/* Item resep — minimal 1 */}
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <h2 className="text-sm font-semibold text-gray-700">Obat yang Diresepkan</h2>
          {[0, 1, 2, 3, 4].map(i => (
            <div key={i} className="mt-3 grid gap-2 rounded-md border border-dashed border-gray-300 p-3 sm:grid-cols-4">
              <div className="sm:col-span-2">
                <label className="block text-xs text-gray-600">Obat{i === 0 ? ' *' : ''}</label>
                <select name={`items[${i}][medicine_id]`} className="mt-1 h-8 w-full rounded border border-gray-300 px-1 text-xs">
                  <option value="">— Pilih —</option>
                  {medicines.map((m: any) => (
                    <option key={m.id} value={m.id}>{m.name} ({m.sku})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-600">Qty</label>
                <input name={`items[${i}][qty_prescribed]`} type="number" min={0} defaultValue="" className="mt-1 h-8 w-full rounded border border-gray-300 px-1 text-xs" />
              </div>
              <div>
                <label className="block text-xs text-gray-600">Aturan Pakai</label>
                <input name={`items[${i}][instructions]`} placeholder="mis. 3×1" className="mt-1 h-8 w-full rounded border border-gray-300 px-1 text-xs" />
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-3">
          <a href="/penjualan/resep" className="rounded-md border border-gray-300 px-4 py-2 text-sm hover:bg-gray-50">Batal</a>
          <button type="submit" className="rounded-md bg-brand-800 px-5 py-2 text-sm font-medium text-white hover:bg-brand-900">
            Simpan Resep
          </button>
        </div>
      </form>
    </div>
  );
}
