import type { Metadata } from 'next';
import Link from 'next/link';
import { requirePageActor } from '@/lib/auth/server';
import { listSales } from '@/modules/sales/service';
import { PAYMENT_METHOD_LABELS } from '@/modules/sales/schemas';
import { Badge } from '@/components/ui/badge';
import { EmptyState, LinkButton, PageHeader, Pagination } from '@/components/ui/page';

export const metadata: Metadata = { title: 'Riwayat Penjualan' };

const dt = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Jakarta' });
const idr = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });
const statusTone = { PAID: 'green', CANCELLED: 'gray', PARTIAL_RETURN: 'amber', RETURNED: 'red' } as const;
const statusLabel = { PAID: 'Lunas', CANCELLED: 'Dibatalkan', PARTIAL_RETURN: 'Retur Sebagian', RETURNED: 'Diretur' } as const;

type SP = Promise<{ q?: string; page?: string; from?: string; to?: string }>;

export default async function SalesListPage({ searchParams }: { searchParams: SP }) {
  const actor = await requirePageActor('sales.view_all');
  const sp = await searchParams;
  const { items, total, page, pageSize, q } = await listSales(actor, {
    page: sp.page ? Number(sp.page) : undefined,
    startDate: sp.from ? new Date(sp.from) : undefined,
    endDate: sp.to ? new Date(sp.to) : undefined,
  });
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader
        title="Riwayat Penjualan"
        description="Semua transaksi penjualan."
        back={{ href: '/penjualan', label: 'Penjualan' }}
        actions={<LinkButton href="/penjualan/kasir">Kasir</LinkButton>}
      />
      <form method="get" className="mb-3 flex gap-2">
        <input
          name="q" defaultValue={q}
          placeholder="Cari nomor atau nama pelanggan…"
          className="h-10 w-full max-w-sm rounded-md border border-gray-300 bg-white px-3 text-sm"
        />
        <button type="submit" className="rounded-md border border-gray-300 bg-white px-4 text-sm hover:bg-gray-50">Cari</button>
      </form>

      {items.length === 0 ? (
        <EmptyState>Belum ada transaksi penjualan.</EmptyState>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-3 py-2">Nomor</th>
                <th className="px-3 py-2">Pelanggan</th>
                <th className="px-3 py-2">Pembayaran</th>
                <th className="px-3 py-2 text-right">Total</th>
                <th className="px-3 py-2">Kasir</th>
                <th className="px-3 py-2">Waktu</th>
                <th className="px-3 py-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {items.map((sale: any) => (
                <tr key={sale.id} className="hover:bg-gray-50">
                  <td className="px-3 py-2">
                    <Link href={`/penjualan/${sale.id}`} className="font-mono text-brand-800 hover:underline">
                      {sale.sale_no}
                    </Link>
                  </td>
                  <td className="px-3 py-2 text-gray-700">
                    {sale.customer ? (
                      <Link href={`/pelanggan/${sale.customer.id}`} className="hover:text-blue-600 hover:underline">
                        {sale.customer.name}
                      </Link>
                    ) : '-'}
                  </td>
                  <td className="px-3 py-2 text-xs">{PAYMENT_METHOD_LABELS[sale.payment_method as string] ?? sale.payment_method}</td>
                  <td className="px-3 py-2 text-right font-medium">{idr.format(Number(sale.grand_total))}</td>
                  <td className="px-3 py-2 text-xs text-gray-600">{sale.cashier?.full_name ?? '-'}</td>
                  <td className="px-3 py-2 text-xs text-gray-600">{dt.format(new Date(sale.sold_at))}</td>
                  <td className="px-3 py-2">
                    <Badge tone={statusTone[sale.status as keyof typeof statusTone] ?? 'gray'}>
                      {statusLabel[sale.status as keyof typeof statusLabel] ?? sale.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Pagination page={page} pages={pages} total={total} params={{ q }} basePath="/penjualan/sesi" />
    </div>
  );
}
