'use client';

import { useState, useEffect, useTransition, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { formatRupiah } from '@/lib/money/format';

// ─── Types ───────────────────────────────────────────────────────────────────

interface Medicine {
  id: string;
  sku: string;
  name: string;
  selling_price: string;
  unit: { id: string; name: string };
  batches: Array<{ id: string; batch_no: string; qty_saleable: number; expiry_date: string | null }>;
}

interface CartItem {
  medicine_id: string;
  batch_id: string;
  unit_id: string;
  name: string;
  batch_no: string;
  qty: number;
  unit_price: string;
  discount_pct: string;
  line_total: number;
}

interface Session {
  id: string;
  session_no: string;
  opening_cash: string;
  status: 'OPEN' | 'CLOSED';
}

// ─── Komponen utama ───────────────────────────────────────────────────────────

export default function KasirPage() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Medicine[]>([]);
  const [searching, setSearching] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'RECEIVABLE'>('CASH');
  const [amountPaid, setAmountPaid] = useState('');
  const [customerId, setCustomerId] = useState<string | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [msg, setMsg] = useState('');
  const [showOpenForm, setShowOpenForm] = useState(false);
  const [openingCash, setOpeningCash] = useState('');
  const [showCloseForm, setShowCloseForm] = useState(false);
  const [closingCash, setClosingCash] = useState('');

  // Load sesi aktif
  useEffect(() => {
    fetch('/api/sales/session')
      .then(r => r.json())
      .then(d => { setSession(d.session ?? null); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  // Cari obat
  useEffect(() => {
    if (!searchQuery.trim()) { setSearchResults([]); return; }
    const timer = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(`/api/medicines/search?q=${encodeURIComponent(searchQuery)}&saleable=1`);
        const d = await r.json();
        setSearchResults(d.items ?? []);
      } catch { /* ignore */ }
      setSearching(false);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const addToCart = useCallback((med: Medicine) => {
    const batch = med.batches[0];
    if (!batch || batch.qty_saleable <= 0) { setMsg('Stok habis.'); return; }
    setCart(prev => {
      const idx = prev.findIndex(c => c.medicine_id === med.id && c.batch_id === batch.id);
      if (idx >= 0) {
        const updated = [...prev];
        const item = { ...updated[idx], qty: updated[idx].qty + 1 };
        item.line_total = calcLine(item);
        updated[idx] = item;
        return updated;
      }
      const price = Number(med.selling_price);
      const newItem: CartItem = {
        medicine_id: med.id, batch_id: batch.id, unit_id: med.unit.id,
        name: med.name, batch_no: batch.batch_no,
        qty: 1, unit_price: med.selling_price, discount_pct: '0',
        line_total: price,
      };
      return [...prev, newItem];
    });
    setSearchQuery('');
    setSearchResults([]);
  }, []);

  const calcLine = (item: CartItem) => {
    const price = Number(item.unit_price) * item.qty;
    return price * (1 - Number(item.discount_pct) / 100);
  };

  const updateQty = (idx: number, qty: number) => {
    if (qty <= 0) { removeItem(idx); return; }
    setCart(prev => {
      const updated = [...prev];
      const item = { ...updated[idx], qty };
      item.line_total = calcLine(item);
      updated[idx] = item;
      return updated;
    });
  };

  const removeItem = (idx: number) => setCart(prev => prev.filter((_, i) => i !== idx));

  const grandTotal = cart.reduce((s, c) => s + c.line_total, 0);
  const kembalian = paymentMethod === 'CASH' ? Math.max(0, Number(amountPaid.replace(/\./g, '').replace(',', '.')) - grandTotal) : 0;

  // Buka sesi
  const handleOpenSession = () => {
    startTransition(async () => {
      const fd = new FormData();
      fd.set('opening_cash', openingCash.replace(/\./g, ''));
      const r = await fetch('/api/sales/session/open', { method: 'POST', body: fd });
      const d = await r.json();
      if (d.ok) { setSession(d.data); setShowOpenForm(false); setMsg('Sesi kasir dibuka.'); }
      else setMsg(d.message ?? 'Gagal membuka sesi.');
    });
  };

  // Tutup sesi
  const handleCloseSession = () => {
    if (!session) return;
    startTransition(async () => {
      const fd = new FormData();
      fd.set('closing_cash', closingCash.replace(/\./g, ''));
      const r = await fetch(`/api/sales/session/${session.id}/close`, { method: 'POST', body: fd });
      const d = await r.json();
      if (d.ok) { setSession(null); setShowCloseForm(false); setCart([]); setMsg('Sesi kasir ditutup.'); }
      else setMsg(d.message ?? 'Gagal menutup sesi.');
    });
  };

  // Checkout
  const handleCheckout = () => {
    if (!session || cart.length === 0) return;
    if (paymentMethod === 'CASH' && Number(amountPaid.replace(/\./g, '').replace(',', '.')) < grandTotal) {
      setMsg('Jumlah bayar kurang dari total.'); return;
    }
    startTransition(async () => {
      const body = {
        session_id: session.id,
        customer_id: customerId,
        payment_method: paymentMethod,
        amount_paid: amountPaid.replace(/\./g, '').replace(',', '.') || String(grandTotal),
        items: cart.map(c => ({
          medicine_id: c.medicine_id, batch_id: c.batch_id, unit_id: c.unit_id,
          qty: c.qty, unit_price: c.unit_price, discount_pct: c.discount_pct,
        })),
      };
      const r = await fetch('/api/sales', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const d = await r.json();
      if (d.ok) {
        const saleId = d.data?.id;
        setCart([]); setAmountPaid(''); setMsg('');
        if (saleId) router.push(`/penjualan/${saleId}/struk`);
      } else setMsg(d.message ?? 'Gagal menyimpan transaksi.');
    });
  };

  if (loading) return <div className="flex h-64 items-center justify-center text-gray-500">Memuat…</div>;

  // Belum ada sesi
  if (!session) {
    return (
      <div className="mx-auto max-w-md p-6">
        <h1 className="text-lg font-semibold">Kasir</h1>
        <p className="mt-1 text-sm text-gray-600">Tidak ada sesi kasir aktif. Buka sesi untuk memulai transaksi.</p>
        {msg && <p className="mt-2 text-sm text-red-600">{msg}</p>}
        {!showOpenForm ? (
          <button onClick={() => setShowOpenForm(true)} className="mt-4 rounded-md bg-brand-800 px-5 py-2 text-sm font-medium text-white hover:bg-brand-900">
            Buka Sesi Kasir
          </button>
        ) : (
          <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
            <h2 className="text-sm font-semibold">Buka Sesi</h2>
            <label className="mt-3 block text-xs font-medium text-gray-700">Kas Awal (Rp)</label>
            <input
              type="text" value={openingCash} onChange={e => setOpeningCash(e.target.value)}
              placeholder="0" className="mt-1 h-10 w-full rounded-md border border-gray-300 px-3 text-sm"
            />
            <div className="mt-3 flex gap-2">
              <button onClick={handleOpenSession} disabled={isPending} className="rounded-md bg-brand-800 px-4 py-2 text-sm font-medium text-white hover:bg-brand-900 disabled:opacity-50">
                {isPending ? 'Membuka…' : 'Buka Sesi'}
              </button>
              <button onClick={() => setShowOpenForm(false)} className="rounded-md border border-gray-300 px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">Batal</button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex h-[calc(100vh-4rem)] overflow-hidden">
      {/* Kolom kiri: pencarian & keranjang */}
      <div className="flex flex-1 flex-col overflow-hidden border-r border-gray-200 bg-white">
        {/* Header sesi */}
        <div className="flex items-center justify-between border-b border-gray-200 px-4 py-2 text-xs text-gray-600">
          <span>Sesi: <strong>{session.session_no}</strong></span>
          <div className="flex gap-2">
            {showCloseForm ? null : (
              <button onClick={() => setShowCloseForm(true)} className="text-xs text-red-600 hover:underline">Tutup Sesi</button>
            )}
          </div>
        </div>

        {/* Tutup sesi form */}
        {showCloseForm && (
          <div className="border-b border-amber-200 bg-amber-50 px-4 py-3">
            <p className="text-xs font-medium text-amber-800">Tutup sesi kasir</p>
            <div className="mt-2 flex items-center gap-2">
              <input
                type="text" value={closingCash} onChange={e => setClosingCash(e.target.value)}
                placeholder="Kas akhir (Rp)" className="h-8 w-40 rounded border border-gray-300 px-2 text-xs"
              />
              <button onClick={handleCloseSession} disabled={isPending} className="rounded bg-red-600 px-3 py-1.5 text-xs text-white hover:bg-red-700 disabled:opacity-50">
                {isPending ? 'Menutup…' : 'Tutup'}
              </button>
              <button onClick={() => setShowCloseForm(false)} className="text-xs text-gray-500 hover:underline">Batal</button>
            </div>
          </div>
        )}

        {/* Pencarian obat */}
        <div className="border-b border-gray-200 px-4 py-3">
          <div className="relative">
            <input
              type="search" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              placeholder="Cari obat berdasarkan nama atau SKU…"
              className="h-10 w-full rounded-md border border-gray-300 bg-gray-50 px-3 pr-8 text-sm focus:border-brand-400 focus:outline-none"
              autoFocus
            />
            {searching && (
              <span className="absolute right-3 top-2.5 text-xs text-gray-400">Mencari…</span>
            )}
          </div>
          {searchResults.length > 0 && (
            <div className="mt-1 max-h-48 overflow-y-auto rounded-md border border-gray-200 bg-white shadow-sm">
              {searchResults.map(med => (
                <button key={med.id} onClick={() => addToCart(med)}
                  className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-gray-50"
                >
                  <span>
                    <span className="font-medium">{med.name}</span>
                    <span className="ml-2 text-xs text-gray-500">{med.sku}</span>
                  </span>
                  <span className="text-xs text-brand-800">{formatRupiah(Number(med.selling_price))}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Keranjang */}
        <div className="flex-1 overflow-y-auto">
          {cart.length === 0 ? (
            <div className="flex h-full items-center justify-center text-sm text-gray-400">
              Belum ada item. Cari obat di atas.
            </div>
          ) : (
            <table className="min-w-full text-sm">
              <thead className="sticky top-0 bg-gray-50 text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-3 py-2 text-left">Obat</th>
                  <th className="px-3 py-2 text-center">Qty</th>
                  <th className="px-3 py-2 text-right">Harga</th>
                  <th className="px-3 py-2 text-right">Diskon%</th>
                  <th className="px-3 py-2 text-right">Subtotal</th>
                  <th className="px-3 py-2"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {cart.map((item, idx) => (
                  <tr key={idx} className="hover:bg-gray-50">
                    <td className="px-3 py-2">
                      <div className="font-medium">{item.name}</div>
                      <div className="text-xs text-gray-500">Batch: {item.batch_no}</div>
                    </td>
                    <td className="px-3 py-2 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => updateQty(idx, item.qty - 1)} className="h-6 w-6 rounded border border-gray-300 text-sm hover:bg-gray-100">-</button>
                        <input
                          type="number" value={item.qty} min={1}
                          onChange={e => updateQty(idx, Number(e.target.value))}
                          className="h-6 w-12 rounded border border-gray-300 text-center text-xs"
                        />
                        <button onClick={() => updateQty(idx, item.qty + 1)} className="h-6 w-6 rounded border border-gray-300 text-sm hover:bg-gray-100">+</button>
                      </div>
                    </td>
                    <td className="px-3 py-2 text-right text-xs">{formatRupiah(Number(item.unit_price))}</td>
                    <td className="px-3 py-2 text-right">
                      <input
                        type="number" value={item.discount_pct} min={0} max={100} step={0.5}
                        onChange={e => {
                          setCart(prev => {
                            const u = [...prev];
                            const it = { ...u[idx], discount_pct: e.target.value };
                            it.line_total = calcLine(it);
                            u[idx] = it;
                            return u;
                          });
                        }}
                        className="h-6 w-14 rounded border border-gray-300 text-right text-xs px-1"
                      />
                    </td>
                    <td className="px-3 py-2 text-right font-medium">{formatRupiah(item.line_total)}</td>
                    <td className="px-3 py-2">
                      <button onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700">×</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Kolom kanan: pembayaran */}
      <div className="flex w-72 flex-col bg-gray-50">
        <div className="flex-1 overflow-y-auto p-4">
          <h2 className="text-sm font-semibold text-gray-700">Pembayaran</h2>

          {/* Total */}
          <div className="mt-4 rounded-lg bg-white p-3 shadow-sm">
            <div className="flex justify-between text-xs text-gray-600">
              <span>{cart.length} item</span>
              <span>{cart.reduce((s, c) => s + c.qty, 0)} satuan</span>
            </div>
            <div className="mt-2 flex justify-between text-base font-semibold">
              <span>Total</span>
              <span className="text-brand-800">{formatRupiah(grandTotal)}</span>
            </div>
          </div>

          {/* Metode pembayaran */}
          <div className="mt-4">
            <label className="text-xs font-medium text-gray-700">Metode Pembayaran</label>
            <div className="mt-1 flex gap-2">
              {(['CASH', 'RECEIVABLE'] as const).map(m => (
                <button key={m} onClick={() => setPaymentMethod(m)}
                  className={`flex-1 rounded-md py-2 text-xs font-medium ${paymentMethod === m ? 'bg-brand-800 text-white' : 'border border-gray-300 bg-white text-gray-700 hover:bg-gray-50'}`}
                >
                  {m === 'CASH' ? 'Tunai' : 'Piutang'}
                </button>
              ))}
            </div>
          </div>

          {/* Pelanggan (opsional, wajib untuk piutang) */}
          <div className="mt-3">
            <label className="text-xs font-medium text-gray-700">
              Pelanggan {paymentMethod === 'RECEIVABLE' && <span className="text-red-500">*</span>}
            </label>
            <input
              type="text" value={customerName} onChange={e => setCustomerName(e.target.value)}
              placeholder={paymentMethod === 'RECEIVABLE' ? 'Wajib untuk piutang' : 'Opsional'}
              className="mt-1 h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-xs"
            />
          </div>

          {/* Jumlah bayar */}
          {paymentMethod === 'CASH' && (
            <div className="mt-3">
              <label className="text-xs font-medium text-gray-700">Jumlah Bayar (Rp)</label>
              <input
                type="text" value={amountPaid} onChange={e => setAmountPaid(e.target.value)}
                placeholder={formatRupiah(grandTotal)}
                className="mt-1 h-9 w-full rounded-md border border-gray-300 bg-white px-2 text-xs"
              />
              {Number(amountPaid.replace(/\./g, '')) >= grandTotal && (
                <div className="mt-1 flex justify-between text-xs">
                  <span className="text-gray-600">Kembalian</span>
                  <span className="font-medium text-green-700">{formatRupiah(kembalian)}</span>
                </div>
              )}
            </div>
          )}

          {msg && <p className="mt-3 text-xs text-red-600">{msg}</p>}
        </div>

        {/* Tombol checkout */}
        <div className="border-t border-gray-200 p-4">
          <button
            onClick={handleCheckout}
            disabled={isPending || cart.length === 0 || !session}
            className="h-12 w-full rounded-lg bg-brand-800 text-sm font-semibold text-white hover:bg-brand-900 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {isPending ? 'Memproses…' : `Bayar ${formatRupiah(grandTotal)}`}
          </button>
        </div>
      </div>
    </div>
  );
}
