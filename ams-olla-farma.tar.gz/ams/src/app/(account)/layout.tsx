import type { ReactNode } from 'react';
import { requireUser } from '@/lib/auth/server';

/** Halaman akun pribadi: cukup login, tanpa sidebar modul. */
export default async function AccountLayout({ children }: { children: ReactNode }) {
  await requireUser();
  return <main className="flex min-h-screen items-start justify-center px-4 py-10">{children}</main>;
}
