'use client';

import { useActionState } from 'react';
import { changePasswordAction, type FormState } from '@/modules/authentication/actions';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { FormField } from '@/components/ui/form-field';

const initial: FormState = { ok: false };

export function ChangePasswordForm({ minLength }: { minLength: number }) {
  const [state, formAction, pending] = useActionState(changePasswordAction, initial);
  return (
    <form action={formAction} className="space-y-4" noValidate>
      {state.message && !state.fields ? <Alert tone="error">{state.message}</Alert> : null}
      <FormField label="Kata sandi lama" name="currentPassword" type="password" autoComplete="current-password" required error={state.fields?.currentPassword} />
      <FormField
        label="Kata sandi baru"
        name="newPassword"
        type="password"
        autoComplete="new-password"
        required
        minLength={minLength}
        hint={`Minimal ${minLength} karakter, tidak memuat nama pengguna.`}
        error={state.fields?.newPassword}
      />
      <FormField label="Ulangi kata sandi baru" name="confirmPassword" type="password" autoComplete="new-password" required error={state.fields?.confirmPassword} />
      <Button type="submit" className="w-full" disabled={pending}>
        {pending ? 'Menyimpan…' : 'Simpan kata sandi baru'}
      </Button>
    </form>
  );
}
