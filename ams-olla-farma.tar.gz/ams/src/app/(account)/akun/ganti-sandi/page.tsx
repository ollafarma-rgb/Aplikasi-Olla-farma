import type { Metadata } from 'next';
import Link from 'next/link';
import { requireUser } from '@/lib/auth/server';
import { PASSWORD_MIN_LENGTH } from '@/lib/auth/password';
import { ChangePasswordForm } from './change-password-form';

export const metadata: Metadata = { title: 'Ganti kata sandi' };

export default async function ChangePasswordPage() {
  const user = await requireUser();
  const forced = user.user.must_change_password;

  return (
    <div className="w-full max-w-sm rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
      <h1 className="text-xl font-semibold">Ganti kata sandi</h1>
      <p className="mt-1 text-sm text-gray-600">
        {forced
          ? 'Demi keamanan, ganti kata sandi awal Anda sebelum memakai AMS.'
          : 'Setelah diganti, sesi Anda di perangkat lain akan dikeluarkan.'}
      </p>
      <div className="mt-5">
        <ChangePasswordForm minLength={PASSWORD_MIN_LENGTH} />
      </div>
      {!forced ? (
        <Link href="/dashboard" className="mt-4 block text-center text-sm text-gray-600 hover:text-gray-900">
          Kembali ke dashboard
        </Link>
      ) : null}
    </div>
  );
}
