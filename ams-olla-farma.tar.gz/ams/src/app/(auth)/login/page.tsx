import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth/server';
import { LoginForm } from './login-form';

export const metadata: Metadata = { title: 'Masuk' };

export default async function LoginPage() {
  if (await getCurrentUser()) redirect('/dashboard');

  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div className="mb-6">
          <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">Apotek OLLA FARMA</p>
          <h1 className="mt-1 text-xl font-semibold">Masuk ke AMS</h1>
          <p className="mt-1 text-sm text-gray-600">Gunakan akun yang diberikan pemilik apotek.</p>
        </div>
        <LoginForm />
      </div>
    </main>
  );
}
