'use client';

import { useActionState } from 'react';
import { loginAction, type FormState } from '@/modules/authentication/actions';
import { Alert } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { FormField } from '@/components/ui/form-field';
import { useOnlineStatus } from '@/components/layout/use-online-status';

const initial: FormState = { ok: false };

export function LoginForm() {
  const [state, formAction, pending] = useActionState(loginAction, initial);
  const online = useOnlineStatus();

  return (
    <form action={formAction} className="space-y-4" noValidate>
      {!online ? <Alert tone="error">Tidak ada koneksi internet. Periksa jaringan apotek.</Alert> : null}
      {state.message && !state.fields ? <Alert tone="error">{state.message}</Alert> : null}
      <FormField
        label="Nama pengguna"
        name="username"
        autoComplete="username"
        autoCapitalize="none"
        spellCheck={false}
        required
        autoFocus
        error={state.fields?.username}
      />
      <FormField
        label="Kata sandi"
        name="password"
        type="password"
        autoComplete="current-password"
        required
        error={state.fields?.password}
      />
      <Button type="submit" className="w-full" disabled={pending || !online}>
        {pending ? 'Memeriksa…' : 'Masuk'}
      </Button>
    </form>
  );
}
