import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = { title: 'Tidak diizinkan' };

export default function ForbiddenPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-sm text-center">
        <h1 className="text-xl font-semibold">Akses tidak diizinkan</h1>
        <p className="mt-2 text-sm text-gray-600">
          Peran Anda tidak memiliki izin untuk halaman ini. Hubungi pemilik apotek bila Anda memerlukan akses.
        </p>
        <Link href="/dashboard" className="mt-4 inline-block text-sm font-medium text-brand-700 hover:underline">
          Kembali ke dashboard
        </Link>
      </div>
    </main>
  );
}
