import { NextResponse, type NextRequest } from 'next/server';

/**
 * Proxy Next.js 16 (pengganti middleware.ts).
 * 1. Pasang Content-Security-Policy dengan nonce baru per request.
 * 2. Alihkan ke /login bila cookie sesi tidak ada (pemeriksaan cepat/optimistis).
 *    Validasi sesi yang sesungguhnya tetap di server (requireUser) karena proxy
 *    tidak boleh menjadi satu-satunya pengaman.
 */

const PUBLIC_PATHS = ['/login', '/api/v1/health'];
const COOKIE_NAMES = ['__Host-ams_session', 'ams_session'];

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const isPublic = PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(`${p}/`));
  const hasCookie = COOKIE_NAMES.some((n) => request.cookies.has(n));

  if (!isPublic && !hasCookie) {
    const url = request.nextUrl.clone();
    url.pathname = '/login';
    url.search = '';
    return NextResponse.redirect(url);
  }

  const nonce = btoa(crypto.randomUUID());
  const isDev = process.env.NODE_ENV !== 'production';
  const csp = [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic'${isDev ? " 'unsafe-eval'" : ''}`,
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' blob: data:",
    "font-src 'self'",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    ...(isDev ? [] : ['upgrade-insecure-requests']),
  ].join('; ');

  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-nonce', nonce);
  requestHeaders.set('Content-Security-Policy', csp);

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set('Content-Security-Policy', csp);
  return response;
}

export const config = {
  matcher: [
    // Semua path kecuali aset statis Next.js dan favicon.
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
};
