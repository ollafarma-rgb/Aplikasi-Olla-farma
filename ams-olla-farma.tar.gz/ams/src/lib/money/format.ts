/**
 * Format tampilan Rupiah. Perhitungan uang TIDAK dilakukan di sini dan tidak
 * pernah memakai number/floating-point; angka uang beredar sebagai string
 * desimal (mis. "12500.00") dan dihitung dengan decimal.js mulai Fase 3.
 */

const DECIMAL_STRING = /^-?\d{1,16}(\.\d{1,4})?$/;

export function isDecimalString(value: string): boolean {
  return DECIMAL_STRING.test(value);
}

/**
 * "1234567.5" -> "Rp 1.234.567,50". Pemisah ribuan titik, desimal koma.
 * Pembulatan setengah ke atas pada digit desimal yang diminta, dilakukan
 * pada string agar bebas galat floating-point.
 */
export function formatRupiah(value: string | number, fractionDigits = 0): string {
  const strValue = typeof value === 'number' ? String(Math.round(value)) : value;
  if (!isDecimalString(strValue)) {
    throw new TypeError(`Bukan angka desimal yang sah: ${strValue}`);
  }
  // alias agar sisa fungsi tetap pakai variabel `value` sebagai string
  const value2 = strValue;
  const negative = value2.startsWith('-');
  const unsigned = negative ? value2.slice(1) : value2;
  const [intPartRaw, fracRaw = ''] = unsigned.split('.');
  const { intPart, frac } = roundHalfUp(intPartRaw, fracRaw, fractionDigits);
  const grouped = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  const body = fractionDigits > 0 ? `${grouped},${frac}` : grouped;
  const isZero = /^[0.,]+$/.test(body);
  return `${negative && !isZero ? '-' : ''}Rp ${body}`;
}

function roundHalfUp(intPart: string, frac: string, digits: number): { intPart: string; frac: string } {
  const padded = frac.padEnd(digits + 1, '0');
  const kept = padded.slice(0, digits);
  const nextDigit = Number(padded[digits]);
  let digitsStr = (intPart.replace(/^0+(?=\d)/, '') || '0') + kept;
  if (nextDigit >= 5) {
    digitsStr = incrementDigits(digitsStr);
  }
  const splitAt = digitsStr.length - digits;
  return {
    intPart: digitsStr.slice(0, splitAt) || '0',
    frac: digits > 0 ? digitsStr.slice(splitAt) : '',
  };
}

function incrementDigits(digits: string): string {
  const arr = digits.split('');
  let i = arr.length - 1;
  while (i >= 0) {
    if (arr[i] === '9') {
      arr[i] = '0';
      i -= 1;
    } else {
      arr[i] = String(Number(arr[i]) + 1);
      return arr.join('');
    }
  }
  return `1${arr.join('')}`;
}
