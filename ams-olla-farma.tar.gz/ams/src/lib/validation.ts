import type { z } from 'zod';
import { AppError } from './errors';

/** Ubah error Zod menjadi peta field -> pesan pertama. */
export function fieldErrors(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path.join('.') || '_';
    out[key] ??= issue.message;
  }
  return out;
}

/** Validasi input; lempar VALIDATION_ERROR berisi pesan per field. */
export function parseOrThrow<S extends z.ZodType>(schema: S, raw: unknown): z.output<S> {
  const r = schema.safeParse(raw);
  if (!r.success) throw new AppError('VALIDATION_ERROR', undefined, fieldErrors(r.error));
  return r.data;
}

/** Normalisasi angka uang (string/Decimal/null) ke 2 desimal untuk perbandingan, tanpa float. */
export function normalizeMoney(v: unknown): string | null {
  if (v === null || v === undefined || v === '') return null;
  const s = String(v);
  if (!/^-?\d+(\.\d+)?$/.test(s)) return s;
  const [i, f = ''] = s.split('.');
  return `${i.replace(/^(-?)0+(?=\d)/, '$1')}.${(f + '00').slice(0, 2)}${f.length > 2 ? f.slice(2).replace(/0+$/, '') : ''}`;
}
