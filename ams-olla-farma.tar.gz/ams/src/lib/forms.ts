import { z } from 'zod';
import type { ErrorCode } from './errors';

/** State Server Action untuk form. `values` mengisi ulang input setelah error. */
export interface ActionState {
  ok: boolean;
  code?: ErrorCode;
  message?: string;
  fields?: Record<string, string>;
  values?: Record<string, string>;
  /** Penanda submit agar form bisa di-remount dengan nilai terakhir. */
  submittedAt?: number;
  /** Data hasil yang perlu ditampilkan sekali (mis. sandi sementara, objek yang dibuat). */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data?: any;
}

export const initialActionState: ActionState = { ok: false };

/** FormData -> objek string (nilai kosong dipertahankan sebagai ''). */
export function formToObject(fd: FormData): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of fd.entries()) {
    if (typeof v === 'string' && !k.startsWith('$ACTION')) out[k] = v;
  }
  return out;
}

// ---- Helper Zod untuk input form (selalu string) ----

export const text = (max: number, label: string) =>
  z.string().trim().min(1, `${label} wajib diisi.`).max(max, `${label} maksimal ${max} karakter.`);

export const optionalText = (max: number, label: string) =>
  z
    .string()
    .trim()
    .max(max, `${label} maksimal ${max} karakter.`)
    .optional()
    .transform((v) => (v ? v : null));

export const optionalId = z
  .string()
  .trim()
  .optional()
  .transform((v) => (v ? v : null))
  .refine((v) => v === null || /^[0-9a-f-]{36}$/i.test(v), 'Pilihan tidak valid.');

export const requiredId = (label: string) =>
  z.string().trim().regex(/^[0-9a-f-]{36}$/i, `${label} wajib dipilih.`);

/** Uang dalam Rupiah sebagai string desimal, maksimal 2 desimal. "12.500" (titik ribuan) diterima. */
export const money = (label: string) =>
  z
    .string()
    .trim()
    .transform((v) => v.replace(/\./g, '').replace(',', '.'))
    .refine((v) => /^\d{1,16}(\.\d{1,2})?$/.test(v), `${label} harus angka Rupiah yang sah.`);

export const optionalMoney = (label: string) =>
  z
    .string()
    .trim()
    .optional()
    .transform((v) => (v ? v.replace(/\./g, '').replace(',', '.') : null))
    .refine((v) => v === null || /^\d{1,16}(\.\d{1,2})?$/.test(v), `${label} harus angka Rupiah yang sah.`);

export const intField = (label: string, min = 0, max = 1_000_000_000) =>
  z
    .string()
    .trim()
    .regex(/^\d+$/, `${label} harus bilangan bulat.`)
    .transform(Number)
    .refine((n) => n >= min && n <= max, `${label} harus antara ${min} dan ${max}.`);

export const optionalInt = (label: string, min = 0) =>
  z
    .string()
    .trim()
    .optional()
    .transform((v) => (v ? v : null))
    .refine((v) => v === null || /^\d+$/.test(v), `${label} harus bilangan bulat.`)
    .transform((v) => (v === null ? null : Number(v)))
    .refine((n) => n === null || n >= min, `${label} minimal ${min}.`);

export const checkbox = z
  .string()
  .optional()
  .transform((v) => v === 'on' || v === 'true' || v === '1');
