import type { DbTransaction } from './client';

/**
 * Isi identitas pengguna untuk trigger database di transaksi ini
 * (riwayat harga dan aturan lain yang butuh "siapa"). SET LOCAL: hilang saat commit.
 */
export async function setActor(tx: DbTransaction, userId: string, reason?: string | null): Promise<void> {
  await tx.$executeRaw`SELECT set_config('ams.user_id', ${userId}, true), set_config('ams.price_reason', ${reason ?? ''}, true)`;
}

/** Ambil nomor urut berikutnya secara atomik (fungsi SQL ams_next_number). */
export async function nextNumber(tx: DbTransaction, docType: string, period: string): Promise<number> {
  const rows = await tx.$queryRaw<{ n: number }[]>`SELECT ams_next_number(${docType}, ${period}) AS n`;
  const n = rows[0]?.n;
  if (typeof n !== 'number') throw new Error('Gagal mengambil nomor urut');
  return n;
}
