import { AppError } from '../errors';

/** Daftar constraint yang error-nya dilaporkan sebagai DUPLICATE (bukan VALIDATION_ERROR). */
const DUPLICATE_CONSTRAINTS = new Set([
  'medicines_sku_key',
  'medicines_barcode_key',
  'medicine_unit_conversions_barcode_key',
  'AMS_BARCODE_DUPLICATE',
  'categories_name_key',
  'units_code_key',
  'manufacturers_name_key',
  'storage_locations_code_key',
  'suppliers_code_key',
  'users_username_key',
  'purchase_orders_po_no_key',
  'goods_receipts_gr_no_key',
  'purchase_returns_return_no_key',
  'customers_code_key',
  'sale_sessions_session_no_key',
  'sales_invoice_no_key',
  'sale_returns_return_no_key',
  'purchase_invoices_invoice_no_key',
  'purchase_invoices_gr_id_key',
  'supplier_payments_payment_no_key',
  'prescriptions_rx_no_key',
]);

/**
 * Terjemahkan pelanggaran constraint database menjadi pesan per field yang
 * bisa dipahami pengguna. Database tetap penjaga terakhir; validasi di service
 * hanya membuat pesannya lebih cepat dan ramah.
 */
const CONSTRAINT_MESSAGES: Record<string, [field: string, message: string]> = {
  medicines_sku_key: ['sku', 'SKU sudah dipakai obat lain.'],
  medicines_barcode_key: ['barcode', 'Barcode sudah dipakai obat lain.'],
  medicine_unit_conversions_barcode_key: ['barcode', 'Barcode sudah dipakai satuan obat lain.'],
  medicine_unit_conversions_medicine_id_unit_id_key: ['unit_id', 'Satuan ini sudah ada di daftar konversi.'],
  AMS_BARCODE_DUPLICATE: ['barcode', 'Barcode sudah dipakai obat atau satuan lain.'],
  AMS_CONVERSION_BASE_UNIT: ['unit_id', 'Satuan dasar tidak perlu ditambahkan sebagai konversi.'],
  medicines_narc_psy_rx_chk: ['requires_prescription', 'Narkotika dan psikotropika wajib resep.'],
  medicines_keras_rx_chk: ['requires_prescription', 'Obat keras wajib resep kecuali ditandai OWA.'],
  medicines_owa_chk: ['is_owa', 'Tanda OWA hanya untuk obat keras yang tidak ditandai wajib resep.'],
  medicines_nie_chk: ['registration_no', 'Nomor izin edar (NIE) wajib diisi untuk obat.'],
  medicines_type_class_chk: ['product_type', 'Jenis produk tidak sesuai dengan golongan obat.'],
  medicines_stock_chk: ['max_stock', 'Stok maksimum harus kosong atau tidak kurang dari stok minimum.'],
  medicines_barcode_chk: ['barcode', 'Barcode hanya huruf, angka, dan tanda minus (4–64 karakter).'],
  muc_factor_chk: ['factor_to_base', 'Isi konversi harus lebih dari 1.'],
  muc_barcode_chk: ['barcode', 'Barcode hanya huruf, angka, dan tanda minus (4–64 karakter).'],
  categories_name_key: ['name', 'Nama kategori sudah ada.'],
  units_code_key: ['code', 'Kode satuan sudah ada.'],
  units_code_chk: ['code', 'Kode satuan hanya huruf besar dan angka.'],
  manufacturers_name_key: ['name', 'Nama pabrik sudah ada.'],
  storage_locations_code_key: ['code', 'Kode lokasi sudah ada.'],
  storage_locations_code_chk: ['code', 'Kode lokasi hanya huruf besar, angka, titik, minus, garis bawah.'],
  suppliers_code_key: ['code', 'Kode pemasok sudah dipakai.'],
  suppliers_term_chk: ['payment_term_days', 'Termin pembayaran 0–365 hari.'],
  users_username_key: ['username', 'Nama pengguna sudah dipakai.'],
  users_username_lower_chk: ['username', 'Nama pengguna 3–50 karakter: huruf kecil, angka, titik, minus, garis bawah.'],
  medicine_batches_medicine_id_batch_no_expiry_date_key: ['batch_no', 'Batch dengan nomor dan tanggal kedaluwarsa ini sudah ada untuk obat tersebut.'],
  AMS_STOCK_NEGATIVE: ['qty', 'Jumlah melebihi stok yang tersedia pada batch.'],
  AMS_STOCK_QTY: ['qty', 'Jumlah harus lebih dari 0.'],
  AMS_BATCH_NOT_FOUND: ['batch_id', 'Batch tidak ditemukan.'],
  purchase_orders_po_no_key: ['po_no', 'Nomor Surat Pesanan sudah dipakai.'],
  goods_receipts_gr_no_key: ['gr_no', 'Nomor penerimaan sudah dipakai.'],
  purchase_returns_return_no_key: ['return_no', 'Nomor retur sudah dipakai.'],
  medicine_batches_goods_receipt_item_id_key: ['batch_no', 'Baris penerimaan ini sudah membuat batch.'],
  customers_code_key: ['code', 'Kode pelanggan sudah dipakai.'],
  sale_sessions_session_no_key: ['session_no', 'Nomor sesi sudah dipakai.'],
  sales_invoice_no_key: ['invoice_no', 'Nomor faktur penjualan sudah dipakai.'],
  sale_returns_return_no_key: ['return_no', 'Nomor retur penjualan sudah dipakai.'],
  purchase_invoices_invoice_no_key: ['invoice_no', 'Nomor faktur pembelian sudah dipakai.'],
  purchase_invoices_gr_id_key: ['gr_id', 'Penerimaan barang ini sudah memiliki faktur.'],
  supplier_payments_payment_no_key: ['payment_no', 'Nomor pembayaran sudah dipakai.'],
  prescriptions_rx_no_key: ['rx_no', 'Nomor resep sudah dipakai.'],
};

function collectText(error: unknown, depth = 0): string {
  if (!error || depth > 4) return '';
  if (typeof error === 'string') return error;
  const e = error as { message?: unknown; meta?: unknown; cause?: unknown };
  return [
    typeof e.message === 'string' ? e.message : '',
    e.meta ? JSON.stringify(e.meta) : '',
    collectText(e.cause, depth + 1),
  ].join(' ');
}

/** Kembalikan AppError bila error berasal dari constraint yang dikenal; selain itu null. */
export function translateDbError(error: unknown): AppError | null {
  if (error instanceof AppError) return error;
  const text = collectText(error);
  for (const [name, [field, message]] of Object.entries(CONSTRAINT_MESSAGES)) {
    if (text.includes(name)) {
      const code = DUPLICATE_CONSTRAINTS.has(name) ? 'DUPLICATE' : 'VALIDATION_ERROR';
      return new AppError(code, message, { [field]: message });
    }
  }
  if (/foreign key/i.test(text) && /delete/i.test(text)) {
    return new AppError('VALIDATION_ERROR', 'Data masih dipakai di data lain sehingga tidak bisa dihapus.');
  }
  return null;
}

/** Jalankan fn; terjemahkan error constraint, teruskan error lain apa adanya. */
export async function withDbErrors<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    throw translateDbError(error) ?? error;
  }
}
