import 'server-only';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '@/generated/prisma/client';

/**
 * Satu instance PrismaClient per proses (Prisma 7 + driver adapter pg).
 * Batas waktu koneksi diset eksplisit: driver pg default-nya tanpa batas,
 * padahal POS harus cepat memberi tahu bila database tidak terjangkau.
 */
function createClient(): PrismaClient {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error('DATABASE_URL belum diset');
  const adapter = new PrismaPg({
    connectionString,
    connectionTimeoutMillis: 5_000,
    idleTimeoutMillis: 30_000,
    max: 10,
  });
  return new PrismaClient({ adapter });
}

const globalForPrisma = globalThis as unknown as { amsPrisma?: PrismaClient };

export const prisma: PrismaClient = globalForPrisma.amsPrisma ?? createClient();

if (process.env.NODE_ENV !== 'production') globalForPrisma.amsPrisma = prisma;

export type DbClient = PrismaClient;
export type DbTransaction = Parameters<Parameters<PrismaClient['$transaction']>[0]>[0];
