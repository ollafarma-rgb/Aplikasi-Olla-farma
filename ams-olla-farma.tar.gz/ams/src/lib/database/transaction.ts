import 'server-only';
import { AppError } from '../errors';
import { prisma, type DbTransaction } from './client';

/** SQLSTATE yang aman untuk diulang: serialization failure dan deadlock. */
const RETRYABLE_SQLSTATE = new Set(['40001', '40P01']);
const CONNECTION_SQLSTATE_PREFIX = '08';

function sqlState(error: unknown): string | undefined {
  const e = error as { code?: string; meta?: { code?: string }; cause?: { code?: string } };
  return e?.meta?.code ?? e?.cause?.code ?? (typeof e?.code === 'string' && /^[0-9A-Z]{5}$/.test(e.code) ? e.code : undefined);
}

export function isRetryable(error: unknown): boolean {
  const code = sqlState(error);
  return (code !== undefined && RETRYABLE_SQLSTATE.has(code)) || (error as { code?: string })?.code === 'P2034';
}

export function isConnectionError(error: unknown): boolean {
  const code = sqlState(error);
  const msg = error instanceof Error ? error.message : '';
  return (code?.startsWith(CONNECTION_SQLSTATE_PREFIX) ?? false) || /ECONNREFUSED|ETIMEDOUT|ENOTFOUND|Connection terminated/i.test(msg);
}

/**
 * Jalankan fn dalam satu transaksi ACID. Diulang maksimal 3 kali untuk
 * konflik serialisasi/deadlock. Error koneksi dipetakan ke SERVICE_UNAVAILABLE
 * agar UI menampilkan "transaksi BELUM tersimpan", bukan sukses palsu.
 */
export async function withTransaction<T>(fn: (tx: DbTransaction) => Promise<T>, maxAttempts = 3): Promise<T> {
  let attempt = 0;
  for (;;) {
    attempt += 1;
    try {
      return await prisma.$transaction(fn, { isolationLevel: 'ReadCommitted', maxWait: 5_000, timeout: 15_000 });
    } catch (error) {
      if (error instanceof AppError) throw error;
      if (isRetryable(error) && attempt < maxAttempts) {
        await new Promise((r) => setTimeout(r, 25 * attempt + Math.random() * 25));
        continue;
      }
      if (isConnectionError(error)) throw new AppError('SERVICE_UNAVAILABLE');
      throw error;
    }
  }
}
