import 'server-only';
import { toFailure } from './errors';
import { formToObject, type ActionState } from './forms';
import { requireActor } from './auth/server';
import type { Actor } from './auth/actor';
import type { PermissionCode } from './permissions/catalog';

/**
 * Pola standar Server Action form: cek izin, jalankan service, kembalikan
 * ActionState. Nilai yang dikirim ikut dikembalikan saat gagal agar form
 * tidak kosong lagi. Redirect setelah sukses dilakukan pemanggil (di luar try).
 */
export async function runFormAction(
  formData: FormData,
  permission: PermissionCode,
  fn: (actor: Actor, values: Record<string, string>) => Promise<string | void | { message?: string; data?: Record<string, string> }>,
): Promise<ActionState> {
  const values = formToObject(formData);
  try {
    const actor = await requireActor(permission);
    const result = await fn(actor, values);
    const message = typeof result === 'string' ? result : result?.message;
    const data = typeof result === 'object' && result ? result.data : undefined;
    return { ok: true, message: message ?? 'Tersimpan.', data, submittedAt: Date.now() };
  } catch (error) {
    const f = toFailure(error);
    return { ok: false, code: f.code, message: f.message, fields: f.fields, values, submittedAt: Date.now() };
  }
}
