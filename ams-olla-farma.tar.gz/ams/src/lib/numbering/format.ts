/**
 * Format nomor dokumen. Angka urut diambil atomik dari fungsi SQL
 * ams_next_number(doc_type, period); modul ini hanya merangkai string.
 *
 * Contoh: PJ/2611/000123  (penjualan, November 2026, urutan 123)
 */

export const DOC_TYPES = {
  SALE: 'PJ',
  PURCHASE_ORDER: 'SP',
  PURCHASE_ORDER_SPECIAL: 'SPK',
  GOODS_RECEIPT: 'PB',
  PRESCRIPTION: 'RX',
  SALES_RETURN: 'RJ',
  PURCHASE_RETURN: 'RB',
  STOCK_ADJUSTMENT: 'PS',
  STOCK_OPNAME: 'SO',
  DISPOSAL: 'BAP',
  SUPPLIER_PAYMENT: 'BYR',
  EXPENSE: 'BIA',
  CASHIER_SHIFT: 'SFT',
  JOURNAL: 'JU',
} as const;

export type DocType = (typeof DOC_TYPES)[keyof typeof DOC_TYPES];

export type PeriodGranularity = 'month' | 'day';

/** Periode dihitung pada zona waktu apotek (default Asia/Jakarta), bukan UTC. */
export function periodKey(date: Date, granularity: PeriodGranularity, timeZone = 'Asia/Jakarta'): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  const yy = get('year').slice(2);
  const mm = get('month');
  const dd = get('day');
  return granularity === 'month' ? `${yy}${mm}` : `${yy}${mm}${dd}`;
}

export function formatDocNumber(prefix: DocType, period: string, sequence: number, width = 6): string {
  if (!Number.isInteger(sequence) || sequence < 1) {
    throw new RangeError('Nomor urut harus bilangan bulat positif');
  }
  const seq = String(sequence);
  if (seq.length > width) {
    throw new RangeError(`Nomor urut ${sequence} melebihi lebar ${width} digit`);
  }
  return `${prefix}/${period}/${seq.padStart(width, '0')}`;
}
