/**
 * Error domain AMS. Setiap error membawa kode stabil yang dipetakan ke pesan
 * Bahasa Indonesia di UI. Jangan pernah mengirim pesan error database mentah
 * ke browser.
 */

export const ERROR_CODES = [
  'UNAUTHENTICATED',
  'FORBIDDEN',
  'VALIDATION_ERROR',
  'DUPLICATE',
  'ACCOUNT_LOCKED',
  'ACCOUNT_INACTIVE',
  'RATE_LIMITED',
  'INSUFFICIENT_STOCK',
  'EXPIRED_BATCH',
  'PRESCRIPTION_REQUIRED',
  'APPROVAL_REQUIRED',
  'INVALID_STATE_TRANSITION',
  'IDEMPOTENCY_CONFLICT',
  'CONCURRENCY_CONFLICT',
  'NOT_FOUND',
  'SERVICE_UNAVAILABLE',
  'INTERNAL_ERROR',
] as const;

export type ErrorCode = (typeof ERROR_CODES)[number];

export const ERROR_MESSAGES: Record<ErrorCode, string> = {
  UNAUTHENTICATED: 'Sesi Anda sudah berakhir. Silakan masuk kembali.',
  FORBIDDEN: 'Anda tidak memiliki izin untuk tindakan ini.',
  VALIDATION_ERROR: 'Periksa kembali isian yang ditandai.',
  DUPLICATE: 'Data dengan nilai tersebut sudah ada.',
  ACCOUNT_LOCKED: 'Akun dikunci sementara karena terlalu banyak percobaan masuk. Coba lagi nanti.',
  ACCOUNT_INACTIVE: 'Akun tidak aktif. Hubungi pemilik apotek.',
  RATE_LIMITED: 'Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.',
  INSUFFICIENT_STOCK: 'Stok layak jual tidak mencukupi.',
  EXPIRED_BATCH: 'Stok yang tersisa sudah kedaluwarsa dan tidak boleh dijual.',
  PRESCRIPTION_REQUIRED: 'Obat ini memerlukan resep yang sudah diverifikasi apoteker.',
  APPROVAL_REQUIRED: 'Tindakan ini memerlukan persetujuan supervisor.',
  INVALID_STATE_TRANSITION: 'Dokumen tidak dapat diproses pada status saat ini.',
  IDEMPOTENCY_CONFLICT: 'Permintaan ganda terdeteksi dengan isi berbeda.',
  CONCURRENCY_CONFLICT: 'Data telah diubah pengguna lain. Muat ulang halaman.',
  NOT_FOUND: 'Data tidak ditemukan.',
  SERVICE_UNAVAILABLE: 'Server tidak dapat dihubungi. Transaksi BELUM tersimpan.',
  INTERNAL_ERROR: 'Terjadi kesalahan sistem. Transaksi BELUM tersimpan.',
};

export class AppError extends Error {
  readonly code: ErrorCode;
  readonly fields?: Record<string, string>;

  constructor(code: ErrorCode, message?: string, fields?: Record<string, string>) {
    super(message ?? ERROR_MESSAGES[code]);
    this.name = 'AppError';
    this.code = code;
    this.fields = fields;
  }
}

export type Result<T> =
  | { ok: true; data: T }
  | { ok: false; code: ErrorCode; message: string; fields?: Record<string, string> };

export function ok<T>(data: T): Result<T> {
  return { ok: true, data };
}

/** Ubah error apa pun menjadi Result aman untuk dikirim ke browser. */
export function toFailure(error: unknown): Extract<Result<never>, { ok: false }> {
  if (error instanceof AppError) {
    return { ok: false, code: error.code, message: error.message, fields: error.fields };
  }
  return { ok: false, code: 'INTERNAL_ERROR', message: ERROR_MESSAGES.INTERNAL_ERROR };
}
