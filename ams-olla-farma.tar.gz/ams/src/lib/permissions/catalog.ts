/**
 * Katalog izin dan peran bawaan AMS.
 *
 * Sumber kebenaran tunggal untuk: seed database, pemeriksaan izin di server,
 * dan menu sidebar. Matriks mengikuti "Matriks peran dan izin" di dokumen Fase 1.
 * Kode izin tidak boleh diganti setelah dipakai di produksi; tambahkan kode baru.
 */

export const PERMISSIONS = [
  // Dashboard
  { code: 'dashboard.operational.view', module: 'dashboard', description: 'Lihat dashboard operasional (penjualan hari ini, stok menipis, ED)' },
  { code: 'dashboard.finance.view', module: 'dashboard', description: 'Lihat dashboard keuangan (laba, utang, nilai persediaan)' },

  // Master obat
  { code: 'medicines.view', module: 'medicines', description: 'Lihat data obat' },
  { code: 'medicines.view_cost', module: 'medicines', description: 'Lihat harga pokok obat' },
  { code: 'medicines.manage', module: 'medicines', description: 'Tambah dan ubah data obat (tanpa harga)' },
  { code: 'medicines.price.manage', module: 'medicines', description: 'Ubah harga jual' },
  { code: 'medicines.regulatory.manage', module: 'medicines', description: 'Ubah golongan regulasi obat (narkotika, psikotropika, prekursor, OOT)' },

  // Pemasok
  { code: 'suppliers.view', module: 'suppliers', description: 'Lihat data pemasok' },
  { code: 'suppliers.manage', module: 'suppliers', description: 'Tambah dan ubah data pemasok' },

  // Pengadaan
  { code: 'procurement.po.create', module: 'procurement', description: 'Buat draf Surat Pesanan reguler' },
  { code: 'procurement.po.approve', module: 'procurement', description: 'Setujui dan kirim Surat Pesanan reguler' },
  { code: 'procurement.po_special.sign', module: 'procurement', description: 'Buat dan tanda tangani SP khusus narkotika/psikotropika/prekursor/OOT' },
  { code: 'procurement.receive.record', module: 'procurement', description: 'Periksa dan catat barang datang' },
  { code: 'procurement.receive.post', module: 'procurement', description: 'Posting penerimaan barang ke stok' },
  { code: 'procurement.invoice.manage', module: 'procurement', description: 'Kelola faktur pembelian' },
  { code: 'procurement.return.create', module: 'procurement', description: 'Buat retur ke pemasok' },
  { code: 'procurement.return.approve', module: 'procurement', description: 'Setujui retur ke pemasok' },
  { code: 'procurement.view', module: 'procurement', description: 'Lihat dokumen pengadaan' },

  // Persediaan
  { code: 'inventory.view', module: 'inventory', description: 'Lihat stok, kartu stok, dan riwayat movement' },
  { code: 'inventory.adjust.create', module: 'inventory', description: 'Buat penyesuaian stok' },
  { code: 'inventory.adjust.approve', module: 'inventory', description: 'Setujui penyesuaian stok' },
  { code: 'inventory.opname.count', module: 'inventory', description: 'Hitung stock opname' },
  { code: 'inventory.opname.post', module: 'inventory', description: 'Setujui dan posting selisih stock opname' },
  { code: 'inventory.quarantine.create', module: 'inventory', description: 'Buat dokumen karantina, rusak, recall, pemusnahan' },
  { code: 'inventory.quarantine.approve', module: 'inventory', description: 'Setujui karantina, rusak, recall, pemusnahan' },

  // POS dan penjualan
  { code: 'pos.access', module: 'sales', description: 'Akses layar kasir, buka/tutup shift' },
  { code: 'sales.create', module: 'sales', description: 'Buat transaksi penjualan' },
  { code: 'sales.sell_rx', module: 'sales', description: 'Jual obat resep yang sudah ditautkan ke resep terverifikasi' },
  { code: 'sales.view_own', module: 'sales', description: 'Lihat riwayat transaksi sendiri' },
  { code: 'sales.view_all', module: 'sales', description: 'Lihat semua riwayat transaksi' },
  { code: 'sales.discount.approve', module: 'sales', description: 'Setujui diskon di atas batas kasir' },
  { code: 'sales.cancel.request', module: 'sales', description: 'Minta pembatalan transaksi' },
  { code: 'sales.cancel.approve', module: 'sales', description: 'Setujui pembatalan transaksi' },
  { code: 'sales.return.receive', module: 'sales', description: 'Terima barang retur penjualan' },
  { code: 'sales.return.inspect', module: 'sales', description: 'Inspeksi dan tentukan disposisi retur penjualan' },
  { code: 'sales.owa.dispense', module: 'sales', description: 'Serahkan Obat Wajib Apotek tanpa resep' },
  { code: 'pricing.discount_rules.manage', module: 'sales', description: 'Buat dan ubah diskon periode (keputusan manajemen)' },

  // Resep
  { code: 'rx.view', module: 'prescriptions', description: 'Lihat resep' },
  { code: 'rx.create', module: 'prescriptions', description: 'Input resep' },
  { code: 'rx.verify', module: 'prescriptions', description: 'Verifikasi (kaji) resep' },
  { code: 'rx.dispense', module: 'prescriptions', description: 'Serahkan obat resep' },
  { code: 'rx.narcotic.manage', module: 'prescriptions', description: 'Kelola resep dan register narkotika/psikotropika' },
  { code: 'rx.narcotic.view', module: 'prescriptions', description: 'Lihat register narkotika/psikotropika' },

  // Pelanggan / pasien
  { code: 'customers.view_basic', module: 'customers', description: 'Lihat nama dan telepon pelanggan' },
  { code: 'customers.view_health', module: 'customers', description: 'Lihat catatan pengobatan pasien (tercatat di audit)' },
  { code: 'customers.manage', module: 'customers', description: 'Tambah dan ubah data pelanggan/pasien' },

  // Keuangan
  { code: 'finance.expense.record_shift', module: 'finance', description: 'Catat biaya kas kecil pada shift sendiri' },
  { code: 'finance.view', module: 'finance', description: 'Lihat data keuangan' },
  { code: 'finance.manage', module: 'finance', description: 'Kelola biaya, jurnal, akun' },
  { code: 'finance.payable.pay', module: 'finance', description: 'Bayar utang pemasok' },
  { code: 'finance.receivable.view', module: 'finance', description: 'Lihat daftar piutang pelanggan' },
  { code: 'finance.receivable.manage', module: 'finance', description: 'Catat pembayaran dan hapus piutang pelanggan' },

  // Laporan
  { code: 'reports.operational.view', module: 'reports', description: 'Lihat laporan operasional' },
  { code: 'reports.inventory.view', module: 'reports', description: 'Lihat laporan stok' },
  { code: 'reports.finance.view', module: 'reports', description: 'Lihat laporan keuangan' },
  { code: 'reports.employee.view', module: 'reports', description: 'Lihat laporan kinerja karyawan' },

  // Administrasi
  { code: 'users.manage', module: 'users', description: 'Kelola pengguna dan peran' },
  { code: 'employees.view', module: 'users', description: 'Lihat data karyawan dan izin praktik' },
  { code: 'settings.manage', module: 'settings', description: 'Kelola pengaturan sistem' },
  { code: 'settings.regulatory.manage', module: 'settings', description: 'Kelola aturan regulasi' },
  { code: 'audit.view', module: 'audit', description: 'Lihat seluruh audit log' },
  { code: 'audit.view_pharmacy', module: 'audit', description: 'Lihat audit log modul kefarmasian' },
] as const;

export type PermissionCode = (typeof PERMISSIONS)[number]['code'];

export type RoleCode = 'OWNER' | 'APOTEKER' | 'TTK' | 'KASIR' | 'GUDANG';

export interface RoleDefinition {
  code: RoleCode;
  name: string;
  permissions: readonly PermissionCode[];
}

const ALL = PERMISSIONS.map((p) => p.code);

/**
 * Owner memegang semua izin kecuali yang menuntut kewenangan profesi apoteker
 * (verifikasi/penyerahan resep, SP khusus, register narkotika, penyerahan OWA).
 */
const PHARMACIST_ONLY: readonly PermissionCode[] = [
  'procurement.po_special.sign',
  'rx.verify',
  'rx.dispense',
  'rx.narcotic.manage',
  'sales.owa.dispense', // tenaga kefarmasian (Apoteker/TTK), bukan pemilik non-farmasi
];

export const ROLES: readonly RoleDefinition[] = [
  {
    code: 'OWNER',
    name: 'Pemilik / Super Admin',
    permissions: ALL.filter((c) => !PHARMACIST_ONLY.includes(c)),
  },
  {
    code: 'APOTEKER',
    name: 'Apoteker',
    permissions: [
      'dashboard.operational.view', 'dashboard.finance.view',
      'medicines.view', 'medicines.view_cost', 'medicines.manage', 'medicines.price.manage', 'medicines.regulatory.manage',
      'suppliers.view', 'suppliers.manage',
      'procurement.view', 'procurement.po.create', 'procurement.po.approve', 'procurement.po_special.sign',
      'procurement.receive.record', 'procurement.receive.post', 'procurement.return.create', 'procurement.return.approve',
      'inventory.view', 'inventory.adjust.create', 'inventory.adjust.approve', 'inventory.opname.count', 'inventory.opname.post',
      'inventory.quarantine.create', 'inventory.quarantine.approve',
      'pos.access', 'sales.create', 'sales.sell_rx', 'sales.view_own', 'sales.view_all',
      'sales.discount.approve', 'sales.cancel.request', 'sales.cancel.approve',
      'sales.return.receive', 'sales.return.inspect', 'sales.owa.dispense', 'pricing.discount_rules.manage',
      'rx.view', 'rx.create', 'rx.verify', 'rx.dispense', 'rx.narcotic.manage', 'rx.narcotic.view',
      'customers.view_basic', 'customers.view_health', 'customers.manage',
      'finance.view', 'finance.payable.pay', 'finance.receivable.view', 'finance.receivable.manage',
      'reports.operational.view', 'reports.inventory.view',
      'employees.view',
      'settings.regulatory.manage',
      'audit.view_pharmacy',
    ],
  },
  {
    code: 'TTK',
    name: 'Tenaga Teknis Kefarmasian',
    permissions: [
      'dashboard.operational.view',
      'medicines.view', 'medicines.manage',
      'suppliers.view',
      'procurement.view', 'procurement.po.create', 'procurement.receive.record', 'procurement.return.create',
      'inventory.view', 'inventory.adjust.create', 'inventory.opname.count', 'inventory.quarantine.create',
      'pos.access', 'sales.create', 'sales.sell_rx', 'sales.view_own', 'sales.view_all',
      'sales.cancel.request', 'sales.return.receive',
      // Keputusan Owner 12 Nov 2026: TTK boleh menyerahkan OWA. Lihat aturan
      // regulasi OWA_HANDOVER (Kepmenkes 347/1990 menyebut Apoteker).
      'sales.owa.dispense',
      'rx.view', 'rx.create', 'rx.narcotic.view',
      'customers.view_basic', 'customers.view_health', 'customers.manage',
      'reports.inventory.view',
    ],
  },
  {
    code: 'KASIR',
    name: 'Kasir / Administrasi',
    permissions: [
      'dashboard.operational.view',
      'medicines.view',
      'pos.access', 'sales.create', 'sales.sell_rx', 'sales.view_own',
      'sales.cancel.request', 'sales.return.receive',
      'customers.view_basic',
      'rx.create', 'rx.view',
      'finance.expense.record_shift',
    ],
  },
  {
    code: 'GUDANG',
    name: 'Staf Gudang',
    permissions: [
      'dashboard.operational.view',
      'medicines.view',
      'suppliers.view',
      'procurement.view', 'procurement.po.create', 'procurement.receive.record', 'procurement.return.create',
      'inventory.view', 'inventory.adjust.create', 'inventory.opname.count', 'inventory.quarantine.create',
      'reports.inventory.view',
    ],
  },
];

export const PERMISSION_CODES: ReadonlySet<string> = new Set(ALL);

export function isPermissionCode(value: string): value is PermissionCode {
  return PERMISSION_CODES.has(value);
}
