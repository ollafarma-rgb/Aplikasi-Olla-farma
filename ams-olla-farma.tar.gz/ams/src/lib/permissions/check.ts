import { AppError } from '../errors';
import { ROLES, type PermissionCode, type RoleCode } from './catalog';

/** Kumpulan izin efektif pengguna (gabungan semua perannya). */
export type PermissionSet = ReadonlySet<PermissionCode>;

export function permissionsForRoles(roleCodes: readonly RoleCode[]): PermissionSet {
  const set = new Set<PermissionCode>();
  for (const code of roleCodes) {
    const role = ROLES.find((r) => r.code === code);
    if (!role) continue;
    for (const p of role.permissions) set.add(p);
  }
  return set;
}

export function hasPermission(perms: PermissionSet, code: PermissionCode): boolean {
  return perms.has(code);
}

export function hasAnyPermission(perms: PermissionSet, codes: readonly PermissionCode[]): boolean {
  return codes.some((c) => perms.has(c));
}

/** Lempar FORBIDDEN bila izin tidak dimiliki. Dipanggil di service, bukan hanya di UI. */
export function assertPermission(perms: PermissionSet, code: PermissionCode): void {
  if (!perms.has(code)) {
    throw new AppError('FORBIDDEN');
  }
}

/**
 * Persetujuan selalu oleh orang lain dan yang memegang izin approver.
 * Mengembalikan pesan alasan penolakan, atau null bila sah.
 */
export function approvalViolation(params: {
  requesterId: string;
  approverId: string;
  approverPerms: PermissionSet;
  requiredPermission: PermissionCode;
}): string | null {
  if (params.requesterId === params.approverId) {
    return 'Persetujuan harus diberikan oleh pengguna lain.';
  }
  if (!params.approverPerms.has(params.requiredPermission)) {
    return 'Penyetuju tidak memiliki izin untuk menyetujui tindakan ini.';
  }
  return null;
}
