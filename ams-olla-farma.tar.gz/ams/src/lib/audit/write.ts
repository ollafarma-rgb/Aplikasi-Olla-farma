import type { DbTransaction } from '../database/client';
import { redactSecrets, type AuditEntry } from './types';

/** Tulis audit di transaksi yang sama dengan perubahan datanya. */
export async function writeAudit(tx: DbTransaction, entry: AuditEntry): Promise<void> {
  await tx.auditLog.create({
    data: {
      user_id: entry.user_id,
      action: entry.action,
      entity: entry.entity,
      entity_id: entry.entity_id ?? null,
      before_json: (redactSecrets(entry.before) ?? undefined) as object | undefined,
      after_json: (redactSecrets(entry.after) ?? undefined) as object | undefined,
      ip: entry.ip ?? null,
      user_agent: entry.user_agent?.slice(0, 300) ?? null,
    },
  });
}

/** Field yang berubah antara dua objek datar (untuk before/after audit). */
export function diffFields(
  before: Record<string, unknown>,
  after: Record<string, unknown>,
): { before: Record<string, unknown>; after: Record<string, unknown> } | null {
  const b: Record<string, unknown> = {};
  const a: Record<string, unknown> = {};
  for (const key of Object.keys(after)) {
    const x = normalize(before[key]);
    const y = normalize(after[key]);
    if (x !== y) {
      b[key] = before[key] ?? null;
      a[key] = after[key] ?? null;
    }
  }
  return Object.keys(a).length ? { before: b, after: a } : null;
}

function normalize(v: unknown): string {
  if (v === undefined || v === null || v === '') return '';
  if (v instanceof Date) return v.toISOString();
  return String(v);
}
