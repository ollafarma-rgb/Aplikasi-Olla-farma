/**
 * Entri audit. prev_hash/hash diisi trigger database (lihat migrasi 001),
 * sehingga aplikasi tidak bisa memalsukan rantai.
 */
export interface AuditEntry {
  user_id: string | null;
  action: AuditAction;
  entity: string;
  entity_id?: string | null;
  before?: Record<string, unknown> | null;
  after?: Record<string, unknown> | null;
  ip?: string | null;
  user_agent?: string | null;
}

export const AUDIT_ACTIONS = [
  'auth.login.success',
  'auth.login.failed',
  'auth.login.locked',
  'auth.logout',
  'auth.password.changed',
  'auth.sessions.revoked',
  'user.created',
  'user.updated',
  'user.deactivated',
  'user.roles.changed',
  'role.permissions.changed',
  'settings.changed',
  'regulatory_rule.changed',
  'user.activated',
  'user.password.reset',
  'user.unlocked',
  'user.license.added',
  'user.license.removed',
  'medicine.created',
  'medicine.updated',
  'medicine.activated',
  'medicine.deactivated',
  'medicine.conversion.saved',
  'medicine.conversion.removed',
  'supplier.created',
  'supplier.updated',
  'reference.created',
  'reference.updated',
  'reference.deleted',
  'inventory.opening_balance',
  'inventory.bucket_move',
  'inventory.adjustment_created',
  'inventory.adjustment_posted',
  'inventory.adjustment_cancelled',
  'inventory.opname_started',
  'inventory.opname_posted',
  'inventory.opname_cancelled',
  'procurement.po_created',
  'procurement.po_sent',
  'procurement.po_cancelled',
  'procurement.gr_created',
  'procurement.gr_posted',
  'procurement.gr_cancelled',
  'procurement.return_created',
  'procurement.return_posted',
  'procurement.return_cancelled',
  'sales.customer_created',
  'sales.customer_updated',
  'sales.session_opened',
  'sales.session_closed',
  'sales.sale_created',
  'sales.sale_cancelled',
  'rx.created',
  'rx.verified',
  'sales.return_drafted',
  'sales.return_posted',
  'finance.invoice_created',
  'finance.payment_recorded',
  // Fase 7 — Diskon Periode & Piutang
  'discount.rule_approved',
  'discount.rule_rejected',
  'discount.rule_cancelled',
  'receivable.created',
  'receivable.payment_recorded',
  'receivable.written_off',
  'settings.profile_updated',
  'settings.receipt_updated',
] as const;

export type AuditAction = (typeof AUDIT_ACTIONS)[number];

/** Field yang tidak boleh pernah masuk audit log. */
const SECRET_KEYS = new Set(['password', 'password_hash', 'supervisor_pin_hash', 'token', 'session_token']);

export function redactSecrets(value: Record<string, unknown> | null | undefined): Record<string, unknown> | null {
  if (!value) return null;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value)) {
    out[k] = SECRET_KEYS.has(k) ? '[DISEMBUNYIKAN]' : v;
  }
  return out;
}
