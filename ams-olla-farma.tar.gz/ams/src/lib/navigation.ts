import type { PermissionCode } from './permissions/catalog';
import type { PermissionSet } from './permissions/check';

/**
 * Menu sidebar. `availableFromPhase` mencegah menu modul yang belum dibangun
 * tampil sebagai tombol yang tidak berfungsi. Naikkan CURRENT_PHASE saat
 * sebuah fase selesai dan lulus uji.
 */
export const CURRENT_PHASE = 9;

export interface NavItem {
  href: string;
  label: string;
  /** Tampil bila pengguna memegang SALAH SATU izin ini. Kosong = semua pengguna login. */
  anyOf: readonly PermissionCode[];
  availableFromPhase: number;
  group: 'utama' | 'farmasi' | 'transaksi' | 'keuangan' | 'admin';
}

export const NAV_ITEMS: readonly NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', anyOf: [], availableFromPhase: 2, group: 'utama' },
  { href: '/obat', label: 'Data Obat', anyOf: ['medicines.view'], availableFromPhase: 3, group: 'farmasi' },
  { href: '/pemasok', label: 'Pemasok', anyOf: ['suppliers.view'], availableFromPhase: 3, group: 'farmasi' },
  { href: '/persediaan', label: 'Persediaan', anyOf: ['inventory.view'], availableFromPhase: 4, group: 'farmasi' },
  { href: '/penyesuaian', label: 'Penyesuaian Stok', anyOf: ['inventory.adjust.create', 'inventory.view'], availableFromPhase: 4, group: 'farmasi' },
  { href: '/opname', label: 'Stok Opname', anyOf: ['inventory.opname.count', 'inventory.view'], availableFromPhase: 4, group: 'farmasi' },
  { href: '/pengadaan', label: 'Pengadaan', anyOf: ['procurement.view'], availableFromPhase: 5, group: 'transaksi' },
  { href: '/kasir', label: 'Kasir (POS)', anyOf: ['pos.access'], availableFromPhase: 6, group: 'transaksi' },
  { href: '/penjualan', label: 'Riwayat Penjualan', anyOf: ['sales.view_own', 'sales.view_all'], availableFromPhase: 6, group: 'transaksi' },
  { href: '/resep', label: 'Resep', anyOf: ['rx.view'], availableFromPhase: 7, group: 'farmasi' },
  { href: '/pelanggan', label: 'Pelanggan', anyOf: ['customers.view_basic'], availableFromPhase: 7, group: 'farmasi' },
  { href: '/keuangan', label: 'Keuangan', anyOf: ['finance.view'], availableFromPhase: 8, group: 'keuangan' },
  { href: '/laporan', label: 'Laporan', anyOf: ['reports.operational.view', 'reports.inventory.view', 'reports.finance.view'], availableFromPhase: 8, group: 'keuangan' },
  { href: '/obat/referensi', label: 'Referensi Obat', anyOf: ['medicines.manage', 'settings.manage'], availableFromPhase: 3, group: 'farmasi' },
  { href: '/karyawan', label: 'Karyawan & Pengguna', anyOf: ['users.manage', 'employees.view'], availableFromPhase: 3, group: 'admin' },
  { href: '/pengaturan', label: 'Pengaturan', anyOf: ['settings.manage', 'settings.regulatory.manage'], availableFromPhase: 9, group: 'admin' },
];

export function visibleNavItems(perms: PermissionSet, phase = CURRENT_PHASE): NavItem[] {
  return NAV_ITEMS.filter(
    (item) => item.availableFromPhase <= phase && (item.anyOf.length === 0 || item.anyOf.some((p) => perms.has(p))),
  );
}
