import 'server-only';
import { cache } from 'react';
import { cookies, headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { authService, type AuthenticatedSession, type RequestContext } from '@/modules/authentication';
import { AppError } from '../errors';
import type { PermissionCode } from '../permissions/catalog';
import { permissionsForRoles, type PermissionSet } from '../permissions/check';
import { clientIpFromForwarded } from './client-ip';
import { sessionCookieName, sessionCookieOptions } from './session-token';

export const COOKIE_SECURE = process.env.NODE_ENV === 'production';
export const COOKIE_NAME = sessionCookieName(COOKIE_SECURE);

/** Jumlah proxy tepercaya di depan aplikasi (diset sesuai hosting di Fase 11). */
const TRUSTED_PROXY_HOPS = Number(process.env.TRUSTED_PROXY_HOPS ?? '1');

export async function getRequestContext(): Promise<RequestContext> {
  const h = await headers();
  return {
    ip: clientIpFromForwarded(h.get('x-forwarded-for'), TRUSTED_PROXY_HOPS),
    userAgent: h.get('user-agent'),
    now: new Date(),
  };
}

export interface CurrentUser extends AuthenticatedSession {
  permissions: PermissionSet;
}

/** Sesi untuk request ini (di-cache per request). null bila belum login. */
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  const session = await authService.validateSession(token, new Date());
  if (!session) return null;
  return { ...session, permissions: permissionsForRoles(session.user.roles) };
});

/** Untuk halaman: alihkan ke login bila belum masuk. */
export async function requireUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect('/login');
  return user;
}

/** Untuk halaman: alihkan ke halaman "tidak diizinkan" bila izin kurang. */
export async function requirePagePermission(code: PermissionCode): Promise<CurrentUser> {
  const user = await requireUser();
  if (!user.permissions.has(code)) redirect('/tidak-diizinkan');
  return user;
}

/** Untuk Server Action dan Route Handler: lempar AppError, jangan redirect. */
export async function requireActionPermission(code?: PermissionCode): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) throw new AppError('UNAUTHENTICATED');
  if (code) {
    // Pengguna yang wajib ganti sandi hanya boleh mengganti sandi.
    if (user.user.must_change_password) throw new AppError('FORBIDDEN', 'Ganti kata sandi Anda terlebih dahulu.');
    if (!user.permissions.has(code)) throw new AppError('FORBIDDEN');
  }
  return user;
}

export async function setSessionCookie(token: string, expiresAt: Date): Promise<void> {
  const store = await cookies();
  store.set(COOKIE_NAME, token, sessionCookieOptions(expiresAt, COOKIE_SECURE));
}

/**
 * Hapus cookie dengan atribut yang sama seperti saat dibuat: browser menolak
 * Set-Cookie untuk nama __Host- tanpa Secure dan Path=/.
 */
export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.set(COOKIE_NAME, '', { ...sessionCookieOptions(new Date(0), COOKIE_SECURE), maxAge: 0 });
}

/** Pelaku untuk service: identitas, izin, IP, user-agent. */
export async function requireActor(code?: PermissionCode): Promise<import('./actor').Actor> {
  const user = await requireActionPermission(code);
  const ctx = await getRequestContext();
  return { id: user.user.id, permissions: user.permissions, ip: ctx.ip, userAgent: ctx.userAgent };
}

/** Untuk halaman (Server Component): pelaku dengan izin wajib; alihkan bila kurang. */
export async function requirePageActor(code: PermissionCode): Promise<import('./actor').Actor> {
  const user = await requirePagePermission(code);
  const ctx = await getRequestContext();
  return { id: user.user.id, permissions: user.permissions, ip: ctx.ip, userAgent: ctx.userAgent };
}
