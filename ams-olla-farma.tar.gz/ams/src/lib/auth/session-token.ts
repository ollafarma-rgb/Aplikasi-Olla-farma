import { createHash, randomBytes } from 'node:crypto';

/**
 * Token sesi: 32 byte acak (256 bit) dikirim ke browser sebagai cookie.
 * Database hanya menyimpan SHA-256 dari token, sehingga kebocoran database
 * tidak memberi akses ke sesi aktif.
 */

/**
 * Produksi: prefiks __Host- (wajib Secure, Path=/, tanpa Domain).
 * Development lokal lewat http://localhost: nama biasa tanpa Secure, karena
 * sebagian browser menolak cookie Secure pada http.
 */
export const SESSION_COOKIE_NAME = '__Host-ams_session';
export const DEV_SESSION_COOKIE_NAME = 'ams_session';

export function sessionCookieName(secure: boolean): string {
  return secure ? SESSION_COOKIE_NAME : DEV_SESSION_COOKIE_NAME;
}

/** Batas sesi: satu shift (8 jam) + cadangan. */
export const SESSION_ABSOLUTE_MS = 12 * 60 * 60 * 1000;
/** Keluar otomatis bila tidak ada aktivitas. */
export const SESSION_IDLE_MS = 30 * 60 * 1000;
/** last_seen_at diperbarui paling sering tiap 60 detik agar DB tidak dibanjiri tulis. */
export const SESSION_TOUCH_INTERVAL_MS = 60 * 1000;

export function generateSessionToken(): string {
  return randomBytes(32).toString('base64url');
}

export function hashSessionToken(token: string): string {
  return createHash('sha256').update(token, 'utf8').digest('hex');
}

/** Token valid hanya bila berbentuk base64url 43 karakter (32 byte). */
export function isWellFormedToken(token: string | undefined | null): token is string {
  return typeof token === 'string' && /^[A-Za-z0-9_-]{43}$/.test(token);
}

export interface SessionRecord {
  id: string;
  user_id: string;
  session_version: number;
  created_at: Date;
  last_seen_at: Date;
  expires_at: Date;
  revoked_at: Date | null;
}

export interface SessionUserState {
  is_active: boolean;
  session_version: number;
  locked_until: Date | null;
}

export type SessionCheck =
  | { valid: true; shouldTouch: boolean }
  | { valid: false; reason: 'revoked' | 'expired' | 'idle' | 'version' | 'inactive' };

/**
 * Aturan murni validitas sesi. Logout paksa bekerja dengan menaikkan
 * users.session_version: semua sesi berversi lama otomatis tidak sah.
 */
export function checkSession(session: SessionRecord, user: SessionUserState, now: Date): SessionCheck {
  if (session.revoked_at) return { valid: false, reason: 'revoked' };
  if (!user.is_active) return { valid: false, reason: 'inactive' };
  if (session.session_version !== user.session_version) return { valid: false, reason: 'version' };
  if (now.getTime() >= session.expires_at.getTime()) return { valid: false, reason: 'expired' };
  if (now.getTime() - session.last_seen_at.getTime() >= SESSION_IDLE_MS) return { valid: false, reason: 'idle' };
  const shouldTouch = now.getTime() - session.last_seen_at.getTime() >= SESSION_TOUCH_INTERVAL_MS;
  return { valid: true, shouldTouch };
}

/** Opsi cookie: HttpOnly, SameSite=Lax, Path=/, Secure di produksi. */
export function sessionCookieOptions(expiresAt: Date, secure: boolean) {
  return {
    httpOnly: true,
    secure,
    sameSite: 'lax' as const,
    path: '/',
    expires: expiresAt,
  };
}
