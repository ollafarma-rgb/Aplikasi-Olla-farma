/**
 * Kebijakan kunci akun: 5 kali gagal berturut-turut -> akun dikunci 15 menit.
 * Login berhasil mengembalikan hitungan ke nol.
 */

export const MAX_FAILED_ATTEMPTS = 5;
export const LOCK_DURATION_MS = 15 * 60 * 1000;

export interface LockoutState {
  failed_login_count: number;
  locked_until: Date | null;
}

export function isLocked(state: LockoutState, now: Date): boolean {
  return state.locked_until !== null && state.locked_until.getTime() > now.getTime();
}

/** Status baru setelah percobaan login gagal. */
export function afterFailedAttempt(state: LockoutState, now: Date): LockoutState {
  // Kunci yang sudah lewat waktunya dianggap reset.
  const base = state.locked_until && state.locked_until.getTime() <= now.getTime()
    ? 0
    : state.failed_login_count;
  const count = base + 1;
  if (count >= MAX_FAILED_ATTEMPTS) {
    return { failed_login_count: count, locked_until: new Date(now.getTime() + LOCK_DURATION_MS) };
  }
  return { failed_login_count: count, locked_until: null };
}

export function afterSuccessfulLogin(): LockoutState {
  return { failed_login_count: 0, locked_until: null };
}

/** Batas laju login per IP+username (di samping kunci akun). */
export const LOGIN_RATE_LIMIT = { windowSeconds: 60, max: 5 } as const;
/** Batas laju API umum per pengguna. */
export const API_RATE_LIMIT = { windowSeconds: 60, max: 120 } as const;
