import type { PermissionCode } from '../permissions/catalog';
import type { PermissionSet } from '../permissions/check';
import { AppError } from '../errors';

/** Pelaku sebuah perintah: siapa, izin apa, dari mana. Dioper ke setiap service. */
export interface Actor {
  id: string;
  permissions: PermissionSet;
  ip: string | null;
  userAgent: string | null;
}

export function can(actor: Actor, code: PermissionCode): boolean {
  return actor.permissions.has(code);
}

export function assertCan(actor: Actor, code: PermissionCode, message?: string): void {
  if (!actor.permissions.has(code)) throw new AppError('FORBIDDEN', message);
}

export function auditMeta(actor: Actor) {
  return { user_id: actor.id, ip: actor.ip, user_agent: actor.userAgent };
}
