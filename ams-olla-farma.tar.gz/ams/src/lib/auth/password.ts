import { randomBytes, scrypt as scryptCb, timingSafeEqual, type ScryptOptions } from 'node:crypto';

/**
 * Hash sandi dengan scrypt bawaan Node.js (tanpa dependensi native).
 * Parameter mengikuti salah satu konfigurasi minimum OWASP Password Storage
 * Cheat Sheet: N=2^15, r=8, p=3 (~32 MiB per hash).
 *
 * Format tersimpan: scrypt$<logN>$<r>$<p>$<salt b64url>$<hash b64url>
 * Parameter ikut disimpan sehingga bisa dinaikkan nanti; sandi lama tetap
 * terverifikasi dan di-hash ulang saat login berikutnya (needsRehash).
 */

export interface ScryptParams {
  logN: number;
  r: number;
  p: number;
}

export const CURRENT_PARAMS: ScryptParams = { logN: 15, r: 8, p: 3 };
const KEY_LENGTH = 64;
const SALT_BYTES = 16;

export const PASSWORD_MIN_LENGTH = 10;
export const PASSWORD_MAX_LENGTH = 128;

function scrypt(password: string, salt: Buffer, params: ScryptParams): Promise<Buffer> {
  const N = 2 ** params.logN;
  const options: ScryptOptions = {
    N,
    r: params.r,
    p: params.p,
    // memori yang dibutuhkan ~ 128 * N * r byte; beri ruang dua kali lipat
    maxmem: 256 * N * params.r,
  };
  return new Promise((resolve, reject) => {
    scryptCb(password.normalize('NFKC'), salt, KEY_LENGTH, options, (err, key) => {
      if (err) reject(err);
      else resolve(key);
    });
  });
}

export async function hashPassword(password: string, params: ScryptParams = CURRENT_PARAMS): Promise<string> {
  const salt = randomBytes(SALT_BYTES);
  const key = await scrypt(password, salt, params);
  return ['scrypt', params.logN, params.r, params.p, salt.toString('base64url'), key.toString('base64url')].join('$');
}

interface ParsedHash {
  params: ScryptParams;
  salt: Buffer;
  key: Buffer;
}

function parseHash(stored: string): ParsedHash | null {
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return null;
  const [, logN, r, p, salt, key] = parts;
  const params = { logN: Number(logN), r: Number(r), p: Number(p) };
  if (![params.logN, params.r, params.p].every((n) => Number.isInteger(n) && n > 0)) return null;
  if (params.logN > 20) return null; // tolak parameter tak wajar (DoS)
  return { params, salt: Buffer.from(salt, 'base64url'), key: Buffer.from(key, 'base64url') };
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parsed = parseHash(stored);
  if (!parsed) return false;
  const candidate = await scrypt(password, parsed.salt, parsed.params);
  return candidate.length === parsed.key.length && timingSafeEqual(candidate, parsed.key);
}

export function needsRehash(stored: string): boolean {
  const parsed = parseHash(stored);
  if (!parsed) return true;
  const { logN, r, p } = parsed.params;
  return logN < CURRENT_PARAMS.logN || r < CURRENT_PARAMS.r || p < CURRENT_PARAMS.p;
}

/**
 * Hash palsu dengan parameter yang sama, dipakai saat username tidak ada agar
 * waktu respons sama dan username tidak bisa ditebak dari lamanya proses.
 */
let dummyHash: Promise<string> | null = null;
export function getDummyHash(): Promise<string> {
  dummyHash ??= hashPassword(randomBytes(24).toString('base64url'));
  return dummyHash;
}

/** Sandi umum yang ditolak walau panjangnya cukup. Daftar diperluas di Fase 10. */
const COMMON_PASSWORDS = new Set([
  '1234567890', '12345678910', 'qwertyuiop', 'password123', 'password1234',
  'passw0rd123', 'apotek12345', 'apotek123456', 'admin12345', 'admin123456',
  'iloveyou123', '0987654321', '1111111111', '1q2w3e4r5t', 'qwerty12345',
]);

/** Kembalikan pesan kesalahan Bahasa Indonesia, atau null bila sandi diterima. */
export function validatePasswordPolicy(password: string, context: { username?: string } = {}): string | null {
  if (password.length < PASSWORD_MIN_LENGTH) {
    return `Kata sandi minimal ${PASSWORD_MIN_LENGTH} karakter.`;
  }
  if (password.length > PASSWORD_MAX_LENGTH) {
    return `Kata sandi maksimal ${PASSWORD_MAX_LENGTH} karakter.`;
  }
  const lower = password.toLowerCase();
  if (COMMON_PASSWORDS.has(lower)) {
    return 'Kata sandi terlalu umum. Gunakan kombinasi lain.';
  }
  if (context.username && lower.includes(context.username.toLowerCase())) {
    return 'Kata sandi tidak boleh memuat nama pengguna.';
  }
  if (/^(.)\1+$/.test(password)) {
    return 'Kata sandi tidak boleh berupa satu karakter berulang.';
  }
  return null;
}
