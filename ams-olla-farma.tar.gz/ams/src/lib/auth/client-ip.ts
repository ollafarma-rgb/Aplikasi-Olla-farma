/**
 * Ambil IP klien dari X-Forwarded-For dengan aman.
 *
 * Load balancer MENAMBAHKAN IP di akhir header; nilai di depan bisa dikirim
 * penyerang sesuka hati. Karena itu IP diambil dari kanan, melewati sejumlah
 * proxy tepercaya (TRUSTED_PROXY_HOPS). Nilai pertama TIDAK pernah dipercaya,
 * kecuali memang hanya ada satu entri dan jumlah hop = 1.
 *
 * hops = jumlah proxy tepercaya di depan aplikasi yang menambahkan entri.
 * Contoh: klien -> load balancer -> aplikasi, LB menulis "spoof, klien" => hops 1
 * menghasilkan "klien".
 */
export function clientIpFromForwarded(header: string | null, trustedHops: number): string | null {
  if (!header || trustedHops < 1) return null;
  const entries = header.split(',').map((s) => s.trim()).filter(Boolean);
  if (entries.length < trustedHops) return null;
  const candidate = entries[entries.length - trustedHops];
  return isIp(candidate) ? candidate : null;
}

function isIp(value: string | undefined): value is string {
  if (!value || value.length > 45) return false;
  const v4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
  const v6 = /^[0-9a-fA-F:]+$/;
  return v4.test(value) || (value.includes(':') && v6.test(value));
}
