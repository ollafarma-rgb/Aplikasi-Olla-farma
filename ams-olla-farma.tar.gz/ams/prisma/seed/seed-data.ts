/**
 * Data seed produksi minimum (bukan data contoh). Data contoh untuk
 * pengembangan dipisah di prisma/seed/dev-sample.ts mulai Fase 3.
 */

export const PHARMACY_SETTINGS: Record<string, unknown> = {
  'pharmacy.profile': {
    name: 'Apotek OLLA FARMA',
    legal_entity: 'PT OLLA FARMA MANDIRI',
    nib: '0511260099194',
    kbli: '47721',
    address: 'Jl. Tgk. Daud Beureueh, Desa/Kel. Bandar Baru, Kec. Kuta Alam, Kota Banda Aceh, Provinsi Aceh, 24415',
    phone: '0823 1825 3080',
    email: 'ollafarma@gmail.com',
    operating_hours: '24 jam, 3 shift',
    sia_number: null,
    responsible_pharmacist: 'apt. Fathia Fikrina, S.Farm',
  },
  'locale': { timezone: 'Asia/Jakarta', currency: 'IDR', language: 'id-ID' },
  // Non-PKP (keputusan Owner 12 Nov 2026): tidak memungut PPN penjualan;
  // PPN pada faktur pembelian tidak dapat dikreditkan sehingga masuk ke harga pokok.
  'tax': { mode: 'NON_PKP', sales_vat_rate: null, purchase_vat_capitalized: true },
  // Keputusan #5 (12 Nov 2026): diskon dibuat per periode oleh manajemen
  // (Owner/Apoteker). Kasir hanya menerapkan diskon periode yang aktif;
  // diskon manual di luar aturan dimatikan.
  'pricing.discounts': { mode: 'PERIOD_RULES', manual_discount_allowed: false },
  // Keputusan #8: piutang disediakan untuk pelanggan/instansi yang diberi
  // plafon kredit. Plafon default 0 = tidak boleh tempo sampai diatur.
  'receivables': { enabled: true, default_credit_limit: '0', default_term_days: 30, approval_required: true },
  // Keputusan #9: printer thermal 80 mm (umum di POS apotek); template 58 mm tersedia.
  'receipt': { paper_width_mm: 80, alt_paper_width_mm: 58, show_pharmacist_name: true, footer: 'Semoga lekas sembuh' },
  // Keputusan #10: dokumen sistem disetujui Pemilik dan Apoteker.
  'governance': { document_approvers: ['OWNER', 'APOTEKER'] },
  'numbering': { sale: 'month', prescription: 'day', default: 'month', sequence_width: 6 },
  'security': { session_absolute_hours: 12, session_idle_minutes: 30, max_failed_logins: 5, lock_minutes: 15 },
};

export interface RegulatorySeed {
  code: string;
  description: string;
  rule: Record<string, unknown>;
  legal_basis: string;
  effective_from: string; // YYYY-MM-DD
}

const VERIFY = 'PERLU VERIFIKASI APJ terhadap teks pasal sebelum dipakai di produksi.';

export const REGULATORY_RULES: RegulatorySeed[] = [
  {
    code: 'RX_RETENTION',
    description: 'Masa simpan resep sebelum boleh dimusnahkan',
    rule: { years: 5 },
    legal_basis: `Permenkes 73/2016 (dirujuk SOP-OF-27 dan SOP-OF-29). ${VERIFY}`,
    effective_from: '2026-11-12',
  },
  {
    code: 'SPECIAL_PO_REQUIRED',
    description: 'Golongan yang wajib memakai Surat Pesanan khusus',
    rule: { drug_classes: ['NARKOTIKA', 'PSIKOTROPIKA'], flags: ['is_precursor', 'is_oot'] },
    legal_basis: `Permenkes 5/2023; SOP-OF-05. ${VERIFY}`,
    effective_from: '2026-11-12',
  },
  {
    code: 'NARCOTIC_COPY_RULE',
    description: 'Resep narkotika hanya dari resep asli atau salinan buatan apotek sendiri',
    rule: { accept_external_copy: false },
    legal_basis: `SOP-OF-20; Permenkes 5/2023. ${VERIFY}`,
    effective_from: '2026-11-12',
  },
  {
    code: 'NARCOTIC_REPORT_DEADLINE',
    description: 'Batas laporan bulanan narkotika/psikotropika melalui SIPNAP',
    rule: { day_of_next_month: 10 },
    legal_basis: `SOP-OF-13. ${VERIFY}`,
    effective_from: '2026-11-12',
  },
  {
    code: 'OWA_HANDOVER',
    description: 'Siapa yang boleh menyerahkan Obat Wajib Apotek tanpa resep',
    // Keputusan Owner 12 Nov 2026: Apoteker dan TTK. Setiap penyerahan wajib
    // mencatat pasien, obat, jumlah, dan petugas. Ubah ke ['APOTEKER'] untuk
    // mengikuti bunyi Kepmenkes 347/1990.
    rule: { handover_roles: ['APOTEKER', 'TTK'], record_patient_and_drug: true, per_patient_limit_configurable: true },
    legal_basis: `Kepmenkes 347/MENKES/SK/VII/1990 mendefinisikan OWA sebagai obat keras yang dapat diserahkan oleh Apoteker tanpa resep; penyerahan oleh TTK adalah keputusan manajemen 12 Nov 2026. ${VERIFY}`,
    effective_from: '2026-11-12',
  },
];

/** Satuan standar (kode huruf besar). Apotek bisa menambah lewat menu Referensi Obat. */
export const UNITS: { code: string; name: string }[] = [
  { code: 'TAB', name: 'Tablet' },
  { code: 'KAPLET', name: 'Kaplet' },
  { code: 'KAP', name: 'Kapsul' },
  { code: 'STRIP', name: 'Strip' },
  { code: 'BLISTER', name: 'Blister' },
  { code: 'BOX', name: 'Box' },
  { code: 'BTL', name: 'Botol' },
  { code: 'TUBE', name: 'Tube' },
  { code: 'SACHET', name: 'Sachet' },
  { code: 'AMP', name: 'Ampul' },
  { code: 'VIAL', name: 'Vial' },
  { code: 'POT', name: 'Pot' },
  { code: 'PCS', name: 'Pcs' },
  { code: 'PAK', name: 'Pak' },
  { code: 'ML', name: 'Mililiter' },
  { code: 'GR', name: 'Gram' },
];
