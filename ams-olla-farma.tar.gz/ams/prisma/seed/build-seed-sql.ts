/**
 * Membangun SQL seed dari katalog izin + data seed. Satu jalur yang sama
 * dipakai prisma/seed.ts (produksi) dan scripts/test-db.sh (pengujian),
 * sehingga yang diuji adalah persis yang di-seed.
 *
 * Idempoten: aman dijalankan ulang. Tidak pernah menghapus izin yang sudah
 * diubah Owner lewat UI (hanya menambah yang belum ada).
 * Semua nilai berasal dari konstanta internal, bukan input pengguna.
 */
import { PERMISSIONS, ROLES } from '../../src/lib/permissions/catalog';
import { PHARMACY_SETTINGS, REGULATORY_RULES, UNITS } from './seed-data';

export interface SeedOwner {
  username: string;
  fullName: string;
  passwordHash: string;
}

export function sqlLiteral(value: string | null): string {
  if (value === null) return 'NULL';
  if (value.includes('\u0000')) throw new Error('Karakter NUL tidak diizinkan dalam seed');
  return `'${value.replace(/'/g, "''")}'`;
}

function jsonLiteral(value: unknown): string {
  return `${sqlLiteral(JSON.stringify(value))}::jsonb`;
}

export function buildSeedSql(options: { owner?: SeedOwner } = {}): string {
  const out: string[] = ['BEGIN;'];

  for (const p of PERMISSIONS) {
    out.push(
      `INSERT INTO "permissions" ("id","code","module","description") VALUES (gen_random_uuid(), ${sqlLiteral(p.code)}, ${sqlLiteral(p.module)}, ${sqlLiteral(p.description)}) ` +
        `ON CONFLICT ("code") DO UPDATE SET "module" = EXCLUDED."module", "description" = EXCLUDED."description";`,
    );
  }

  for (const role of ROLES) {
    out.push(
      `INSERT INTO "roles" ("id","code","name","is_system") VALUES (gen_random_uuid(), ${sqlLiteral(role.code)}, ${sqlLiteral(role.name)}, true) ` +
        `ON CONFLICT ("code") DO UPDATE SET "name" = EXCLUDED."name", "is_system" = true;`,
    );
    const codes = role.permissions.map((c) => sqlLiteral(c)).join(', ');
    out.push(
      `INSERT INTO "role_permissions" ("role_id","permission_id") ` +
        `SELECT r."id", p."id" FROM "roles" r JOIN "permissions" p ON p."code" IN (${codes}) ` +
        `WHERE r."code" = ${sqlLiteral(role.code)} ON CONFLICT DO NOTHING;`,
    );
  }

  for (const [key, value] of Object.entries(PHARMACY_SETTINGS)) {
    out.push(
      `INSERT INTO "pharmacy_settings" ("id","key","value_json","updated_at") VALUES (gen_random_uuid(), ${sqlLiteral(key)}, ${jsonLiteral(value)}, CURRENT_TIMESTAMP) ` +
        `ON CONFLICT ("key") DO NOTHING;`,
    );
  }

  for (const rule of REGULATORY_RULES) {
    out.push(
      `INSERT INTO "regulatory_rules" ("id","code","description","rule_json","legal_basis","effective_from") VALUES ` +
        `(gen_random_uuid(), ${sqlLiteral(rule.code)}, ${sqlLiteral(rule.description)}, ${jsonLiteral(rule.rule)}, ${sqlLiteral(rule.legal_basis)}, ${sqlLiteral(rule.effective_from)}::date) ` +
        `ON CONFLICT ("code","effective_from") DO NOTHING;`,
    );
  }

  for (const u of UNITS) {
    out.push(
      `INSERT INTO "units" ("id","code","name") VALUES (gen_random_uuid(), ${sqlLiteral(u.code)}, ${sqlLiteral(u.name)}) ON CONFLICT ("code") DO NOTHING;`,
    );
  }

  if (options.owner) {
    const o = options.owner;
    out.push(
      `INSERT INTO "users" ("id","username","password_hash","must_change_password","full_name","updated_at") VALUES ` +
        `(gen_random_uuid(), ${sqlLiteral(o.username)}, ${sqlLiteral(o.passwordHash)}, true, ${sqlLiteral(o.fullName)}, CURRENT_TIMESTAMP) ` +
        `ON CONFLICT ("username") DO NOTHING;`,
    );
    out.push(
      `INSERT INTO "user_roles" ("user_id","role_id") SELECT u."id", r."id" FROM "users" u, "roles" r ` +
        `WHERE u."username" = ${sqlLiteral(o.username)} AND r."code" = 'OWNER' ON CONFLICT DO NOTHING;`,
    );
  }

  out.push('COMMIT;');
  return out.join('\n');
}
