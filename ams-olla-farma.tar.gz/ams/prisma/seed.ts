/**
 * Seed produksi: izin, peran, pengaturan apotek, aturan regulasi, dan akun
 * Owner pertama (dari variabel lingkungan, tidak pernah dari kode).
 * Jalankan dengan pengguna pemilik skema: `npm run db:seed`.
 */
import 'dotenv/config';
import { Client } from 'pg';
import { hashPassword, validatePasswordPolicy } from '../src/lib/auth/password';
import { buildSeedSql, type SeedOwner } from './seed/build-seed-sql';

async function resolveOwner(): Promise<SeedOwner | undefined> {
  const username = process.env.SEED_OWNER_USERNAME?.trim().toLowerCase();
  const password = process.env.SEED_OWNER_PASSWORD ?? '';
  const fullName = process.env.SEED_OWNER_FULL_NAME?.trim() || 'Pemilik Apotek';
  if (!username || !password) {
    console.log('SEED_OWNER_USERNAME/SEED_OWNER_PASSWORD kosong: akun Owner tidak dibuat.');
    return undefined;
  }
  const problem = validatePasswordPolicy(password, { username });
  if (problem) throw new Error(`Sandi Owner ditolak: ${problem}`);
  return { username, fullName, passwordHash: await hashPassword(password) };
}

async function main() {
  const url = process.env.MIGRATION_DATABASE_URL;
  if (!url) throw new Error('MIGRATION_DATABASE_URL belum diset');
  const owner = await resolveOwner();
  const client = new Client({ connectionString: url });
  await client.connect();
  try {
    await client.query(buildSeedSql({ owner }));
    console.log(`Seed selesai${owner ? `; Owner "${owner.username}" wajib ganti sandi saat login pertama` : ''}.`);
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
