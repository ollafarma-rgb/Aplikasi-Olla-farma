-- =============================================================================
-- Migrasi 006 — Fase 7: Diskon Periode & Piutang Pelanggan
-- =============================================================================
-- Tambahan:
--   1. ENUM: DiscountScope, DiscountType, ReceivableStatus
--   2. TABLE: discount_rules
--   3. COLUMN: sale_items.discount_rule_id (nullable FK)
--   4. TABLE: customer_receivables
--   5. TABLE: receivable_payments

-- -----------------------------------------------------------------------------
-- 1. ENUM BARU
-- -----------------------------------------------------------------------------

CREATE TYPE "DiscountScope" AS ENUM ('ALL', 'CATEGORY', 'MEDICINE');
CREATE TYPE "DiscountType"  AS ENUM ('PERCENT', 'AMOUNT');
CREATE TYPE "ReceivableStatus" AS ENUM ('OPEN', 'PARTIAL', 'PAID', 'WRITTEN_OFF');

-- -----------------------------------------------------------------------------
-- 2. TABEL discount_rules
-- -----------------------------------------------------------------------------

CREATE TABLE discount_rules (
    id           UUID        NOT NULL DEFAULT gen_random_uuid(),
    code         VARCHAR(50) NOT NULL,
    name         VARCHAR(150) NOT NULL,
    scope        "DiscountScope" NOT NULL,
    category_id  UUID,
    medicine_id  UUID,
    type         "DiscountType" NOT NULL,
    value        DECIMAL(18, 2) NOT NULL,
    min_qty_base INTEGER NOT NULL DEFAULT 1,
    starts_at    TIMESTAMPTZ NOT NULL,
    ends_at      TIMESTAMPTZ NOT NULL,
    status       "DocStatus" NOT NULL DEFAULT 'DRAFT',
    created_by   UUID NOT NULL,
    approved_by  UUID,
    approved_at  TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT discount_rules_pkey PRIMARY KEY (id),
    CONSTRAINT discount_rules_code_key UNIQUE (code),

    -- Periode valid: ends_at harus setelah starts_at
    CONSTRAINT discount_period_chk CHECK (ends_at > starts_at),
    -- Nilai diskon harus positif
    CONSTRAINT discount_value_positive_chk CHECK (value > 0),
    -- Diskon persen tidak boleh > 100
    CONSTRAINT discount_percent_max_chk CHECK (type <> 'PERCENT' OR value <= 100),
    -- Maker-checker: pembuat tidak bisa menyetujui sendiri
    CONSTRAINT discount_not_self_approve_chk CHECK (approved_by IS NULL OR approved_by <> created_by),

    CONSTRAINT discount_rules_category_id_fkey
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    CONSTRAINT discount_rules_medicine_id_fkey
        FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE RESTRICT,
    CONSTRAINT discount_rules_created_by_fkey
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT discount_rules_approved_by_fkey
        FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX discount_rules_status_period_idx
    ON discount_rules (status, starts_at, ends_at);

-- -----------------------------------------------------------------------------
-- 3. KOLOM discount_rule_id DI sale_items
-- -----------------------------------------------------------------------------

ALTER TABLE sale_items
    ADD COLUMN discount_rule_id UUID,
    ADD CONSTRAINT sale_items_discount_rule_id_fkey
        FOREIGN KEY (discount_rule_id) REFERENCES discount_rules(id) ON DELETE RESTRICT;

CREATE INDEX sale_items_discount_rule_id_idx ON sale_items (discount_rule_id);

-- -----------------------------------------------------------------------------
-- 4. TABEL customer_receivables
-- -----------------------------------------------------------------------------

CREATE TABLE customer_receivables (
    id          UUID NOT NULL DEFAULT gen_random_uuid(),
    sale_id     UUID NOT NULL,
    customer_id UUID NOT NULL,
    amount      DECIMAL(18, 2) NOT NULL,
    paid_amount DECIMAL(18, 2) NOT NULL DEFAULT 0,
    due_date    DATE NOT NULL,
    status      "ReceivableStatus" NOT NULL DEFAULT 'OPEN',
    notes       VARCHAR(500),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT customer_receivables_pkey PRIMARY KEY (id),
    CONSTRAINT customer_receivables_sale_id_key UNIQUE (sale_id),

    -- Pembayaran tidak boleh melebihi total
    CONSTRAINT receivable_paid_amount_chk CHECK (paid_amount >= 0 AND paid_amount <= amount),
    -- Jumlah piutang harus positif
    CONSTRAINT receivable_amount_positive_chk CHECK (amount > 0),

    CONSTRAINT customer_receivables_sale_id_fkey
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE RESTRICT,
    CONSTRAINT customer_receivables_customer_id_fkey
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT
);

CREATE INDEX customer_receivables_customer_status_idx
    ON customer_receivables (customer_id, status);
CREATE INDEX customer_receivables_status_due_date_idx
    ON customer_receivables (status, due_date);

-- (updated_at di-handle oleh Prisma @updatedAt, tidak perlu trigger DB)

-- -----------------------------------------------------------------------------
-- 5. TABEL receivable_payments
-- -----------------------------------------------------------------------------

CREATE TABLE receivable_payments (
    id            UUID NOT NULL DEFAULT gen_random_uuid(),
    payment_no    VARCHAR(50) NOT NULL,
    receivable_id UUID NOT NULL,
    amount        DECIMAL(18, 2) NOT NULL,
    paid_at       TIMESTAMPTZ NOT NULL,
    reference     VARCHAR(100),
    received_by   UUID NOT NULL,
    notes         VARCHAR(300),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT receivable_payments_pkey PRIMARY KEY (id),
    CONSTRAINT receivable_payments_payment_no_key UNIQUE (payment_no),

    CONSTRAINT receivable_payment_amount_positive_chk CHECK (amount > 0),

    CONSTRAINT receivable_payments_receivable_id_fkey
        FOREIGN KEY (receivable_id) REFERENCES customer_receivables(id) ON DELETE RESTRICT,
    CONSTRAINT receivable_payments_received_by_fkey
        FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX receivable_payments_receivable_id_idx ON receivable_payments (receivable_id);
CREATE INDEX receivable_payments_paid_at_idx       ON receivable_payments (paid_at);
