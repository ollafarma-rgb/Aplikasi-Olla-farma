-- Fase 4 — Persediaan: batch, kartu stok (buku besar stok), penyesuaian, opname.
-- Prinsip: saldo per bucket di medicine_batches adalah CACHE dari stock_movements,
-- diperbarui dalam transaksi yang sama lewat fungsi ams_apply_stock_movement.

-- ENUM
CREATE TYPE "StockBucket" AS ENUM ('SALEABLE', 'QUARANTINE', 'DAMAGED');
CREATE TYPE "MovementType" AS ENUM ('OPENING', 'ADJUSTMENT', 'OPNAME', 'QUARANTINE_MOVE', 'DISPOSAL');
CREATE TYPE "DocStatus" AS ENUM ('DRAFT', 'POSTED', 'CANCELLED');
CREATE TYPE "OpnameStatus" AS ENUM ('DRAFT', 'COUNTING', 'POSTED', 'CANCELLED');

-- TABEL: batch obat ------------------------------------------------------------
CREATE TABLE "medicine_batches" (
  "id" UUID NOT NULL,
  "medicine_id" UUID NOT NULL,
  "batch_no" VARCHAR(50) NOT NULL,
  "expiry_date" DATE NOT NULL,
  "source" "MovementType" NOT NULL DEFAULT 'OPENING',
  "received_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "unit_cost" DECIMAL(18,4) NOT NULL,
  "qty_received" INTEGER NOT NULL,
  "qty_saleable" INTEGER NOT NULL DEFAULT 0,
  "qty_quarantine" INTEGER NOT NULL DEFAULT 0,
  "qty_damaged" INTEGER NOT NULL DEFAULT 0,
  "is_recalled" BOOLEAN NOT NULL DEFAULT false,
  "note" VARCHAR(300),
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "medicine_batches_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "batches_qty_recv_chk" CHECK ("qty_received" >= 0),
  CONSTRAINT "batches_qty_saleable_chk" CHECK ("qty_saleable" >= 0),
  CONSTRAINT "batches_qty_quarantine_chk" CHECK ("qty_quarantine" >= 0),
  CONSTRAINT "batches_qty_damaged_chk" CHECK ("qty_damaged" >= 0),
  CONSTRAINT "batches_cost_chk" CHECK ("unit_cost" >= 0),
  CONSTRAINT "batches_batch_no_chk" CHECK (length(btrim("batch_no")) >= 1)
);
CREATE UNIQUE INDEX "medicine_batches_medicine_id_batch_no_expiry_date_key"
  ON "medicine_batches" ("medicine_id", "batch_no", "expiry_date");
CREATE INDEX "medicine_batches_medicine_id_expiry_date_idx"
  ON "medicine_batches" ("medicine_id", "expiry_date");
CREATE INDEX "medicine_batches_expiry_date_idx" ON "medicine_batches" ("expiry_date");

-- TABEL: buku besar stok (kartu stok), append-only -----------------------------
CREATE TABLE "stock_movements" (
  "id" BIGSERIAL NOT NULL,
  "occurred_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "business_date" DATE NOT NULL,
  "medicine_id" UUID NOT NULL,
  "batch_id" UUID NOT NULL,
  "movement_type" "MovementType" NOT NULL,
  "bucket_from" "StockBucket",
  "bucket_to" "StockBucket",
  "qty" INTEGER NOT NULL,
  "unit_cost" DECIMAL(18,4) NOT NULL,
  "ref_type" VARCHAR(50) NOT NULL,
  "ref_id" UUID,
  "ref_no" VARCHAR(50) NOT NULL,
  "reason" VARCHAR(300),
  "user_id" UUID NOT NULL,
  "approval_id" UUID,
  CONSTRAINT "stock_movements_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sm_qty_chk" CHECK ("qty" > 0),
  CONSTRAINT "sm_bucket_chk" CHECK ("bucket_from" IS NOT NULL OR "bucket_to" IS NOT NULL),
  CONSTRAINT "sm_cost_chk" CHECK ("unit_cost" >= 0)
);
CREATE INDEX "stock_movements_medicine_id_occurred_at_idx" ON "stock_movements" ("medicine_id", "occurred_at");
CREATE INDEX "stock_movements_batch_id_occurred_at_idx" ON "stock_movements" ("batch_id", "occurred_at");
CREATE INDEX "stock_movements_ref_type_ref_id_idx" ON "stock_movements" ("ref_type", "ref_id");
CREATE INDEX "stock_movements_business_date_idx" ON "stock_movements" ("business_date");

-- TABEL: penyesuaian stok ------------------------------------------------------
CREATE TABLE "stock_adjustments" (
  "id" UUID NOT NULL,
  "adj_no" VARCHAR(50) NOT NULL,
  "status" "DocStatus" NOT NULL DEFAULT 'DRAFT',
  "reason_code" VARCHAR(50) NOT NULL,
  "notes" VARCHAR(500),
  "created_by" UUID NOT NULL,
  "approval_id" UUID,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "posted_at" TIMESTAMPTZ(6),
  CONSTRAINT "stock_adjustments_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "stock_adjustments_adj_no_key" UNIQUE ("adj_no")
);

CREATE TABLE "stock_adjustment_items" (
  "id" UUID NOT NULL,
  "adjustment_id" UUID NOT NULL,
  "batch_id" UUID NOT NULL,
  "bucket" "StockBucket" NOT NULL,
  "qty_delta" INTEGER NOT NULL,
  "reason" VARCHAR(300),
  CONSTRAINT "stock_adjustment_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sai_delta_chk" CHECK ("qty_delta" <> 0)
);
CREATE INDEX "stock_adjustment_items_adjustment_id_idx" ON "stock_adjustment_items" ("adjustment_id");

-- TABEL: stok opname -----------------------------------------------------------
CREATE TABLE "stock_opnames" (
  "id" UUID NOT NULL,
  "opname_no" VARCHAR(50) NOT NULL,
  "scope_note" VARCHAR(300),
  "status" "OpnameStatus" NOT NULL DEFAULT 'DRAFT',
  "started_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "posted_at" TIMESTAMPTZ(6),
  "created_by" UUID NOT NULL,
  "approved_by" UUID,
  "adjustment_id" UUID,
  CONSTRAINT "stock_opnames_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "stock_opnames_opname_no_key" UNIQUE ("opname_no"),
  CONSTRAINT "stock_opnames_adjustment_id_key" UNIQUE ("adjustment_id")
);

CREATE TABLE "stock_opname_items" (
  "id" UUID NOT NULL,
  "opname_id" UUID NOT NULL,
  "batch_id" UUID NOT NULL,
  "bucket" "StockBucket" NOT NULL DEFAULT 'SALEABLE',
  "system_qty" INTEGER NOT NULL,
  "counted_qty" INTEGER,
  "notes" VARCHAR(300),
  CONSTRAINT "stock_opname_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "stock_opname_items_opname_id_batch_id_bucket_key" UNIQUE ("opname_id", "batch_id", "bucket"),
  CONSTRAINT "soi_counted_chk" CHECK ("counted_qty" IS NULL OR "counted_qty" >= 0),
  CONSTRAINT "soi_system_chk" CHECK ("system_qty" >= 0)
);
CREATE INDEX "stock_opname_items_opname_id_idx" ON "stock_opname_items" ("opname_id");

-- FOREIGN KEY ------------------------------------------------------------------
ALTER TABLE "medicine_batches" ADD CONSTRAINT "medicine_batches_medicine_id_fkey"
  FOREIGN KEY ("medicine_id") REFERENCES "medicines" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_medicine_id_fkey"
  FOREIGN KEY ("medicine_id") REFERENCES "medicines" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_batch_id_fkey"
  FOREIGN KEY ("batch_id") REFERENCES "medicine_batches" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_user_id_fkey"
  FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_approval_id_fkey"
  FOREIGN KEY ("approval_id") REFERENCES "approvals" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_created_by_fkey"
  FOREIGN KEY ("created_by") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_adjustments" ADD CONSTRAINT "stock_adjustments_approval_id_fkey"
  FOREIGN KEY ("approval_id") REFERENCES "approvals" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_adjustment_items" ADD CONSTRAINT "stock_adjustment_items_adjustment_id_fkey"
  FOREIGN KEY ("adjustment_id") REFERENCES "stock_adjustments" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_adjustment_items" ADD CONSTRAINT "stock_adjustment_items_batch_id_fkey"
  FOREIGN KEY ("batch_id") REFERENCES "medicine_batches" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "stock_opnames" ADD CONSTRAINT "stock_opnames_created_by_fkey"
  FOREIGN KEY ("created_by") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_opnames" ADD CONSTRAINT "stock_opnames_approved_by_fkey"
  FOREIGN KEY ("approved_by") REFERENCES "users" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_opnames" ADD CONSTRAINT "stock_opnames_adjustment_id_fkey"
  FOREIGN KEY ("adjustment_id") REFERENCES "stock_adjustments" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_opname_items" ADD CONSTRAINT "stock_opname_items_opname_id_fkey"
  FOREIGN KEY ("opname_id") REFERENCES "stock_opnames" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "stock_opname_items" ADD CONSTRAINT "stock_opname_items_batch_id_fkey"
  FOREIGN KEY ("batch_id") REFERENCES "medicine_batches" ("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- FUNGSI: terapkan satu pergerakan stok + perbarui cache bucket secara atomik --
CREATE FUNCTION ams_apply_stock_movement(
  p_batch_id uuid,
  p_type "MovementType",
  p_bucket_from "StockBucket",
  p_bucket_to "StockBucket",
  p_qty integer,
  p_unit_cost numeric,
  p_ref_type text,
  p_ref_id uuid,
  p_ref_no text,
  p_reason text,
  p_business_date date,
  p_approval_id uuid
) RETURNS bigint
LANGUAGE plpgsql AS $$
DECLARE
  v_user uuid;
  v_medicine uuid;
  v_avail integer;
  v_bdate date;
  v_id bigint;
BEGIN
  IF p_qty IS NULL OR p_qty <= 0 THEN
    RAISE EXCEPTION 'AMS_STOCK_QTY: jumlah pergerakan harus lebih dari 0';
  END IF;
  IF p_bucket_from IS NULL AND p_bucket_to IS NULL THEN
    RAISE EXCEPTION 'AMS_STOCK_BUCKET: pergerakan tanpa asal dan tujuan';
  END IF;

  v_user := ams_current_user_id();
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'AMS_NO_ACTOR: identitas pengguna belum di-set (ams.user_id)';
  END IF;

  -- Kunci baris batch agar saldo konsisten di bawah konkurensi.
  SELECT "medicine_id" INTO v_medicine FROM "medicine_batches" WHERE "id" = p_batch_id FOR UPDATE;
  IF v_medicine IS NULL THEN
    RAISE EXCEPTION 'AMS_BATCH_NOT_FOUND: batch tidak ditemukan';
  END IF;

  IF p_bucket_from IS NOT NULL THEN
    SELECT CASE p_bucket_from
             WHEN 'SALEABLE' THEN "qty_saleable"
             WHEN 'QUARANTINE' THEN "qty_quarantine"
             ELSE "qty_damaged" END
      INTO v_avail FROM "medicine_batches" WHERE "id" = p_batch_id;
    IF v_avail < p_qty THEN
      RAISE EXCEPTION 'AMS_STOCK_NEGATIVE: stok bucket % hanya % kurang dari %', p_bucket_from, v_avail, p_qty;
    END IF;
    UPDATE "medicine_batches" SET
      "qty_saleable" = "qty_saleable" - (CASE WHEN p_bucket_from = 'SALEABLE' THEN p_qty ELSE 0 END),
      "qty_quarantine" = "qty_quarantine" - (CASE WHEN p_bucket_from = 'QUARANTINE' THEN p_qty ELSE 0 END),
      "qty_damaged" = "qty_damaged" - (CASE WHEN p_bucket_from = 'DAMAGED' THEN p_qty ELSE 0 END),
      "updated_at" = now()
    WHERE "id" = p_batch_id;
  END IF;

  IF p_bucket_to IS NOT NULL THEN
    UPDATE "medicine_batches" SET
      "qty_saleable" = "qty_saleable" + (CASE WHEN p_bucket_to = 'SALEABLE' THEN p_qty ELSE 0 END),
      "qty_quarantine" = "qty_quarantine" + (CASE WHEN p_bucket_to = 'QUARANTINE' THEN p_qty ELSE 0 END),
      "qty_damaged" = "qty_damaged" + (CASE WHEN p_bucket_to = 'DAMAGED' THEN p_qty ELSE 0 END),
      "updated_at" = now()
    WHERE "id" = p_batch_id;
  END IF;

  v_bdate := COALESCE(p_business_date, (now() AT TIME ZONE 'Asia/Jakarta')::date);

  INSERT INTO "stock_movements"
    ("business_date","medicine_id","batch_id","movement_type","bucket_from","bucket_to",
     "qty","unit_cost","ref_type","ref_id","ref_no","reason","user_id","approval_id")
  VALUES
    (v_bdate, v_medicine, p_batch_id, p_type, p_bucket_from, p_bucket_to,
     p_qty, p_unit_cost, p_ref_type, p_ref_id, p_ref_no, NULLIF(btrim(p_reason), ''), v_user, p_approval_id)
  RETURNING "id" INTO v_id;

  RETURN v_id;
END;
$$;

-- TRIGGER: append-only untuk stock_movements, no-delete untuk batch -------------
CREATE TRIGGER "stock_movements_append_only_trg" BEFORE UPDATE OR DELETE ON "stock_movements"
  FOR EACH ROW EXECUTE FUNCTION ams_reject_mutation();
CREATE TRIGGER "medicine_batches_no_delete_trg" BEFORE DELETE ON "medicine_batches"
  FOR EACH ROW EXECUTE FUNCTION ams_reject_mutation();
