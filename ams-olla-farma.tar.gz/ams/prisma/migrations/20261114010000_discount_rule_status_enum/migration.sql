-- Migration: Perbaiki enum status untuk discount_rules
-- DocStatus (DRAFT/POSTED/CANCELLED) tidak sesuai untuk diskon yang perlu APPROVED/REJECTED.
-- Tambah enum DiscountRuleStatus dan migrasi kolom.

-- 1. Buat enum baru
CREATE TYPE "DiscountRuleStatus" AS ENUM ('DRAFT', 'APPROVED', 'REJECTED', 'CANCELLED');

-- 2. Hapus default dulu sebelum ALTER TYPE
ALTER TABLE discount_rules ALTER COLUMN status DROP DEFAULT;

-- 3. Migrasi kolom ke type baru (cast via text)
ALTER TABLE discount_rules
  ALTER COLUMN status TYPE "DiscountRuleStatus"
  USING status::text::"DiscountRuleStatus";

-- 4. Pasang default baru
ALTER TABLE discount_rules
  ALTER COLUMN status SET DEFAULT 'DRAFT'::"DiscountRuleStatus";
