-- =============================================================================
-- AMS migrasi 001 — Fase 2: identitas, sesi, RBAC, audit, infrastruktur
-- Bagian A mengikuti gaya DDL yang dihasilkan Prisma dari prisma/schema.prisma.
-- Bagian B adalah aturan yang tidak dikelola Prisma (CHECK, trigger, fungsi).
-- WAJIB: setelah paket terpasang, jalankan
--   npx prisma migrate diff --from-migrations prisma/migrations \
--     --to-schema prisma/schema.prisma --script
-- dan pastikan hasilnya kosong (tidak ada drift).
-- =============================================================================

-- ---------------------------------------------------------------------------
-- A. DDL (setara Prisma)
-- ---------------------------------------------------------------------------

-- CreateEnum
CREATE TYPE "LicenseType" AS ENUM ('STR', 'SIPA', 'SIPTTK', 'OTHER');

-- CreateEnum
CREATE TYPE "IdempotencyStatus" AS ENUM ('IN_PROGRESS', 'COMPLETED', 'FAILED');

-- CreateTable
CREATE TABLE "users" (
    "id" UUID NOT NULL,
    "username" VARCHAR(50) NOT NULL,
    "password_hash" TEXT NOT NULL,
    "supervisor_pin_hash" TEXT,
    "must_change_password" BOOLEAN NOT NULL DEFAULT true,
    "full_name" VARCHAR(150) NOT NULL,
    "phone" VARCHAR(30),
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "failed_login_count" INTEGER NOT NULL DEFAULT 0,
    "locked_until" TIMESTAMPTZ(6),
    "session_version" INTEGER NOT NULL DEFAULT 1,
    "last_login_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_sessions" (
    "id" VARCHAR(64) NOT NULL,
    "user_id" UUID NOT NULL,
    "session_version" INTEGER NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "last_seen_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,
    "revoked_at" TIMESTAMPTZ(6),
    "ip" VARCHAR(45),
    "user_agent" VARCHAR(300),

    CONSTRAINT "user_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "employee_licenses" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "license_type" "LicenseType" NOT NULL,
    "number" VARCHAR(100) NOT NULL,
    "valid_until" DATE,
    "attachment_id" UUID,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "employee_licenses_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "roles" (
    "id" UUID NOT NULL,
    "code" VARCHAR(50) NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "is_system" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "roles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "permissions" (
    "id" UUID NOT NULL,
    "code" VARCHAR(100) NOT NULL,
    "module" VARCHAR(50) NOT NULL,
    "description" TEXT NOT NULL,

    CONSTRAINT "permissions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_roles" (
    "user_id" UUID NOT NULL,
    "role_id" UUID NOT NULL,

    CONSTRAINT "user_roles_pkey" PRIMARY KEY ("user_id","role_id")
);

-- CreateTable
CREATE TABLE "role_permissions" (
    "role_id" UUID NOT NULL,
    "permission_id" UUID NOT NULL,

    CONSTRAINT "role_permissions_pkey" PRIMARY KEY ("role_id","permission_id")
);

-- CreateTable
CREATE TABLE "approvals" (
    "id" UUID NOT NULL,
    "action_code" VARCHAR(100) NOT NULL,
    "requested_by" UUID NOT NULL,
    "approved_by" UUID NOT NULL,
    "ref_type" VARCHAR(50) NOT NULL,
    "ref_id" UUID NOT NULL,
    "reason" TEXT NOT NULL,
    "approved_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "approvals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "idempotency_keys" (
    "id" UUID NOT NULL,
    "scope" VARCHAR(50) NOT NULL,
    "key" VARCHAR(100) NOT NULL,
    "user_id" UUID NOT NULL,
    "request_hash" VARCHAR(64) NOT NULL,
    "status" "IdempotencyStatus" NOT NULL DEFAULT 'IN_PROGRESS',
    "response_json" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "idempotency_keys_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "number_sequences" (
    "id" UUID NOT NULL,
    "doc_type" VARCHAR(30) NOT NULL,
    "period" VARCHAR(10) NOT NULL,
    "last_value" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "number_sequences_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "rate_limits" (
    "key" VARCHAR(200) NOT NULL,
    "window_start" TIMESTAMPTZ(6) NOT NULL,
    "hits" INTEGER NOT NULL,

    CONSTRAINT "rate_limits_pkey" PRIMARY KEY ("key")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" BIGSERIAL NOT NULL,
    "occurred_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "user_id" UUID,
    "action" VARCHAR(100) NOT NULL,
    "entity" VARCHAR(50) NOT NULL,
    "entity_id" VARCHAR(64),
    "before_json" JSONB,
    "after_json" JSONB,
    "ip" VARCHAR(45),
    "user_agent" VARCHAR(300),
    "prev_hash" VARCHAR(64),
    "hash" VARCHAR(64) NOT NULL DEFAULT '',

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "pharmacy_settings" (
    "id" UUID NOT NULL,
    "key" VARCHAR(100) NOT NULL,
    "value_json" JSONB NOT NULL,
    "updated_by" UUID,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "pharmacy_settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "regulatory_rules" (
    "id" UUID NOT NULL,
    "code" VARCHAR(100) NOT NULL,
    "description" TEXT NOT NULL,
    "rule_json" JSONB NOT NULL,
    "legal_basis" TEXT NOT NULL,
    "effective_from" DATE NOT NULL,
    "effective_to" DATE,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "regulatory_rules_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "attachments" (
    "id" UUID NOT NULL,
    "storage_key" TEXT NOT NULL,
    "filename" TEXT NOT NULL,
    "mime" VARCHAR(100) NOT NULL,
    "size" INTEGER NOT NULL,
    "sha256" VARCHAR(64) NOT NULL,
    "ref_type" VARCHAR(50),
    "ref_id" UUID,
    "uploaded_by" UUID NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "attachments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");

-- CreateIndex
CREATE INDEX "user_sessions_user_id_idx" ON "user_sessions"("user_id");

-- CreateIndex
CREATE INDEX "user_sessions_expires_at_idx" ON "user_sessions"("expires_at");

-- CreateIndex
CREATE INDEX "employee_licenses_valid_until_idx" ON "employee_licenses"("valid_until");

-- CreateIndex
CREATE UNIQUE INDEX "roles_code_key" ON "roles"("code");

-- CreateIndex
CREATE UNIQUE INDEX "permissions_code_key" ON "permissions"("code");

-- CreateIndex
CREATE INDEX "approvals_ref_type_ref_id_idx" ON "approvals"("ref_type", "ref_id");

-- CreateIndex
CREATE INDEX "idempotency_keys_expires_at_idx" ON "idempotency_keys"("expires_at");

-- CreateIndex
CREATE UNIQUE INDEX "idempotency_keys_scope_key_key" ON "idempotency_keys"("scope", "key");

-- CreateIndex
CREATE UNIQUE INDEX "number_sequences_doc_type_period_key" ON "number_sequences"("doc_type", "period");

-- CreateIndex
CREATE INDEX "audit_logs_entity_entity_id_idx" ON "audit_logs"("entity", "entity_id");

-- CreateIndex
CREATE INDEX "audit_logs_occurred_at_idx" ON "audit_logs"("occurred_at");

-- CreateIndex
CREATE INDEX "audit_logs_user_id_occurred_at_idx" ON "audit_logs"("user_id", "occurred_at");

-- CreateIndex
CREATE UNIQUE INDEX "pharmacy_settings_key_key" ON "pharmacy_settings"("key");

-- CreateIndex
CREATE UNIQUE INDEX "regulatory_rules_code_effective_from_key" ON "regulatory_rules"("code", "effective_from");

-- CreateIndex
CREATE UNIQUE INDEX "attachments_storage_key_key" ON "attachments"("storage_key");

-- CreateIndex
CREATE INDEX "attachments_ref_type_ref_id_idx" ON "attachments"("ref_type", "ref_id");

-- AddForeignKey
ALTER TABLE "user_sessions" ADD CONSTRAINT "user_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "employee_licenses" ADD CONSTRAINT "employee_licenses_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "employee_licenses" ADD CONSTRAINT "employee_licenses_attachment_id_fkey" FOREIGN KEY ("attachment_id") REFERENCES "attachments"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "permissions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "approvals" ADD CONSTRAINT "approvals_requested_by_fkey" FOREIGN KEY ("requested_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "approvals" ADD CONSTRAINT "approvals_approved_by_fkey" FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "idempotency_keys" ADD CONSTRAINT "idempotency_keys_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pharmacy_settings" ADD CONSTRAINT "pharmacy_settings_updated_by_fkey" FOREIGN KEY ("updated_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "attachments" ADD CONSTRAINT "attachments_uploaded_by_fkey" FOREIGN KEY ("uploaded_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- ---------------------------------------------------------------------------
-- B. Aturan di luar Prisma
-- ---------------------------------------------------------------------------

-- B1. CHECK constraint
ALTER TABLE "users"
  ADD CONSTRAINT "users_username_lower_chk" CHECK ("username" = lower("username") AND "username" ~ '^[a-z0-9._-]{3,50}$'),
  ADD CONSTRAINT "users_failed_login_count_chk" CHECK ("failed_login_count" >= 0),
  ADD CONSTRAINT "users_session_version_chk" CHECK ("session_version" >= 1);

ALTER TABLE "user_sessions"
  ADD CONSTRAINT "user_sessions_id_hex_chk" CHECK ("id" ~ '^[0-9a-f]{64}$'),
  ADD CONSTRAINT "user_sessions_expiry_chk" CHECK ("expires_at" > "created_at");

ALTER TABLE "approvals"
  ADD CONSTRAINT "approvals_not_self_chk" CHECK ("approved_by" <> "requested_by"),
  ADD CONSTRAINT "approvals_reason_chk" CHECK (length(btrim("reason")) > 0);

ALTER TABLE "number_sequences"
  ADD CONSTRAINT "number_sequences_last_value_chk" CHECK ("last_value" >= 0);

ALTER TABLE "rate_limits"
  ADD CONSTRAINT "rate_limits_hits_chk" CHECK ("hits" >= 0);

ALTER TABLE "attachments"
  ADD CONSTRAINT "attachments_size_chk" CHECK ("size" >= 0),
  ADD CONSTRAINT "attachments_sha256_chk" CHECK ("sha256" ~ '^[0-9a-f]{64}$');

ALTER TABLE "regulatory_rules"
  ADD CONSTRAINT "regulatory_rules_period_chk" CHECK ("effective_to" IS NULL OR "effective_to" > "effective_from");

-- B2. Penjaga umum: tabel append-only menolak UPDATE, DELETE, TRUNCATE
CREATE FUNCTION ams_reject_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'AMS_APPEND_ONLY: % pada tabel % tidak diizinkan', TG_OP, TG_TABLE_NAME
    USING ERRCODE = 'P0001';
END;
$$;

-- B3. Audit log: rantai hash SHA-256 diisi di DB, diserialkan dengan advisory lock
CREATE FUNCTION ams_audit_chain() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
  v_prev text;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext('ams_audit_logs_chain'));
  -- id diambil ulang SETELAH kunci didapat, agar urutan id = urutan rantai.
  -- (Default kolom sudah dievaluasi sebelum trigger dan bisa tidak berurutan
  -- antar sesi paralel; nilai itu dibuang, menyisakan celah yang tidak masalah.)
  NEW."id" := nextval(pg_get_serial_sequence('"audit_logs"', 'id'));
  SELECT "hash" INTO v_prev FROM "audit_logs" ORDER BY "id" DESC LIMIT 1;
  NEW."occurred_at" := COALESCE(NEW."occurred_at", CURRENT_TIMESTAMP);
  NEW."prev_hash" := v_prev;
  NEW."hash" := encode(sha256(convert_to(ams_audit_payload(
      v_prev, NEW."id", NEW."occurred_at", NEW."user_id", NEW."action", NEW."entity",
      NEW."entity_id", NEW."before_json", NEW."after_json"), 'UTF8')), 'hex');
  RETURN NEW;
END;
$$;

-- Payload kanonik yang di-hash (dipakai juga oleh fungsi verifikasi).
CREATE FUNCTION ams_audit_payload(
  p_prev text, p_id bigint, p_at timestamptz, p_user uuid, p_action text,
  p_entity text, p_entity_id text, p_before jsonb, p_after jsonb
) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
  SELECT concat_ws('|',
    COALESCE(p_prev, 'GENESIS'),
    p_id::text,
    to_char(p_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
    COALESCE(p_user::text, '-'),
    p_action,
    p_entity,
    COALESCE(p_entity_id, '-'),
    COALESCE(p_before::text, '-'),
    COALESCE(p_after::text, '-'));
$$;

CREATE TRIGGER "audit_logs_chain_trg"
  BEFORE INSERT ON "audit_logs"
  FOR EACH ROW EXECUTE FUNCTION ams_audit_chain();

CREATE TRIGGER "audit_logs_append_only_trg"
  BEFORE UPDATE OR DELETE ON "audit_logs"
  FOR EACH ROW EXECUTE FUNCTION ams_reject_mutation();

CREATE TRIGGER "audit_logs_no_truncate_trg"
  BEFORE TRUNCATE ON "audit_logs"
  FOR EACH STATEMENT EXECUTE FUNCTION ams_reject_mutation();

-- Verifikasi rantai: mengembalikan id baris pertama yang rusak, atau NULL bila utuh.
CREATE FUNCTION ams_audit_verify_chain() RETURNS bigint
LANGUAGE plpgsql STABLE AS $$
DECLARE
  r record;
  v_prev text := NULL;
BEGIN
  FOR r IN SELECT * FROM "audit_logs" ORDER BY "id" LOOP
    IF r."prev_hash" IS DISTINCT FROM v_prev
       OR r."hash" <> encode(sha256(convert_to(ams_audit_payload(
            v_prev, r."id", r."occurred_at", r."user_id", r."action", r."entity",
            r."entity_id", r."before_json", r."after_json"), 'UTF8')), 'hex') THEN
      RETURN r."id";
    END IF;
    v_prev := r."hash";
  END LOOP;
  RETURN NULL;
END;
$$;

-- B4. Penomoran dokumen atomik: aman untuk banyak kasir sekaligus.
CREATE FUNCTION ams_next_number(p_doc_type text, p_period text) RETURNS integer
LANGUAGE plpgsql AS $$
DECLARE
  v_next integer;
BEGIN
  INSERT INTO "number_sequences" ("id", "doc_type", "period", "last_value")
  VALUES (gen_random_uuid(), p_doc_type, p_period, 1)
  ON CONFLICT ("doc_type", "period")
  DO UPDATE SET "last_value" = "number_sequences"."last_value" + 1
  RETURNING "last_value" INTO v_next;
  RETURN v_next;
END;
$$;

-- B5. Pembatas laju jendela tetap. TRUE = diizinkan, FALSE = melebihi batas.
CREATE FUNCTION ams_rate_limit_hit(p_key text, p_window_seconds integer, p_max integer)
RETURNS boolean
LANGUAGE plpgsql AS $$
DECLARE
  v_hits integer;
BEGIN
  INSERT INTO "rate_limits" ("key", "window_start", "hits")
  VALUES (p_key, CURRENT_TIMESTAMP, 1)
  ON CONFLICT ("key") DO UPDATE SET
    "window_start" = CASE
      WHEN "rate_limits"."window_start" <= CURRENT_TIMESTAMP - make_interval(secs => p_window_seconds)
      THEN CURRENT_TIMESTAMP ELSE "rate_limits"."window_start" END,
    "hits" = CASE
      WHEN "rate_limits"."window_start" <= CURRENT_TIMESTAMP - make_interval(secs => p_window_seconds)
      THEN 1 ELSE "rate_limits"."hits" + 1 END
  RETURNING "hits" INTO v_hits;
  RETURN v_hits <= p_max;
END;
$$;

-- B6. Peran sistem tidak boleh dihapus.
CREATE FUNCTION ams_protect_system_role() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF OLD."is_system" THEN
    RAISE EXCEPTION 'AMS_SYSTEM_ROLE: peran sistem % tidak boleh dihapus', OLD."code"
      USING ERRCODE = 'P0001';
  END IF;
  RETURN OLD;
END;
$$;

CREATE TRIGGER "roles_protect_system_trg"
  BEFORE DELETE ON "roles"
  FOR EACH ROW EXECUTE FUNCTION ams_protect_system_role();
