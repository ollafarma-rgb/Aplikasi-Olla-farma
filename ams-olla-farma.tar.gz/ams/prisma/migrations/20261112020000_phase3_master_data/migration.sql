-- =============================================================================
-- AMS migrasi 002 — Fase 3: master data obat, referensi, pemasok
-- Bagian A setara DDL Prisma; bagian B aturan di luar Prisma.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- A. DDL (setara Prisma)
-- ---------------------------------------------------------------------------

CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- CreateEnum
CREATE TYPE "ProductType" AS ENUM ('PRESCRIPTION_DRUG', 'OTC', 'LIMITED_OTC', 'MEDICAL_DEVICE', 'SUPPLEMENT', 'VITAMIN', 'MEDICAL_SUPPLY', 'OTHER');

-- CreateEnum
CREATE TYPE "DrugClass" AS ENUM ('BEBAS', 'BEBAS_TERBATAS', 'KERAS', 'NARKOTIKA', 'PSIKOTROPIKA', 'NON_OBAT');

-- CreateEnum
CREATE TYPE "StorageCondition" AS ENUM ('ROOM', 'COOL', 'REFRIGERATED', 'SPECIAL_CABINET');

-- CreateEnum
CREATE TYPE "SupplierStatus" AS ENUM ('ACTIVE', 'INACTIVE', 'BLOCKED');

-- CreateTable
CREATE TABLE "categories" (
    "id" UUID NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "units" (
    "id" UUID NOT NULL,
    "code" VARCHAR(20) NOT NULL,
    "name" VARCHAR(50) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "units_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "manufacturers" (
    "id" UUID NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "country" VARCHAR(80),

    CONSTRAINT "manufacturers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "storage_locations" (
    "id" UUID NOT NULL,
    "code" VARCHAR(30) NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "condition" "StorageCondition" NOT NULL DEFAULT 'ROOM',

    CONSTRAINT "storage_locations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "medicines" (
    "id" UUID NOT NULL,
    "sku" VARCHAR(50) NOT NULL,
    "barcode" VARCHAR(64),
    "name" VARCHAR(200) NOT NULL,
    "generic_name" VARCHAR(200),
    "brand" VARCHAR(100),
    "category_id" UUID,
    "product_type" "ProductType" NOT NULL,
    "drug_class" "DrugClass" NOT NULL,
    "dosage_form" VARCHAR(50),
    "strength" VARCHAR(50),
    "manufacturer_id" UUID,
    "registration_no" VARCHAR(50),
    "base_unit_id" UUID NOT NULL,
    "purchase_unit_id" UUID NOT NULL,
    "sales_unit_id" UUID NOT NULL,
    "default_purchase_price" DECIMAL(18,2),
    "selling_price" DECIMAL(18,2) NOT NULL,
    "min_stock" INTEGER NOT NULL DEFAULT 0,
    "max_stock" INTEGER,
    "storage_location_id" UUID,
    "requires_prescription" BOOLEAN NOT NULL DEFAULT false,
    "is_owa" BOOLEAN NOT NULL DEFAULT false,
    "is_precursor" BOOLEAN NOT NULL DEFAULT false,
    "is_oot" BOOLEAN NOT NULL DEFAULT false,
    "is_lasa" BOOLEAN NOT NULL DEFAULT false,
    "is_high_alert" BOOLEAN NOT NULL DEFAULT false,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "medicines_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "medicine_unit_conversions" (
    "id" UUID NOT NULL,
    "medicine_id" UUID NOT NULL,
    "unit_id" UUID NOT NULL,
    "factor_to_base" INTEGER NOT NULL,
    "barcode" VARCHAR(64),
    "selling_price" DECIMAL(18,2),

    CONSTRAINT "medicine_unit_conversions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "medicine_price_history" (
    "id" BIGSERIAL NOT NULL,
    "medicine_id" UUID NOT NULL,
    "unit_id" UUID NOT NULL,
    "price_type" VARCHAR(20) NOT NULL,
    "old_price" DECIMAL(18,2),
    "new_price" DECIMAL(18,2),
    "reason" TEXT,
    "changed_by" UUID NOT NULL,
    "changed_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "medicine_price_history_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "suppliers" (
    "id" UUID NOT NULL,
    "code" VARCHAR(30) NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "company_name" VARCHAR(200),
    "address" TEXT,
    "phone" VARCHAR(30),
    "email" VARCHAR(150),
    "sales_rep" VARCHAR(100),
    "npwp" VARCHAR(30),
    "pbf_license_no" VARCHAR(100),
    "payment_term_days" INTEGER NOT NULL DEFAULT 30,
    "status" "SupplierStatus" NOT NULL DEFAULT 'ACTIVE',
    "notes" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "suppliers_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "categories_name_key" ON "categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "units_code_key" ON "units"("code");

-- CreateIndex
CREATE UNIQUE INDEX "manufacturers_name_key" ON "manufacturers"("name");

-- CreateIndex
CREATE UNIQUE INDEX "storage_locations_code_key" ON "storage_locations"("code");

-- CreateIndex
CREATE UNIQUE INDEX "medicines_sku_key" ON "medicines"("sku");

-- CreateIndex
CREATE UNIQUE INDEX "medicines_barcode_key" ON "medicines"("barcode");

-- CreateIndex
CREATE INDEX "medicines_name_trgm_idx" ON "medicines" USING GIN ("name" gin_trgm_ops);

-- CreateIndex
CREATE INDEX "medicines_generic_name_trgm_idx" ON "medicines" USING GIN ("generic_name" gin_trgm_ops);

-- CreateIndex
CREATE INDEX "medicines_brand_trgm_idx" ON "medicines" USING GIN ("brand" gin_trgm_ops);

-- CreateIndex
CREATE INDEX "medicines_is_active_drug_class_idx" ON "medicines"("is_active", "drug_class");

-- CreateIndex
CREATE UNIQUE INDEX "medicine_unit_conversions_barcode_key" ON "medicine_unit_conversions"("barcode");

-- CreateIndex
CREATE UNIQUE INDEX "medicine_unit_conversions_medicine_id_unit_id_key" ON "medicine_unit_conversions"("medicine_id", "unit_id");

-- CreateIndex
CREATE INDEX "medicine_price_history_medicine_id_changed_at_idx" ON "medicine_price_history"("medicine_id", "changed_at");

-- CreateIndex
CREATE UNIQUE INDEX "suppliers_code_key" ON "suppliers"("code");

-- CreateIndex
CREATE INDEX "suppliers_name_idx" ON "suppliers"("name");

-- AddForeignKey
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_manufacturer_id_fkey" FOREIGN KEY ("manufacturer_id") REFERENCES "manufacturers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_base_unit_id_fkey" FOREIGN KEY ("base_unit_id") REFERENCES "units"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_purchase_unit_id_fkey" FOREIGN KEY ("purchase_unit_id") REFERENCES "units"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_sales_unit_id_fkey" FOREIGN KEY ("sales_unit_id") REFERENCES "units"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicines" ADD CONSTRAINT "medicines_storage_location_id_fkey" FOREIGN KEY ("storage_location_id") REFERENCES "storage_locations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicine_unit_conversions" ADD CONSTRAINT "medicine_unit_conversions_medicine_id_fkey" FOREIGN KEY ("medicine_id") REFERENCES "medicines"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicine_unit_conversions" ADD CONSTRAINT "medicine_unit_conversions_unit_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "units"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicine_price_history" ADD CONSTRAINT "medicine_price_history_medicine_id_fkey" FOREIGN KEY ("medicine_id") REFERENCES "medicines"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicine_price_history" ADD CONSTRAINT "medicine_price_history_unit_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "units"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medicine_price_history" ADD CONSTRAINT "medicine_price_history_changed_by_fkey" FOREIGN KEY ("changed_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- ---------------------------------------------------------------------------
-- B. Aturan di luar Prisma
-- ---------------------------------------------------------------------------

-- B1. CHECK umum
ALTER TABLE "units" ADD CONSTRAINT "units_code_chk" CHECK ("code" ~ '^[A-Z0-9]{1,20}$');
ALTER TABLE "categories" ADD CONSTRAINT "categories_name_chk" CHECK (length(btrim("name")) > 0);
ALTER TABLE "storage_locations" ADD CONSTRAINT "storage_locations_code_chk" CHECK ("code" ~ '^[A-Z0-9._-]{1,30}$');

ALTER TABLE "medicines"
  ADD CONSTRAINT "medicines_stock_chk" CHECK ("min_stock" >= 0 AND ("max_stock" IS NULL OR "max_stock" >= "min_stock")),
  ADD CONSTRAINT "medicines_price_chk" CHECK ("selling_price" >= 0 AND ("default_purchase_price" IS NULL OR "default_purchase_price" >= 0)),
  ADD CONSTRAINT "medicines_barcode_chk" CHECK ("barcode" IS NULL OR "barcode" ~ '^[0-9A-Za-z-]{4,64}$'),
  ADD CONSTRAINT "medicines_name_chk" CHECK (length(btrim("name")) > 0),
  -- Narkotika dan psikotropika selalu wajib resep.
  ADD CONSTRAINT "medicines_narc_psy_rx_chk" CHECK ("drug_class" NOT IN ('NARKOTIKA', 'PSIKOTROPIKA') OR "requires_prescription"),
  -- Obat keras wajib resep kecuali ditandai OWA.
  ADD CONSTRAINT "medicines_keras_rx_chk" CHECK ("drug_class" <> 'KERAS' OR "requires_prescription" OR "is_owa"),
  -- OWA hanya untuk obat keras dan tidak sekaligus wajib resep.
  ADD CONSTRAINT "medicines_owa_chk" CHECK (NOT "is_owa" OR ("drug_class" = 'KERAS' AND NOT "requires_prescription")),
  -- Obat (bukan non-obat) wajib punya nomor izin edar.
  ADD CONSTRAINT "medicines_nie_chk" CHECK ("drug_class" = 'NON_OBAT' OR "registration_no" IS NOT NULL),
  -- Jenis produk konsisten dengan golongan.
  ADD CONSTRAINT "medicines_type_class_chk" CHECK (
    ("product_type" <> 'PRESCRIPTION_DRUG' OR "drug_class" IN ('KERAS', 'NARKOTIKA', 'PSIKOTROPIKA')) AND
    ("product_type" <> 'OTC' OR "drug_class" = 'BEBAS') AND
    ("product_type" <> 'LIMITED_OTC' OR "drug_class" = 'BEBAS_TERBATAS') AND
    ("product_type" NOT IN ('MEDICAL_DEVICE', 'MEDICAL_SUPPLY') OR "drug_class" = 'NON_OBAT'));

ALTER TABLE "medicine_unit_conversions"
  ADD CONSTRAINT "muc_factor_chk" CHECK ("factor_to_base" > 1),
  ADD CONSTRAINT "muc_price_chk" CHECK ("selling_price" IS NULL OR "selling_price" >= 0),
  ADD CONSTRAINT "muc_barcode_chk" CHECK ("barcode" IS NULL OR "barcode" ~ '^[0-9A-Za-z-]{4,64}$');

ALTER TABLE "suppliers"
  ADD CONSTRAINT "suppliers_term_chk" CHECK ("payment_term_days" BETWEEN 0 AND 365),
  ADD CONSTRAINT "suppliers_name_chk" CHECK (length(btrim("name")) > 0);

-- B2. Barcode unik lintas tabel obat dan konversi.
CREATE FUNCTION ams_barcode_unique_across() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW."barcode" IS NULL THEN RETURN NEW; END IF;
  PERFORM pg_advisory_xact_lock(hashtext('ams_barcode:' || NEW."barcode"));
  IF TG_TABLE_NAME = 'medicines' THEN
    IF EXISTS (SELECT 1 FROM "medicine_unit_conversions" WHERE "barcode" = NEW."barcode") THEN
      RAISE EXCEPTION 'AMS_BARCODE_DUPLICATE: barcode % sudah dipakai satuan obat lain', NEW."barcode" USING ERRCODE = '23505';
    END IF;
  ELSE
    IF EXISTS (SELECT 1 FROM "medicines" WHERE "barcode" = NEW."barcode") THEN
      RAISE EXCEPTION 'AMS_BARCODE_DUPLICATE: barcode % sudah dipakai obat lain', NEW."barcode" USING ERRCODE = '23505';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER "medicines_barcode_across_trg" BEFORE INSERT OR UPDATE OF "barcode" ON "medicines"
  FOR EACH ROW EXECUTE FUNCTION ams_barcode_unique_across();
CREATE TRIGGER "muc_barcode_across_trg" BEFORE INSERT OR UPDATE OF "barcode" ON "medicine_unit_conversions"
  FOR EACH ROW EXECUTE FUNCTION ams_barcode_unique_across();

-- B3. Konversi tidak boleh memakai satuan dasar obatnya sendiri.
CREATE FUNCTION ams_conversion_not_base() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM "medicines" WHERE "id" = NEW."medicine_id" AND "base_unit_id" = NEW."unit_id") THEN
    RAISE EXCEPTION 'AMS_CONVERSION_BASE_UNIT: satuan dasar tidak perlu dicatat sebagai konversi' USING ERRCODE = '23514';
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER "muc_not_base_trg" BEFORE INSERT OR UPDATE ON "medicine_unit_conversions"
  FOR EACH ROW EXECUTE FUNCTION ams_conversion_not_base();

-- B4. Riwayat harga otomatis (aturan bisnis #10). Aplikasi wajib mengisi
--     SET LOCAL ams.user_id (dan opsional ams.price_reason) dalam transaksi.
CREATE FUNCTION ams_current_user_id() RETURNS uuid
LANGUAGE plpgsql STABLE AS $$
DECLARE v text;
BEGIN
  v := current_setting('ams.user_id', true);
  IF v IS NULL OR v = '' THEN
    RAISE EXCEPTION 'AMS_NO_ACTOR: perubahan ini wajib menyertakan pengguna (ams.user_id)' USING ERRCODE = 'P0001';
  END IF;
  RETURN v::uuid;
END;
$$;

CREATE FUNCTION ams_medicine_price_history() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE v_reason text := NULLIF(current_setting('ams.price_reason', true), '');
BEGIN
  IF TG_OP = 'INSERT' OR NEW."selling_price" IS DISTINCT FROM OLD."selling_price" THEN
    INSERT INTO "medicine_price_history" ("medicine_id","unit_id","price_type","old_price","new_price","reason","changed_by")
    VALUES (NEW."id", NEW."base_unit_id", 'SELLING',
            CASE WHEN TG_OP = 'UPDATE' THEN OLD."selling_price" END, NEW."selling_price", v_reason, ams_current_user_id());
  END IF;
  IF (TG_OP = 'INSERT' AND NEW."default_purchase_price" IS NOT NULL)
     OR (TG_OP = 'UPDATE' AND NEW."default_purchase_price" IS DISTINCT FROM OLD."default_purchase_price") THEN
    INSERT INTO "medicine_price_history" ("medicine_id","unit_id","price_type","old_price","new_price","reason","changed_by")
    VALUES (NEW."id", NEW."purchase_unit_id", 'PURCHASE_DEFAULT',
            CASE WHEN TG_OP = 'UPDATE' THEN OLD."default_purchase_price" END, NEW."default_purchase_price", v_reason, ams_current_user_id());
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER "medicines_price_history_trg" AFTER INSERT OR UPDATE OF "selling_price", "default_purchase_price" ON "medicines"
  FOR EACH ROW EXECUTE FUNCTION ams_medicine_price_history();

CREATE FUNCTION ams_conversion_price_history() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    IF OLD."selling_price" IS NOT NULL THEN
      INSERT INTO "medicine_price_history" ("medicine_id","unit_id","price_type","old_price","new_price","reason","changed_by")
      VALUES (OLD."medicine_id", OLD."unit_id", 'SELLING_UNIT', OLD."selling_price", NULL,
              NULLIF(current_setting('ams.price_reason', true), ''), ams_current_user_id());
    END IF;
    RETURN OLD;
  END IF;
  IF (TG_OP = 'INSERT' AND NEW."selling_price" IS NOT NULL)
     OR (TG_OP = 'UPDATE' AND NEW."selling_price" IS DISTINCT FROM OLD."selling_price") THEN
    INSERT INTO "medicine_price_history" ("medicine_id","unit_id","price_type","old_price","new_price","reason","changed_by")
    VALUES (NEW."medicine_id", NEW."unit_id", 'SELLING_UNIT',
            CASE WHEN TG_OP = 'UPDATE' THEN OLD."selling_price" END, NEW."selling_price",
            NULLIF(current_setting('ams.price_reason', true), ''), ams_current_user_id());
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER "muc_price_history_trg" AFTER INSERT OR UPDATE OF "selling_price" OR DELETE ON "medicine_unit_conversions"
  FOR EACH ROW EXECUTE FUNCTION ams_conversion_price_history();

-- Riwayat harga append-only.
CREATE TRIGGER "price_history_append_only_trg" BEFORE UPDATE OR DELETE ON "medicine_price_history"
  FOR EACH ROW EXECUTE FUNCTION ams_reject_mutation();

-- B5. Obat dan pemasok tidak pernah dihapus; nonaktifkan saja.
CREATE TRIGGER "medicines_no_delete_trg" BEFORE DELETE ON "medicines"
  FOR EACH ROW EXECUTE FUNCTION ams_reject_mutation();
CREATE TRIGGER "suppliers_no_delete_trg" BEFORE DELETE ON "suppliers"
  FOR EACH ROW EXECUTE FUNCTION ams_reject_mutation();
