-- Fase 5 — Pengadaan: Surat Pesanan (SP), penerimaan barang (membuat batch), retur pembelian.
-- Prinsip: penerimaan barang yang di-posting membuat batch baru lewat
-- ams_apply_stock_movement (movement_type RECEIPT) — fungsi yang sama dipakai
-- Fase 4, tidak diubah. Retur pembelian memakai maker-checker seperti
-- StockAdjustment (approval tercatat di tabel approvals).

-- ENUM baru pada MovementType: tiap ALTER TYPE adalah statement terpisah
-- (auto-commit sendiri), jadi aman dipakai oleh statement berikutnya di file ini.
ALTER TYPE "MovementType" ADD VALUE 'RECEIPT';
ALTER TYPE "MovementType" ADD VALUE 'PURCHASE_RETURN';

CREATE TYPE "PurchaseOrderType" AS ENUM ('REGULER', 'NARKOTIKA', 'PSIKOTROPIKA', 'PREKURSOR', 'OOT');
CREATE TYPE "PurchaseOrderStatus" AS ENUM ('DRAFT', 'SENT', 'PARTIAL', 'RECEIVED', 'CANCELLED');
CREATE TYPE "GoodsReceiptStatus" AS ENUM ('DRAFT', 'POSTED', 'CANCELLED');
CREATE TYPE "ReceiptCondition" AS ENUM ('OK', 'DAMAGED', 'REJECTED');

-- TABEL: Surat Pesanan (SP) -----------------------------------------------------
CREATE TABLE "purchase_orders" (
  "id" UUID NOT NULL,
  "po_no" VARCHAR(50) NOT NULL,
  "supplier_id" UUID NOT NULL,
  "order_type" "PurchaseOrderType" NOT NULL DEFAULT 'REGULER',
  "status" "PurchaseOrderStatus" NOT NULL DEFAULT 'DRAFT',
  "expected_date" DATE,
  "notes" VARCHAR(500),
  "created_by" UUID NOT NULL,
  "signed_by" UUID,
  "signed_at" TIMESTAMPTZ(6),
  "cancelled_at" TIMESTAMPTZ(6),
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "purchase_orders_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "purchase_orders_po_no_key" UNIQUE ("po_no"),
  CONSTRAINT "po_no_chk" CHECK (length(btrim("po_no")) >= 1),
  CONSTRAINT "purchase_orders_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_orders_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_orders_signed_by_fkey" FOREIGN KEY ("signed_by") REFERENCES "users"("id") ON DELETE RESTRICT
);
CREATE INDEX "purchase_orders_supplier_id_created_at_idx" ON "purchase_orders" ("supplier_id", "created_at");
CREATE INDEX "purchase_orders_status_idx" ON "purchase_orders" ("status");

-- TABEL: baris SP ----------------------------------------------------------------
CREATE TABLE "purchase_order_items" (
  "id" UUID NOT NULL,
  "po_id" UUID NOT NULL,
  "medicine_id" UUID NOT NULL,
  "unit_id" UUID NOT NULL,
  "qty_ordered" INTEGER NOT NULL,
  "qty_received_base" INTEGER NOT NULL DEFAULT 0,
  "price" DECIMAL(18,2) NOT NULL,
  "discount_pct" DECIMAL(5,2) NOT NULL DEFAULT 0,
  CONSTRAINT "purchase_order_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "po_items_qty_ordered_chk" CHECK ("qty_ordered" > 0),
  CONSTRAINT "po_items_qty_received_chk" CHECK ("qty_received_base" >= 0),
  CONSTRAINT "po_items_price_chk" CHECK ("price" >= 0),
  CONSTRAINT "po_items_discount_chk" CHECK ("discount_pct" >= 0 AND "discount_pct" <= 100),
  CONSTRAINT "purchase_order_items_po_id_fkey" FOREIGN KEY ("po_id") REFERENCES "purchase_orders"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_order_items_medicine_id_fkey" FOREIGN KEY ("medicine_id") REFERENCES "medicines"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_order_items_unit_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "units"("id") ON DELETE RESTRICT
);
CREATE INDEX "purchase_order_items_po_id_idx" ON "purchase_order_items" ("po_id");

-- TABEL: Penerimaan Barang --------------------------------------------------------
CREATE TABLE "goods_receipts" (
  "id" UUID NOT NULL,
  "gr_no" VARCHAR(50) NOT NULL,
  "po_id" UUID,
  "supplier_id" UUID NOT NULL,
  "supplier_do_no" VARCHAR(100),
  "received_at" TIMESTAMPTZ(6) NOT NULL,
  "status" "GoodsReceiptStatus" NOT NULL DEFAULT 'DRAFT',
  "checked_by" UUID NOT NULL,
  "posted_by" UUID,
  "posted_at" TIMESTAMPTZ(6),
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  CONSTRAINT "goods_receipts_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "goods_receipts_gr_no_key" UNIQUE ("gr_no"),
  CONSTRAINT "gr_no_chk" CHECK (length(btrim("gr_no")) >= 1),
  CONSTRAINT "goods_receipts_po_id_fkey" FOREIGN KEY ("po_id") REFERENCES "purchase_orders"("id") ON DELETE RESTRICT,
  CONSTRAINT "goods_receipts_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE RESTRICT,
  CONSTRAINT "goods_receipts_checked_by_fkey" FOREIGN KEY ("checked_by") REFERENCES "users"("id") ON DELETE RESTRICT,
  CONSTRAINT "goods_receipts_posted_by_fkey" FOREIGN KEY ("posted_by") REFERENCES "users"("id") ON DELETE RESTRICT
);
CREATE INDEX "goods_receipts_supplier_id_received_at_idx" ON "goods_receipts" ("supplier_id", "received_at");
CREATE INDEX "goods_receipts_status_idx" ON "goods_receipts" ("status");

-- TABEL: baris Penerimaan Barang ---------------------------------------------------
CREATE TABLE "goods_receipt_items" (
  "id" UUID NOT NULL,
  "gr_id" UUID NOT NULL,
  "po_item_id" UUID,
  "medicine_id" UUID NOT NULL,
  "unit_id" UUID NOT NULL,
  "qty" INTEGER NOT NULL,
  "qty_base" INTEGER NOT NULL,
  "batch_no" VARCHAR(50) NOT NULL,
  "expiry_date" DATE NOT NULL,
  "unit_cost" DECIMAL(18,4) NOT NULL,
  "condition" "ReceiptCondition" NOT NULL DEFAULT 'OK',
  "notes" VARCHAR(300),
  CONSTRAINT "goods_receipt_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "gr_items_qty_chk" CHECK ("qty" > 0),
  CONSTRAINT "gr_items_qty_base_chk" CHECK ("qty_base" > 0),
  CONSTRAINT "gr_items_cost_chk" CHECK ("unit_cost" >= 0),
  CONSTRAINT "gr_items_batch_no_chk" CHECK (length(btrim("batch_no")) >= 1),
  CONSTRAINT "goods_receipt_items_gr_id_fkey" FOREIGN KEY ("gr_id") REFERENCES "goods_receipts"("id") ON DELETE RESTRICT,
  CONSTRAINT "goods_receipt_items_po_item_id_fkey" FOREIGN KEY ("po_item_id") REFERENCES "purchase_order_items"("id") ON DELETE RESTRICT,
  CONSTRAINT "goods_receipt_items_medicine_id_fkey" FOREIGN KEY ("medicine_id") REFERENCES "medicines"("id") ON DELETE RESTRICT,
  CONSTRAINT "goods_receipt_items_unit_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "units"("id") ON DELETE RESTRICT
);
CREATE INDEX "goods_receipt_items_gr_id_idx" ON "goods_receipt_items" ("gr_id");

-- medicine_batches: tautan ke item penerimaan barang asal (null untuk saldo awal) --
ALTER TABLE "medicine_batches" ADD COLUMN "goods_receipt_item_id" UUID;
ALTER TABLE "medicine_batches" ADD CONSTRAINT "medicine_batches_goods_receipt_item_id_key" UNIQUE ("goods_receipt_item_id");
ALTER TABLE "medicine_batches" ADD CONSTRAINT "medicine_batches_goods_receipt_item_id_fkey"
  FOREIGN KEY ("goods_receipt_item_id") REFERENCES "goods_receipt_items"("id") ON DELETE RESTRICT;

-- TABEL: Retur Pembelian ------------------------------------------------------------
CREATE TABLE "purchase_returns" (
  "id" UUID NOT NULL,
  "return_no" VARCHAR(50) NOT NULL,
  "supplier_id" UUID NOT NULL,
  "status" "DocStatus" NOT NULL DEFAULT 'DRAFT',
  "notes" VARCHAR(500),
  "created_by" UUID NOT NULL,
  "approval_id" UUID,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "posted_at" TIMESTAMPTZ(6),
  CONSTRAINT "purchase_returns_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "purchase_returns_return_no_key" UNIQUE ("return_no"),
  CONSTRAINT "return_no_chk" CHECK (length(btrim("return_no")) >= 1),
  CONSTRAINT "purchase_returns_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_returns_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_returns_approval_id_fkey" FOREIGN KEY ("approval_id") REFERENCES "approvals"("id") ON DELETE RESTRICT
);
CREATE INDEX "purchase_returns_supplier_id_created_at_idx" ON "purchase_returns" ("supplier_id", "created_at");

-- TABEL: baris Retur Pembelian ---------------------------------------------------
CREATE TABLE "purchase_return_items" (
  "id" UUID NOT NULL,
  "return_id" UUID NOT NULL,
  "batch_id" UUID NOT NULL,
  "bucket" "StockBucket" NOT NULL,
  "qty" INTEGER NOT NULL,
  "unit_cost" DECIMAL(18,4) NOT NULL,
  "reason" VARCHAR(300) NOT NULL,
  CONSTRAINT "purchase_return_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "return_items_qty_chk" CHECK ("qty" > 0),
  CONSTRAINT "return_items_cost_chk" CHECK ("unit_cost" >= 0),
  CONSTRAINT "return_items_reason_chk" CHECK (length(btrim("reason")) >= 1),
  CONSTRAINT "purchase_return_items_return_id_fkey" FOREIGN KEY ("return_id") REFERENCES "purchase_returns"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_return_items_batch_id_fkey" FOREIGN KEY ("batch_id") REFERENCES "medicine_batches"("id") ON DELETE RESTRICT
);
CREATE INDEX "purchase_return_items_return_id_idx" ON "purchase_return_items" ("return_id");
