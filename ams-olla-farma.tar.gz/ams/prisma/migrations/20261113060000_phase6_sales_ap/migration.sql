-- Fase 6 — Penjualan & Kasir, Retur Penjualan, Faktur Pembelian & Utang Dagang.
-- Penambahan MovementType: SALE (keluar stok penjualan) dan SALE_RETURN (masuk dari retur).
-- Customer/pasien, sesi kasir, transaksi penjualan FEFO, resep dokter,
-- retur penjualan maker-checker, faktur pembelian, dan pembayaran ke pemasok.

-- ALTER TYPE harus auto-commit sendiri sebelum dipakai di tabel berikutnya.
ALTER TYPE "MovementType" ADD VALUE 'SALE';
ALTER TYPE "MovementType" ADD VALUE 'SALE_RETURN';

-- ENUM baru -------------------------------------------------------------------
CREATE TYPE "PaymentMethod" AS ENUM ('CASH', 'RECEIVABLE');
CREATE TYPE "SaleSessionStatus" AS ENUM ('OPEN', 'CLOSED');
CREATE TYPE "SaleStatus" AS ENUM ('ACTIVE', 'CANCELLED');
CREATE TYPE "SaleReturnStatus" AS ENUM ('DRAFT', 'POSTED', 'CANCELLED');
CREATE TYPE "ReturnDisposition" AS ENUM ('RESTOCK', 'QUARANTINE', 'DISPOSE');
CREATE TYPE "InvoiceStatus" AS ENUM ('UNPAID', 'PARTIAL', 'PAID');
CREATE TYPE "PrescriptionStatus" AS ENUM ('PENDING', 'VERIFIED', 'DISPENSED', 'CANCELLED');

-- TABEL: customers -------------------------------------------------------------
CREATE TABLE "customers" (
  "id" UUID NOT NULL,
  "code" VARCHAR(20) NOT NULL,
  "name" VARCHAR(200) NOT NULL,
  "phone" VARCHAR(30),
  "address" VARCHAR(500),
  "date_of_birth" DATE,
  "credit_limit" DECIMAL(18,2) NOT NULL DEFAULT 0,
  "credit_used" DECIMAL(18,2) NOT NULL DEFAULT 0,
  "notes" VARCHAR(500),
  "is_active" BOOLEAN NOT NULL DEFAULT true,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "customers_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "customers_code_key" UNIQUE ("code"),
  CONSTRAINT "customer_code_chk" CHECK (length(btrim("code")) >= 1),
  CONSTRAINT "customer_name_chk" CHECK (length(btrim("name")) >= 1),
  CONSTRAINT "customer_credit_limit_chk" CHECK ("credit_limit" >= 0),
  CONSTRAINT "customer_credit_used_chk" CHECK ("credit_used" >= 0)
);
CREATE INDEX "customers_phone_idx" ON "customers" ("phone");
CREATE INDEX "customers_name_trgm_idx" ON "customers" USING GIN ("name" gin_trgm_ops);

-- TABEL: sale_sessions ---------------------------------------------------------
CREATE TABLE "sale_sessions" (
  "id" UUID NOT NULL,
  "session_no" VARCHAR(50) NOT NULL,
  "cashier_id" UUID NOT NULL,
  "status" "SaleSessionStatus" NOT NULL DEFAULT 'OPEN',
  "opened_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "closed_at" TIMESTAMPTZ(6),
  "opening_cash" DECIMAL(18,2) NOT NULL,
  "closing_cash" DECIMAL(18,2),
  "expected_cash" DECIMAL(18,2),
  "cash_difference" DECIMAL(18,2),
  "notes" VARCHAR(500),
  CONSTRAINT "sale_sessions_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sale_sessions_session_no_key" UNIQUE ("session_no"),
  CONSTRAINT "session_no_chk" CHECK (length(btrim("session_no")) >= 1),
  CONSTRAINT "session_opening_cash_chk" CHECK ("opening_cash" >= 0),
  CONSTRAINT "sale_sessions_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT
);
CREATE INDEX "sale_sessions_cashier_id_opened_at_idx" ON "sale_sessions" ("cashier_id", "opened_at");
CREATE INDEX "sale_sessions_status_idx" ON "sale_sessions" ("status");

-- Pastikan kasir tidak punya lebih dari satu sesi OPEN sekaligus
CREATE UNIQUE INDEX "sale_sessions_cashier_open_unique_idx"
  ON "sale_sessions" ("cashier_id")
  WHERE "status" = 'OPEN';

-- TABEL: prescriptions ---------------------------------------------------------
CREATE TABLE "prescriptions" (
  "id" UUID NOT NULL,
  "rx_no" VARCHAR(50) NOT NULL,
  "customer_id" UUID,
  "doctor_name" VARCHAR(200) NOT NULL,
  "doctor_sip" VARCHAR(50),
  "clinic_name" VARCHAR(200),
  "prescribed_at" DATE NOT NULL,
  "status" "PrescriptionStatus" NOT NULL DEFAULT 'PENDING',
  "notes" VARCHAR(500),
  "created_by" UUID NOT NULL,
  "verified_by" UUID,
  "verified_at" TIMESTAMPTZ(6),
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  CONSTRAINT "prescriptions_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "prescriptions_rx_no_key" UNIQUE ("rx_no"),
  CONSTRAINT "rx_no_chk" CHECK (length(btrim("rx_no")) >= 1),
  CONSTRAINT "rx_doctor_name_chk" CHECK (length(btrim("doctor_name")) >= 1),
  CONSTRAINT "prescriptions_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "customers"("id") ON DELETE RESTRICT,
  CONSTRAINT "prescriptions_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT,
  CONSTRAINT "prescriptions_verified_by_fkey" FOREIGN KEY ("verified_by") REFERENCES "users"("id") ON DELETE RESTRICT
);
CREATE INDEX "prescriptions_customer_id_prescribed_at_idx" ON "prescriptions" ("customer_id", "prescribed_at");
CREATE INDEX "prescriptions_status_idx" ON "prescriptions" ("status");

-- TABEL: prescription_items ----------------------------------------------------
CREATE TABLE "prescription_items" (
  "id" UUID NOT NULL,
  "prescription_id" UUID NOT NULL,
  "medicine_id" UUID NOT NULL,
  "qty_prescribed" INTEGER NOT NULL,
  "instructions" VARCHAR(300) NOT NULL,
  "notes" VARCHAR(300),
  CONSTRAINT "prescription_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "rx_items_qty_chk" CHECK ("qty_prescribed" > 0),
  CONSTRAINT "prescription_items_prescription_id_fkey" FOREIGN KEY ("prescription_id") REFERENCES "prescriptions"("id") ON DELETE RESTRICT,
  CONSTRAINT "prescription_items_medicine_id_fkey" FOREIGN KEY ("medicine_id") REFERENCES "medicines"("id") ON DELETE RESTRICT
);
CREATE INDEX "prescription_items_prescription_id_idx" ON "prescription_items" ("prescription_id");

-- TABEL: sales -----------------------------------------------------------------
CREATE TABLE "sales" (
  "id" UUID NOT NULL,
  "invoice_no" VARCHAR(50) NOT NULL,
  "session_id" UUID NOT NULL,
  "cashier_id" UUID NOT NULL,
  "customer_id" UUID,
  "prescription_id" UUID,
  "status" "SaleStatus" NOT NULL DEFAULT 'ACTIVE',
  "payment_method" "PaymentMethod" NOT NULL DEFAULT 'CASH',
  "subtotal" DECIMAL(18,2) NOT NULL,
  "discount_amount" DECIMAL(18,2) NOT NULL DEFAULT 0,
  "total_amount" DECIMAL(18,2) NOT NULL,
  "amount_paid" DECIMAL(18,2) NOT NULL,
  "change_given" DECIMAL(18,2) NOT NULL DEFAULT 0,
  "notes" VARCHAR(500),
  "sold_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "cancelled_at" TIMESTAMPTZ(6),
  "cancelled_by" UUID,
  CONSTRAINT "sales_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sales_invoice_no_key" UNIQUE ("invoice_no"),
  CONSTRAINT "sales_prescription_id_key" UNIQUE ("prescription_id"),
  CONSTRAINT "invoice_no_chk" CHECK (length(btrim("invoice_no")) >= 1),
  CONSTRAINT "sales_subtotal_chk" CHECK ("subtotal" >= 0),
  CONSTRAINT "sales_discount_chk" CHECK ("discount_amount" >= 0),
  CONSTRAINT "sales_total_chk" CHECK ("total_amount" >= 0),
  CONSTRAINT "sales_paid_chk" CHECK ("amount_paid" >= 0),
  CONSTRAINT "sales_change_chk" CHECK ("change_given" >= 0),
  CONSTRAINT "sales_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "sale_sessions"("id") ON DELETE RESTRICT,
  CONSTRAINT "sales_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT,
  CONSTRAINT "sales_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "customers"("id") ON DELETE RESTRICT,
  CONSTRAINT "sales_prescription_id_fkey" FOREIGN KEY ("prescription_id") REFERENCES "prescriptions"("id") ON DELETE RESTRICT,
  CONSTRAINT "sales_cancelled_by_fkey" FOREIGN KEY ("cancelled_by") REFERENCES "users"("id") ON DELETE RESTRICT
);
CREATE INDEX "sales_session_id_sold_at_idx" ON "sales" ("session_id", "sold_at");
CREATE INDEX "sales_customer_id_sold_at_idx" ON "sales" ("customer_id", "sold_at");
CREATE INDEX "sales_status_idx" ON "sales" ("status");
CREATE INDEX "sales_sold_at_idx" ON "sales" ("sold_at");

-- TABEL: sale_items ------------------------------------------------------------
CREATE TABLE "sale_items" (
  "id" UUID NOT NULL,
  "sale_id" UUID NOT NULL,
  "medicine_id" UUID NOT NULL,
  "batch_id" UUID NOT NULL,
  "unit_id" UUID NOT NULL,
  "qty" INTEGER NOT NULL,
  "qty_base" INTEGER NOT NULL,
  "unit_price" DECIMAL(18,2) NOT NULL,
  "unit_cost" DECIMAL(18,4) NOT NULL,
  "discount_pct" DECIMAL(5,2) NOT NULL DEFAULT 0,
  "line_total" DECIMAL(18,2) NOT NULL,
  CONSTRAINT "sale_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sale_items_qty_chk" CHECK ("qty" > 0),
  CONSTRAINT "sale_items_qty_base_chk" CHECK ("qty_base" > 0),
  CONSTRAINT "sale_items_price_chk" CHECK ("unit_price" >= 0),
  CONSTRAINT "sale_items_cost_chk" CHECK ("unit_cost" >= 0),
  CONSTRAINT "sale_items_discount_chk" CHECK ("discount_pct" >= 0 AND "discount_pct" <= 100),
  CONSTRAINT "sale_items_total_chk" CHECK ("line_total" >= 0),
  CONSTRAINT "sale_items_sale_id_fkey" FOREIGN KEY ("sale_id") REFERENCES "sales"("id") ON DELETE RESTRICT,
  CONSTRAINT "sale_items_medicine_id_fkey" FOREIGN KEY ("medicine_id") REFERENCES "medicines"("id") ON DELETE RESTRICT,
  CONSTRAINT "sale_items_batch_id_fkey" FOREIGN KEY ("batch_id") REFERENCES "medicine_batches"("id") ON DELETE RESTRICT,
  CONSTRAINT "sale_items_unit_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "units"("id") ON DELETE RESTRICT
);
CREATE INDEX "sale_items_sale_id_idx" ON "sale_items" ("sale_id");
CREATE INDEX "sale_items_medicine_id_sale_id_idx" ON "sale_items" ("medicine_id", "sale_id");

-- TABEL: sale_returns ----------------------------------------------------------
CREATE TABLE "sale_returns" (
  "id" UUID NOT NULL,
  "return_no" VARCHAR(50) NOT NULL,
  "sale_id" UUID NOT NULL,
  "status" "SaleReturnStatus" NOT NULL DEFAULT 'DRAFT',
  "notes" VARCHAR(500),
  "received_by" UUID NOT NULL,
  "approval_id" UUID,
  "posted_at" TIMESTAMPTZ(6),
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  CONSTRAINT "sale_returns_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sale_returns_return_no_key" UNIQUE ("return_no"),
  CONSTRAINT "sale_return_no_chk" CHECK (length(btrim("return_no")) >= 1),
  CONSTRAINT "sale_returns_sale_id_fkey" FOREIGN KEY ("sale_id") REFERENCES "sales"("id") ON DELETE RESTRICT,
  CONSTRAINT "sale_returns_received_by_fkey" FOREIGN KEY ("received_by") REFERENCES "users"("id") ON DELETE RESTRICT,
  CONSTRAINT "sale_returns_approval_id_fkey" FOREIGN KEY ("approval_id") REFERENCES "approvals"("id") ON DELETE RESTRICT
);
CREATE INDEX "sale_returns_sale_id_idx" ON "sale_returns" ("sale_id");
CREATE INDEX "sale_returns_status_idx" ON "sale_returns" ("status");

-- TABEL: sale_return_items -----------------------------------------------------
CREATE TABLE "sale_return_items" (
  "id" UUID NOT NULL,
  "return_id" UUID NOT NULL,
  "sale_item_id" UUID NOT NULL,
  "batch_id" UUID NOT NULL,
  "qty" INTEGER NOT NULL,
  "qty_base" INTEGER NOT NULL,
  "unit_price" DECIMAL(18,2) NOT NULL,
  "disposition" "ReturnDisposition" NOT NULL DEFAULT 'RESTOCK',
  "reason" VARCHAR(300) NOT NULL,
  CONSTRAINT "sale_return_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sale_return_items_qty_chk" CHECK ("qty" > 0),
  CONSTRAINT "sale_return_items_qty_base_chk" CHECK ("qty_base" > 0),
  CONSTRAINT "sale_return_items_reason_chk" CHECK (length(btrim("reason")) >= 1),
  CONSTRAINT "sale_return_items_return_id_fkey" FOREIGN KEY ("return_id") REFERENCES "sale_returns"("id") ON DELETE RESTRICT,
  CONSTRAINT "sale_return_items_sale_item_id_fkey" FOREIGN KEY ("sale_item_id") REFERENCES "sale_items"("id") ON DELETE RESTRICT,
  CONSTRAINT "sale_return_items_batch_id_fkey" FOREIGN KEY ("batch_id") REFERENCES "medicine_batches"("id") ON DELETE RESTRICT
);
CREATE INDEX "sale_return_items_return_id_idx" ON "sale_return_items" ("return_id");

-- TABEL: purchase_invoices -----------------------------------------------------
CREATE TABLE "purchase_invoices" (
  "id" UUID NOT NULL,
  "invoice_no" VARCHAR(50) NOT NULL,
  "supplier_inv_no" VARCHAR(100),
  "gr_id" UUID NOT NULL,
  "supplier_id" UUID NOT NULL,
  "status" "InvoiceStatus" NOT NULL DEFAULT 'UNPAID',
  "invoice_date" DATE NOT NULL,
  "due_date" DATE NOT NULL,
  "subtotal" DECIMAL(18,2) NOT NULL,
  "tax_amount" DECIMAL(18,2) NOT NULL DEFAULT 0,
  "total_amount" DECIMAL(18,2) NOT NULL,
  "amount_paid" DECIMAL(18,2) NOT NULL DEFAULT 0,
  "notes" VARCHAR(500),
  "created_by" UUID NOT NULL,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  "updated_at" TIMESTAMPTZ(6) NOT NULL,
  CONSTRAINT "purchase_invoices_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "purchase_invoices_invoice_no_key" UNIQUE ("invoice_no"),
  CONSTRAINT "purchase_invoices_gr_id_key" UNIQUE ("gr_id"),
  CONSTRAINT "inv_no_chk" CHECK (length(btrim("invoice_no")) >= 1),
  CONSTRAINT "inv_subtotal_chk" CHECK ("subtotal" >= 0),
  CONSTRAINT "inv_tax_chk" CHECK ("tax_amount" >= 0),
  CONSTRAINT "inv_total_chk" CHECK ("total_amount" >= 0),
  CONSTRAINT "inv_paid_chk" CHECK ("amount_paid" >= 0),
  CONSTRAINT "purchase_invoices_gr_id_fkey" FOREIGN KEY ("gr_id") REFERENCES "goods_receipts"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_invoices_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE RESTRICT,
  CONSTRAINT "purchase_invoices_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT
);
CREATE INDEX "purchase_invoices_supplier_id_due_date_idx" ON "purchase_invoices" ("supplier_id", "due_date");
CREATE INDEX "purchase_invoices_status_idx" ON "purchase_invoices" ("status");

-- TABEL: supplier_payments -----------------------------------------------------
CREATE TABLE "supplier_payments" (
  "id" UUID NOT NULL,
  "payment_no" VARCHAR(50) NOT NULL,
  "invoice_id" UUID NOT NULL,
  "supplier_id" UUID NOT NULL,
  "payment_date" DATE NOT NULL,
  "amount" DECIMAL(18,2) NOT NULL,
  "reference_no" VARCHAR(100),
  "notes" VARCHAR(300),
  "paid_by" UUID NOT NULL,
  "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT now(),
  CONSTRAINT "supplier_payments_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "supplier_payments_payment_no_key" UNIQUE ("payment_no"),
  CONSTRAINT "payment_no_chk" CHECK (length(btrim("payment_no")) >= 1),
  CONSTRAINT "payment_amount_chk" CHECK ("amount" > 0),
  CONSTRAINT "supplier_payments_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "purchase_invoices"("id") ON DELETE RESTRICT,
  CONSTRAINT "supplier_payments_supplier_id_fkey" FOREIGN KEY ("supplier_id") REFERENCES "suppliers"("id") ON DELETE RESTRICT,
  CONSTRAINT "supplier_payments_paid_by_fkey" FOREIGN KEY ("paid_by") REFERENCES "users"("id") ON DELETE RESTRICT
);
CREATE INDEX "supplier_payments_invoice_id_idx" ON "supplier_payments" ("invoice_id");
CREATE INDEX "supplier_payments_supplier_id_payment_date_idx" ON "supplier_payments" ("supplier_id", "payment_date");

-- Tambah NumberSequence untuk nomor urut baru ----------------------------------
-- (dilakukan via seed/service saat pertama kali dibutuhkan, bukan di sini)

-- Trigger APPEND-ONLY sudah ada dari Fase 4; tidak ada perubahan pada fungsi
-- ams_apply_stock_movement — movement_type SALE dan SALE_RETURN ditangani
-- di service layer, bukan lewat trigger khusus.
