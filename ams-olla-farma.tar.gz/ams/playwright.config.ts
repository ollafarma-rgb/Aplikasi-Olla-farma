import { defineConfig, devices } from '@playwright/test';

/**
 * E2E memakai database tes yang sudah dimigrasi + di-seed (scripts/test-db.sh)
 * dan aplikasi yang berjalan di port 3100.
 */
export default defineConfig({
  testDir: 'tests/e2e',
  fullyParallel: false,
  retries: process.env.CI ? 1 : 0,
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:3100',
    locale: 'id-ID',
    timezoneId: 'Asia/Jakarta',
    trace: 'retain-on-failure',
  },
  projects: [
    { name: 'desktop-chrome', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['Pixel 7'] } },
  ],
  webServer: process.env.E2E_BASE_URL
    ? undefined
    : { command: 'npm run build && npx next start -p 3100', port: 3100, timeout: 180_000, reuseExistingServer: true },
});
