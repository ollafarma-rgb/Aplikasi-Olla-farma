#!/usr/bin/env bash
# Siapkan database uji bersih: buat ulang, semua migrasi, hak akses ams_app, seed (+ owner.test).
# Pakai: scripts/prepare-db.sh <nama_db>   (butuh superuser PostgreSQL lokal lewat PGUSER/socket)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DB="${1:?nama database}"
case "$DB" in *prod*) echo "Menolak: nama database mengandung 'prod'"; exit 1;; esac
PSQL=(psql -X -q -v ON_ERROR_STOP=1)
"${PSQL[@]}" -d postgres -c "DROP DATABASE IF EXISTS \"$DB\" WITH (FORCE);" -c "CREATE DATABASE \"$DB\";"
"${PSQL[@]}" -d postgres -c "DO \$\$BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ams_app') THEN CREATE ROLE ams_app LOGIN PASSWORD 'ams_app_dev'; END IF; END\$\$;"
for m in "$ROOT"/prisma/migrations/*/migration.sql; do "${PSQL[@]}" -d "$DB" -f "$m"; done
"${PSQL[@]}" -d "$DB" -v app_role=ams_app -f "$ROOT/infra/db/app-role.sql"
(cd "$ROOT" && node_modules/.bin/tsx scripts/print-seed-sql.ts --test-owner) | "${PSQL[@]}" -d "$DB"
