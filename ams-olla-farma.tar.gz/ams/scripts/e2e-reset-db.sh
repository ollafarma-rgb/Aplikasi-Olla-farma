#!/usr/bin/env bash
# Kembalikan database E2E ke kondisi bersih: buat ulang, migrasi, hak akses, seed.
# Memakai MIGRATION_DATABASE_URL dari .env (database KHUSUS tes/dev, jangan produksi).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
set -a; source "$ROOT/.env"; set +a

DB_NAME="$(python3 -c "import sys,urllib.parse as u; print(u.urlparse(sys.argv[1]).path.lstrip('/'))" "$MIGRATION_DATABASE_URL")"
ADMIN_URL="$(python3 -c "import sys,urllib.parse as u; p=u.urlparse(sys.argv[1]); print(p._replace(path='/postgres').geturl())" "$MIGRATION_DATABASE_URL")"
case "$DB_NAME" in *prod*) echo "Menolak: nama database mengandung 'prod'"; exit 1;; esac

psql -X -q -v ON_ERROR_STOP=1 "$ADMIN_URL" -c "DROP DATABASE IF EXISTS \"$DB_NAME\" WITH (FORCE);" -c "CREATE DATABASE \"$DB_NAME\";"
for m in "$ROOT"/prisma/migrations/*/migration.sql; do
  psql -X -q -v ON_ERROR_STOP=1 "$MIGRATION_DATABASE_URL" -f "$m"
done
psql -X -q -v ON_ERROR_STOP=1 "$MIGRATION_DATABASE_URL" -v app_role=ams_app -f "$ROOT/infra/db/app-role.sql"
(cd "$ROOT" && npx tsx prisma/seed.ts)
echo "Database $DB_NAME siap untuk E2E."
