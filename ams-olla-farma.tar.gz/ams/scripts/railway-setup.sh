#!/bin/bash
# ============================================================
# railway-setup.sh — Jalankan SEKALI setelah deploy pertama
# di Railway via: railway run bash scripts/railway-setup.sh
# ============================================================
set -e

echo "=== AMS Railway Setup ==="
echo ""

# 1. Migrate database
echo "[1/2] Menjalankan migrasi database..."
DATABASE_URL="${MIGRATION_DATABASE_URL:-$DATABASE_URL}" npx prisma migrate deploy
echo "    ✓ Migrasi selesai"

# 2. Seed data (izin, peran, satuan, pengaturan)
echo "[2/2] Seed data dasar..."
npm run db:seed
echo "    ✓ Seed selesai"

echo ""
echo "=== Setup selesai ==="
echo "Buka: https://<nama-app>.railway.app"
