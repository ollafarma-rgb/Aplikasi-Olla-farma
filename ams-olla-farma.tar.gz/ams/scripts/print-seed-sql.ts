/**
 * Cetak SQL seed ke stdout. Dipakai scripts/test-db.sh.
 * Opsi --test-owner menambahkan pengguna owner.test (HANYA untuk database tes).
 */
import { hashPassword } from '../src/lib/auth/password';
import { PERMISSIONS } from '../src/lib/permissions/catalog';
import { buildSeedSql } from '../prisma/seed/build-seed-sql';

async function main() {
  const args = process.argv.slice(2);
  if (args.includes('--count')) {
    process.stdout.write(String(PERMISSIONS.length));
    return;
  }
  const owner = args.includes('--test-owner')
    ? { username: 'owner.test', fullName: 'Owner Uji', passwordHash: await hashPassword('Uji-Sandi-Owner-2026') }
    : undefined;
  process.stdout.write(buildSeedSql({ owner }));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
