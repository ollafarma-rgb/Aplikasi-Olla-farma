#!/usr/bin/env bash
# Uji database terhadap PostgreSQL asli (bukan mock).
# Membuat database sementara, menerapkan semua migrasi, seed (dua kali untuk
# uji idempoten), lalu menjalankan semua file tests/integration/db/*.sql.
#
# Variabel: PGHOST/PGPORT/PGUSER (superuser lokal), TEST_DB (default ams_test).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEST_DB="${TEST_DB:-ams_test}"
APP_ROLE="ams_app"
TSX="${TSX:-$ROOT/node_modules/.bin/tsx}"
PSQL=(psql -X -q -v ON_ERROR_STOP=1)

echo "== Menyiapkan database $TEST_DB"
"${PSQL[@]}" -d postgres -c "DROP DATABASE IF EXISTS \"$TEST_DB\" WITH (FORCE);"
"${PSQL[@]}" -d postgres -c "CREATE DATABASE \"$TEST_DB\";"
"${PSQL[@]}" -d postgres -c "DO \$\$BEGIN IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '$APP_ROLE') THEN CREATE ROLE $APP_ROLE LOGIN; END IF; END\$\$;"

echo "== Menerapkan migrasi"
for m in "$ROOT"/prisma/migrations/*/migration.sql; do
  echo "   $(basename "$(dirname "$m")")"
  "${PSQL[@]}" -d "$TEST_DB" -f "$m"
done
"${PSQL[@]}" -d "$TEST_DB" -v app_role="$APP_ROLE" -f "$ROOT/infra/db/app-role.sql"

echo "== Seed (dua kali, uji idempoten)"
SEED_SQL="$(mktemp)"
(cd "$ROOT" && "$TSX" scripts/print-seed-sql.ts --test-owner) > "$SEED_SQL"
"${PSQL[@]}" -d "$TEST_DB" -f "$SEED_SQL"
BEFORE="$("${PSQL[@]}" -tA -d "$TEST_DB" -c "SELECT (SELECT count(*) FROM permissions)||'/'||(SELECT count(*) FROM role_permissions)||'/'||(SELECT count(*) FROM pharmacy_settings)")"
"${PSQL[@]}" -d "$TEST_DB" -f "$SEED_SQL"
AFTER="$("${PSQL[@]}" -tA -d "$TEST_DB" -c "SELECT (SELECT count(*) FROM permissions)||'/'||(SELECT count(*) FROM role_permissions)||'/'||(SELECT count(*) FROM pharmacy_settings)")"
rm -f "$SEED_SQL"
if [[ "$BEFORE" != "$AFTER" ]]; then echo "GAGAL: seed tidak idempoten ($BEFORE vs $AFTER)"; exit 1; fi
echo "LULUS: seed idempoten ($AFTER izin/hak peran/pengaturan)"

PERM_COUNT="$(cd "$ROOT" && "$TSX" scripts/print-seed-sql.ts --count)"
"${PSQL[@]}" -d "$TEST_DB" -f "$ROOT/tests/integration/db/_helpers.sql"
"${PSQL[@]}" -d "$TEST_DB" -c "GRANT USAGE ON SCHEMA amstest TO $APP_ROLE; GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA amstest TO $APP_ROLE;"

echo "== Uji fungsional (superuser)"
"${PSQL[@]}" -d "$TEST_DB" -v perm_count="$PERM_COUNT" -f "$ROOT/tests/integration/db/001_phase2_foundation.sql" 2>&1 | sed -n -e 's/.*NOTICE:  //p' -e '/ERROR/p'

echo "== Uji master data Fase 3 (superuser)"
"${PSQL[@]}" -d "$TEST_DB" -f "$ROOT/tests/integration/db/003_phase3_master_data.sql" 2>&1 | sed -n -e 's/.*NOTICE:  //p' -e '/ERROR/p'

echo "== Uji persediaan Fase 4 (superuser)"
"${PSQL[@]}" -d "$TEST_DB" -f "$ROOT/tests/integration/db/004_phase4_inventory.sql" 2>&1 | sed -n -e 's/.*NOTICE:  //p' -e '/ERROR/p'

echo "== Uji pengadaan Fase 5 (superuser)"
"${PSQL[@]}" -d "$TEST_DB" -f "$ROOT/tests/integration/db/005_phase5_procurement.sql" 2>&1 | sed -n -e 's/.*NOTICE:  //p' -e '/ERROR/p'

echo "== Uji hak akses (sebagai $APP_ROLE)"
"${PSQL[@]}" -d "$TEST_DB" -c "SET ROLE $APP_ROLE;" -f "$ROOT/tests/integration/db/002_app_role_privileges.sql" 2>&1 | sed -n -e 's/.*NOTICE:  //p' -e '/ERROR/p'

echo "== Uji konkurensi penomoran (4 sesi paralel x 250 nomor)"
"${PSQL[@]}" -d "$TEST_DB" -c "CREATE TABLE amstest.nums (v int);"
for i in 1 2 3 4; do
  "${PSQL[@]}" -d "$TEST_DB" -c "INSERT INTO amstest.nums SELECT ams_next_number('KONK', '2611') FROM generate_series(1,250);" &
done
wait
RESULT="$("${PSQL[@]}" -tA -d "$TEST_DB" -c "SELECT count(*)||'/'||count(DISTINCT v)||'/'||max(v) FROM amstest.nums")"
if [[ "$RESULT" != "1000/1000/1000" ]]; then echo "GAGAL: penomoran paralel menghasilkan duplikat/lompatan ($RESULT)"; exit 1; fi
echo "LULUS: 1000 nomor paralel unik dan berurutan tanpa celah ($RESULT)"

echo "== Uji konkurensi rantai audit (4 sesi paralel x 100 baris)"
for i in 1 2 3 4; do
  "${PSQL[@]}" -d "$TEST_DB" -c "SET ROLE $APP_ROLE; INSERT INTO audit_logs (action, entity) SELECT 'auth.login.failed', 'user' FROM generate_series(1,100);" &
done
wait
BROKEN="$("${PSQL[@]}" -tA -d "$TEST_DB" -c "SELECT coalesce(ams_audit_verify_chain()::text, 'utuh')")"
if [[ "$BROKEN" != "utuh" ]]; then echo "GAGAL: rantai audit rusak pada id $BROKEN"; exit 1; fi
echo "LULUS: 400 baris audit paralel, rantai hash tetap utuh"

echo "== SEMUA UJI DATABASE LULUS"
