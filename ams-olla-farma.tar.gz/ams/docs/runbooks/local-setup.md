# Menjalankan AMS di komputer lokal

Prasyarat: Node.js 22.12+, PostgreSQL 16 (atau Docker), akses internet untuk `npm install`.

```bash
# 1. Paket
npm install

# 2. Database lokal (Docker) — atau pakai PostgreSQL 16 yang sudah ada
docker compose up -d db
psql "postgresql://ams_owner:ams_owner_dev@localhost:5432/ams" -c "CREATE ROLE ams_app LOGIN PASSWORD 'ams_app_dev';"
psql "postgresql://ams_owner:ams_owner_dev@localhost:5432/postgres" -c "CREATE DATABASE ams_shadow;"

# 3. Konfigurasi
cp .env.example .env.local   # isi sandi; isi SEED_OWNER_PASSWORD sekali saja
cp .env.local .env           # prisma.config.ts memuat .env lewat dotenv

# 4. Migrasi, hak akses aplikasi, client, seed
npm run db:migrate
psql "$MIGRATION_DATABASE_URL" -v app_role=ams_app -f infra/db/app-role.sql
npm run db:generate
npm run db:seed

# 5. Pastikan skema Prisma = migrasi (harus tidak ada output SQL)
npm run db:drift

# 6. Jalankan
npm run dev     # http://localhost:3000
```

## Tes

```bash
npm run lint && npm run typecheck && npm test   # lint, tipe, Vitest
npm run test:db                                  # tes database (butuh superuser PostgreSQL lokal)
npm run build
npm run test:e2e:reset                           # buat ulang database dev untuk E2E
npx next start -p 3100 & E2E_BASE_URL=http://localhost:3100 npm run test:e2e
```

Hentikan server Next.js sebelum `test:e2e:reset` (database tidak bisa dihapus selama ada koneksi).

## Bila binaries.prisma.sh tidak bisa diakses

`prisma generate` tidak menjalankan schema engine, sehingga bisa dijalankan dengan
`PRISMA_SCHEMA_ENGINE_BINARY=/path/ke/file-kosong npx prisma generate`. Migrasi
(`migrate deploy`, `migrate diff`) tetap membutuhkan schema engine asli; tanpa itu,
terapkan `migration.sql` dengan `psql` hanya untuk development lokal.
