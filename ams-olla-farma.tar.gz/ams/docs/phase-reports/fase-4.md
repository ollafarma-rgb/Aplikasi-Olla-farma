# Laporan Fase 4 — Persediaan (Batch, Kartu Stok, Penyesuaian, Opname)

Tanggal: 12 November 2026 · Status: **selesai**, dengan satu pemeriksaan tertunda (`prisma migrate diff`, lihat Masalah diketahui)

## Lingkup

Mesin persediaan yang menjadi fondasi semua transaksi berikutnya: batch obat dengan HPP aktual dan tanggal kedaluwarsa, buku besar stok (kartu stok) yang append-only, saldo awal, perpindahan antar-bucket (siap jual / karantina / rusak), penyesuaian stok dengan persetujuan, dan stok opname. Belum ada penerimaan barang (Fase 5), sehingga stok masuk lewat saldo awal.

## Konsep inti

- **Batch** menyimpan stok per bucket (siap jual, karantina, rusak) beserta `unit_cost` = HPP aktual batch itu (keputusan Fase 1: HPP biaya aktual per batch).
- **Kartu stok** (`stock_movements`) adalah buku besar append-only: setiap perubahan stok menulis satu baris (jenis, dari→ke bucket, jumlah, HPP, referensi, pengguna). Saldo bucket di batch adalah cache yang diperbarui dalam transaksi yang sama.
- Satu fungsi database `ams_apply_stock_movement` mengunci baris batch, memeriksa stok tidak menjadi negatif, memperbarui cache, dan menulis kartu stok secara atomik. Identitas penulis diambil dari `ams.user_id` (sama seperti riwayat harga).
- **FEFO-ready**: batch diurutkan berdasarkan tanggal kedaluwarsa lalu waktu terima, siap dipakai modul penjualan.

## Fitur

- **Ringkasan persediaan**: stok per obat dari seluruh batch, nilai persediaan, filter "stok menipis" (≤ stok minimum) dan "akan/sudah kedaluwarsa" (≤ 90 hari), pencarian.
- **Kartu stok per obat**: daftar batch (bucket, ED, HPP) dan 100 pergerakan terakhir.
- **Saldo awal** (apoteker/pemilik): membuat batch + mencatat stok awal beserta HPP, tiap entri bernomor (`SALDO-YYMM-####`) dan masuk kartu stok.
- **Pindah bucket**: siap jual ↔ karantina ↔ rusak, total stok batch tetap kekal.
- **Penyesuaian stok** (maker-checker): dibuat sebagai draf oleh gudang/TTK, berlaku hanya setelah disetujui apoteker/pemilik; pembuat tidak boleh menyetujui dokumennya sendiri; setiap posting menulis kartu stok dan tercatat sebagai `Approval`.
- **Stok opname**: mulai (snapshot jumlah sistem) → hitung fisik → posting selisih. Posting membuat penyesuaian otomatis yang mengoreksi stok ke hasil hitung; pemosting harus berbeda dari pembuat.
- Obat, batch, dan kartu stok tidak bisa dihapus (nonaktif/koreksi saja).

## Perubahan database

Migrasi `20261112040000_phase4_inventory`: 6 tabel (medicine_batches, stock_movements, stock_adjustments, stock_adjustment_items, stock_opnames, stock_opname_items), 4 enum (StockBucket, MovementType, DocStatus, OpnameStatus), 15 foreign key, 12 CHECK constraint, 1 fungsi (`ams_apply_stock_movement`) dan 2 trigger baru (kartu stok append-only, batch tidak bisa dihapus) di atas fungsi bersama Fase 2/3. Hak `ams_app` dicabut untuk UPDATE/DELETE pada `stock_movements`.

## Versi

Next.js 16.4.6 · React 19.3.1 · Prisma 7.10.1 + `@prisma/adapter-pg` · PostgreSQL 16 · TypeScript 6.0.3 · Zod 4.6 · Tailwind 4.3.5 · Vitest 5.1 · Playwright 1.63.

## Perintah

```bash
npm run lint && npm run typecheck && npm test   # lint, tipe, tes unit + integrasi
npm run test:db                                  # tes database (PostgreSQL asli)
npm run test:e2e:reset && npm run test:e2e        # E2E (database tes dibuat ulang)
npm run build
```

## Hasil uji (12 Nov 2026)

| Uji | Hasil |
| --- | --- |
| ESLint | 0 masalah |
| TypeScript seluruh proyek | 0 error |
| Vitest (10 file, unit + integrasi) | 126 lulus |
| Database (4 file SQL + konkurensi paralel) | 99 pemeriksaan lulus |
| Playwright E2E, Chrome desktop | 14 lulus |
| Playwright E2E, ponsel (Pixel 7) | 14 lulus |
| `next build` | Berhasil (29 rute + proxy) |
| Kolom skema Prisma vs database hasil migrasi | cocok (`npm run db:drift` kosong) |
| `prisma migrate diff` | **Tertunda** |

Cakupan E2E Fase 4: saldo awal menambah stok dan muncul di kartu stok; filter stok menipis; penyesuaian — pembuat tidak bisa menyetujui sendiri, apoteker menyetujui dan stok berkurang; opname — hitung selisih lalu apoteker posting mengoreksi stok.

Cakupan uji integrasi Fase 4 (vitest): saldo awal (termasuk tolak non-apoteker dan batch duplikat), ringkasan & nilai stok, pindah bucket, penyesuaian maker-checker, posting melebihi stok ditolak tanpa mengubah stok, dan opname end-to-end.

## Uji database Fase 4 (SQL asli)

Saldo awal menambah bucket siap jual dan menulis kartu stok; identitas pengguna wajib; stok tidak boleh negatif; jumlah harus > 0 dan punya asal/tujuan; kartu stok tidak bisa di-UPDATE/DELETE; batch tidak bisa dihapus; batch unik per (obat, nomor, ED); FEFO terurut; serta pencabutan hak `ams_app` atas kartu stok.

## Masalah diketahui

- `prisma migrate diff`/`deploy` masih menunggu akses `binaries.prisma.sh` (diblokir kebijakan jaringan sesi pengembangan). Migrasi diuji dengan `psql` dan diverifikasi kolomnya lewat `npm run db:drift`.
- Stok opname menghitung selisih dari stok terkini saat diposting (bukan dari snapshot), sehingga hasil akhir selalu sama dengan hitung fisik meski ada transaksi selama penghitungan. Bucket yang diopname sementara dibatasi ke "siap jual"; opname karantina/rusak menyusul bila diperlukan.
- Pemusnahan (berita acara) dan penarikan (recall) formal dijadwalkan menyusul; perpindahan ke bucket rusak dan penandaan recall pada batch sudah tersedia sebagai dasarnya.

## Sisa pekerjaan

Tidak ada untuk Fase 4 selain pemeriksaan `prisma migrate diff` di lingkungan ber-internet. Fase berikutnya: Fase 5 (pengadaan — Surat Pesanan, penerimaan barang yang membuat batch, retur pembelian).
