# Laporan Fase 5 — Pengadaan (Surat Pesanan, Penerimaan Barang, Retur Pembelian)

Tanggal: 13 November 2026 · Status: **selesai**, dengan pemeriksaan tertunda yang sama seperti fase sebelumnya (`prisma migrate diff`, lihat Masalah diketahui)

## Lingkup

Alur pembelian ke pemasok yang menjadi sumber stok masuk setelah saldo awal: **Surat Pesanan (SP)** ke pemasok, **Penerimaan Barang** yang memeriksa dan memposting barang datang (membentuk batch baru dan menambah kartu stok), serta **Retur Pembelian** untuk mengembalikan barang ke pemasok. Faktur pembelian dan pembayaran ke pemasok (utang dagang) **belum** termasuk fase ini — menyusul di fase keuangan/AP berikutnya.

## Konsep inti

- **SP reguler** dibuat dan dikirim oleh apoteker/pemilik (atau gudang/TTK untuk draf); **SP khusus** (narkotika, psikotropika, prekursor, OOT) wajib dibuat **dan** ditandatangani oleh apoteker sendiri (Kepmenkes 347/1990), lewat izin `procurement.po_special.sign` yang menggantikan izin create/approve biasa untuk keempat jenis ini.
- **Penerimaan barang** memakai maker-checker seperti penyesuaian/opname di Fase 4: siapa yang mencatat draf (memeriksa fisik barang) tidak boleh memposting draf yang sama; posting membentuk `MedicineBatch` baru per baris (kecuali kondisi "Ditolak") dan menulis kartu stok (`RECEIPT`) lewat fungsi `ams_apply_stock_movement` yang sama dari Fase 4 — fungsi itu tidak diubah karena jenis pergerakan hanya disimpan untuk klasifikasi, tidak memengaruhi logikanya.
- **Retur pembelian** juga maker-checker: pembuat draf tidak boleh menyetujui draf retur miliknya sendiri; persetujuan membuat baris `Approval` dan memposting pergerakan `PURCHASE_RETURN` yang mengurangi bucket asal batch.
- **Konversi satuan**: SP dan penerimaan boleh memakai satuan beli apa pun (mis. BOX) tanpa terikat ke "satuan beli default" obat; faktor konversi ke satuan dasar dicari langsung dari `MedicineUnitConversion` saat posting.
- **Status SP otomatis**: setelah posting penerimaan, SP berubah ke **Diterima sebagian** atau **Diterima penuh** berdasarkan total jumlah yang sudah diterima vs dipesan per baris; tidak ada aksi manual untuk ini.
- Penomoran dokumen memakai fungsi `ams_next_number` yang sama dari fase sebelumnya dengan prefiks baru: `SP-YYMM-####`, `GR-YYMM-####`, `RB-YYMM-####`.

## Fitur

- **Surat Pesanan**: buat draf (pemasok, jenis SP, baris obat/satuan/jumlah/harga/diskon) → kirim ke pemasok → (opsional) batalkan. Halaman detail menampilkan baris pesanan, jumlah diterima per baris, dan daftar penerimaan terkait.
- **Penerimaan Barang**: pilih SP yang sudah terkirim → isi jumlah diterima, no. batch, tanggal ED, HPP per satuan dasar, dan kondisi (baik/rusak/ditolak) per baris sebagai draf → pemeriksa lain memposting (membentuk batch + kartu stok) atau membatalkan draf.
- **Retur Pembelian**: pilih pemasok → pilih batch yang berasal dari penerimaan pemasok itu dan masih punya stok → isi bucket asal, jumlah, dan alasan (wajib) sebagai draf → penyetuju lain menyetujui (mengurangi stok) atau membatalkan draf.
- Hub `/pengadaan` menampilkan ringkasan jumlah dokumen per jenis sebagai titik masuk ke ketiga alur.
- Semua izin pengadaan (`procurement.*`) sudah disiapkan sejak perencanaan Fase 1 — tidak ada perubahan katalog izin atau matriks peran di fase ini.

## Perubahan database

Migrasi `20261113000000_phase5_procurement`: 6 tabel baru (purchase_orders, purchase_order_items, goods_receipts, goods_receipt_items, purchase_returns, purchase_return_items), 4 enum baru (PurchaseOrderType, PurchaseOrderStatus, GoodsReceiptStatus, ReceiptCondition), 2 nilai baru pada enum `MovementType` (RECEIPT, PURCHASE_RETURN), kolom `goods_receipt_item_id` (unik, nullable) pada `medicine_batches` untuk menautkan batch ke baris penerimaan yang membuatnya, serta foreign key dan CHECK constraint terkait (jumlah > 0, diskon 0–100%, alasan retur wajib diisi). Tidak ada tabel append-only baru — dokumen pengadaan boleh diubah statusnya oleh aplikasi (bukan ledger); hanya `stock_movements` yang tetap append-only dari Fase 4.

## Versi

Next.js 16.4.6 · React 19.3.1 · Prisma 7.10.1 + `@prisma/adapter-pg` · PostgreSQL 16 · TypeScript 6.0.3 · Zod 4.6 · Tailwind 4.3.5 · Vitest 5.1 · Playwright 1.63.

## Perintah

```bash
npm run lint && npm run typecheck && npm test   # lint, tipe, tes unit + integrasi
npm run test:db                                  # tes database (PostgreSQL asli)
npm run test:e2e:reset && npm run test:e2e        # E2E (database tes dibuat ulang)
npm run build
```

## Hasil uji (13 Nov 2026)

| Uji | Hasil |
| --- | --- |
| ESLint | 0 masalah |
| TypeScript seluruh proyek | 0 error |
| Vitest (11 file, unit + integrasi) | 137 lulus |
| Database (5 file SQL + hak akses + konkurensi paralel) | semua lulus (`SEMUA UJI DATABASE LULUS`) |
| Playwright E2E `procurement.spec.ts`, Chrome desktop | 3 lulus |
| Playwright E2E `procurement.spec.ts`, ponsel (Pixel 7) | 3 lulus |
| Playwright E2E fase 2–4 (`auth`, `master-data`, `inventory`) | 14 lulus, tanpa regresi |
| `next build` | Berhasil (37 rute + proxy, 9 rute baru di bawah `/pengadaan`) |
| Kolom skema Prisma vs database hasil migrasi | cocok (`model 35 masalah 0`) |
| `prisma migrate diff` | **Tertunda** (lihat Masalah diketahui) |

Cakupan E2E Fase 5 (`procurement.spec.ts`): SP dibuat sebagai draf lalu dikirim ke pemasok; penerimaan — pencatat draf tidak bisa memposting sendiri, apoteker lain memposting dan batch baru muncul di kartu stok, SP otomatis berstatus "Diterima penuh"; retur — pembuat draf tidak bisa menyetujui sendiri, apoteker lain menyetujui dan stok berkurang sesuai jumlah retur.

Cakupan uji integrasi Fase 5 (vitest, `tests/integration/services/procurement.test.ts`, 11 kasus): SP dibuat gudang → dikirim apoteker → status SENT; SP khusus narkotika wajib `po_special.sign` (gudang ditolak); kasir tidak boleh membuat SP; SP tanpa baris ditolak; SP draf/terkirim bisa dibatalkan; penerimaan penuh dengan konversi BOX→TAB membentuk batch baru, kartu stok RECEIPT, dan SP berstatus RECEIVED; penerimaan sebagian → SP berstatus PARTIAL, baris berkondisi "Ditolak" tidak membentuk batch; penerimaan hanya untuk SP yang sudah terkirim (bukan draf); retur draf tidak bisa disetujui pembuat sendiri, apoteker lain memposting mengurangi stok saleable; retur melebihi stok batch ditolak dengan pesan ramah; retur tanpa alasan ditolak di tingkat input.

### Catatan metode verifikasi E2E

`procurement.spec.ts` memakai akun uji dengan nama pengguna tetap (`owner.test`, `apt.e2e.proc`) sama seperti pola di fase-fase sebelumnya. Karena kedua proyek Playwright (`desktop-chrome` dan `mobile`) memakai basis data E2E yang sama, menjalankan kedua proyek dalam satu perintah `playwright test` akan bentrok nama pengguna/SP pada proyek kedua. Verifikasi dilakukan dengan `npm run test:e2e:reset` di antara proyek (`--project=desktop-chrome` lalu reset lalu `--project=mobile`), sama seperti metode yang berhasil untuk `inventory.spec.ts` pada Fase 4. Ditemukan juga bahwa menjalankan keempat berkas spesifikasi (fase 2–5) berurutan dalam satu proses server yang sama bisa memicu pembatas laju login bawaan aplikasi (maksimum 5 percobaan login per pengguna per 60 detik, Fase 2) karena akun `owner.test` login berulang kali di tiap berkas; ini perilaku keamanan yang disengaja, bukan cacat — fase 2–4 tetap lulus penuh (14/14) sebelum pembatas itu tersentuh.

## Uji database Fase 5 (SQL asli)

Jumlah baris SP/penerimaan/retur harus > 0; diskon SP 0–100%; nomor dokumen (SP/GR/RB) unik; status awal SP = DRAFT; `MovementType` punya nilai RECEIPT; penerimaan RECEIPT menambah stok saleable batch baru dan menulis satu baris kartu stok; satu baris penerimaan hanya bisa tertaut ke satu batch (`goods_receipt_item_id` unik); retur tanpa jumlah/alasan ditolak; retur PURCHASE_RETURN mengurangi stok saleable dan pergerakannya tertaut ke `Approval`; retur melebihi stok ditolak (`AMS_STOCK_NEGATIVE`); menyetujui retur sendiri ditolak (`approvals_not_self_chk`); pemasok yang sudah dipakai SP/GR/retur tetap tidak bisa dihapus (trigger append-only Fase 3); SP yang sudah punya baris/penerimaan tidak bisa dihapus (FK RESTRICT).

## Masalah diketahui

- `prisma migrate diff`/`deploy` masih menunggu akses `binaries.prisma.sh` (diblokir kebijakan jaringan sesi pengembangan) — sama seperti fase-fase sebelumnya. Migrasi diuji dengan `psql` dan diverifikasi kolomnya lewat pemeriksa drift kustom.
- Faktur pembelian (`PurchaseInvoice`) dan pembayaran ke pemasok (`SupplierPayment`) belum ada; retur pembelian saat ini tidak membuat catatan piutang/pengurang utang karena utang dagang belum dimodelkan. Menyusul di fase keuangan/AP.
- Tidak ada maker-checker untuk pengiriman SP (create dan approve/sign SP boleh dilakukan orang yang sama bila ia punya kedua izin, mis. Owner) — sesuai keputusan bahwa pemisahan peran lewat katalog izin sudah cukup dan, untuk SP khusus, apoteker memang diwajibkan menandatangani sendiri secara regulasi.

## Sisa pekerjaan

Tidak ada untuk Fase 5 selain pemeriksaan `prisma migrate diff` di lingkungan ber-internet. Fase berikutnya: Fase 6 (kemungkinan penjualan/kasir atau faktur pembelian & utang dagang — menunggu keputusan urutan dari pemilik/apoteker).
