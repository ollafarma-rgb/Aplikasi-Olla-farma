# Laporan Fase 3 — Master Data Obat, Pemasok, dan Pengguna

Tanggal: 12 November 2026 · Status: **selesai**, dengan satu pemeriksaan tertunda (`prisma migrate diff`, lihat Masalah diketahui)

## Lingkup

Data master yang menjadi fondasi semua transaksi berikutnya: katalog obat dengan satuan berjenjang dan barcode, data referensi (kategori, satuan, pabrik, lokasi penyimpanan), pemasok (PBF), serta manajemen karyawan dan akun pengguna.

## Fitur

- **Obat / produk**: tambah, ubah, aktif/nonaktif (tidak bisa dihapus), pencarian toleran salah ketik (nama, generik, merek, SKU, barcode), filter golongan dan status, SKU otomatis (`OBT-000001`).
- **Satuan berjenjang**: konversi satuan (mis. 1 BOX = 100 TAB) dengan barcode dan harga jual per satuan opsional; stok selalu dihitung dalam satuan dasar.
- **Barcode unik lintas entitas**: satu barcode tidak bisa dipakai dua obat atau dua satuan sekaligus (dijaga trigger database, bukan hanya aplikasi).
- **Aturan regulasi di form dan database**: golongan harus cocok dengan jenis produk; narkotika/psikotropika wajib resep; obat keras wajib resep kecuali ditandai OWA; NIE wajib untuk obat. Golongan berisiko tinggi (narkotika, psikotropika, prekursor, OOT) hanya bisa dibuat/diubah pemegang izin regulasi.
- **Harga dengan jejak**: setiap perubahan harga jual wajib menyertakan alasan dan tercatat di riwayat harga yang append-only. TTK tanpa izin harga membuat obat dalam status nonaktif berharga 0 untuk ditinjau apoteker.
- **Referensi**: kategori, satuan, pabrik, lokasi penyimpanan — tambah/ubah/aktif-nonaktif; referensi yang sedang dipakai tidak bisa dihapus (dijaga foreign key).
- **Pemasok (PBF)**: tambah, ubah, aktif/nonaktif/blokir (tidak bisa dihapus), kode otomatis (`PBF-0001`), termin pembayaran.
- **Karyawan & pengguna**: buat akun (sandi sementara sekali tampil, wajib ganti saat login pertama), ubah profil dan peran, aktif/nonaktif (memutus semua sesi), reset sandi, buka kunci akun, kelola izin praktik (STR/SIPA/SIPTTK). Perubahan peran menaikkan `session_version` sehingga karyawan harus login ulang. Akun Owner dilindungi dari penonaktifan/penurunan peran yang berbahaya.

## Keputusan yang dipakai

Konsisten dengan keputusan Fase 2: penyerahan OWA oleh TTK diterapkan sebagai aturan yang bisa dikonfigurasi dan ditandai perlu verifikasi APJ; penyetuju dokumen Pemilik dan Apoteker; HPP biaya aktual per batch (dipakai mulai Fase 4). Buka-kunci akun oleh Owner — yang di Fase 2 ditandai sebagai sisa pekerjaan — selesai di fase ini.

## Perubahan database

Migrasi `20261112020000_phase3_master_data`: 8 tabel (kategori, satuan, pabrik, lokasi penyimpanan, obat, konversi satuan obat, riwayat harga obat, pemasok), 4 enum, 15 indeks (termasuk GIN pg_trgm untuk pencarian), 11 foreign key, 17 CHECK constraint regulasi/konsistensi, 5 fungsi dan 8 trigger (barcode unik lintas entitas, konversi bukan satuan dasar, riwayat harga otomatis dari `ams.user_id`, append-only dan larangan hapus untuk obat/pemasok/riwayat harga). Hak `ams_app` dicabut untuk UPDATE/DELETE pada `medicine_price_history`.

## Versi

Next.js 16.4.6 · React 19.3.1 · Prisma 7.10.1 + `@prisma/adapter-pg` · PostgreSQL 16 · TypeScript 6.0.3 · Zod 4.6 · Tailwind 4.3.5 · Vitest 5.1 · Playwright 1.63.

## Perintah

```bash
npm run lint && npm run typecheck && npm test   # lint, tipe, tes unit + integrasi
npm run test:db                                  # tes database (PostgreSQL asli)
npm run test:e2e:reset && npm run test:e2e        # E2E (database tes dibuat ulang)
npm run build
```

## Hasil uji (12 Nov 2026)

| Uji | Hasil |
| --- | --- |
| ESLint | 0 masalah |
| TypeScript seluruh proyek | 0 error |
| Vitest (9 file, unit + integrasi) | 116 lulus |
| Database (3 file SQL + konkurensi paralel) | 81 pemeriksaan lulus |
| Playwright E2E, Chrome desktop | 10 lulus |
| Playwright E2E, ponsel (Pixel 7) | 10 lulus |
| `next build` | Berhasil (16 rute + proxy) |
| Kolom skema Prisma vs database hasil migrasi | cocok (`npm run db:drift` kosong) |
| `prisma migrate diff` | **Tertunda** |

Cakupan E2E Fase 3: owner membuat obat dengan harga awal; barcode ganda ditolak; pencarian berdasarkan nama generik; tambah konversi satuan dan perubahan harga tercatat di riwayat; owner membuat kasir, kasir login (wajib ganti sandi), melihat menu terbatas, dan ditolak saat membuka halaman karyawan.

## Bug yang ditemukan uji dan diperbaiki

1. **Pencarian error di produksi**: form pencarian mengirim `golongan=` (string kosong) yang ditolak enum filter dan memicu error server. Skema filter obat dan pemasok kini memperlakukan nilai kosong dari form sebagai "tidak difilter" (ditambah uji regresi unit).
2. Selektor E2E: label satuan (dasar/beli/jual/konversi) saling tumpang tindih sebagai substring; diperbaiki dengan pencocokan label persis dan selektor sel tabel.

## Masalah diketahui

- `prisma migrate diff` dan `prisma migrate deploy` masih menunggu akses `binaries.prisma.sh` (diblokir kebijakan jaringan sesi pengembangan). Migrasi diuji dengan `psql` dan diverifikasi kolomnya lewat `npm run db:drift`. Di CI/hosting: jalankan `db:drift` (harus kosong) sebelum `prisma migrate deploy` pertama.
- Aturan regulasi di seed (termasuk penyerahan OWA oleh TTK) tetap bertanda "PERLU VERIFIKASI APJ".

## Sisa pekerjaan

Tidak ada untuk Fase 3 selain pemeriksaan `prisma migrate diff` di lingkungan yang bisa mengunduh schema engine. Fase berikutnya: Fase 4 (persediaan — batch, kedaluwarsa, kartu stok, HPP per batch).
