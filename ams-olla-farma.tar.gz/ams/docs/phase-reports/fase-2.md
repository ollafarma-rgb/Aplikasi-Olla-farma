# Laporan Fase 2 — Fondasi Proyek

Tanggal: 12 November 2026 · Status: **selesai**, dengan satu pemeriksaan tertunda (`prisma migrate diff`, lihat Masalah diketahui)

## Keputusan yang dipakai

| # | Keputusan | Penerapan |
| --- | --- | --- |
| 1 | Untuk Apotek OLLA FARMA | Profil apotek di seed |
| 2 | Region Aceh | Belum ada region cloud di Aceh; usulan Jakarta, final di Fase 11 |
| 3 | HPP biaya aktual per batch | Dipakai mulai Fase 4 |
| 4 | Non-PKP | Pengaturan `tax`; PPN pembelian masuk harga pokok |
| 5 | Diskon per periode, keputusan manajemen | Izin `pricing.discount_rules.manage` (Pemilik, Apoteker); diskon manual dimatikan |
| 6 | OWA boleh diserahkan TTK | Izin OWA untuk TTK; aturan `OWA_HANDOVER` bisa diubah; perlu tinjauan APJ (Kepmenkes 347/1990 menyebut Apoteker) |
| 8 | Piutang | Plafon kredit per pelanggan, default 0 |
| 9 | Printer thermal | 80 mm, template 58 mm |
| 10 | Penyetuju dokumen | Pemilik dan Apoteker |

Keputusan teknis: ADR-011 s.d. ADR-020 di `docs/adr/README.md`.

## Fitur

- Login username + sandi, kunci akun 5× gagal (15 menit), rate limit login, sesi 12 jam / idle 30 menit, logout, logout paksa, wajib ganti sandi awal.
- RBAC: 60 izin, 5 peran bawaan, pemeriksaan izin di server.
- Layout aplikasi: sidebar (desktop), menu (ponsel), top bar, banner koneksi terputus; menu modul yang belum dibangun tidak ditampilkan.
- Audit log append-only dengan rantai hash SHA-256 dan fungsi verifikasi pemalsuan.
- Penomoran dokumen atomik, idempotensi (tabel), persetujuan (tidak bisa menyetujui sendiri).
- Header keamanan + CSP bernonce, cookie `__Host-` Secure HttpOnly SameSite=Lax.
- Health check `/api/v1/health`.

## Perubahan database

Migrasi `20261112000000_phase2_identity_foundation`: 15 tabel, 2 enum, 17 indeks, 13 foreign key (RESTRICT), 12 CHECK constraint, 7 fungsi SQL, 4 trigger. Pengguna DB aplikasi `ams_app` tanpa DDL dan tanpa UPDATE/DELETE audit (`infra/db/app-role.sql`).

## Versi

Next.js 16.4.6 · React 19.3.1 · Prisma 7.10.1 + `@prisma/adapter-pg` · PostgreSQL 16 · TypeScript 6.0.3 · Zod 4.6 · Tailwind 4.3.5 · Vitest 5.1 · Playwright 1.63.

## Perintah

```bash
npm run lint && npm run typecheck && npm test   # lint, tipe, tes unit
npm run test:db                                  # tes database (PostgreSQL asli)
npm run test:e2e:reset && npm run test:e2e        # E2E (database tes dibuat ulang)
npm run build
```

## Hasil uji (12 Nov 2026)

| Uji | Hasil |
| --- | --- |
| ESLint | 0 masalah |
| TypeScript seluruh proyek | 0 error |
| Vitest (6 file) | 74 lulus |
| Database (2 file SQL + konkurensi paralel) | 51 pemeriksaan lulus |
| Playwright E2E, Chrome desktop | 5 lulus |
| Playwright E2E, ponsel (Pixel 7) | 5 lulus |
| `next build` | Berhasil (7 rute + proxy) |
| Kolom skema Prisma vs database hasil migrasi | 15/15 tabel cocok |
| `prisma migrate diff` | **Tertunda** |

## Bug yang ditemukan uji dan diperbaiki

1. Rantai hash audit rusak saat ditulis paralel.
2. Penghapusan cookie `__Host-` tanpa Secure akan ditolak browser.
3. IP klien dari X-Forwarded-For bisa dipalsukan untuk mengakali rate limit.
4. Skrip uji: selektor E2E bentrok dengan elemen pengumuman rute Next.js; skrip reset database salah membentuk URL.

## Masalah diketahui

- `prisma migrate diff` dan `prisma migrate deploy` membutuhkan biner schema engine dari `binaries.prisma.sh`, yang diblokir kebijakan jaringan sesi pengembangan ini. Migrasi diuji dengan `psql`; tabel `_prisma_migrations` belum ada di database lokal. Di CI/hosting yang punya akses internet: jalankan `npm run db:drift` (harus kosong) sebelum `prisma migrate deploy` pertama.
- Kunci akun bisa disalahgunakan untuk mengunci akun orang lain selama 15 menit; buka kunci oleh Owner dibangun di Fase 3.
- Penulisan audit diserialkan sampai commit; diukur di uji beban Fase 10.
- Aturan regulasi di seed bertanda "PERLU VERIFIKASI APJ", termasuk penyerahan OWA oleh TTK.

## Sisa pekerjaan

Tidak ada untuk Fase 2 selain pemeriksaan `prisma migrate diff` di lingkungan yang bisa mengunduh schema engine. Fase berikutnya: Fase 3 (master data obat, kategori, satuan, barcode, pemasok, karyawan dan pengguna).
