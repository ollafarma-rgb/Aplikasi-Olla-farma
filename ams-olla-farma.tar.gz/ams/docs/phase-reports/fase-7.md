# Laporan Fase 7 — Aturan Diskon & Piutang Pelanggan

**Tanggal selesai:** 2026-11-14  
**Status:** ✅ SELESAI

---

## Ringkasan

Fase 7 mengimplementasikan dua modul keuangan penting: sistem aturan diskon dengan pola
maker-checker, dan manajemen piutang pelanggan lengkap dengan laporan aging.

---

## Fitur yang Diimplementasikan

### 1. Aturan Diskon (`/harga/aturan-diskon`)

- **Model Prisma:** `DiscountRule`, `DiscountScope` enum, `DiscountRuleStatus` enum
- **Status flow:** DRAFT → APPROVED / REJECTED / CANCELLED
- **Maker-checker:** pencipta tidak dapat menyetujui aturannya sendiri
- **Tipe diskon:** PERCENT (persentase) dan AMOUNT (nominal tetap)
- **Scope:** ALL, CATEGORY, MEDICINE
- **Server Actions:** `createDiscountRule`, `approveDiscountRule`, `rejectDiscountRule`, `cancelDiscountRule`
- **Permissions:** `discount.view`, `discount.create`, `discount.approve`
- **UI halaman:**
  - `/harga/aturan-diskon` — daftar dengan filter status/scope
  - `/harga/aturan-diskon/baru` — form buat aturan (apoteker)
  - `/harga/aturan-diskon/[id]` — detail + tombol aksi approval (owner)

### 2. Piutang Pelanggan (`/keuangan/piutang`)

- **Model Prisma:** `Receivable`, `ReceivablePayment`
- **Status flow:** OPEN → PARTIAL → PAID / WRITTEN_OFF
- **Integrasi penjualan:** Sale dengan `payment_method = RECEIVABLE` otomatis membuat Receivable
- **Server Actions:** `recordReceivablePayment`, `writeOffReceivable`
- **Permissions:** `finance.receivable.view`, `finance.receivable.manage`
- **UI halaman:**
  - `/keuangan/piutang` — daftar piutang dengan filter status/pelanggan
  - `/keuangan/piutang/[id]` — detail + riwayat pembayaran + form catat bayar
  - `/keuangan/piutang/aging` — laporan aging 4 bucket (0-30, 31-60, 61-90, >90 hari)

---

## Kendala Teknis & Solusi

### `prisma generate` Diblokir (Network 403)

File `src/generated/prisma/internal/class.ts` tidak dapat di-regenerate karena proxy
memblokir koneksi ke registry npm. Solusi: edit manual dengan Python script byte-level
untuk menyisipkan `DiscountRuleStatus` enum di 4 tempat:

1. Definisi enum di `inlineSchema`
2. Tipe field `status` di model `DiscountRule` di `inlineSchema`
3. Tipe field di `runtimeDataModel` JSON
4. Entri enum di objek `enums` di `runtimeDataModel`

### UUID Validation Prisma (P2007)

String seperti `'non-existent-id'` bukan UUID valid — Prisma membuang P2007 sebelum
query ke DB. Test integration harus menggunakan UUID valid yang tidak ada di DB:
`'00000000-0000-7000-8000-000000000001'`.

### Unique Constraint `sale_sessions_cashier_open_unique_idx`

Hanya 1 sesi kasir OPEN per kasir diizinkan. Test integration piutang perlu membuat
SaleSession sekali di `beforeAll` dan memakai ulang `sessionId`.

### Field Sale yang Salah Nama

Model Sale menggunakan `amount_paid` (bukan `paid_amount`) dan `change_given` (bukan
`change_amount`). Juga wajib menyertakan `session_id` FK ke SaleSession.

### CHECK Constraint `customer_credit_used_chk`

`credit_used >= 0` selalu divalidasi. Test harus menginisialisasi pelanggan dengan
`credit_used` yang cukup besar agar pembayaran tidak menjadikannya negatif.

---

## Hasil Pengujian

| Suite | Jumlah Test | Hasil |
|-------|------------|-------|
| `tests/integration/services/discounts.test.ts` | 16 | ✅ 16/16 PASS |
| `tests/integration/services/receivables.test.ts` | 16 | ✅ 16/16 PASS |
| `tests/e2e/discounts-receivables.spec.ts` | ~11 skenario | Ditulis (Playwright) |

**Total integrasi Fase 7:** 32/32 test lulus ✅

---

## File yang Dibuat / Diubah

### Baru
```
src/app/(app)/harga/aturan-diskon/page.tsx
src/app/(app)/harga/aturan-diskon/baru/page.tsx
src/app/(app)/harga/aturan-diskon/[id]/page.tsx
src/app/(app)/keuangan/piutang/page.tsx
src/app/(app)/keuangan/piutang/[id]/page.tsx
src/app/(app)/keuangan/piutang/aging/page.tsx
src/lib/services/discounts.ts
src/lib/services/receivables.ts
src/lib/actions/discounts.ts
src/lib/actions/receivables.ts
tests/integration/services/discounts.test.ts
tests/integration/services/receivables.test.ts
tests/e2e/discounts-receivables.spec.ts
```

### Diubah
```
src/generated/prisma/internal/class.ts   — tambah DiscountRuleStatus (manual)
prisma/schema.prisma                      — model DiscountRule, Receivable, ReceivablePayment
src/lib/audit/types.ts                    — tambah action codes diskon & piutang
src/lib/permissions.ts                    — tambah permission codes baru
```

---

## Status Fase Keseluruhan

| Fase | Deskripsi | Status |
|------|-----------|--------|
| 1 | Setup & Auth | ✅ |
| 2 | Manajemen SDM | ✅ |
| 3 | Manajemen Obat | ✅ |
| 4 | Pengadaan | ✅ |
| 5 | Penjualan & Kasir | ✅ |
| 6 | Inventori & HPP | ✅ (26 error pre-existing, tidak disentuh) |
| 7 | Diskon & Piutang | ✅ |

---

## Catatan untuk Fase Berikutnya

- **Error Fase 6** (26 TypeScript errors) belum diperbaiki — scope di luar Fase 7.
- `prisma generate` masih diblokir; setiap tambahan model/enum memerlukan edit manual class.ts.
- Pola UUID test (`'00000000-0000-7000-8000-00000000000X'`) sudah jadi konvensi.
