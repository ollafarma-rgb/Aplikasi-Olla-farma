# Architecture Decision Records (ADR)

Keputusan K1–K10 dicatat di dokumen Fase 1. Berkas ini mencatat keputusan lanjutan dan perubahan.

| No | Tanggal | Keputusan | Status |
| --- | --- | --- | --- |
| ADR-011 | 2026-11-12 | Autentikasi sesi buatan sendiri (bukan Auth.js) | Diterima |
| ADR-012 | 2026-11-12 | Hash sandi scrypt bawaan Node.js (bukan Argon2id) | Diterima |
| ADR-013 | 2026-11-12 | Rantai hash audit dihitung trigger database | Diterima |
| ADR-014 | 2026-11-12 | Prisma ORM 7 + driver adapter `pg` | Diterima |
| ADR-015 | 2026-11-12 | Status pajak Non-PKP: PPN pembelian masuk harga pokok | Diterima (keputusan Owner) |
| ADR-016 | 2026-11-12 | Hosting region Jakarta (tidak ada region cloud di Aceh) | Usulan, final di Fase 11 |
| ADR-017 | 2026-11-12 | Diskon hanya lewat aturan periode yang disetujui manajemen | Diterima (keputusan #5) |
| ADR-018 | 2026-11-12 | OWA boleh diserahkan Apoteker dan TTK, sebagai aturan yang bisa diubah | Diterima (keputusan #6), perlu tinjauan APJ |
| ADR-019 | 2026-11-12 | Piutang pelanggan dengan plafon kredit per pelanggan | Diterima (keputusan #8) |
| ADR-020 | 2026-11-12 | Struk thermal 80 mm, template 58 mm tersedia | Diterima (keputusan #9) |

## ADR-011 — Autentikasi sesi buatan sendiri

**Konteks.** Instruksi master meminta Auth.js "atau solusi setara". Sejak September 2025 Auth.js dipelihara tim Better Auth dan proyek baru dianjurkan memakai Better Auth. AMS hanya butuh login username + sandi, sesi yang bisa dicabut seketika (logout paksa, akun dinonaktifkan), dan audit lengkap.

**Keputusan.** Modul sesi kecil di `src/lib/auth` + `src/modules/authentication`: token acak 256-bit di cookie HttpOnly, database hanya menyimpan SHA-256 token (`user_sessions`), batas 12 jam absolut dan 30 menit idle, logout paksa lewat `users.session_version`.

**Alasan.** Tanpa dependensi tambahan dan tabel bawaan library; setiap aturan teruji unit (67 tes) dan database. Better Auth tetap opsi bila kelak dibutuhkan OAuth/SSO.

**Konsekuensi.** Tim memikul tanggung jawab kode keamanan ini; wajib ditinjau ulang di uji keamanan Fase 10.

## ADR-012 — scrypt bawaan Node.js

**Keputusan.** `crypto.scrypt` dengan N=2^15, r=8, p=3 (salah satu konfigurasi minimum OWASP), parameter disimpan di string hash dan hash otomatis diperbarui saat login bila parameter naik.

**Alasan.** Argon2id butuh paket native yang rentan gagal build di hosting serverless; scrypt setara secara keamanan untuk kebutuhan ini dan tanpa dependensi.

## ADR-013 — Rantai hash audit di trigger database

**Keputusan.** `prev_hash` dan `hash` (SHA-256) diisi trigger `ams_audit_chain`, diserialkan dengan advisory lock; `id` diambil ulang setelah kunci didapat. `ams_audit_verify_chain()` mendeteksi baris yang diubah.

**Alasan.** Aplikasi tidak bisa memalsukan rantai; uji paralel 4 sesi × 100 baris membuktikan rantai tetap utuh (versi pertama gagal di uji ini dan sudah diperbaiki).

**Konsekuensi.** Transaksi yang menulis audit diserialkan sampai commit. Untuk satu apotek (puluhan transaksi per jam) ini aman; dipantau di uji beban Fase 10.

## ADR-014 — Prisma ORM 7

Prisma 7 mewajibkan generator `prisma-client` dengan `output` eksplisit, `prisma.config.ts`, dan driver adapter (`@prisma/adapter-pg`). CHECK constraint, trigger, dan fungsi SQL ditulis manual di `migration.sql`. Setelah paket terpasang, `npm run db:drift` harus kosong.

## ADR-015 — Non-PKP

Apotek tidak memungut PPN penjualan. PPN di faktur pembelian tidak bisa dikreditkan, sehingga dimasukkan ke harga pokok batch (`purchase_vat_capitalized: true`). Diterapkan di Fase 5 (penerimaan) dan Fase 6 (struk tanpa PPN). Bila status berubah menjadi PKP, cukup ubah pengaturan `tax`; transaksi lama tidak diubah.

## ADR-016 — Region hosting

Owner meminta "regional Aceh". Belum ada penyedia cloud besar dengan pusat data di Aceh; region terdekat ada di Jakarta. Usulan: region Jakarta. Pilihan penyedia dan biaya diputuskan di Fase 11.

## ADR-017 — Diskon periode

Diskon ditetapkan manajemen (izin `pricing.discount_rules.manage`: Pemilik, Apoteker) sebagai aturan dengan cakupan (semua/kategori/obat), jenis (persen/nominal), dan periode berlaku. Aturan baru berstatus DRAFT dan aktif setelah disetujui pengguna lain. Kasir tidak bisa mengetik diskon bebas (`manual_discount_allowed: false`); setiap baris penjualan menyimpan `discount_rule_id` sehingga laporan diskon bisa ditelusuri. Tabel `discount_rules` dibangun di Fase 6.

## ADR-018 — Penyerahan OWA

Keputusan manajemen: Apoteker dan TTK boleh menyerahkan OWA. Kepmenkes 347/MENKES/SK/VII/1990 mendefinisikan OWA sebagai obat keras yang dapat diserahkan oleh Apoteker tanpa resep, sehingga keputusan ini disimpan sebagai aturan `OWA_HANDOVER` (bukan dikunci di kode) dan ditandai perlu tinjauan APJ. Mengubah `handover_roles` menjadi `["APOTEKER"]` cukup lewat pengaturan. Setiap penyerahan OWA mencatat pasien, obat, jumlah, dan petugas.

## ADR-019 — Piutang

Metode bayar `PIUTANG` membuat satu baris `customer_receivables` per penjualan. Penjualan tempo ditolak bila pelanggan tidak terdaftar, plafon 0, atau saldo + transaksi melebihi plafon. Pelunasan lewat `receivable_payments` dengan jurnal kas/bank. Dibangun di Fase 6 (penjualan tempo) dan Fase 8 (pelunasan, umur piutang).

## ADR-020 — Struk 80 mm

Lebar 80 mm memuat nama obat panjang, aturan pakai, dan nama apoteker tanpa terpotong. Template 58 mm disediakan untuk printer kecil. Dicetak lewat CSS print dari browser, tanpa driver khusus.
